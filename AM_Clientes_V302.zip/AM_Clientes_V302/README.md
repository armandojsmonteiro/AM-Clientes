# AM Clientes V302

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 302
- `versionName`: `1.0.302`

## Alterações desta versão

- Menus de seleção personalizados com fundo branco arredondado e destaque azul-claro na opção selecionada, mantendo as opções específicas de cada campo.
- Calendário com cantos arredondados, preservando o calendário branco e o destaque azul.
- Botão **Definir** no calendário para aplicar imediatamente a data de hoje; **OK** confirma a data escolhida e **Cancelar** fecha sem a aplicar.
- Ao tocar na data apresentada no cabeçalho do calendário, é possível escolher dia, mês e ano sequencialmente, sem navegar pelas setas mês a mês.
- Mantidos os restantes comportamentos e o estilo visual da versão anterior.

## Validação

O código-fonte foi atualizado. A compilação do APK ainda precisa de ser validada pelo workflow Android/Gradle.
