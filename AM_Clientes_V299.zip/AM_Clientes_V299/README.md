# AM Clientes V299

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 299
- `versionName`: `1.0.299`

## Alterações desta versão

- Mensagens de confirmação com cantos arredondados e botões Cancelar e Confirmar distribuídos lado a lado, com margens equilibradas.
- Avisos simples com o mesmo cartão visual arredondado e botão OK azul.
- Diálogos de Adicionar movimento e Associar equipamento com superfície arredondada e botões coerentes com o estilo da aplicação.
- Corrigido o arrastamento: a sombra acompanha apenas o puxador dos três traços, evitando que o cartão salte para a esquerda durante o gesto.
- Cancelar a edição de uma subscrição não guarda alterações, recolhe o formulário e regressa com animação ao cartão que abriu o editor.
- A ordem dos serviços e subscrições continua a ser guardada na empresa ativa.

## Validação

O código-fonte foi atualizado. A compilação APK não foi executada neste ambiente por não ter Gradle/Android SDK disponíveis.
