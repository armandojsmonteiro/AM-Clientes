AM Clientes V348 — Android nativo

V348 ajusta exclusivamente os submenus “Apresentação da aplicação” e “Empresas da aplicação” em Configurações para aproximar as dimensões da referência: pré-visualização do logótipo mais compacta, botões com altura reduzida e seletor de empresa com altura compacta. Os restantes menus e funcionalidades não foram alterados.

Projeto exclusivamente Android nativo. O workflow GitHub Actions compila o APK e publica o artefacto AM_Clientes_V348.apk.
