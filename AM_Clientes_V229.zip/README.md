AM Clientes V229 — based directly on V226; fixes Pack consumption accounting and page-wide touch scrolling.
