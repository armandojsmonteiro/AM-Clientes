# AM Clientes V309

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 309
- `versionName`: `1.0.309`

## Alterações desta versão

- Tipo de subscrição corrigido para duas opções de lógica: `Subscrição simples` ou `Pack`. O nome do pack continua a ser definido no campo Nome.
- Ao escolher `Pack`, aparece o seletor múltiplo `Subscrições incluídas no pack`, com as subscrições simples já registadas, realce azul-claro e visto por cada opção selecionada.
- As subscrições incluídas são guardadas como componentes estruturados, preservando o custo e a regra de compra da subscrição associada, incluindo o campo usado pelo cálculo de licenças consumidas.
- O cartão exterior de Subscrições passa a conter o formulário e todos os cartões individuais, à semelhança da secção Serviços.
- Contornos azuis mais visíveis no módulo Serviços e subscrições, sem alterar o tema global da aplicação.
- Preservadas as correções anteriores do calendário, menus, aviso e edição de serviços.

## Validação

A compilação Android/Gradle deve ser confirmada no workflow do GitHub Actions.
