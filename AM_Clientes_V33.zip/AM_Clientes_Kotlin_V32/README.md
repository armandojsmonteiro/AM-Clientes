# AM Clientes — V30

V16 é a continuação direta da V15.

## Alteração desta versão
- Menu lateral alinhado com a referência visual enviada.
- Todos os itens do menu passam a ter caixas individuais arredondadas com contorno.
- Início selecionado em azul principal.
- Ícones coloridos preservados.
- Tipografia compacta preservada para manter todos os itens visíveis.
- Seletor de empresa mantido em caixa própria.

## Estado funcional
A navegação inicial e o menu lateral estão implementados. As páginas Clientes, Subscrições, Catálogos, Arquivado, Histórico, Estatísticas, Configurações e Gestão ainda apresentam o ecrã-base da secção; a área completa de Configurações ainda não foi construída.


### V17
Primeiro ecrã do menu Clientes ajustado à referência. A navegação inicial e o menu lateral da V16 permanecem preservados.


### V24
V24 parte da V23 e altera exclusivamente o menu Clientes, reduzindo os botões Fechar/Abrir e Adicionar para 62dp de largura. O Início/Home permanece intocado.


### V30
Correção visual do menu Subscrições a partir da V29: os indicadores do contexto Clientes deixam de aparecer neste menu e o balão de Subscrições é ligeiramente ampliado verticalmente.
