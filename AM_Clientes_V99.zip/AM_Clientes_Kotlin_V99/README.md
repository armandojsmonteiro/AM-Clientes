# AM Clientes V99

V99 parte diretamente da V96, preservando a estabilidade do formulário de Clientes. A alteração desta versão é visual: todos os campos de seleção passam a apresentar o estado inicial de forma uniforme, a preto, com `— Selecionar —`. A lógica de abertura e edição de clientes não é alterada.
