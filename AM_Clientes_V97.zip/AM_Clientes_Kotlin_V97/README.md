# AM Clientes V97

V97 mantém a V96 como base e corrige a uniformização visual dos campos de seleção, dos placeholders de datas e do campo de escrita de mensagens em Configurações.
