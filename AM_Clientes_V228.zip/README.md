AM Clientes V228 — correção final do consumo de Packs, reordenação pelo ☷ e scroll por toque.

VersionCode: 228
VersionName: 1.0.228
