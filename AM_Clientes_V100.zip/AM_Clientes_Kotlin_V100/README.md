# AM Clientes V100

Base utilizada: V99.

Esta versão altera apenas os dois campos do formulário Novo cliente/Editar cliente identificados no teste: Nome Empresa e Data de criação. Ambos passam a apresentar `— Selecionar —` a preto e com o mesmo tamanho/alinhamento visual. A lógica de abertura, criação e edição de clientes não é alterada.
