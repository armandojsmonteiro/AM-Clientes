AM Clientes V270 — projeto Android nativo.

Estado consolidado da nova aplicação independente.
- Package / Application ID: com.aminovacao.amclientes231
- Aplicação 100% Android nativa; sem HTML/WebView como solução de interface.
- V230 é apenas a referência funcional da aplicação original; esta aplicação é independente.
- Arranque em estado vazio, sem dados de demonstração.
- O backup JSON externo continua a ser a fonte de dados para testes/importação.
- Interface trabalhada progressivamente, menu a menu, sem patches ou implementações concorrentes para o mesmo elemento.

Alteração V270:
- Partindo da V268, corrigido apenas o tamanho do botão Fechar Cliente no ecrã de cliente aberto: 72 x 40 dp.
- Nenhuma outra alteração visual ou funcional foi feita nesta versão.
