AM Clientes V253 — projeto Android nativo.

Base: V248.

Foco desta versão: menu lateral.
- Aumenta a tipografia dos itens principais para aproximar do original.
- Mantém um espaçamento maior entre ícone e texto no menu principal.
- Reforça os contornos dos botões do menu.
- O submenu de Empresas usa um bloco exterior escuro separado.
- Empresa 1 e Gerir empresas ficam dentro desse bloco.
- Empresa ativa permanece com seleção azul.
- Não altera a lógica funcional da aplicação.
