AM Clientes V219

Correção de build: configuração do Gradle endurecida para o GitHub Actions, sem cache de build e com execução limitada de workers para evitar falhas na fase mergeLibDexDebug.
