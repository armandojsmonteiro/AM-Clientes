AM Clientes V215

Correções: elimina o refresh periódico do seletor de Packs que fazia a lista entrar em loop; deduplica associações de subscrições espelhadas no mesmo equipamento para evitar consumos duplicados; mantém validade e regra 6 por 5; preserva o consumo de Packs nas subscrições originais.
