# AM Clientes V339

## Alterações da V339

- Equilibrado o espaçamento vertical do cabeçalho de Estatísticas quando os cartões de resumo estão recolhidos, removendo o espaço vazio que permanecia por baixo do título.
- Corrigido o cabeçalho de Gestão da base de dados: ícone separado do título multiline e botão Fechar com o mesmo tamanho e letra padrão dos restantes menus.
- Adicionados puxadores de arrastamento às secções de Estatísticas. A ordem é guardada nas preferências da aplicação e mantida ao sair e voltar a entrar no menu.
- Mantidas as funções de abrir/fechar dos cartões e as funções existentes de Estatísticas.

## Versão

- `versionCode`: 339
- `versionName`: `1.0.339`
- Aplicação Android nativa.
