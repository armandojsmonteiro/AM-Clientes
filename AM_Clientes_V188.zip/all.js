// V178 — afinações finais de Serviços, Subscrições e serviços adicionais do cliente.

/* V525 — FONTE ÚNICA para refresh + memória do menu. */
(function(){
  const KEY='amClientesRefreshView';
  window.__AM_V351_RELOAD_TARGET='inicio';
  window.__AM_V351_IS_RELOAD=false;
  let reload=false;
  try{
    const nav=performance.getEntriesByType('navigation')[0];
    reload=nav ? nav.type==='reload' : (performance.navigation && performance.navigation.type===1);
  }catch(e){}
  window.__AM_V351_IS_RELOAD=!!reload;
  let target='inicio';
  try{
    if(reload) target=sessionStorage.getItem(KEY)||'inicio';
    else sessionStorage.removeItem(KEY);
  }catch(e){}
  window.__AM_V351_RELOAD_TARGET=target;

  if(reload){
    const rules=[];
    if(target==='clientes'){
      rules.push('#clientes .layout{display:none !important;}');
      rules.push('#clientes #homeShortcuts{display:none !important;}');
      rules.push('#todosClientes{display:block !important;}');
    }else if(target==='config'){
      rules.push('#config{display:none !important;}');
      rules.push('#clientes{display:none !important;}');
    }else if(target!=='inicio'){
      rules.push('#clientes{display:none !important;}');
    }
    const panels={clientes:'#todosClientes',subscricoes:'#subscricoes',catalogos:'#catalogos',historico:'#historico',atividade:'#atividade',estatisticas:'#estatisticas',gestao:'#gestao'};
    const selector=panels[target];
    if(selector && target!=='config') rules.push(selector+'{display:block !important;}');
    if(rules.length){
      const style=document.createElement('style');
      style.id='v525-prepaint-style';
      style.textContent=rules.join('');
      document.head.appendChild(style);
    }
  }

  function bindMenuMemory(){
    const map={navInicio:'inicio',navClientes:'clientes',navSubscricoes:'subscricoes',navCatalogos:'catalogos',navArquivados:'historico',navHistorico:'atividade',navEstatisticas:'estatisticas',navConfig:'config',navGestao:'gestao'};
    Object.entries(map).forEach(([id,viewId])=>{
      const el=document.getElementById(id);
      if(!el || el.dataset.v525Memory==='1')return;
      el.dataset.v525Memory='1';
      el.addEventListener('click',function(){try{sessionStorage.setItem(KEY,viewId);}catch(e){}},true);
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bindMenuMemory,{once:true});else bindMenuMemory();
})();


let DATA=[{"ID Cliente":"CLI001","Nome":"Cliente 1","Nome Empresa":"Empresa 1","Contacto":"","Email":"","Morada":"","Serviço":"Serviço 1","Descrição Manutenção":"","Preço":0,"Periodicidade":"","Pagamento":"","Método Pagamento":"","Validade":"","Saldo":0,"VPN":"","Utilizador VPN":"","Password VPN":"","Equipamento":"Equipamento 1","Mac Adress":"","Utilizador":"","Senha":"","Link":"","Pacote":"","Tempo":"","Data Instalação":"","Estado Cliente":"","Observações":""},{"ID Cliente":"CLI002","Nome":"Cliente 2","Nome Empresa":"Empresa 1","Contacto":"","Email":"","Morada":"","Serviço":"Serviço 2","Descrição Manutenção":"","Preço":0,"Periodicidade":"","Pagamento":"","Método Pagamento":"","Validade":"","Saldo":0,"VPN":"","Utilizador VPN":"","Password VPN":"","Equipamento":"Equipamento 2","Mac Adress":"","Utilizador":"","Senha":"","Link":"","Pacote":"","Tempo":"","Data Instalação":"","Estado Cliente":"","Observações":""},{"ID Cliente":"CLI003","Nome":"Cliente 3","Nome Empresa":"Empresa 1","Contacto":"","Email":"","Morada":"","Serviço":"Serviço 3","Descrição Manutenção":"","Preço":0,"Periodicidade":"","Pagamento":"","Método Pagamento":"","Validade":"","Saldo":0,"VPN":"","Utilizador VPN":"","Password VPN":"","Equipamento":"Equipamento 3","Mac Adress":"","Utilizador":"","Senha":"","Link":"","Pacote":"","Tempo":"","Data Instalação":"","Estado Cliente":"","Observações":""},{"ID Cliente":"CLI004","Nome":"Cliente 4","Nome Empresa":"Empresa 1","Contacto":"","Email":"","Morada":"","Serviço":"Serviço 4","Descrição Manutenção":"","Preço":0,"Periodicidade":"","Pagamento":"","Método Pagamento":"","Validade":"","Saldo":0,"VPN":"","Utilizador VPN":"","Password VPN":"","Equipamento":"Equipamento 4","Mac Adress":"","Utilizador":"","Senha":"","Link":"","Pacote":"","Tempo":"","Data Instalação":"","Estado Cliente":"","Observações":""},{"ID Cliente":"CLI005","Nome":"Cliente 5","Nome Empresa":"Empresa 1","Contacto":"","Email":"","Morada":"","Serviço":"Serviço 5","Descrição Manutenção":"","Preço":0,"Periodicidade":"","Pagamento":"","Método Pagamento":"","Validade":"","Saldo":0,"VPN":"","Utilizador VPN":"","Password VPN":"","Equipamento":"Equipamento 5","Mac Adress":"","Utilizador":"","Senha":"","Link":"","Pacote":"","Tempo":"","Data Instalação":"","Estado Cliente":"","Observações":""}];
const INITIAL_DATA=structuredClone(DATA);
let ARCHIVED=[];
let ACTIVITY=[];
const names={};
let selected=null, currentTemplate='renewal';
let v150BaseServiceValue=0;
// V154: manter o valor do serviço principal sincronizado também em window,
// porque a rotina final de saldo/gravação usa window.v150BaseServiceValue.
// Sem esta ponte, o valor aparecia no formulário mas era tratado como 0 no saldo
// e era gravado como 0, desaparecendo ao reabrir o cliente.
Object.defineProperty(window, 'v150BaseServiceValue', {
  configurable: true,
  get(){ return v150BaseServiceValue; },
  set(value){ v150BaseServiceValue = Number(value)||0; }
});
const defaults={
renewal:`[AGORA]

A validade do serviço [SERVIÇO] em nome de [CLIENTE] termina em [DATA].

Espero que tenha gostado do nosso serviço de manutenção e que queira continuar nosso cliente.

Caso queira continuar, por favor contacte-nos.

Obrigado.`,
expired:`[AGORA]

O serviço [SERVIÇO] em nome de [CLIENTE] encontra-se expirado desde [DATA].

Caso pretenda renovar, por favor contacte-nos.

Obrigado.`,
payment:`[AGORA]

Relativamente ao serviço [SERVIÇO] em nome de [CLIENTE], ficou registado um saldo de [SALDO]€.

Obrigado.`,
maintenance:`[AGORA]

Informamos que a manutenção do serviço [SERVIÇO] em nome de [CLIENTE] está agendada.

Obrigado.`,
custom:``
};
let templates=JSON.parse(localStorage.getItem('amTemplates')||'null')||defaults;

const DEMO_BASE_VERSION='V219_DEMO_3';
const DEMO_SUBSCRIPTIONS=[1,2,3,4,5].map(n=>({id:`SUB-00${n}`,type:`Subscrição ${n}`,name:`Subscrição ${n}`,client:`Cliente ${n}`,limit:10,devices:[]}));

function dateOf(v){return new Date(String(v).includes('T')?v:v+'T00:00:00')}
function days(c){let d=dateOf(c['Validade']);let n=new Date();n.setHours(0,0,0,0);return Math.ceil((d-n)/86400000)}
function status(c){let d=days(c);return d<0?'expired':d<=30?'warning':'active'}
function statusLabel(c){let s=status(c),d=days(c);return s==='expired'?'EXPIRADO':d+' dias'}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function clientName(c){return c['Nome']||c['Nome Empresa']||'Sem nome'}

// V592 — Dados de clientes isolados por empresa ativa.
function v592CompanyStorageKey(base){
  const active=v586GetActiveCompany?.()||APP_SETTINGS?.companyProfiles?.[0]||{id:'company_default'};
  return base+'__'+String(active.id||'company_default');
}
function v592HasCompanyData(base){ return localStorage.getItem(v592CompanyStorageKey(base))!==null; }
function v592LoadCompanyData(base,legacyKey,fallback){
  const scoped=localStorage.getItem(v592CompanyStorageKey(base));
  if(scoped!==null) return JSON.parse(scoped);
  const active=v586GetActiveCompany?.();
  if(active?.id==='company_default'){
    const legacy=localStorage.getItem(legacyKey);
    if(legacy!==null){
      localStorage.setItem(v592CompanyStorageKey(base),legacy);
      return JSON.parse(legacy);
    }
  }
  return structuredClone(fallback);
}
function v592SaveCompanyData(base,value){ localStorage.setItem(v592CompanyStorageKey(base),JSON.stringify(value)); }
function v592LoadActiveCompanyClientData(){
  DATA=v592LoadCompanyData('amClientesDB','amClientesDB',INITIAL_DATA);
  ARCHIVED=v592LoadCompanyData('amClientesArchived','amClientesArchived',[]);
  ACTIVITY=v592LoadCompanyData('amClientesActivity','amClientesActivity',[]);
}
function v592RefreshAfterCompanySwitch(){
  selected=null;

  // Carregar imediatamente todos os dados da empresa acabada de selecionar.
  v592LoadActiveCompanyClientData();
  if(typeof loadSubscriptions==='function') loadSubscriptions();
  if(typeof loadConfigLists==='function') loadConfigLists();

  // Clientes: atualizar logo a vista que está por trás do menu lateral,
  // sem obrigar a fazer refresh à página.
  if(typeof render==='function') render();
  if(typeof renderFullClients==='function'){
    try{ renderFullClients(); }catch(e){}
  }

  // Subscrições: este já era o comportamento correto e mantém-se.
  if(typeof renderSubscriptions==='function') renderSubscriptions();

  // Catálogos: voltar a desenhar o catálogo que estiver aberto com os
  // dados da nova empresa, tal como já acontece nas subscrições.
  const catalogWork=document.getElementById('catalogWork');
  const catalogType=catalogWork?.dataset?.type;
  if(catalogType && typeof renderCatalogWork==='function'){
    try{ renderCatalogWork(catalogType); }catch(e){}
  }

  // Configurações e restantes elementos dependentes da empresa ativa.
  if(typeof renderSettings==='function'){
    try{ renderSettings(); }catch(e){}
  }

  if(typeof v589RenderCompanySwitcher==='function') v589RenderCompanySwitcher();
}

function loadDB(){
  try{return v592LoadCompanyData('amClientesDB','amClientesDB',INITIAL_DATA)}
  catch(e){return structuredClone(INITIAL_DATA)}
}

function initialiseDemoBase(){
  // V167: instalação nova começa totalmente vazia.
  // Este bloco corre apenas quando ainda não existe amClientesAppSettings;
  // numa atualização nunca entra aqui.
  if(V167_FRESH_INSTALL){
    const emptyLists=Object.fromEntries(Object.keys(DEFAULT_LISTS).map(key=>[key,[]]));
    APP_SETTINGS={
      title:'AM Clientes',
      logo:'',
      shortcuts:[],
      activeCompanyId:'company_1',
      companyProfiles:[v676DefaultCompany()]
    };
    DATA=[];
    ARCHIVED=[];
    ACTIVITY=[];
    SUBSCRIPTIONS=[];
    CONFIG_LISTS=structuredClone(emptyLists);
    templates={};
    selected=null;

    // Limpar qualquer vestígio de dados de versões anteriores que possa existir
    // mesmo sem amClientesAppSettings.
    const prefixes=[
      'amClientesDB','amClientesArchived','amClientesActivity',
      'amClientesSubscriptions','am_catalog_','am_v665_config_',
      'amClientesConfig_','am_v117_service_catalog__','amTemplates__',
      'amTemplates','amClientesEmptyBase'
    ];
    const keys=[];
    for(let i=0;i<localStorage.length;i++) keys.push(localStorage.key(i));
    keys.filter(Boolean).forEach(key=>{
      if(prefixes.some(prefix=>String(key).startsWith(prefix))) localStorage.removeItem(key);
    });
    localStorage.removeItem('amClientesConfigLists');
    localStorage.removeItem('amClientesSubscriptions');
    localStorage.removeItem('amTemplateMeta');
    localStorage.removeItem('amClientesDemoVersion');
    localStorage.removeItem('amClientesV593DistinctCompanyTestData');
    localStorage.removeItem('amClientesV624AllCompanyConfigurationExamples');

    // Marca a base como vazia para que os carregadores posteriores também
    // permaneçam vazios e não reponham demonstrações.
    v676SetGlobalDatabaseEmpty(true);
    v675SetBaseEmpty(true);

    saveAppSettings();
    v592SaveCompanyData('amClientesDB',DATA);
    v592SaveCompanyData('amClientesArchived',ARCHIVED);
    v592SaveCompanyData('amClientesActivity',ACTIVITY);
    localStorage.setItem(v618SubscriptionsStorageKey(),JSON.stringify([]));
    Object.keys(CATALOGS).forEach(type=>{
      try{ localStorage.setItem(v618CatalogStorageKey(type),JSON.stringify([])); }catch(e){}
    });
    try{ localStorage.setItem('am_v117_service_catalog__company_1',JSON.stringify([])); }catch(e){}
    localStorage.setItem(v743ConfigListsStorageKey(),JSON.stringify(emptyLists));
    localStorage.setItem('amTemplates__company_1',JSON.stringify({}));
    localStorage.setItem('amTemplateMeta',JSON.stringify({}));
    return;
  }

  // V676: depois de uma limpeza total, não voltar a criar a demonstração.
  if(typeof v676IsGlobalDatabaseEmpty==='function' && v676IsGlobalDatabaseEmpty()) return;

  // CORRIGIDO: deixou de comparar versões (isso apagava os dados sempre que o
  // ficheiro era atualizado). Agora só semeia os dados de demonstração se
  // ainda não existir NENHUMA base de dados guardada no navegador — ou seja,
  // corre uma única vez, na primeira utilização, e nunca mais apaga nada.
  const jaExisteBaseGuardada=localStorage.getItem('amClientesDB')!==null;
  const jaExisteConfiguracaoDaAplicacao=localStorage.getItem('amClientesAppSettings')!==null;
  if(jaExisteConfiguracaoDaAplicacao && !v676IsGlobalDatabaseEmpty()) return;
  if(jaExisteBaseGuardada){
    if(localStorage.getItem('amClientesDemoVersion')!==DEMO_BASE_VERSION){
      localStorage.setItem('amClientesDemoVersion',DEMO_BASE_VERSION);
    }
    return;
  }

  // Começar esta versão com a base de demonstração, sem herdar os dados
  // antigos que estavam guardados no navegador.
  localStorage.removeItem(v592CompanyStorageKey('amClientesDB'));
  localStorage.removeItem(v592CompanyStorageKey('amClientesArchived'));
  localStorage.removeItem(v592CompanyStorageKey('amClientesActivity'));
  localStorage.removeItem('amClientesSubscriptions');
  localStorage.removeItem('amClientesConfigLists');
  localStorage.removeItem('amTemplates');
  localStorage.removeItem('amTemplateMeta');

  DATA=structuredClone(INITIAL_DATA);
  ARCHIVED=[];
  ACTIVITY=[];
  SUBSCRIPTIONS=structuredClone(DEMO_SUBSCRIPTIONS);
  CONFIG_LISTS=structuredClone(DEFAULT_LISTS);
  templates=structuredClone(defaults);

  v592SaveCompanyData('amClientesDB',DATA);
  v592SaveCompanyData('amClientesArchived',ARCHIVED);
  v592SaveCompanyData('amClientesActivity',ACTIVITY);
  localStorage.setItem('amClientesSubscriptions',JSON.stringify(SUBSCRIPTIONS));
  localStorage.setItem('amClientesConfigLists',JSON.stringify(CONFIG_LISTS));
  localStorage.setItem('amTemplates',JSON.stringify(templates));

  const factoryMessageMeta={
    renewal:{name:'Renovação',icon:'🔔'},
    expired:{name:'Expirado',icon:'⚠️'},
    payment:{name:'Pagamento',icon:'💶'},
    maintenance:{name:'Manutenção',icon:'🛠️'},
    custom:{name:'Personalizada',icon:'✏️'}
  };
  if(window.MESSAGE_META) window.MESSAGE_META=structuredClone(factoryMessageMeta);
  localStorage.setItem('amTemplateMeta',JSON.stringify(factoryMessageMeta));

  localStorage.setItem('amClientesDemoVersion',DEMO_BASE_VERSION);
}
function loadArchived(){
  try{return v592LoadCompanyData('amClientesArchived','amClientesArchived',[])}catch(e){return []}
}
function loadActivity(){
  try{return v592LoadCompanyData('amClientesActivity','amClientesActivity',[])}catch(e){return []}
}
function saveActivity(){ v592SaveCompanyData('amClientesActivity',ACTIVITY); }
function snapshotState(){
  return {
    clientes:structuredClone(DATA),
    arquivados:structuredClone(ARCHIVED),
    listas:structuredClone(CONFIG_LISTS),
    mensagens:structuredClone(templates),
    appSettings:structuredClone(APP_SETTINGS),
    subscricoes:structuredClone(SUBSCRIPTIONS)
  };
}
// V170 — o histórico não pode fazer a base local ultrapassar a quota do WebView.
// Mantemos os registos mais recentes e preservamos o mecanismo de desfazer.
const V170_MAX_ACTIVITY_RECORDS=20;
const V170_MAX_ACTIVITY_CHARS=700000;
function pruneActivity(){
  if(!Array.isArray(ACTIVITY)) { ACTIVITY=[]; return; }
  while(ACTIVITY.length>V170_MAX_ACTIVITY_RECORDS) ACTIVITY.shift();
  // Se existirem snapshots grandes, reduzir pelo tamanho total antes de gravar.
  let guard=0;
  while(ACTIVITY.length>1 && guard++<V170_MAX_ACTIVITY_RECORDS){
    let size=0;
    try{ size=JSON.stringify(ACTIVITY).length; }catch(e){ break; }
    if(size<=V170_MAX_ACTIVITY_CHARS) break;
    ACTIVITY.shift();
  }
}
function v172ActivityValue(value){
  if(value===null || value===undefined || String(value).trim()==='') return '(vazio)';
  if(typeof value==='boolean') return value?'Sim':'Não';
  if(Array.isArray(value)) return value.length ? value.map(v=>v172ActivityValue(v)).join(', ') : '(vazio)';
  if(typeof value==='object') return '[dados]';
  return String(value);
}
function v172ActivityFieldName(key){
  const map={
    'Nome':'Nome','Observações':'Observações','Contacto':'Contacto','Email':'E-mail','Morada':'Morada','Nome Empresa':'Empresa',
    'tipo':'Tipo de equipamento','nome':'Nome do equipamento','marca':'Marca','modelo':'Modelo','referencia':'Referência',
    'mac':'MAC','utilizador':'Utilizador','senha':'Senha','link':'Link','servico':'Serviço','subscricao':'Subscrição',
    'validade':'Validade','periodicidade':'Periodicidade','metodoPagamento':'Método de pagamento','dataPagamento':'Data de pagamento',
    'dataInstalacao':'Data de início','valorPago':'Valor pago','servicoValor':'Valor do serviço','saldo':'Saldo','vpn':'VPN',
    'ID Cliente':'ID do cliente','Preço':'Preço','Pagamento':'Pagamento','Método Pagamento':'Método de pagamento','Validade':'Validade'
  };
  return map[key]||key;
}
function v172ActivitySame(a,b){
  try{return JSON.stringify(a??null)===JSON.stringify(b??null);}catch(e){return String(a??'')===String(b??'');}
}
function v172ClientForSnapshot(list, original){
  if(!Array.isArray(list))return null;
  const id=String(original?.['ID Cliente']??'');
  if(id){const byId=list.find(x=>String(x?.['ID Cliente']??'')===id);if(byId)return byId;}
  const name=String(original?.Nome??'').trim();
  return list.find(x=>String(x?.Nome??'').trim()===name)||null;
}
function v172DescribeClientChanges(beforeClient,afterClient){
  if(!beforeClient||!afterClient)return [];
  const lines=[];
  const ignored=new Set(['equipamentos','ID Cliente','Estado Cliente']);
  const keys=new Set([...Object.keys(beforeClient),...Object.keys(afterClient)]);
  for(const key of keys){
    if(ignored.has(key))continue;
    const oldV=beforeClient[key], newV=afterClient[key];
    if(v172ActivitySame(oldV,newV))continue;
    if(typeof oldV==='object' || typeof newV==='object')continue;
    lines.push(`${v172ActivityFieldName(key)}: ${v172ActivityValue(oldV)} → ${v172ActivityValue(newV)}`);
  }
  const oldEq=Array.isArray(beforeClient.equipamentos)?beforeClient.equipamentos:[];
  const newEq=Array.isArray(afterClient.equipamentos)?afterClient.equipamentos:[];
  const max=Math.max(oldEq.length,newEq.length);
  for(let i=0;i<max;i++){
    const oe=oldEq[i], ne=newEq[i];
    if(!oe && ne){ lines.push(`Equipamento ${i+1}: adicionado${ne.nome?` — ${v172ActivityValue(ne.nome)}`:''}`); continue; }
    if(oe && !ne){ lines.push(`Equipamento ${i+1}: removido${oe.nome?` — ${v172ActivityValue(oe.nome)}`:''}`); continue; }
    if(!oe||!ne)continue;
    const ekeys=new Set([...Object.keys(oe),...Object.keys(ne)]);
    for(const key of ekeys){
      if(key==='vpns' || key==='movimentos')continue;
      const ov=oe[key], nv=ne[key];
      if(v172ActivitySame(ov,nv))continue;
      if(typeof ov==='object' || typeof nv==='object')continue;
      lines.push(`Equipamento ${i+1} · ${v172ActivityFieldName(key)}: ${v172ActivityValue(ov)} → ${v172ActivityValue(nv)}`);
    }
    const ovp=Array.isArray(oe.vpns)?oe.vpns:[], nvp=Array.isArray(ne.vpns)?ne.vpns:[];
    if(!v172ActivitySame(ovp,nvp)) lines.push(`Equipamento ${i+1} · VPN: informação alterada`);
  }
  return lines.slice(0,14);
}
function v172DescribeActivity(a){
  const base=String(a?.detail||a?.action||'Alteração');
  const before=a?.before?.clientes, after=a?.after?.clientes;
  if(String(a?.action||'').toLowerCase()==='cliente editado' && Array.isArray(before) && Array.isArray(after)){
    const oldClient=before.find(x=>String(x?.['ID Cliente']??'')===String(after.find(y=>String(y?.['ID Cliente']??'')===String(x?.['ID Cliente']??''))?.['ID Cliente']??''));
    let afterClient=null, beforeClient=null;
    for(const c of after){
      const b=v172ClientForSnapshot(before,c);
      if(b && !v172ActivitySame(b,c)){beforeClient=b;afterClient=c;break;}
    }
    if(!afterClient && beforeClient) afterClient=v172ClientForSnapshot(after,beforeClient);
    const changes=v172DescribeClientChanges(beforeClient,afterClient);
    if(changes.length)return `Alteração no cliente ${clientName(afterClient)}\n\n${changes.map(x=>'• '+x).join('\n')}`;
  }
  return base;
}
function showActivityDetail(id){
  const a=ACTIVITY.find(x=>String(x.id)===String(id));
  if(!a)return;
  const overlay=document.createElement('div');
  overlay.className='am-confirm-overlay';
  overlay.innerHTML=`<div class="am-confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="v172ActivityDetailTitle">
    <h3 id="v172ActivityDetailTitle">${esc(a.action||'Alteração')}</h3>
    <p>${esc(v172DescribeActivity(a))}</p>
    <div class="am-confirm-actions" style="justify-content:center"><button class="primary" type="button">Fechar</button></div>
  </div>`;
  const close=()=>overlay.remove();
  overlay.querySelector('button').onclick=close;
  overlay.addEventListener('click',e=>{if(e.target===overlay)close()});
  document.body.appendChild(overlay);
}
function v172LatestUndoable(){
  for(let i=ACTIVITY.length-1;i>=0;i--){
    const a=ACTIVITY[i];
    if(a && !a.undone && !a.redoInvalid)return a;
  }
  return null;
}
function v172ApplySnapshot(snapshot){
  if(!snapshot)return false;
  DATA=structuredClone(snapshot.clientes||[]);
  ARCHIVED=structuredClone(snapshot.arquivados||[]);
  CONFIG_LISTS=structuredClone(snapshot.listas||DEFAULT_LISTS);
  templates=structuredClone(snapshot.mensagens||templates);
  if(snapshot.appSettings){APP_SETTINGS=structuredClone(snapshot.appSettings);saveAppSettings();}
  if(Array.isArray(snapshot.subscricoes)){SUBSCRIPTIONS=structuredClone(snapshot.subscricoes);if(typeof saveSubscriptions==='function')saveSubscriptions();}
  v592SaveCompanyData('amClientesDB',DATA);
  v592SaveCompanyData('amClientesArchived',ARCHIVED);
  localStorage.setItem('amClientesConfigLists',JSON.stringify(CONFIG_LISTS));
  localStorage.setItem('amTemplates',JSON.stringify(templates));
  selected=null;
  if(typeof render==='function')render();
  return true;
}
async function redoActivity(id){
  pruneActivity();
  const a=ACTIVITY.find(x=>String(x.id)===String(id));
  if(!a || !a.undone || a.redoInvalid){alert('Esta alteração já não pode ser refeita porque entretanto foi feita outra alteração.');return;}
  const confirmed=await showAppConfirm('Pretende refazer esta alteração?',v172DescribeActivity(a),'Refazer','Cancelar');
  if(!confirmed)return;
  try{
    if(!v172ApplySnapshot(a.after)){alert('Não foi possível refazer esta alteração.');return;}
    a.undone=false;
    a.redoneAt=new Date().toISOString();
    saveActivity();
    view('atividade');
    renderActivity();
  }catch(err){console.error(err);alert('Não foi possível refazer esta alteração.');}
}

function recordAction(action,detail,before,after){
  try{
    pruneActivity();
    ACTIVITY.forEach(a=>{if(a && a.undone && !a.redoInvalid)a.redoInvalid=true;});
    ACTIVITY.push({
      id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),
      at:new Date().toISOString(),
      action,
      detail,
      before:before||snapshotState(),
      after:after||snapshotState()
    });
    pruneActivity();
    saveActivity();
    const box=document.getElementById('activityList');
    if(box && !document.getElementById('atividade')?.classList.contains('hidden')) renderActivity();
  }catch(e){
    console.error('Erro ao registar histórico:',e);
  }
}
function changedFields(beforeClient,afterClient){
  if(!beforeClient||!afterClient)return [];
  const keys=new Set([...Object.keys(beforeClient),...Object.keys(afterClient)]);
  return [...keys].filter(k=>String(beforeClient[k]??'')!==String(afterClient[k]??''));
}


function saveDB(){
  pruneActivity();
  try{
    v592SaveCompanyData('amClientesDB',DATA);
    v592SaveCompanyData('amClientesArchived',ARCHIVED);
    v592SaveCompanyData('amClientesActivity',ACTIVITY);
  }catch(e){
    // V170 — se a quota ainda for atingida, reduzir o histórico e repetir a gravação.
    if(String(e?.name||'').includes('Quota') || /quota/i.test(String(e?.message||e))){
      while(ACTIVITY.length>1){
        ACTIVITY.shift();
        try{
          v592SaveCompanyData('amClientesDB',DATA);
          v592SaveCompanyData('amClientesArchived',ARCHIVED);
          v592SaveCompanyData('amClientesActivity',ACTIVITY);
          break;
        }catch(_){ }
      }
    }else{ throw e; }
  }
  render();
}
function nextId(){
 let nums=DATA.concat(ARCHIVED||[])
   .map(c=>parseInt(String(c['ID Cliente']||'').replace(/^CLI-/i,'').replace(/^CLI/i,''),10))
   .filter(Number.isFinite);
 let n=nums.length?Math.max(...nums)+1:1;
 while(DATA.some(c=>String(c['ID Cliente'])===String(n)) || (ARCHIVED||[]).some(c=>String(c['ID Cliente'])===String(n))) n++;
 return String(n);
}
const DEFAULT_LISTS={ saldos:[], 
  valores:["10","20","30","40","50"],"empresas": ["Empresa 1", "Empresa 2", "Empresa 3", "Empresa 4", "Empresa 5"], "servicos": ["Serviço 1", "Serviço 2", "Serviço 3", "Serviço 4", "Serviço 5"], "pagamentos": ["Pagamento 1", "Pagamento 2", "Pagamento 3", "Pagamento 4", "Pagamento 5"], "vpns": ["VPN 1", "VPN 2", "VPN 3", "VPN 4", "VPN 5"], "nome_equipamentos": ["Marca 1", "Marca 2", "Marca 3", "Marca 4", "Marca 5"], "equipamentos": ["Equipamento 1", "Equipamento 2", "Equipamento 3", "Equipamento 4", "Equipamento 5"], "periodicidades": ["Periodicidade 1", "Periodicidade 2", "Periodicidade 3", "Periodicidade 4", "Periodicidade 5"], "metodos_contacto": ["Contacto 1", "Contacto 2", "Contacto 3", "Contacto 4", "Contacto 5"], "pacotes": ["Pacote 1", "Pacote 2", "Pacote 3", "Pacote 4", "Pacote 5"], "valores": ["10","20","30","40","50"]};

if(!Object.prototype.hasOwnProperty.call(window,'v586AddingCompany')) window.v586AddingCompany=false;
if(!Object.prototype.hasOwnProperty.call(window,'v586EditingCompany')) window.v586EditingCompany=false;

let APP_SETTINGS={
  title:'AM Clientes',
  logo:'',
  shortcuts:[],
  activeCompanyId:'company_1',
  companyProfiles:[{
    id:'company_1',
    name:'Empresa 1',
    data:{legalName:'',responsible:'',email:'',phone:'',address:'',postalCode:'',locality:'',nif:'',website:''}
  }]
};

function v586EmptyCompanyData(){
  return {legalName:'',responsible:'',email:'',phone:'',address:'',postalCode:'',locality:'',nif:'',website:''};
}
function v586NormalizeCompanyProfiles(v){
  const raw=Array.isArray(v.companyProfiles)?v.companyProfiles:[];
  const profiles=raw.map((profile,i)=>({
    id:String(profile?.id||('company_'+Date.now().toString(36)+'_'+i)),
    name:String(profile?.name||('Empresa '+(i+1))),
    data:{legalName:String(profile?.data?.legalName||''),responsible:String(profile?.data?.responsible||''),email:String(profile?.data?.email||''),phone:String(profile?.data?.phone||''),address:String(profile?.data?.address||''),postalCode:String(profile?.data?.postalCode||''),locality:String(profile?.data?.locality||''),nif:String(profile?.data?.nif||''),website:String(profile?.data?.website||'')}
  }));
  if(!profiles.length){
    profiles.push((typeof v676IsGlobalDatabaseEmpty==='function' && v676IsGlobalDatabaseEmpty())
      ? v676DefaultCompany()
      : {id:'company_1',name:'Empresa 1',data:v586EmptyCompanyData()});
  }
  const active=profiles.some(profile=>profile.id===String(v.activeCompanyId||''))
    ?String(v.activeCompanyId)
    :profiles[0].id;
  return {profiles,active};
}


// V679 — Reposição com 5 clientes simples da base oficial, sem datas/pagamentos/valores.
// V678 — Confirmações de Repor/Limpar simplificadas; reposição não gera faturação de demonstração.
// V677 — Base limpa apresenta a empresa estrutural apenas como "Empresa"; Repor volta a Empresa 1–5.
// V676 — Estado global da base: quando se faz "Limpar base de dados",
// não voltamos a semear automaticamente as 5 empresas/atalhos de demonstração.
function v676GlobalEmptyKey(){ return 'amClientesGlobalDatabaseEmpty'; }
function v676IsGlobalDatabaseEmpty(){ return localStorage.getItem(v676GlobalEmptyKey())==='1'; }
function v676SetGlobalDatabaseEmpty(v){
  if(v) localStorage.setItem(v676GlobalEmptyKey(),'1');
  else localStorage.removeItem(v676GlobalEmptyKey());
}
function v676DefaultCompany(){
  // Base limpa: existe apenas uma empresa estrutural vazia, sem numeração.
  return {id:'company_1',name:'Empresa',data:v586EmptyCompanyData()};
}
function v676DemoShortcuts(){
  return [1,2,3,4,5].map(n=>({
    id:'shortcut_demo_'+n,
    name:'Site '+n,
    description:'Descrição do site '+n,
    url:'https://example.com/link'+n
  }));
}

// V593 — Ambiente de teste com 5 empresas e bases de clientes visualmente distintas.
function v593BuildTestClients(companyNumber){
  // V679 — Base de teste alinhada com a base oficial: apenas 5 clientes simples,
  // sem pagamentos, sem método de pagamento e sem datas. Assim o estado fica N/A.
  return structuredClone(INITIAL_DATA).map((client,index)=>{
    const number=index+1;
    client['Nome']='Cliente '+number;
    client['Nome Empresa']='Empresa '+companyNumber;
    client['Serviço']='Serviço '+number;
    client['Equipamento']='Equipamento '+number;
    client['Preço']=0;
    client['Pagamento']='';
    client['Método Pagamento']='';
    client['Validade']='';
    client['Periodicidade']='';
    client['Saldo']=0;
    client['Data Instalação']='';
    client['Estado Cliente']='';
    client['Observações']='';
    return client;
  });
}
function v593PrepareTestCompanies(){
  if(v676IsGlobalDatabaseEmpty()){
    APP_SETTINGS.companyProfiles=[v676DefaultCompany()];
    APP_SETTINGS.activeCompanyId='company_1';
    return;
  }
  const previous=Array.isArray(APP_SETTINGS.companyProfiles)?APP_SETTINGS.companyProfiles:[];
  const previousById=new Map(previous.map(p=>[String(p.id),p]));
  const previousActive=v586GetActiveCompany?.()||previous[0];
  const profiles=[1,2,3,4,5].map(n=>{
    const id='company_'+n;
    const old=previousById.get(id) || (n===1 ? previousActive : null);
    return {
      id,
      name:'Empresa '+n,
      data: old?.data ? {...v586EmptyCompanyData(),...old.data} : v586EmptyCompanyData()
    };
  });
  APP_SETTINGS.companyProfiles=profiles;
  if(!profiles.some(p=>p.id===APP_SETTINGS.activeCompanyId)) APP_SETTINGS.activeCompanyId='company_1';
  saveAppSettings();
}
function v593SeedDistinctCompanyDataOnce(){
  const marker='amClientesV593DistinctCompanyTestData';
  if(localStorage.getItem(marker)==='1') return;
  [1,2,3,4,5].forEach(n=>{
    const suffix='__company_'+n;
    localStorage.setItem('amClientesDB'+suffix,JSON.stringify(v593BuildTestClients(n)));
    localStorage.setItem('amClientesArchived'+suffix,JSON.stringify([]));
    localStorage.setItem('amClientesActivity'+suffix,JSON.stringify([]));
  });
  localStorage.setItem(marker,'1');
}


// V619 — Ambiente de teste completo por empresa.
// Cada uma das 5 empresas recebe 5 exemplos próprios de subscrições,
// equipamentos, serviços, produtos e marcas. Os dados já criados pelo
// utilizador não são substituídos: só são trocados exemplos genéricos
// de demonstração da versão anterior.
function v619GenericDemoNames(prefix){
  return [1,2,3,4,5].map(n=>prefix+' '+n);
}
function v619IsGenericDemoList(rows,prefix){
  if(!Array.isArray(rows) || rows.length!==5) return false;
  const expected=new Set(v619GenericDemoNames(prefix));
  return rows.every(row=>expected.has(String(row?.nome||row?.name||'')));
}
function v619CompanyDemoSubscriptions(companyNumber){
  return [1,2,3,4,5].map(n=>({
    id:'SUB-E'+companyNumber+'-'+String(n).padStart(2,'0'),
    type:'Subscrição '+n+' da Empresa '+companyNumber,
    name:'Subscrição '+n+' da Empresa '+companyNumber,
    client:'Cliente '+n+' da Empresa '+companyNumber,
    limit:10,
    validityType:'purchase',
    licenseUsed:0,
    purchaseDate:'',
    startDate:'',
    validityMonths:0,
    endDate:'',
    cost:0,
    revenue:0,
    movements:[],
    devices:[]
  }));
}
function v619CompanyDemoCatalogs(companyNumber){
  const company=' da Empresa '+companyNumber;
  return {
    equipamentos:[1,2,3,4,5].map(n=>({
      nome:'Equipamento '+n+company,
      tipo:['Câmara','NVR','Router','Alarme','Acessório'][n-1],
      marca:'Marca '+n+company,
      modelo:'Modelo '+n+company,
      referencia:'E'+companyNumber+'-REF-'+String(n).padStart(3,'0'),
      categoria:['Câmara IP','NVR','Router','Alarme','Acessório'][n-1],
      custo:'0',pvp:'0',venda:'0',foto:''
    })),
    produtos:[1,2,3,4,5].map(n=>({
      nome:'Produto '+n+company,
      marca:'Marca '+n+company,
      tipo:n<=2?'Consumível':'Material',
      unidade:n===2?'metro':'unidade',
      quantidade:'0',custo:'0',venda:'0'
    })),
    servicos:[1,2,3,4,5].map(n=>({
      nome:'Serviço '+n+company,
      tipo:['Mão de obra','Mão de obra','Configuração','Manutenção','Instalação'][n-1],
      unidade:n<=2?'Hora':'Serviço',
      venda:String(n*10)
    })),
    marcas:[1,2,3,4,5].map(n=>({nome:'Marca '+n+company}))
  };
}
function v624SeedAllCompanyConfigurationExamplesOnce(){
  const marker='amClientesV624AllCompanyConfigurationExamples';
  if(localStorage.getItem(marker)==='1') return;
  [1,2,3,4,5].forEach(companyNumber=>{
    const suffix='__company_'+companyNumber;
    const c=' da Empresa '+companyNumber;
    const examples={
      equipamentos:[1,2,3,4,5].map(n=>({nome:'Equipamento '+n+c,tipo:['Câmara','NVR','Router','Alarme','Acessório'][n-1],marca:'Marca '+n+c,modelo:'Modelo '+n+c,referencia:'E'+companyNumber+'-REF-'+String(n).padStart(3,'0'),categoria:['Câmara IP','NVR','Router','Alarme','Acessório'][n-1],custo:'0',pvp:'0',venda:'0',foto:''})),
      produtos:[1,2,3,4,5].map(n=>({nome:'Produto '+n+c,marca:'Marca '+n+c,tipo:n<=2?'Consumível':'Material',unidade:n===2?'metro':'unidade',quantidade:'0',custo:'0',venda:'0'})),
      servicos:[1,2,3,4,5].map(n=>({nome:'Serviço '+n+c,tipo:['Mão de obra','Mão de obra','Configuração','Manutenção','Instalação'][n-1],unidade:n<=2?'Hora':'Serviço',venda:String(n*10)})),
      marcas:[1,2,3,4,5].map(n=>({nome:'Marca '+n+c}))
    };
    Object.entries(examples).forEach(([type,rows])=>{
      localStorage.setItem('am_catalog_'+type+suffix,JSON.stringify(rows));
    });
    if(typeof v619CompanyDemoSubscriptions==='function'){
      localStorage.setItem('amClientesSubscriptions'+suffix,JSON.stringify(v619CompanyDemoSubscriptions(companyNumber)));
    }
  });
  localStorage.setItem(marker,'1');
}

function loadAppSettings(){
  try{
    const raw=localStorage.getItem('amClientesAppSettings');
    if(raw){
      const v=JSON.parse(raw);
      const companies=v586NormalizeCompanyProfiles(v);
      APP_SETTINGS={
        title:String(v.title||'AM Clientes'),
        logo:String(v.logo||''),
        shortcuts:Array.isArray(v.shortcuts)?v.shortcuts:[],
        activeCompanyId:companies.active,
        companyProfiles:companies.profiles
      };
    }else{
      const companies=v586NormalizeCompanyProfiles(APP_SETTINGS);
      APP_SETTINGS.companyProfiles=companies.profiles;
      APP_SETTINGS.activeCompanyId=companies.active;
    }
  }catch(e){
    const fallbackCompany=(typeof v676IsGlobalDatabaseEmpty==='function' && v676IsGlobalDatabaseEmpty())
      ? v676DefaultCompany()
      : {id:'company_1',name:'Empresa 1',data:v586EmptyCompanyData()};
    APP_SETTINGS={title:'AM Clientes',logo:'',shortcuts:[],activeCompanyId:'company_1',companyProfiles:[fallbackCompany]};
  }
}
function v586GetActiveCompany(){
  const normalized=v586NormalizeCompanyProfiles(APP_SETTINGS);
  APP_SETTINGS.companyProfiles=normalized.profiles;
  APP_SETTINGS.activeCompanyId=normalized.active;
  return APP_SETTINGS.companyProfiles.find(profile=>profile.id===APP_SETTINGS.activeCompanyId)||APP_SETTINGS.companyProfiles[0];
}

function v589RenderCompanySwitcher(){
  const label=document.getElementById('companySwitcherLabel');
  const list=document.getElementById('companySwitcherList');
  if(!label||!list)return;
  const active=v586GetActiveCompany();
  label.textContent='🏢 '+(active.name||'Empresa ativa');
  list.innerHTML=(APP_SETTINGS.companyProfiles||[]).map(profile=>
    `<button type="button" class="${profile.id===active.id?'company-switcher-active':''}" onclick="v589SwitchCompanyFromMenu('${esc(profile.id)}')">${profile.id===active.id?'✓ ':''}🏢 ${esc(profile.name)}</button>`
  ).join('')+`<button type="button" class="company-switcher-manage" onclick="v589OpenCompanyManagement()">⚙️ Gerir empresas</button>`;
}
function v589ToggleCompanySwitcher(){
  const list=document.getElementById('companySwitcherList');
  if(!list)return;
  v589RenderCompanySwitcher();
  list.classList.toggle('is-open');
}
function v589CloseCompanySwitcher(){
  document.getElementById('companySwitcherList')?.classList.remove('is-open');
}
function v589SwitchCompanyFromMenu(id){
  const profiles=APP_SETTINGS.companyProfiles||[];
  if(!profiles.some(profile=>profile.id===id))return;
  APP_SETTINGS.activeCompanyId=id;
  saveAppSettings();
  v592RefreshAfterCompanySwitch();
  v589CloseCompanySwitcher();
  if(document.getElementById('settingsForm')?.parentElement?.classList.contains('active')) renderSettings();
}
function v589OpenCompanyManagement(){
  v589CloseCompanySwitcher();
  // V721 — ao entrar em Gerir empresas, fechar também a barra lateral completa.
  const drawer=document.getElementById('sideMenu');
  const overlay=document.getElementById('menuOverlay');
  const hamburger=document.getElementById('menuHamburger');
  drawer?.classList.remove('open');
  overlay?.classList.remove('open');
  drawer?.setAttribute('aria-hidden','true');
  overlay?.setAttribute('aria-hidden','true');
  hamburger?.setAttribute('aria-expanded','false');
  openSettings();
  const card=document.querySelector('#settingsForm > .company-data-card');
  if(card?.classList.contains('v577-collapsed')) card.classList.remove('v577-collapsed');
}

function v112EnsureShortcutIds(){
  if(!Array.isArray(APP_SETTINGS.shortcuts)) APP_SETTINGS.shortcuts=[];
  let changed=false;
  APP_SETTINGS.shortcuts.forEach((s,i)=>{
    if(!s.id){
      s.id='shortcut_'+Date.now().toString(36)+'_'+i+'_'+Math.random().toString(36).slice(2,7);
      changed=true;
    }
  });
  if(changed) localStorage.setItem('amClientesAppSettings',JSON.stringify(APP_SETTINGS));
}
v112EnsureShortcutIds();

function saveAppSettings(){
  localStorage.setItem('amClientesAppSettings',JSON.stringify(APP_SETTINGS));
  applyAppSettings();
}
function applyAppSettings(){
  v589RenderCompanySwitcher();
  const title=document.getElementById('appTitle');
  const logo=document.getElementById('appLogo');
  if(title) title.textContent=APP_SETTINGS.title||'AM Clientes';
  if(logo){
    if(APP_SETTINGS.logo){
      logo.innerHTML=`<img src="${APP_SETTINGS.logo}" alt="Logotipo" style="width:100%;height:100%;object-fit:contain;border-radius:inherit">`;
    }else{
      logo.textContent='AM';
    }
  }
}
function handleLogoFile(input){
  const file=input?.files?.[0];
  if(!file)return;
  if(!file.type.startsWith('image/')){
    alert('Escolhe uma imagem válida para o logotipo.');
    input.value='';
    return;
  }
  const reader=new FileReader();
  reader.onload=()=>{
    const img=new Image();
    img.onload=()=>{
      const max=500;
      const scale=Math.min(1,max/img.width,max/img.height);
      const w=Math.max(1,Math.round(img.width*scale));
      const h=Math.max(1,Math.round(img.height*scale));
      const canvas=document.createElement('canvas');
      canvas.width=w; canvas.height=h;
      canvas.getContext('2d').drawImage(img,0,0,w,h);
      APP_SETTINGS.logo=canvas.toDataURL('image/png');
      saveAppSettings();
      renderSettings();
    };
    img.src=reader.result;
  };
  reader.readAsDataURL(file);
}
function removeAppLogo(){
  APP_SETTINGS.logo='';
  saveAppSettings();
  renderSettings();
}

let CONFIG_LISTS={};

function v743ConfigListsStorageKey(){
  return v592CompanyStorageKey('amClientesConfigLists');
}
function loadConfigLists(){
  try{
    const scopedKey=v743ConfigListsStorageKey();
    let raw=localStorage.getItem(scopedKey);

    // Migração única da configuração global antiga para a Empresa 1.
    if(raw===null && v586GetActiveCompany()?.id==='company_1'){
      const legacy=localStorage.getItem('amClientesConfigLists');
      if(legacy!==null){
        localStorage.setItem(scopedKey,legacy);
        raw=legacy;
      }
    }

    if(raw!==null){
      const saved=JSON.parse(raw)||{};
      CONFIG_LISTS=Object.assign({},structuredClone(DEFAULT_LISTS),saved);
    }else{
      // Uma empresa nova começa sem opções próprias.
      CONFIG_LISTS=Object.fromEntries(Object.keys(DEFAULT_LISTS).map(key=>[key,[]]));
    }

    Object.keys(CONFIG_LISTS).forEach(k=>{
      if(!Array.isArray(CONFIG_LISTS[k])) CONFIG_LISTS[k]=[];
    });
  }catch(e){
    CONFIG_LISTS=Object.fromEntries(Object.keys(DEFAULT_LISTS).map(key=>[key,[]]));
  }
}
// V167 — instalação nova começa totalmente vazia.
// Só é considerado "primeiro arranque" quando ainda não existe configuração
// persistida da aplicação. Uma atualização de uma instalação existente nunca
// entra neste caminho e, portanto, não apaga dados do utilizador.
const V167_FRESH_INSTALL = localStorage.getItem('amClientesAppSettings') === null
  && localStorage.getItem('amClientesGlobalDatabaseEmpty') !== '1';

ensureConfigDemoExamples();
function ensureConfigDemoExamples(){
  // Numa instalação nova a base deve começar vazia, sem os exemplos 1–5.
  if(V167_FRESH_INSTALL || (typeof v676IsGlobalDatabaseEmpty==='function' && v676IsGlobalDatabaseEmpty())) return;
  const examples={
    empresas:['Empresa 1','Empresa 2','Empresa 3','Empresa 4','Empresa 5'],
    servicos:['Serviço 1','Serviço 2','Serviço 3','Serviço 4','Serviço 5'],
    pagamentos:['Pagamento 1','Pagamento 2','Pagamento 3','Pagamento 4','Pagamento 5'],
    vpns:['VPN 1','VPN 2','VPN 3','VPN 4','VPN 5'],
    nome_equipamentos:['Marca 1','Marca 2','Marca 3','Marca 4','Marca 5'],
    equipamentos:['Equipamento 1','Equipamento 2','Equipamento 3','Equipamento 4','Equipamento 5'],
    periodicidades:['Periodicidade 1','Periodicidade 2','Periodicidade 3','Periodicidade 4','Periodicidade 5'],
    metodos_contacto:['Contacto 1','Contacto 2','Contacto 3','Contacto 4','Contacto 5'],
    pacotes:['Pacote 1','Pacote 2','Pacote 3','Pacote 4','Pacote 5'],
    valores:['10','20','30','40','50']
  };
  let changed=false;
  Object.entries(examples).forEach(([key,vals])=>{
    if(!Array.isArray(CONFIG_LISTS[key])) CONFIG_LISTS[key]=[];
    vals.forEach(v=>{ if(CONFIG_LISTS[key].length<5 && !CONFIG_LISTS[key].includes(v)){ CONFIG_LISTS[key].push(v); changed=true; } });
  });
  if(changed) saveConfigLists();
}

function saveConfigLists(){
  localStorage.setItem(v743ConfigListsStorageKey(),JSON.stringify(CONFIG_LISTS));
}
function listOptions(key, current=''){
  const arr=CONFIG_LISTS[key]||[];
  let html=arr.map(v=>`<option value="${esc(v)}" ${String(v)===String(current)?'selected':''}>${esc(v)}</option>`).join('');
  const labels={empresas:'empresa',servicos:'serviço',pagamentos:'método de pagamento',vpns:'VPN',nome_equipamentos:'marca do equipamento',equipamentos:'tipo de equipamento',periodicidades:'periodicidade',metodos_contacto:'canal de contacto',valores:'valor'};
  const label=labels[key]||'';
  return `<option value="">— Selecionar${label?' '+label:''} —</option>${html}<option value="__custom__">✏️ Outro...</option>`;
}
function selectConfigValue(key, inputId){
  const sel=document.getElementById(inputId+'_select');
  const inp=document.getElementById(inputId);
  if(!sel||!inp)return;
  if(sel.value==='__custom__'){
    inp.style.display='block'; inp.focus(); inp.value='';
  }else{
    inp.value=sel.value; inp.style.display='none';
  }
}
function configField(key,label,inputId,current){
  const arr=CONFIG_LISTS[key]||[];
  return `<div class="field"><label>${esc(label)}</label>
    <select id="${inputId}_select" onchange="selectConfigValue('${key}','${inputId}')">${listOptions(key,current)}</select>
    <input id="${inputId}" type="text" value="${esc(current||'')}" style="${current && !arr.includes(current)?'display:block':'display:none'}" placeholder="Ex.: Escrever outro">
  </div>`;
}
function openSettings(){
  // V353 — construir o conteúdo primeiro e só depois mostrar Configurações.
  // Evita o frame intermédio em que o painel aparece vazio/fechado.
  v147SyncServicesFromCatalog();
  renderSettings();
  view('config');
}
// V730 — edição dos atalhos diretamente no formulário de Configurações.
// O lápis carrega os dados existentes nos campos Nome/Descrição/URL; não usa prompts.
if(!Object.prototype.hasOwnProperty.call(window,'v730EditingShortcutIndex')) window.v730EditingShortcutIndex=null;

function renderSettings(){
  const box=document.getElementById('settingsForm');
  if(!box)return;
  const preservedSections=v586CaptureSettingsSections();
  const preservedScrollY=window.scrollY||document.documentElement.scrollTop||0;
  const labels={
    empresas:'Empresas dos clientes',pagamentos:'Métodos de pagamento',
    nome_equipamentos:'Marcas dos Equipamentos',equipamentos:'Tipo de Equipamentos',periodicidades:'Periodicidades',
    metodos_contacto:'Canais de contacto',valores:'Valores de pagamento'
  };
  const activeCompany=v586GetActiveCompany();
  const addingCompany=window.v586AddingCompany===true;
  const editingCompany=window.v586EditingCompany===true;
  const companyData=addingCompany?v586EmptyCompanyData():(activeCompany.data||v586EmptyCompanyData());
  box.innerHTML=`
    <div class="card v577-collapsed v628-settings-card" data-v628-section="app" style="margin-bottom:12px">
      <h3><span class="v628-settings-handle" title="Arrastar para ordenar" aria-label="Arrastar para ordenar">☷</span><span class="v628-settings-label">Apresentação da aplicação</span></h3>
      <div class="field">
        <label>Nome a apresentar na aplicação</label>
        <input id="appTitleInput" type="text" value="${esc(APP_SETTINGS.title||'AM Clientes')}" placeholder="Ex.: Nome a apresentar na aplicação">
      </div>
      <div class="field settings-logo-field">
        <label>Logotipo a apresentar na aplicação</label>
        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
          <div class="logo" style="flex:0 0 auto;width:64px;height:64px">${APP_SETTINGS.logo?`<img src="${APP_SETTINGS.logo}" alt="Logotipo" style="width:100%;height:100%;object-fit:contain;border-radius:inherit">`:'AM'}</div>
          <div class="actions" style="align-items:center">
            <button type="button" class="primary" onclick="document.getElementById('appLogoFile').click()">Escolher logotipo</button>
            <input id="appLogoFile" type="file" accept="image/*" onchange="handleLogoFile(this)" style="display:none">
            ${APP_SETTINGS.logo?'<button type="button" onclick="removeAppLogo()">🗑️ Remover logotipo</button>':''}
          </div>
        </div>
      </div>
      <div class="actions">
        <button class="primary" onclick="saveAppIdentity()">💾 Guardar apresentação</button>
      </div>
    </div>
    <div class="card v577-collapsed company-data-card v628-settings-card" data-v628-section="company-data" style="margin-bottom:12px">
      <h3><span class="v628-settings-handle" title="Arrastar para ordenar" aria-label="Arrastar para ordenar">☷</span><span class="v628-settings-label">Empresas da aplicação</span></h3>
      <div class="field">
        <label>Empresa ativa</label>
        <select id="activeCompanySelect" onchange="v586SwitchCompany(this.value)">
          ${APP_SETTINGS.companyProfiles.map(profile=>`<option value="${esc(profile.id)}" ${profile.id===activeCompany.id?'selected':''}>${esc(profile.name)}</option>`).join('')}
        </select>
      </div>
      <div class="actions" style="margin-top:8px">
        <button type="button" class="primary" onclick="v586AddCompany()">＋ Adicionar empresa</button>
        <button type="button" onclick="v586EditActiveCompany()" title="Editar empresa" aria-label="Editar empresa">✏️</button>
        ${APP_SETTINGS.companyProfiles.length>1?'<button type="button" onclick="v586DeleteActiveCompany()">🗑️ Remover empresa</button>':''}
      </div>
      <div class="row">
        <div class="field"><label>Nome da empresa</label><input id="companyLegalName" value="${addingCompany?'':esc(companyData.legalName||activeCompany.name||'')}" placeholder="Ex.: Nome da empresa"></div>
        <div class="field"><label>Responsável</label><input id="companyResponsible" value="${esc(companyData.responsible||'')}" placeholder="Ex.: Nome do responsável"></div>
      </div>
      <div class="row">
        <div class="field"><label>E-mail</label><input id="companyEmail" type="email" value="${esc(companyData.email||'')}" placeholder="Ex.: email@empresa.pt"></div>
        <div class="field"><label>Telemóvel</label><input id="companyPhone" type="tel" value="${esc(companyData.phone||'')}" placeholder="Ex.: Telemóvel"></div>
      </div>
      <div class="field"><label>NIF</label><input id="companyNif" value="${esc(companyData.nif||'')}" placeholder="Ex.: NIF da empresa"></div>
      <div class="field"><label>Morada</label><input id="companyAddress" value="${esc(companyData.address||'')}" placeholder="Ex.: Morada da empresa"></div>
      <div class="row">
        <div class="field"><label>Código postal</label><input id="companyPostalCode" value="${esc(companyData.postalCode||'')}" placeholder="Ex.: Código postal da empresa"></div>
        <div class="field"><label>Localidade</label><input id="companyLocality" value="${esc(companyData.locality||'')}" placeholder="Ex.: Localidade da empresa"></div>
      </div>
      <div class="field"><label>Website</label><input id="companyWebsite" type="url" value="${esc(companyData.website||'')}" placeholder="Ex.: https://empresa.pt"></div>
      <div class="actions"><button class="primary" type="button" onclick="v586SaveCompanyData()">${addingCompany?'💾 Guardar e adicionar empresa':'💾 Guardar dados da empresa'}</button>${(addingCompany||editingCompany)?'<button type="button" onclick="v586CancelCompanyEdit()">Cancelar</button>':''}</div>
    </div>
  ` + `
    
<div class="card v577-collapsed v628-settings-card" data-v628-section="shortcuts" style="margin-bottom:12px">
      <h3><span class="v628-settings-handle" title="Arrastar para ordenar" aria-label="Arrastar para ordenar">☷</span><span class="v628-settings-label">Botões do menu Início</span></h3>
      
      ${(()=>{
        const editIndex=Number.isInteger(window.v730EditingShortcutIndex)?window.v730EditingShortcutIndex:null;
        const editing=editIndex!==null && Array.isArray(APP_SETTINGS.shortcuts) && !!APP_SETTINGS.shortcuts[editIndex];
        const item=editing?APP_SETTINGS.shortcuts[editIndex]:{};
        return `
      <div class="row">
        <div class="field"><label>Nome</label><input id="shortcutName" type="text" value="${esc(item.name||'')}" placeholder="Ex.: Cloudflare"></div>
        <div class="field"><label>Descrição</label><input id="shortcutDesc" type="text" value="${esc(item.description||'')}" placeholder="Ex.: Gestão dos túneis"></div>
      </div>
      <div class="field" style="margin-top:8px"><label>URL</label><input id="shortcutUrl" type="url" value="${esc(item.url||'')}" placeholder="https://exemplo.pt"></div>
      <div class="actions" style="margin-top:8px">
        <button type="button" class="primary" onclick="saveShortcutForm()">${editing?'💾 Guardar alterações':'＋ Adicionar'}</button>
        ${editing?'<button type="button" onclick="cancelShortcutEdit()">Cancelar</button>':''}
      </div>`;
      })()}
      <div class="config-items v112-sort-list" style="margin-top:10px" data-v112-sort="shortcuts">
        ${(APP_SETTINGS.shortcuts||[]).map((v,i)=>`
          <div class="client v112-sort-item" data-id="${esc(v.id||('legacy_'+i))}">
            <span class="v112-handle" title="Arrastar para ordenar">☷</span>
            <div style="min-width:0;flex:1"><strong>${esc(v.name)}</strong><small>${esc(v.description||'')} · ${esc(v.url)}</small></div>
            <div class="actions"><button onclick="editShortcut(${i})">✏️</button><button onclick="deleteShortcut(${i})">🗑️</button></div>
          </div>`).join('')}
      </div>
    </div>
  ` + `
  ` + Object.keys(labels).map(key=>`
    <div class="card v577-collapsed v628-settings-card" data-v628-section="config-${esc(key)}" style="margin-bottom:12px">
      <h3><span class="v628-settings-handle" title="Arrastar para ordenar" aria-label="Arrastar para ordenar">☷</span><span class="v628-settings-label">${esc(labels[key])}</span></h3>
      ${(()=>{
        const editIndex=(window.v731EditingConfig && Number.isInteger(window.v731EditingConfig[key]))?window.v731EditingConfig[key]:null;
        const list=Array.isArray(CONFIG_LISTS[key])?CONFIG_LISTS[key]:[];
        const editing=editIndex!==null && editIndex>=0 && editIndex<list.length;
        const value=editing?String(list[editIndex]??''):'';
        return `
      <div class="actions">
        <input id="new_${key}" placeholder="Ex.: Adicionar opção" value="${esc(value)}">
        <button class="primary" type="button" onclick="${editing?`saveConfigEdit('${key}',${editIndex})`:`addConfig('${key}')`}">${editing?'💾 Guardar alterações':'＋ Adicionar'}</button>
        ${editing?`<button type="button" onclick="cancelConfigEdit('${key}')">Cancelar</button>`:''}
      </div>`;
      })()}
      <div class="config-items v112-sort-list" data-v112-sort="config" data-v112-key="${esc(key)}">${(CONFIG_LISTS[key]||[]).map((v,i)=>`
        <div class="client v112-sort-item" data-id="${esc(String(v))}">
          <span class="v112-handle" title="Arrastar para ordenar">☷</span>
          <span style="flex:1;min-width:0">${esc(v)}</span>
          <div class="actions">
            <button type="button" onclick="editConfig('${key}',${i})">✏️</button>
            <button type="button" onclick="deleteConfig('${key}',${i})">🗑️</button>
          </div>
        </div>`).join('')}</div>
    </div>`).join('');
  try{ v117RenderCatalog(); }catch(e){}
  try{ v628ApplySettingsOrder(); }catch(e){}
  // Ao reconstruir Configurações, mantém exatamente os submenus que estavam
  // abertos/fechados e a posição do utilizador. Uma gravação/edição/remoção
  // não deve fechar o submenu em que o utilizador estava.
  try{ v586RestoreSettingsSections(preservedSections); }catch(e){}
  requestAnimationFrame(()=>window.scrollTo({top:preservedScrollY,behavior:'auto'}));
}
function v628ApplySettingsOrder(){
  const box=document.getElementById('settingsForm');
  if(!box)return;
  const cards=[...box.querySelectorAll(':scope > .v628-settings-card')];
  if(!cards.length)return;
  let order=[];
  try{ order=JSON.parse(localStorage.getItem('amClientesSettingsMenuOrder')||'[]'); }catch(_){ order=[]; }
  const byKey=new Map(cards.map(card=>[String(card.dataset.v628Section||''),card]));
  const used=new Set();
  order.forEach(key=>{
    const card=byKey.get(String(key||''));
    if(card){ box.appendChild(card); used.add(String(key)); }
  });
  cards.forEach(card=>{
    const key=String(card.dataset.v628Section||'');
    if(!used.has(key)) box.appendChild(card);
  });
}
function addShortcut(){
  const name=(document.getElementById('shortcutName')?.value||'').trim();
  const description=(document.getElementById('shortcutDesc')?.value||'').trim();
  const raw=(document.getElementById('shortcutUrl')?.value||'').trim();
  if(!name || !raw){ showAppAlert('Aviso','Preenche os campos antes de adicionar.'); return; }
  let url=raw;
  if(!/^https?:\/\//i.test(url)) url='https://'+url;
  try{ new URL(url); }catch(e){ showAppAlert('Aviso','O URL não é válido.'); return; }
  const before=snapshotState();
  if(!Array.isArray(APP_SETTINGS.shortcuts)) APP_SETTINGS.shortcuts=[];
  APP_SETTINGS.shortcuts.push({id:Date.now().toString(36)+Math.random().toString(36).slice(2,6),name,description,url});
  saveAppSettings();
  recordAction('Botão do Início adicionado','Atalho adicionado: '+name,before,snapshotState());
  renderSettings();
  renderHomeShortcuts();
}
function editShortcut(i){
  const v=APP_SETTINGS.shortcuts?.[i]; if(!v)return;
  // V730 — entra em modo de edição no próprio formulário.
  window.v730EditingShortcutIndex=i;
  const sectionState=v586CaptureSettingsSections();
  sectionState.shortcuts=true;
  const scrollY=window.scrollY||document.documentElement.scrollTop||0;
  renderSettings();
  v586RestoreSettingsSections(sectionState);
  requestAnimationFrame(()=>{
    window.scrollTo({top:scrollY,behavior:'auto'});
    const input=document.getElementById('shortcutName');
    if(input){input.focus();input.select();}
  });
}
function cancelShortcutEdit(){
  window.v730EditingShortcutIndex=null;
  const sectionState=v586CaptureSettingsSections();
  const scrollY=window.scrollY||document.documentElement.scrollTop||0;
  renderSettings();
  v586RestoreSettingsSections(sectionState);
  requestAnimationFrame(()=>window.scrollTo({top:scrollY,behavior:'auto'}));
}
function saveShortcutForm(){
  const name=(document.getElementById('shortcutName')?.value||'').trim();
  const description=(document.getElementById('shortcutDesc')?.value||'').trim();
  const raw=(document.getElementById('shortcutUrl')?.value||'').trim();
  if(!name || !raw){ showAppAlert('Aviso','Preenche os campos antes de adicionar.'); return; }
  let url=raw;
  if(!/^https?:\/\//i.test(url)) url='https://'+url;
  try{new URL(url)}catch(e){showAppAlert('Aviso','O URL não é válido.');return;}
  const editIndex=Number.isInteger(window.v730EditingShortcutIndex)?window.v730EditingShortcutIndex:null;
  const before=snapshotState();
  if(editIndex!==null && Array.isArray(APP_SETTINGS.shortcuts) && APP_SETTINGS.shortcuts[editIndex]){
    const old=APP_SETTINGS.shortcuts[editIndex];
    APP_SETTINGS.shortcuts[editIndex]={...old,name,description,url};
    saveAppSettings();
    recordAction('Botão do Início alterado','Atalho alterado: '+name,before,snapshotState());
  }else{
    if(!Array.isArray(APP_SETTINGS.shortcuts)) APP_SETTINGS.shortcuts=[];
    APP_SETTINGS.shortcuts.push({id:Date.now().toString(36)+Math.random().toString(36).slice(2,6),name,description,url});
    saveAppSettings();
    recordAction('Botão do Início adicionado','Atalho adicionado: '+name,before,snapshotState());
  }
  window.v730EditingShortcutIndex=null;
  const sectionState=v586CaptureSettingsSections();
  const scrollY=window.scrollY||document.documentElement.scrollTop||0;
  renderSettings();
  v586RestoreSettingsSections(sectionState);
  renderHomeShortcuts();
  requestAnimationFrame(()=>window.scrollTo({top:scrollY,behavior:'auto'}));
}
async function deleteShortcut(i){
  const v=APP_SETTINGS.shortcuts?.[i]; if(!v)return;
  const confirmed=await showAppConfirm('Apagar botão?','Tem a certeza que pretende apagar o botão "'+v.name+'"?','Apagar','Cancelar');
  if(!confirmed)return;
  const before=snapshotState();
  APP_SETTINGS.shortcuts.splice(i,1);
  saveAppSettings();
  recordAction('Botão do Início apagado','Atalho apagado: '+v.name,before,snapshotState());
  renderSettings(); renderHomeShortcuts();
}
function openShortcut(i){
  const v=APP_SETTINGS.shortcuts?.[i]; if(!v?.url)return;
  window.open(v.url,'_blank','noopener,noreferrer');
}
function renderHomeShortcuts(){
  const box=document.getElementById('homeShortcuts'); if(!box)return;
  const arr=Array.isArray(APP_SETTINGS.shortcuts)?APP_SETTINGS.shortcuts:[];
  box.innerHTML=`<div class="card" style="padding:14px">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px"><h2 style="margin:0">🔗 Atalhos</h2></div>
    ${arr.length ? `<div class="shortcut-grid v112-home-sort" data-v112-sort="home-shortcuts">${arr.map((v,i)=>`
      <div class="v112-home-item" data-id="${esc(v.id||('legacy_'+i))}">
        <button class="shortcut-card" onclick="openShortcut(${i})" title="${esc(v.url)}"><strong>${esc(v.name)}</strong>${v.description?`<small>${esc(v.description)}</small>`:''}</button>
      </div>`).join('')}</div>` : `<div style="color:var(--muted);font-size:14px;padding:4px 0 2px">Ainda não existem atalhos. Pode adicioná-los em Configurações.</div>`}
  </div>`;
}

function saveAppIdentity(){
  const input=document.getElementById('appTitleInput');
  const title=(input?.value||'').trim()||'AM Clientes';
  APP_SETTINGS.title=title;
  saveAppSettings();
  renderSettings();
  recordAction('configuração','Apresentação da aplicação alterada');
}
function v586CompanyField(id){
  return (document.getElementById(id)?.value||'').trim();
}
function v586EditActiveCompany(){
  window.v586AddingCompany=false;
  window.v586EditingCompany=true;
  const sectionState=v586CaptureSettingsSections();
  sectionState['company-data']=true;
  const scrollY=window.scrollY||document.documentElement.scrollTop||0;
  renderSettings();
  v586RestoreSettingsSections(sectionState);
  requestAnimationFrame(()=>{
    window.scrollTo({top:scrollY,behavior:'auto'});
    const input=document.getElementById('companyLegalName');
    if(input){input.focus();input.select();}
  });
}
function v586CancelCompanyEdit(){
  window.v586AddingCompany=false;
  window.v586EditingCompany=false;
  const sectionState=v586CaptureSettingsSections();
  sectionState['company-data']=false;
  const scrollY=window.scrollY||document.documentElement.scrollTop||0;
  renderSettings();
  v586RestoreSettingsSections(sectionState);
  requestAnimationFrame(()=>window.scrollTo({top:scrollY,behavior:'auto'}));
}
function v586CaptureSettingsSections(){
  const box=document.getElementById('settingsForm');
  const state={};
  if(!box)return state;
  box.querySelectorAll(':scope > .v628-settings-card').forEach(card=>{
    const key=String(card.dataset.v628Section||'');
    if(key) state[key]=!card.classList.contains('v577-collapsed');
  });
  return state;
}
function v586RestoreSettingsSections(state){
  const box=document.getElementById('settingsForm');
  if(!box)return;
  box.querySelectorAll(':scope > .v628-settings-card').forEach(card=>{
    const key=String(card.dataset.v628Section||'');
    if(Object.prototype.hasOwnProperty.call(state,key)){
      card.classList.toggle('v577-collapsed',!state[key]);
    }
  });
}
function v586SaveCompanyData(){
  const legalName=v586CompanyField('companyLegalName');
  const companyData={
    legalName,
    responsible:v586CompanyField('companyResponsible'),
    email:v586CompanyField('companyEmail'),
    phone:v586CompanyField('companyPhone'),
    address:v586CompanyField('companyAddress'),
    postalCode:v586CompanyField('companyPostalCode'),
    locality:v586CompanyField('companyLocality'),
    nif:v586CompanyField('companyNif'),
    website:v586CompanyField('companyWebsite')
  };

  if(window.v586AddingCompany===true){
    if(!legalName){ showAppAlert('Aviso','Preenche o campo antes de adicionar.'); return; }

    const id='company_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);
    const clean=legalName;
    const emptyClients=[];
    const emptyArchived=[];
    const emptyActivity=[];
    const emptySubscriptions=[];
    const emptyCatalog=[];
    const emptyConfig=Object.fromEntries(Object.keys(DEFAULT_LISTS).map(key=>[key,[]]));

    APP_SETTINGS.companyProfiles.push({id,name:clean,data:companyData});
    APP_SETTINGS.activeCompanyId=id;

    // Depois de o utilizador criar uma empresa, a base já não está vazia.
    // É fundamental limpar o marcador criado pelo Limpar base de dados;
    // caso contrário, no arranque seguinte a rotina de inicialização poderia
    // voltar a substituir APP_SETTINGS pela empresa estrutural vazia.
    if(typeof v676SetGlobalDatabaseEmpty==='function') v676SetGlobalDatabaseEmpty(false);

    // Primeiro guardar a própria empresa.
    saveAppSettings();

    // Depois criar todas as bases da nova empresa, separadas das restantes.
    v592SaveCompanyData('amClientesDB',emptyClients);
    v592SaveCompanyData('amClientesArchived',emptyArchived);
    v592SaveCompanyData('amClientesActivity',emptyActivity);
    localStorage.setItem(v618SubscriptionsStorageKey(),JSON.stringify(emptySubscriptions));
    ['equipamentos','produtos','servicos','marcas'].forEach(type=>{
      localStorage.setItem(v618CatalogStorageKey(type),JSON.stringify(emptyCatalog));
    });
    localStorage.setItem('am_v117_service_catalog__'+id,JSON.stringify([]));
    localStorage.setItem(v743ConfigListsStorageKey(),JSON.stringify(emptyConfig));
    localStorage.setItem('amTemplates__'+id,JSON.stringify({}));

    DATA=[];
    ARCHIVED=[];
    ACTIVITY=[];
    SUBSCRIPTIONS=[];
    CONFIG_LISTS=structuredClone(emptyConfig);
    templates={};
    selected=null;

    // Manter o formulário de empresas aberto após guardar.
    // A nova empresa fica ativa, mas o formulário continua em modo de adição
    // e o campo Nome da empresa permanece vazio para a próxima empresa.
    window.v586AddingCompany=true;
    window.v586EditingCompany=false;

    v589RenderCompanySwitcher();
    if(typeof render==='function') render();
    if(typeof renderSubscriptions==='function') renderSubscriptions();
    if(typeof v117LoadCatalog==='function') v117LoadCatalog();
    if(typeof renderSettings==='function'){
      const state=v586CaptureSettingsSections();
      state['company-data']=true;
      renderSettings();
      v586RestoreSettingsSections(state);
    }

    recordAction('configuração','Empresa adicionada: '+clean);
    return;
  }

  const profile=v586GetActiveCompany();
  const sectionState=v586CaptureSettingsSections();
  const scrollY=window.scrollY||document.documentElement.scrollTop||0;

  profile.name=legalName||profile.name||'Empresa sem nome';
  profile.data=companyData;

  saveAppSettings();
  window.v586EditingCompany=false;
  v589RenderCompanySwitcher();
  renderSettings();
  v586RestoreSettingsSections(sectionState);
  requestAnimationFrame(()=>window.scrollTo({top:scrollY,behavior:'auto'}));
  recordAction('configuração','Dados da empresa atualizados: '+profile.name);
}
function v586SwitchCompany(id){
  const profiles=APP_SETTINGS.companyProfiles||[];
  if(!profiles.some(profile=>profile.id===id))return;

  window.v586AddingCompany=false;
  window.v586EditingCompany=false;
  APP_SETTINGS.activeCompanyId=id;
  saveAppSettings();
  v589CloseCompanySwitcher();

  v592LoadActiveCompanyClientData();
  if(typeof loadSubscriptions==='function') loadSubscriptions();
  if(typeof loadConfigLists==='function') loadConfigLists();
  if(typeof v117LoadCatalog==='function') v117LoadCatalog();

  renderSettings();
}
function v586AddCompany(){
  window.v586AddingCompany=true;
  window.v586EditingCompany=false;
  const sectionState=v586CaptureSettingsSections();
  sectionState['company-data']=true;
  const scrollY=window.scrollY||document.documentElement.scrollTop||0;
  renderSettings();
  v586RestoreSettingsSections(sectionState);
  requestAnimationFrame(()=>{
    window.scrollTo({top:scrollY,behavior:'auto'});
    const input=document.getElementById('companyLegalName');
    if(input){input.focus();input.select();}
  });
}

async function v586DeleteActiveCompany(){
  const profile=v586GetActiveCompany();
  if((APP_SETTINGS.companyProfiles||[]).length<=1)return;
  const confirmed=await showAppConfirm('Remover empresa?','Tem a certeza que pretende remover a empresa "'+profile.name+'"?','Remover','Cancelar');
  if(!confirmed)return;
  APP_SETTINGS.companyProfiles=APP_SETTINGS.companyProfiles.filter(item=>item.id!==profile.id);
  APP_SETTINGS.activeCompanyId=APP_SETTINGS.companyProfiles[0].id;
  saveAppSettings();
  v589RenderCompanySwitcher();
  renderSettings();
  recordAction('configuração','Empresa removida: '+profile.name);
}

// V731 — os restantes menus de Configurações usam exatamente o mesmo
// comportamento de edição inline já aplicado às empresas e aos atalhos.
// Nunca usar prompt() para editar uma opção.
if(!window.v731EditingConfig) window.v731EditingConfig={};

function addConfig(key){
  const el=document.getElementById('new_'+key), v=(el?.value||'').trim();
  if(!v){
    showAppAlert('Aviso','Preenche o campo antes de adicionar.');
    el?.focus();
    return;
  }
  const before=snapshotState();
  if(!CONFIG_LISTS[key])CONFIG_LISTS[key]=[];
  if(CONFIG_LISTS[key].includes(v)){
    showAppAlert('Aviso','Essa opção já existe.');
    el?.focus();
    return;
  }
  CONFIG_LISTS[key].push(v);
  recordAction('Configuração adicionada','Opção adicionada em '+key+': '+v,before,snapshotState());
  saveConfigLists();

  const sectionState=v586CaptureSettingsSections();
  sectionState['config-'+key]=true;
  const scrollY=window.scrollY||document.documentElement.scrollTop||0;
  renderSettings();
  v586RestoreSettingsSections(sectionState);
  requestAnimationFrame(()=>window.scrollTo({top:scrollY,behavior:'auto'}));
}

function editConfig(key,i){
  const list=Array.isArray(CONFIG_LISTS[key])?CONFIG_LISTS[key]:[];
  const index=Number(i);
  if(!Number.isInteger(index)||index<0||index>=list.length)return;
  window.v731EditingConfig[key]=index;

  const sectionState=v586CaptureSettingsSections();
  sectionState['config-'+key]=true;
  const scrollY=window.scrollY||document.documentElement.scrollTop||0;
  renderSettings();
  v586RestoreSettingsSections(sectionState);
  requestAnimationFrame(()=>{
    window.scrollTo({top:scrollY,behavior:'auto'});
    const input=document.getElementById('new_'+key);
    if(input){input.focus();input.select();}
  });
}

function cancelConfigEdit(key){
  if(window.v731EditingConfig) delete window.v731EditingConfig[key];

  const sectionState=v586CaptureSettingsSections();
  sectionState['config-'+key]=true;
  const scrollY=window.scrollY||document.documentElement.scrollTop||0;
  renderSettings();
  v586RestoreSettingsSections(sectionState);
  requestAnimationFrame(()=>window.scrollTo({top:scrollY,behavior:'auto'}));
}

function saveConfigEdit(key,i){
  const list=Array.isArray(CONFIG_LISTS[key])?CONFIG_LISTS[key]:[];
  const index=Number(i);
  if(!Number.isInteger(index)||index<0||index>=list.length)return;

  const el=document.getElementById('new_'+key);
  const novo=(el?.value||'').trim();
  if(!novo){
    showAppAlert('Aviso','Preenche o campo antes de guardar.');
    el?.focus();
    return;
  }

  const old=String(list[index]??'');
  if(novo!==old && list.some((v,n)=>n!==index && String(v)===novo)){
    showAppAlert('Aviso','Essa opção já existe.');
    el?.focus();
    return;
  }

  const before=snapshotState();
  list[index]=novo;

  recordAction(
    'Configuração renomeada',
    'Opção renomeada em '+key+': '+old+' → '+novo,
    before,
    snapshotState()
  );

  saveConfigLists();
  if(window.v731EditingConfig) delete window.v731EditingConfig[key];

  const sectionState=v586CaptureSettingsSections();
  sectionState['config-'+key]=true;
  const scrollY=window.scrollY||document.documentElement.scrollTop||0;
  renderSettings();
  v586RestoreSettingsSections(sectionState);
  requestAnimationFrame(()=>window.scrollTo({top:scrollY,behavior:'auto'}));
}

async function deleteConfig(key,i){
  const list=Array.isArray(CONFIG_LISTS[key])?CONFIG_LISTS[key]:[];
  const index=Number(i);
  if(!Number.isInteger(index)||index<0||index>=list.length)return;
  const v=String(list[index]??'');
  if(!v)return;
  const confirmed=await showAppConfirm('Apagar opção?','Tem a certeza que pretende apagar "'+v+'"?','Apagar','Cancelar');
  if(!confirmed)return;

  const before=snapshotState();
  list.splice(index,1);

  recordAction(
    'Configuração apagada',
    'Opção apagada em '+key+': '+v,
    before,
    snapshotState()
  );

  saveConfigLists();
  renderSettings();
}

const FORM_FIELDS=[
['Nome','Nome'],['Nome Empresa','Nome Empresa'],['Contacto','Contacto'],['Email','Email'],['Morada','Morada'],
['Serviço','Serviço'],['Descrição Manutenção','Descrição do Serviço'],['Preço','Valor'],['Saldo','Saldo'],['Periodicidade','Periodicidade'],
['Pagamento','Pagamento'],['Método Pagamento','Método Pagamento'],['Validade','Validade'],
['VPN','VPN'],['Utilizador VPN','Utilizador VPN'],['Password VPN','Password VPN'],['Subscrição','Subscrição'],['Equipamento','Equipamento'],
['Mac Adress','Mac Adress'],['Utilizador','Utilizador'],['Senha','Senha'],['Link','Link'],['Pacote','Pacote'],
['Tempo','Tempo'],['Data Instalação','Data Instalação'],['Estado Cliente','Estado Cliente'],['Observações','Observações']
];
function newClient(){
  const c={};
  FORM_FIELDS.forEach(([k])=>c[k]='');
  c['ID Cliente']=nextId();

  // Guardar exatamente de onde abrimos o formulário.
  // Se o utilizador estiver na lista completa de Clientes, o Cancelar
  // deve regressar à mesma lista aberta, e não ao Início.
  const full=document.getElementById('todosClientes');
  const fullOpen=!!full && !full.classList.contains('hidden');
  editReturnContext={
    type:fullOpen?'full':'home',
    mode:fullOpen?(currentListMode||'all'):'all'
  };
  window.editorInClients=true;

  // Move the existing editor container into Clientes while creating a client.
  // The form itself is unchanged; only its location in the UI changes.
  const ef=document.getElementById('editForm');
  const clients=document.getElementById('clientes');
  if(ef && clients && ef.parentElement!==clients) clients.appendChild(ef);

  showEditor(c,true);
}
function editClient(id,source){
 const c=DATA.find(x=>String(x['ID Cliente'])===String(id));
 if(!c)return;
 const full=document.getElementById('todosClientes');
 const fullOpen=!!full && !full.classList.contains('hidden');
 editReturnContext={
   type:source==='subscription'?'subscription':(fullOpen?'full':'home'),
   mode:currentListMode
 };

 // A edição de clientes pertence ao contexto Clientes, quer seja iniciada
 // a partir da lista completa quer a partir do Início. Só as subscrições
 // mantêm o comportamento próprio da Gestão.
 window.editorInClients=source!=='subscription';
 if(window.editorInClients){
   const ef=document.getElementById('editForm');
   const clients=document.getElementById('clientes');
   if(ef && clients && ef.parentElement!==clients) clients.appendChild(ef);
 }
 showEditor(c,false);
}

function clientSelectField(key,label,inputId,current){
  const arr=CONFIG_LISTS[key]||[];
  const options=arr.map(v=>'<option value="'+esc(v)+'" '+(String(v)===String(current)?'selected':'')+'>'+esc(v)+'</option>').join('');
  const isCustom=current && !arr.includes(current);
  return '<div class="field"><label>'+esc(label)+'</label>'+
    '<select class="client-placeholder-select '+(current?'has-value':'')+'" id="'+inputId+'_select" onchange="syncClientSelect(\''+key+'\',\''+inputId+'\'); this.classList.toggle(\'has-value\', !!this.value)"'+(key==='periodicidades'?' ; v117RenderEquipments(); v117UpdatePaymentBalance();':'')+'>'+
    '<option value="">Selecionar empresa</option>'+options+
    '<option value="__custom__" '+(isCustom?'selected':'')+'>✏️ Outro...</option></select>'+
    '<input id="'+inputId+'" type="text" value="'+esc(current||'')+'" '+
    'style="margin-top:6px;'+(isCustom?'':'display:none')+'" placeholder="Ex.: Escrever outro">'+
    '</div>';
}
function clientPaidValueField(current){
  const arr=Array.isArray(CONFIG_LISTS.valores)?CONFIG_LISTS.valores:[];
  const norm=v=>String(v??'').replace(/\s/g,'').replace('€','').replace(/\./g,'').replace(',','.');
  const currentN=norm(current);
  const exists=arr.some(v=>norm(v)===currentN && currentN!=='');
  const options=arr.map(v=>{
    const n=norm(v);
    const label=(Number.isFinite(Number(n))?Math.round(Number(n))+' €':String(v));
    return '<option value="'+esc(v)+'" '+(n===currentN&&currentN!==''?'selected':'')+'>'+esc(label)+'</option>';
  }).join('');
  const custom=current && !exists;
  return '<div class="field"><label>Valor pago</label>'+
    '<select id="f_Preço_select" onchange="syncPaidValueSelect()">'+
    '<option value="">Selecionar valor pago</option>'+options+
    '<option value="__custom__" '+(custom?'selected':'')+'>✏️ Outro valor...</option></select>'+
    '<div class="currency-input" style="margin-top:6px;'+(custom||!arr.length?'':'display:none')+'">'+
    '<input id="f_Preço" type="text" inputmode="numeric" value="'+esc(current||'')+'" '+
    'oninput="v117UpdatePaymentBalance()" placeholder="Ex.: Valor pago">'+
    '</div>'+
    '</div>';
}
function syncPaidValueSelect(){
  const s=document.getElementById('f_Preço_select');
  const i=document.getElementById('f_Preço');
  if(!s||!i)return;
  if(s.value==='__custom__'){
    i.style.display='block';
    i.value='';
    i.focus();
  }else{
    i.value=s.value;
    i.style.display='none';
    if(typeof v117UpdatePaymentBalance==='function')v117UpdatePaymentBalance();
  }
}
function syncClientSelect(key,inputId){
  const s=document.getElementById(inputId+'_select');
  const i=document.getElementById(inputId);
  if(!s||!i)return;
  if(s.value==='__custom__'){
    i.style.display='block';i.value='';i.focus();
  }else{
    i.value=s.value;i.style.display='none';
  }
}
function returnFromEditor(id){
 const ctx=editReturnContext||{type:'home',mode:'all'};
 window.editorInClients=false;

 // Primeiro regressa ao ecrã normal.
 if(ctx.type==='home') goHome();
 else view('clientes');

 if(ctx.type==='full' || ctx.type==='subscription'){
   const homeLayout=document.querySelector('#clientes .layout');
   const p=document.getElementById('todosClientes');

   if(homeLayout) homeLayout.classList.add('hidden');
   if(p) p.classList.remove('hidden');

   currentListMode=ctx.mode||'all';

   const title=document.getElementById('listTitle');
   if(title) title.textContent=
     currentListMode==='active'?'🟢 Clientes ativos':
     currentListMode==='warning'?'🟠 Clientes a expirar':
     currentListMode==='expired'?'🔴 Clientes expirados':'📋 Clientes';

   const fs=document.getElementById('fullSearch');
   if(fs) fs.value='';

   renderFullClients();

   selected=null;
   if(id) selectClient(id);
 }else{
   const homeLayout=document.querySelector('#clientes .layout');
   const p=document.getElementById('todosClientes');

   if(p) p.classList.add('hidden');
   if(homeLayout) homeLayout.classList.remove('hidden');

   currentListMode='all';
   selected=null;

   render();
   if(id) selectClient(id);
 }

 // A remoção é feita no fim do ciclo de renderização, como acontece após
 // um refresh: só então o formulário deixa definitivamente de estar em Clientes.
 requestAnimationFrame(()=>{
   requestAnimationFrame(()=>{
     const clients=document.getElementById('clientes');
     const gestaoBody=document.getElementById('gestaoBody');
     const ef=document.getElementById('editForm');

     if(ef && clients && ef.parentElement===clients){
       clients.removeChild(ef);
       if(gestaoBody) gestaoBody.appendChild(ef);
     }else if(ef && gestaoBody && ef.parentElement!==gestaoBody){
       gestaoBody.appendChild(ef);
     }

     const finalEditor=document.getElementById('editForm');
     if(finalEditor){
       finalEditor.innerHTML='';
       finalEditor.hidden=true;
     }
   });
 });
}

function subscriptionField(label,inputId,current){
  const arr=Array.isArray(SUBSCRIPTIONS)?SUBSCRIPTIONS:[];
  const options=arr.map(s=>{
    const value=s.name||'';
    return '<option value="'+esc(value)+'" '+(String(value)===String(current||'')?'selected':'')+'>'+esc(value)+'</option>';
  }).join('');
  return '<div class="field"><label>'+esc(label)+'</label>'+
    '<select id="'+inputId+'_select" onchange="syncSubscriptionSelect(\''+inputId+'\')">'+
    '<option value="">— Nenhuma —</option>'+options+
    '<option value="__custom__" '+(current && !arr.some(s=>String(s.name)===String(current))?'selected':'')+'>✏️ Outra...</option></select>'+
    '<input id="'+inputId+'" type="text" value="'+esc(current||'')+'" '+
    'style="margin-top:6px;'+(current && !arr.some(s=>String(s.name)===String(current))?'':'display:none')+'" placeholder="Ex.: Escrever outra">'+
    '</div>';
}
function syncSubscriptionSelect(inputId){
  const s=document.getElementById(inputId+'_select');
  const i=document.getElementById(inputId);
  if(!s||!i)return;
  if(s.value==='__custom__'){
    i.style.display='block';i.value='';i.focus();
  }else{
    i.value=s.value;i.style.display='none';
  }
}
function linkedSubscriptionClients(subName){
  if(!subName)return [];
  const target=String(subName).trim();
  return DATA.filter(c=>String(c['Subscrição']||'').trim()===target);
}
function subscriptionLinkedCount(s){
  if(!s)return 0;
  // Cada cliente que tenha esta subscrição atribuída conta como 1 equipamento/licença.
  // Não obrigamos o campo "Equipamento" a estar preenchido para fazer a contagem.
  const linked=linkedSubscriptionClients(s.name).length;
  const manual=Array.isArray(s.devices)
    ? s.devices.filter(d=>String(d?.name||'').trim()).length
    : 0;
  return linked+manual;
}

function v183Money(v){
  if(v==null||v==='')return 0;
  return Number(String(v).replace(/\s/g,'').replace(/€/g,'').replace(/\./g,'').replace(',','.'))||0;
}
function v183EquipmentMainServiceValue(e){
  if(!e)return 0;
  const explicit=v183Money(e.servicoValor);
  if(explicit)return explicit;
  const cat=Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[];
  const svc=cat.find(s=>String(s.name||'')===String(e.servico||''));
  return v183Money(svc?.value||0);
}
function v183EquipmentTotal(e){
  return v117EquipmentServiceTotal(e);
}
function v183EquipmentBalance(e){
  return v183Money(e?.valorPago)-v183EquipmentTotal(e);
}
function v183SyncEquipmentService(i){
  const e=window.v117EditorEquipments?.[i];
  if(!e)return;
  const svc=Array.isArray(v117ServiceCatalog)?v117ServiceCatalog.find(s=>String(s.name||'')===String(e.servico||'')):null;
  e.servicoValor=v183Money(svc?.value||e.servicoValor||0);
  const value=document.getElementById(`v183_servico_valor_${i}`);
  if(value)value.value=e.servicoValor?String(Math.round(e.servicoValor))+' €':'';
  const saldo=document.getElementById(`v183_saldo_${i}`);
  if(saldo)saldo.value=String(Math.round(v183EquipmentBalance(e)))+' €';
}
function v183InitClient(c,isNew){
  if(!c)return;
  if(!c['Data Criação']) c['Data Criação']=c['Data Instalação']||'';
  if(!Array.isArray(c.equipamentos)) c.equipamentos=[];
  if(!c.equipamentos.length && !isNew && (c['Serviço']||c['Validade']||c['Preço']||c['Data Instalação'])){
    c.equipamentos=[{
      id:'eq_migr_'+Date.now().toString(36),
      nome:c['Equipamento']||'',
      tipo:'',
      mac:c['Mac Adress']||'',
      utilizador:c['Utilizador']||'',
      senha:c['Senha']||'',
      link:c['Link']||'',
      servico:c['Serviço']||'',
      servicoValor:v183Money(c['Serviço Valor']),
      periodicidade:c['Periodicidade']||'',
      dataInstalacao:c['Data Instalação']||'',
      dataPagamento:c['Pagamento']||'',
      validade:c['Validade']||'',
      valorPago:v183Money(c['Preço']),
      vpns:[],
      servicos:[]
    }];
  }
}
function showEditor(c,isNew){
  const ef=document.getElementById('editForm');
  if(ef) ef.hidden=false;
  v183InitClient(c,isNew);
  if(window.editorInClients) {
    // O editor deve ocupar sozinho a secção Clientes, tal como acontecia
    // quando a edição era aberta a partir da própria lista de Clientes.
    // Assim, ao editar a partir do Início, não fica o formulário no fim da página.
    view('clientes');
    const homeLayout=document.querySelector('#clientes .layout');
    const fullPanel=document.getElementById('todosClientes');
    const homeShortcuts=document.getElementById('homeShortcuts');
    if(homeLayout) homeLayout.classList.add('hidden');
    if(fullPanel) fullPanel.classList.add('hidden');
    // Durante a edição, a secção Clientes fica totalmente isolada: também
    // escondemos os atalhos do Início para ficar apenas o formulário.
    if(homeShortcuts) homeShortcuts.classList.add('hidden');

    setTimeout(()=>{
      const ef=document.getElementById('editForm');
      if(ef) ef.scrollIntoView({behavior:'smooth',block:'start'});
    },50);
  } else view('gestao');
  v117InitEquipments(c);
  v147SyncServicesFromCatalog();

  const CLIENT_EDIT_FIELDS=[
    ['Nome','Nome'],['Observações','Observações'],['Contacto','Contacto'],
    ['Nome Empresa','Nome Empresa'],['Email','Email'],['Morada','Morada'],
    ['Data Criação','Data de criação']
  ];

  editForm.innerHTML='<h3>'+ (isNew?'Novo cliente':'Editar cliente') +' · '+esc(c['ID Cliente'])+'</h3><div class="row client-form">'+
  CLIENT_EDIT_FIELDS.map(([k,l])=>{
    const lists={'Nome Empresa':'empresas','Método Pagamento':'pagamentos'};
    if(lists[k]) return clientSelectField(lists[k],l,'f_'+css(k),c[k]||'');
    const type=k==='Data Criação'?'date':'text';
    const placeholders={
      'Nome':'Ex.: Nome do cliente',
      'Observações':'Ex.: Observações sobre o cliente',
      'Contacto':'Ex.: Número de contacto',
      'Email':'Ex.: email@cliente.pt',
      'Morada':'Ex.: Morada do cliente',
      'Data Criação':'Ex.: Data de criação'
    };
    const ph=placeholders[k]||'';
    if(k==='Data Criação'){
      const hasDate=!!(c[k]||'');
      return `<div class="field"><label>${esc(l)}</label><div class="client-date-input-wrap ${hasDate?'has-value':''}"><input id="f_${css(k)}" type="date" value="${esc(c[k]||'')}" onfocus="this.parentElement.classList.add('is-focused')" onblur="this.parentElement.classList.remove('is-focused')" oninput="this.parentElement.classList.toggle('has-value',!!this.value)"><span class="client-date-placeholder">Selecionar data</span></div></div>`;
    }
    return `<div class="field"><label>${esc(l)}</label><input id="f_${css(k)}" type="${type}" value="${esc(c[k]||'')}" placeholder="${esc(ph)}"></div>`;
  }).join('')+
  '</div><div id="v117EquipmentBox"></div><div class="actions client-editor-actions" style="margin-top:12px"><button type="button" class="primary" onclick="saveClient(\''+esc(c['ID Cliente'])+'\','+isNew+')">💾 Guardar</button>'+
  '<button type="button" onclick="returnFromEditor(\''+esc(c['ID Cliente'])+'\')">Cancelar</button>'+
  (!isNew?`<button type="button" onclick="deleteClient('${esc(c['ID Cliente'])}')">🗑️ Apagar</button>`:'')+
  '</div>';

  v117RenderEquipments();
}
function css(k){return k.replace(/[^a-zA-Z0-9]/g,'_')}
function saveClient(id,isNew){
 const before=snapshotState();
 const oldClient=DATA.find(x=>String(x['ID Cliente'])===String(id));
 const c=isNew ? {} : JSON.parse(JSON.stringify(oldClient||{}));

 ['Nome','Observações','Contacto','Nome Empresa','Email','Morada','Data Criação'].forEach(k=>{
   const el=document.getElementById('f_'+css(k));
   if(el)c[k]=el.value||'';
 });
 if(!c['Data Criação'])c['Data Criação']=new Date().toISOString().slice(0,10);

 c['ID Cliente']=id;
 c['equipamentos']=JSON.parse(JSON.stringify(window.v117EditorEquipments||[]));

 c['equipamentos'].forEach(e=>{
   const svc=(Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[]).find(s=>String(s.name||'')===String(e.servico||''));
   if(svc)e.servicoValor=Number(svc.value||0);

   (e.vpns||[]).forEach(v=>{
     const vs=(Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[]).find(s=>String(s.name||'')===String(v.nome||''));
     if(vs){
       v.valor=Number(vs.value||0);
       v.serviceId=vs.id||v.serviceId||'';
     }
   });

   e.saldo=String(Math.round(v183EquipmentBalance(e)));
 });

 // Compatibilidade com a base antiga. A nova lógica usa sempre c.equipamentos.
 const eq0=c.equipamentos[0]||{};
 c['Serviço']=String(eq0.servico||'');
 c['Periodicidade']=String(eq0.periodicidade||'');
 c['Método Pagamento']=String(eq0.metodoPagamento||'');
 c['Pagamento']=String(eq0.dataPagamento||'');
 c['Validade']=String(eq0.validade||'');
 c['Preço']=String(eq0.valorPago??'');
 c['Saldo']=String(Math.round(c.equipamentos.reduce((sum,e)=>sum+v183EquipmentBalance(e),0)));
 c['Data Instalação']=String(eq0.dataInstalacao||'');
 c['Equipamento']=String(eq0.nome||'');
 c['Mac Adress']=String(eq0.mac||'');
 c['Utilizador']=String(eq0.utilizador||'');
 c['Senha']=String(eq0.senha||'');
 c['Link']=String(eq0.link||'');

 const vpn0=(Array.isArray(eq0.vpns)&&eq0.vpns.length)?eq0.vpns[0]:null;
 c['VPN']=String(vpn0?.nome||eq0.vpn||'');
 c['Utilizador VPN']=String(vpn0?.utilizador||'');
 c['Password VPN']=String(vpn0?.senha||'');
 c['Subscrição']=String(eq0.subscricao||vpn0?.subscricao||'');
 c['Estado Cliente']='';

 if(isNew){
   DATA.push(c);
   recordAction('Cliente criado','Novo cliente criado: '+clientName(c),before,snapshotState());
 }else{
   const i=DATA.findIndex(x=>String(x['ID Cliente'])===String(id));
   if(i>=0){
     DATA[i]=c;
     const fields=changedFields(oldClient,c);
     let detail='Cliente alterado: '+clientName(c);
     if(fields.length)detail+=' — campos: '+fields.join(', ');
     recordAction('Cliente editado',detail,before,snapshotState());
   }
 }
 saveDB();
 try{
   renderEstatisticas();
   loadSubscriptions();
   renderSubscriptions();
 }catch(e){}
 // Atualizar imediatamente toda a interface antes de fechar o editor.
 // Assim, os contadores e a lista já mostram o novo cliente sem precisar de refresh.
 render();
 try{
   renderFullClients();
 }catch(e){}

 returnFromEditor(id);

 // Garantia final: depois de o editor sair, atualizar novamente os contadores/listas
 // no próximo ciclo visual, mantendo a mesma lógica de fecho do Cancelar.
 requestAnimationFrame(()=>{
   render();
   try{ renderFullClients(); }catch(e){}
 });
 alert('Cliente guardado com sucesso.');
}

function deleteClient(id){
 const c=DATA.find(x=>String(x['ID Cliente'])===String(id));
 if(!c)return;

 if(confirm('Apagar '+clientName(c)+'?\\n\\nEsta ação remove o cliente desta base local.')){
   const before=snapshotState();
   DATA=DATA.filter(x=>String(x['ID Cliente'])!==String(id));
   recordAction('Cliente apagado','Cliente apagado: '+clientName(c),before);
   saveDB();
   selected=null;

    // O cliente já foi removido: fechar imediatamente qualquer pré-visualização
    // que ainda esteja visível, tanto no Início como na lista completa.
    const d=document.getElementById('detail');
    if(d){
      d.classList.add('hidden');
      d.innerHTML='';
      d.dataset.openClientId='';
    }

    const fd=document.getElementById('fullClientDetail');
    if(fd){
      fd.classList.add('hidden');
      fd.innerHTML='';
      fd.dataset.openClientId='';
    }

    // Fechar também a área de edição que ficou aberta no fim da página.
    // Ao apagar, não deve permanecer nem pré-visualização nem formulário de edição.
    const ef=document.getElementById('editForm');
    if(ef){
      ef.innerHTML='';
      ef.classList.add('hidden');
      ef.style.display='none';
      ef.hidden=true;
    }
    window.editorInClients=false;

   const ctx=editReturnContext||{type:'home',mode:'all'};

   // Depois de apagar, regressar à lista de onde o cliente foi aberto.
   view('clientes');

   if(ctx.type==='full'){
     const homeLayout=document.querySelector('#clientes .layout');
     const p=document.getElementById('todosClientes');

     if(homeLayout) homeLayout.classList.add('hidden');
     if(p) p.classList.remove('hidden');

     currentListMode=ctx.mode||'all';

     const title=document.getElementById('listTitle');
     if(title) title.textContent=
       currentListMode==='active'?'🟢 Clientes ativos':
       currentListMode==='warning'?'🟠 Clientes a expirar':
       currentListMode==='expired'?'🔴 Clientes expirados':'📋 Clientes';

     const fs=document.getElementById('fullSearch');
     if(fs) fs.value='';

     const fd=document.getElementById('fullClientDetail');
     if(fd){fd.classList.add('hidden');fd.innerHTML='';}

     renderFullClients();
   }else{
     const homeLayout=document.querySelector('#clientes .layout');
     const p=document.getElementById('todosClientes');

     if(p) p.classList.add('hidden');
     if(homeLayout) homeLayout.classList.remove('hidden');

     currentListMode='all';

     const d=document.getElementById('detail');
     if(d){d.classList.add('hidden');d.innerHTML='';}

     render();
   }
 }
}
let dbFileHandle=null;
async function v170DownloadBlob(blob,filename,mime){
  if(window.AndroidDownloader && typeof window.AndroidDownloader.saveFile==='function'){
    const dataUrl=await new Promise((resolve,reject)=>{
      const reader=new FileReader();
      reader.onload=()=>resolve(String(reader.result||''));
      reader.onerror=()=>reject(reader.error||new Error('Não foi possível preparar o ficheiro.'));
      reader.readAsDataURL(blob);
    });
    const base64=dataUrl.split(',')[1]||'';
    return await new Promise((resolve,reject)=>{
      const previous=window.__amSaveCompleted;
      const timer=setTimeout(()=>{
        window.__amSaveCompleted=previous;
        reject(new Error('O Android não respondeu ao pedido para guardar o ficheiro.'));
      },30000);
      window.__amSaveCompleted=function(ok){
        clearTimeout(timer);
        window.__amSaveCompleted=previous;
        if(ok) resolve(true);
        else reject(new Error('O ficheiro não foi guardado.'));
      };
      try{ window.AndroidDownloader.saveFile(filename,mime,base64); }
      catch(e){ clearTimeout(timer); window.__amSaveCompleted=previous; reject(e); }
    });
  }
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download=filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
  return false;
}

async function saveToFile(){
  saveDB();
  const payload=JSON.stringify({
    version: 7,
    app: 'AM Clientes',
    savedAt: new Date().toISOString(),
    clientes: DATA,
    arquivados: ARCHIVED,
    listas: CONFIG_LISTS,
    mensagens: templates,
    atividade: ACTIVITY,
    appSettings: APP_SETTINGS
  },null,2);

  async function downloadCopy(){
    const blob=new Blob([payload],{type:'application/json'});
    await v170DownloadBlob(blob,'AM_Clientes_base.json','application/json');
  }

  try{
    if(!window.showSaveFilePicker){
      await downloadCopy();
      alert('💾 O navegador não permite guardar diretamente no mesmo ficheiro. Foi descarregada uma cópia atualizada.');
      return;
    }

    // Primeira tentativa: reutilizar o ficheiro escolhido anteriormente.
    if(dbFileHandle){
      try{
        const writable=await dbFileHandle.createWritable();
        await writable.write(payload);
        await writable.close();
        alert('💾 Base guardada no ficheiro.');
        return;
      }catch(e){
        // O handle pode ter ficado inválido depois de fechar/reabrir o HTML,
        // mover o ficheiro ou perder a permissão. Nesse caso, pede novamente
        // a localização do ficheiro em vez de bloquear o utilizador.
        dbFileHandle=null;
      }
    }

    // Novo ficheiro ou recuperação de um handle inválido.
    dbFileHandle=await window.showSaveFilePicker({
      suggestedName:'AM_Clientes_base.json',
      types:[{description:'Base AM Clientes',accept:{'application/json':['.json']}}]
    });

    const writable=await dbFileHandle.createWritable();
    await writable.write(payload);
    await writable.close();
    alert('💾 Base guardada no ficheiro. As próximas alterações serão guardadas no mesmo ficheiro.');
  }catch(e){
    if(e && e.name==='AbortError') return;

    // Se o Android/navegador não conseguir manter o acesso ao ficheiro,
    // não perde os dados: cria automaticamente uma cópia para download.
    try{
      await downloadCopy();
      alert('⚠️ O acesso ao ficheiro anterior expirou. Foi criada uma cópia atualizada da base de dados.');
    }catch(e2){
      alert('Não foi possível guardar a base de dados: '+(e?.message||e2?.message||e));
    }
  }
}
function excelEscape(v){
  return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
}
function excelSheet(name, rows){
  if(!Array.isArray(rows) || !rows.length) return '';
  const headers=[...new Set(rows.flatMap(r=>Object.keys(r||{})))];
  let x=`<Worksheet ss:Name="${excelEscape(name)}"><Table>`;
  x+='<Row>'+headers.map(h=>`<Cell><Data ss:Type="String">${excelEscape(h)}</Data></Cell>`).join('')+'</Row>';
  for(const r of rows){
    x+='<Row>'+headers.map(h=>{
      const v=r?.[h];
      const type=(typeof v==='number' && Number.isFinite(v))?'Number':'String';
      return `<Cell><Data ss:Type="${type}">${excelEscape(v)}</Data></Cell>`;
    }).join('')+'</Row>';
  }
  return x+'</Table></Worksheet>';
}
async function exportExcel(){
  const xml=`<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><Selected/></WorksheetOptions>
${excelSheet('Clientes',DATA)}
${excelSheet('Arquivados',ARCHIVED)}
${excelSheet('Atividade',ACTIVITY)}
${excelSheet('Subscricoes',SUBSCRIPTIONS)}
${excelSheet('Equipamentos',getCatalog('equipamentos'))}
${excelSheet('Produtos',getCatalog('produtos'))}
${excelSheet('Servicos',getCatalog('servicos'))}
${excelSheet('Marcas',getCatalog('marcas'))}
</Workbook>`;

  try{
    await v170DownloadBlob(new Blob([xml],{type:'application/vnd.ms-excel'}),'AM_Clientes_BACKUP_COMPLETO.xls','application/vnd.ms-excel');
    await showAppAlert('Cópia de segurança criada','A cópia de segurança Excel foi criada com sucesso.');
  }catch(e){
    if(e?.name==='AbortError') return;
    await showAppAlert('Não foi possível guardar','Não foi possível criar a cópia Excel: '+(e?.message||e));
  }
}

function parseExcelXml(text){
  const doc=new DOMParser().parseFromString(text,'application/xml');
  if(doc.querySelector('parsererror')) throw new Error('O ficheiro Excel não tem um formato compatível.');
  const sheets=[...doc.getElementsByTagNameNS('*','Worksheet')];
  const result={};
  for(const ws of sheets){
    const name=ws.getAttribute('ss:Name')||ws.getAttributeNS('urn:schemas-microsoft-com:office:spreadsheet','Name')||ws.getAttribute('Name')||'Sheet';
    const rows=[...ws.getElementsByTagNameNS('*','Row')].map(row=>[...row.getElementsByTagNameNS('*','Data')].map(d=>d.textContent));
    if(!rows.length) continue;
    const headers=rows[0];
    result[name]=rows.slice(1).filter(r=>r.some(v=>String(v).trim()!=='')).map(r=>Object.fromEntries(headers.map((h,i)=>[h,r[i]??''])));
  }
  return result;
}
// V701 — mensagens próprias na Gestão, sem o cabeçalho nativo "Esta página indica".
function showAppAlert(title,message,okText='OK'){
  return new Promise(resolve=>{
    const old=document.getElementById('amAlertOverlay');
    if(old) old.remove();
    const overlay=document.createElement('div');
    overlay.id='amAlertOverlay';
    overlay.className='am-confirm-overlay am-alert-overlay';
    overlay.innerHTML=`<div class="am-confirm-dialog am-alert-dialog" role="dialog" aria-modal="true" aria-labelledby="amAlertTitle">
      <h3 id="amAlertTitle"></h3><p id="amAlertMessage"></p>
      <div class="am-confirm-actions am-alert-actions"><button type="button" class="am-confirm-ok"></button></div>
    </div>`;
    const finish=()=>{overlay.remove();resolve();};
    overlay.querySelector('#amAlertTitle').textContent=title;
    overlay.querySelector('#amAlertMessage').textContent=message;
    const ok=overlay.querySelector('.am-confirm-ok');
    ok.textContent=okText; ok.onclick=finish;
    overlay.addEventListener('click',e=>{if(e.target===overlay)finish()});
    const onKey=e=>{if(e.key==='Escape'||e.key==='Enter'){document.removeEventListener('keydown',onKey);finish()}};
    document.addEventListener('keydown',onKey);
    document.body.appendChild(overlay);
    ok.focus();
  });
}

async function pickAppFile({description,accept}){
  if(window.showOpenFilePicker){
    const result=await window.showOpenFilePicker({
      multiple:false,
      types:[{description,accept}]
    });
    return {file:await result[0].getFile(),handle:result[0]};
  }
  const acceptList=Object.entries(accept||{}).flatMap(([mime,exts])=>[...(exts||[]),mime]).join(',');
  const file=await new Promise((resolve,reject)=>{
    const input=document.createElement('input');
    input.type='file'; input.accept=acceptList;
    input.onchange=()=>{const f=input.files?.[0]; f?resolve(f):reject(new DOMException('Seleção cancelada.','AbortError'));};
    input.click();
  });
  return {file,handle:null};
}

async function importExcel(){
  try{
    const picked=await pickAppFile({
      description:'Ficheiro Excel AM Clientes',
      accept:{'application/vnd.ms-excel':['.xls'], 'application/xml':['.xml'], 'text/xml':['.xml']}
    });
    const text=await picked.file.text();
    const sheets=parseExcelXml(text);
    const clientes=sheets.Clientes||sheets.clientes||[];
    const arquivados=sheets.Arquivados||sheets.arquivados||[];
    if(!clientes.length && !arquivados.length) throw new Error('Não encontrei uma folha Clientes válida neste ficheiro Excel.');
    DATA=structuredClone(clientes);
    ARCHIVED=structuredClone(arquivados);
    saveDB();
    v592SaveCompanyData('amClientesArchived',ARCHIVED);
    render();
    await showAppAlert('Ficheiro importado','O ficheiro Excel foi importado com sucesso.');
  }catch(e){
    if(e?.name!=='AbortError') await showAppAlert('Não foi possível importar','Não foi possível importar o Excel: '+(e?.message||e));
  }
}
// V676 — Separação entre "Repor" (exemplos) e "Limpar" (limpeza total de empresas e atalhos).
function v675EmptyBaseKey(){ return v592CompanyStorageKey('amClientesEmptyBase'); }
function v675IsBaseEmpty(){ return localStorage.getItem(v675EmptyBaseKey())==='1'; }
function v675SetBaseEmpty(v){
  if(v) localStorage.setItem(v675EmptyBaseKey(),'1');
  else localStorage.removeItem(v675EmptyBaseKey());
}

async function clearDatabase(){
  const confirmed=await showAppConfirm('Limpar base de dados?','Todos os clientes, histórico, subscrições e configurações desta base serão removidos.','Confirmar','Cancelar');
  if(!confirmed) return;

  // V167: a limpeza passa a ter uma única operação central e idempotente.
  // Todas as estruturas em memória são limpas antes de qualquer render.
  DATA=[];
  ARCHIVED=[];
  ACTIVITY=[];
  SUBSCRIPTIONS=[];
  CONFIG_LISTS=Object.fromEntries(Object.keys(DEFAULT_LISTS).map(key=>[key,[]]));
  templates={};
  selected=null;
  window.v117ServiceCatalog=[];
  if(window.MESSAGE_META) window.MESSAGE_META={};

  // Marcar a base como vazia ANTES de voltar a chamar qualquer renderizador.
  // Os carregadores V665/V666/V704 verificam este estado e ficam impedidos de
  // voltar a criar os exemplos.
  v676SetGlobalDatabaseEmpty(true);
  v675SetBaseEmpty(true);

  // Apagar todas as chaves conhecidas, incluindo as versões antigas dos
  // catálogos e das listas por empresa. Fazemos a leitura primeiro e só depois
  // removemos para não saltar posições durante o percurso do localStorage.
  const prefixes=[
    'amClientesDB',
    'amClientesArchived',
    'amClientesActivity',
    'amClientesSubscriptions',
    'am_catalog_',
    'am_v665_config_',
    'amClientesConfig_',
    'am_v117_service_catalog',
    'amTemplates',
    'amClientesEmptyBase'
  ];
  const exact=[
    'amClientesConfigLists',
    'amClientesSubscriptions',
    'amTemplates',
    'amTemplateMeta',
    'amClientesDemoVersion',
    'amClientesV593DistinctCompanyTestData',
    'amClientesV624AllCompanyConfigurationExamples'
  ];
  const keys=[];
  for(let i=0;i<localStorage.length;i++) keys.push(localStorage.key(i));
  keys.filter(Boolean).forEach(key=>{
    if(exact.includes(key) || prefixes.some(prefix=>String(key).startsWith(prefix))){
      try{ localStorage.removeItem(key); }catch(e){}
    }
  });

  // A aplicação continua com uma única empresa estrutural vazia, mas sem
  // clientes, subscrições, catálogos, listas, atalhos ou mensagens.
  APP_SETTINGS={
    ...APP_SETTINGS,
    shortcuts:[],
    activeCompanyId:'company_1',
    companyProfiles:[v676DefaultCompany()]
  };
  saveAppSettings();

  // Persistir explicitamente o vazio em TODAS as fontes atuais. Assim, mesmo
  // que um carregador antigo seja executado depois, encontra [] em vez de 5
  // exemplos.
  v592SaveCompanyData('amClientesDB',DATA);
  v592SaveCompanyData('amClientesArchived',ARCHIVED);
  v592SaveCompanyData('amClientesActivity',ACTIVITY);
  localStorage.setItem(v618SubscriptionsStorageKey(),JSON.stringify([]));
  localStorage.setItem(v743ConfigListsStorageKey(),JSON.stringify(CONFIG_LISTS));
  Object.keys(CATALOGS).forEach(type=>{
    try{ localStorage.setItem(v618CatalogStorageKey(type),JSON.stringify([])); }catch(e){}
  });
  try{ localStorage.setItem('am_v117_service_catalog__company_1',JSON.stringify([])); }catch(e){}
  try{ localStorage.setItem('amTemplates__company_1',JSON.stringify({})); }catch(e){}
  try{ localStorage.setItem('amTemplateMeta',JSON.stringify({})); }catch(e){}

  // Atualização imediata do estado visual e dos dados em memória.
  try{ if(typeof loadSubscriptions==='function') loadSubscriptions(); }catch(e){ SUBSCRIPTIONS=[]; }
  try{ if(typeof loadConfigLists==='function') loadConfigLists(); }catch(e){}
  CONFIG_LISTS=Object.fromEntries(Object.keys(DEFAULT_LISTS).map(key=>[key,[]]));
  try{ if(typeof saveConfigLists==='function') saveConfigLists(); }catch(e){}
  window.v117ServiceCatalog=[];

  render();
  if(typeof renderSubscriptions==='function') renderSubscriptions();
  if(typeof renderSettings==='function') renderSettings();
  if(typeof renderMessages==='function') renderMessages();
  if(typeof v589RenderCompanySwitcher==='function') v589RenderCompanySwitcher();
  if(typeof v117RenderCatalog==='function'){
    try{ v117RenderCatalog(); }catch(e){}
  }
}

async function openFromFile(){
  try{
    const picked=await pickAppFile({
      description:'Backup completo AM Clientes',
      accept:{'application/json':['.json']}
    });
    const handle=picked.handle;
    const imported=JSON.parse(await picked.file.text());

    let importedClients, importedArchived=[], importedLists=null, importedMessages=null, importedActivity=[], importedAppSettings=null, importedSubscriptions=[], importedMessageMeta=null, importedCatalogs=null;
    if(Array.isArray(imported)){
      importedClients=imported;
    }else if(imported && Array.isArray(imported.clientes)){
      importedClients=imported.clientes;
      importedArchived=Array.isArray(imported.arquivados)?imported.arquivados:[];
      importedLists=(imported.listas && typeof imported.listas==='object') ? imported.listas : null;
      importedMessages=(imported.mensagens && typeof imported.mensagens==='object') ? imported.mensagens : null;
      importedActivity=Array.isArray(imported.atividade)?imported.atividade:[];
      importedAppSettings=(imported.appSettings && typeof imported.appSettings==='object') ? imported.appSettings : null;
      importedSubscriptions=Array.isArray(imported.subscricoes)?imported.subscricoes:[];
      importedMessageMeta=(imported.mensagensMeta && typeof imported.mensagensMeta==='object') ? imported.mensagensMeta : null;
      importedCatalogs=(imported.catalogos && typeof imported.catalogos==='object') ? imported.catalogos : null;
    }else{
      throw new Error('Este ficheiro não é um backup válido do AM Clientes.');
    }

    DATA=structuredClone(importedClients);
    ARCHIVED=structuredClone(importedArchived);
    ACTIVITY=structuredClone(importedActivity);
    pruneActivity(); saveActivity();
    v592SaveCompanyData('amClientesArchived',ARCHIVED);
    if(importedLists){ CONFIG_LISTS=structuredClone(importedLists); saveConfigLists(); }
    if(importedMessages){ templates=structuredClone(importedMessages); localStorage.setItem('amTemplates',JSON.stringify(templates)); }
    if(importedMessageMeta && window.MESSAGE_META){ window.MESSAGE_META=structuredClone(importedMessageMeta); localStorage.setItem('amTemplateMeta',JSON.stringify(window.MESSAGE_META)); }
    if(Array.isArray(importedSubscriptions)){ SUBSCRIPTIONS=structuredClone(importedSubscriptions); saveSubscriptions(); }
    if(importedCatalogs){ Object.keys(CATALOGS).forEach(type=>{ const rows=Array.isArray(importedCatalogs[type])?structuredClone(importedCatalogs[type]):[]; setCatalog(type,rows); }); if(typeof v117RenderCatalog==='function'){ try{ v117RenderCatalog(); }catch(e){} } }
    if(importedAppSettings){
      APP_SETTINGS={title:String(importedAppSettings.title||'AM Clientes'),logo:String(importedAppSettings.logo||''),shortcuts:Array.isArray(importedAppSettings.shortcuts)?structuredClone(importedAppSettings.shortcuts):[]};
      saveAppSettings();
    }
    dbFileHandle=handle;
    v592SaveCompanyData('amClientesDB',DATA);
    render();
    if(typeof renderSettings==='function') renderSettings();

    const nClientes=DATA.length;
    const nArquivados=ARCHIVED.length;
    const nListas=importedLists ? Object.values(importedLists).reduce((n,a)=>n+(Array.isArray(a)?a.length:0),0) : 0;
    const nMensagens=importedMessages ? Object.keys(importedMessages).length : 0;
    await showAppAlert(
      importedLists || importedMessages ? 'Backup carregado' : 'Base de clientes carregada',
      importedLists || importedMessages
        ? `Backup carregado com sucesso.\n\n${nClientes} clientes\n${nArquivados} clientes arquivados\n${nListas} opções de configuração\n${nMensagens} modelos de mensagem`
        : `Base de clientes carregada.\n\n${nClientes} clientes.\n\nEste é um backup antigo sem configurações e mensagens.`
    );
  }catch(e){
    if(e?.name!=='AbortError') await showAppAlert('Não foi possível abrir','Não foi possível abrir o backup: '+(e?.message||e));
  }
}

async function quickSaveBackup(){
  const backup={
    version:9,
    app:'AM Clientes',
    savedAt:new Date().toISOString(),
    clientes:DATA,
    arquivados:ARCHIVED,
    listas:CONFIG_LISTS,
    mensagens:templates,
    atividade:ACTIVITY,
    appSettings:APP_SETTINGS,
    subscricoes:SUBSCRIPTIONS,
    mensagensMeta:(window.MESSAGE_META && typeof window.MESSAGE_META==='object') ? window.MESSAGE_META : {},
    catalogos:Object.fromEntries(Object.keys(CATALOGS).map(k=>[k,getCatalog(k)]))
  };
  const text=JSON.stringify(backup,null,2);

  try{
    // If the user previously opened/saved a physical backup file and the
    // browser granted a writable handle, update that exact file.
    if(dbFileHandle && typeof dbFileHandle.createWritable==='function'){
      const writable=await dbFileHandle.createWritable();
      await writable.write(text);
      await writable.close();
      saveDB();
      await showAppAlert('Base de dados guardada','A base de dados foi guardada com sucesso.');
      return;
    }

    // No linked file yet: create a new backup file.
    const blob=new Blob([text],{type:'application/json'});
    await v170DownloadBlob(blob,'AM_Clientes_BACKUP_COMPLETO.json','application/json');
    saveDB();
    await showAppAlert('Cópia de segurança criada','A cópia de segurança foi criada com sucesso.');
  }catch(e){
    await showAppAlert('Não foi possível guardar','Não foi possível guardar a base: '+e.message);
  }
}

async function exportJson(){
  const backup={
    version:10,
    app:'AM Clientes',
    savedAt:new Date().toISOString(),
    clientes:DATA,
    arquivados:ARCHIVED,
    listas:CONFIG_LISTS,
    mensagens:templates,
    atividade:ACTIVITY,
    appSettings:APP_SETTINGS,
    subscricoes:SUBSCRIPTIONS,
    mensagensMeta:(window.MESSAGE_META && typeof window.MESSAGE_META==='object') ? window.MESSAGE_META : {},
    catalogos:Object.fromEntries(Object.keys(CATALOGS).map(k=>[k,getCatalog(k)]))
  };
  const text=JSON.stringify(backup,null,2);
  try{
    await v170DownloadBlob(new Blob([text],{type:'application/json'}),'AM_Clientes_BACKUP_COMPLETO.json','application/json');
    await showAppAlert('Cópia de segurança criada','A cópia de segurança JSON foi criada com sucesso.');
  }catch(e){
    if(e?.name==='AbortError') return;
    await showAppAlert('Não foi possível guardar','Não foi possível criar a cópia JSON: '+(e?.message||e));
  }
}

let currentListMode='all';
let editReturnContext={type:'home',mode:'all'};
// Depois de fechar a lista completa pelo menu Clientes, o título Clientes
// deve reabrir a mesma lista completa, em vez de voltar ao painel resumido do Início.
let fullListWasClosedByUser=false;


function goHome(){
  setActiveNav('inicio');
  const shortcuts=document.getElementById('homeShortcuts');
  if(shortcuts) shortcuts.classList.remove('hidden');
  const homeClients=document.querySelector('#clientes .layout');
  if(homeClients)homeClients.classList.remove('hidden');
  const homeClientsBody=document.getElementById('homeClientsBody');
  if(homeClientsBody)homeClientsBody.classList.remove('hidden');
  setHomeClientPreviewExpanded(false);
  updateHomeClientsOpenCloseButton();

  ['clientes','lista','mensagens','historico','atividade','base','catalogos','gestao','subscricoes','estatisticas','todosClientes','config'].forEach(id=>{
    const el=document.getElementById(id);
    if(el) el.classList.toggle('hidden', id!=='clientes');
  });

  // O Início deve sempre voltar ao estado original: nenhum cliente aberto.
  ['detail','fullClientDetail'].forEach(id=>{
    const el=document.getElementById(id);
    if(el){
      // O menu Início não deve mostrar nenhuma caixa/instrução vazia.
      // A ficha só aparece quando o utilizador toca num cliente.
      el.classList.add('hidden');
      el.innerHTML='';
    }
  });

  const s=document.getElementById('search');
  if(s) s.value='';
  selected=null;
  currentListMode='all';
  fullListWasClosedByUser=false;

  // Repor os três clientes de aviso no painel inicial.
  render();
}


function resetFullClientsToAll(){
  // A abertura pelo menu "Clientes" deve ser sempre uma lista integral,
  // independentemente do último filtro usado nos cartões de estado.
  currentListMode='all';
  const title=document.getElementById('listTitle');
  if(title) title.textContent='📋 Clientes';
  const fs=document.getElementById('fullSearch');
  if(fs) fs.value='';
  clearFullClientDetail();
  renderFullClients();
}

function closeCurrentListOrClient(){
 const p=document.getElementById('todosClientes');
 const d=document.getElementById('fullClientDetail');
 const fs=document.getElementById('fullSearch');
 const fl=document.getElementById('fullClientList');
 const cb=document.getElementById('listCloseBtn');

 // Fechar apenas a ficha do cliente.
 if(d && !d.classList.contains('hidden')){
   d.classList.add('hidden');
   d.innerHTML='';
   selected=null;
   if(cb) cb.textContent='Fechar';
   return;
 }

 // O painel permanece visível. Apenas a lista é recolhida.
 if(p && !p.classList.contains('hidden')){
   if(p.dataset.listCollapsed==='1'){
     p.dataset.listCollapsed='0';
     if(fs) fs.classList.remove('hidden');
     if(fl) fl.classList.remove('hidden');
     if(cb) cb.textContent='Fechar';
     fullListWasClosedByUser=false;
     resetFullClientsToAll();
     return;
   }

   if(fs) fs.classList.add('hidden');
   if(fl) fl.classList.add('hidden');
   if(d){
     d.classList.add('hidden');
     d.innerHTML='';
   }
   selected=null;
   // Ao fechar qualquer lista de estado, limpar o estado visual do título.
   // Ativos, A expirar e Expirados seguem exatamente o mesmo caminho.
   p.classList.remove('status-title-expired');
   p.dataset.listCollapsed='1';
   if(cb) cb.textContent='Abrir';
   fullListWasClosedByUser=true;
   currentListMode='all';

   const title=document.getElementById('listTitle');
   if(title) title.textContent='📋 Clientes';
 }
}

function clearFullClientDetail(){
 const d=document.getElementById('fullClientDetail');
 if(d){d.classList.add('hidden');d.innerHTML='';d.dataset.openClientId='';}
 selected=null;
 const cb=document.getElementById('listCloseBtn'); if(cb) cb.textContent='Fechar';
}
function clearHomeClientDetail(){
 const d=document.getElementById('detail');
 if(d){
   d.classList.add('hidden');
   d.innerHTML='';
   d.dataset.openClientId='';
   // Recolocar a ficha no corpo normal, depois da lista.
   const body=document.getElementById('homeClientsBody');
   if(body && d.parentElement!==body) body.appendChild(d);
 }
 selected=null;
}

// V259 — na lista do Início, a ficha do cliente fica imediatamente
// por baixo do cliente selecionado, tal como acontece visualmente
// na área Clientes. Não cria uma ficha separada no fim da lista.
function placeHomeClientDetailAfter(id){
  const list=document.getElementById('list');
  const d=document.getElementById('detail');
  if(!list || !d)return;

  // No Início, a pré-visualização fica sempre no topo:
  // 1) cliente selecionado aberto e completo
  // 2) por baixo, a lista original dos 3 clientes.
  // A lista não é alterada nem perde o cliente selecionado.
  if(d.parentElement!==list.parentElement){
    const body=document.getElementById('homeClientsBody');
    if(body) body.insertBefore(d,list);
  }else{
    list.parentElement.insertBefore(d,list);
  }
}

function updateHomeClientsOpenCloseButton(){
  const body=document.getElementById('homeClientsBody');
  const btn=document.getElementById('homeClientsOpenCloseBtn');
  if(!body || !btn)return;
  btn.textContent=body.classList.contains('hidden') ? 'Abrir' : 'Fechar';
}

function toggleHomeClientPanel(){
  const body=document.getElementById('homeClientsBody');
  const card=document.getElementById('homeClientsCard');
  if(!body)return;
  const willOpen=body.classList.contains('hidden');
  body.classList.toggle('hidden', !willOpen);
  if(card) card.classList.toggle('is-closed', !willOpen);

  if(!willOpen){
    const d=document.getElementById('detail');
    if(d){d.classList.add('hidden');d.innerHTML='';}
    selected=null;
  }
  updateHomeClientsOpenCloseButton();
}

function handleHomeClientsTitleClick(){
  // Se acabámos de fechar a lista completa, o título Clientes funciona
  // como o botão Clientes do menu superior e reabre a lista integral.
  if(fullListWasClosedByUser){
    toggleFullClients();
    return;
  }
  // No Início normal mantém-se o comportamento original.
  toggleHomeClientPanel();
}
function openClientsNav(){
  const p=document.getElementById('todosClientes');

  // O botão Clientes do menu superior apenas abre a área.
  // Nunca fecha a lista que está no painel inferior.
  if(p && !p.classList.contains('hidden')) return;

  toggleFullClients();
}

function toggleFullClients(){
  const p=document.getElementById('todosClientes');
  const homeClients=document.querySelector('#clientes .layout');
  const shortcuts=document.getElementById('homeShortcuts');
  if(!p)return;

  const isOpen=!p.classList.contains('hidden');
  const isCollapsed=p.dataset.listCollapsed==='1';

  // Painel aberto e lista recolhida: abrir novamente.
  if(isOpen && isCollapsed){
    p.dataset.listCollapsed='0';
    const fs=document.getElementById('fullSearch');
    const fl=document.getElementById('fullClientList');
    if(fs) fs.classList.remove('hidden');
    if(fl) fl.classList.remove('hidden');
    fullListWasClosedByUser=false;
    const cb=document.getElementById('listCloseBtn');
    if(cb) cb.textContent='Fechar';
    resetFullClientsToAll();
    return;
  }

  // Painel aberto e lista visível: recolher.
  if(isOpen){
    closeCurrentListOrClient();
    return;
  }

  // Painel fechado: abrir normalmente.
  fullListWasClosedByUser=false;
  view('clientes');
  clearHomeClientDetail();

  const homeBody=document.getElementById('homeClientsBody');
  const homeCard=document.getElementById('homeClientsCard');
  if(homeBody) homeBody.classList.add('hidden');
  if(homeCard) homeCard.classList.add('is-closed');

  p.classList.remove('hidden');
  p.dataset.listCollapsed='0';

  if(homeClients) homeClients.classList.add('hidden');
  if(shortcuts) shortcuts.classList.add('hidden');

  resetFullClientsToAll();

  const cb=document.getElementById('listCloseBtn');
  if(cb) cb.textContent='Fechar';
}

// V533 — Os cartões de estado no menu Clientes são independentes do Início.
// Quando uma lista de estado é aberta a partir da lista completa de Clientes,
// voltar a carregar no mesmo cartão regressa à lista completa, sem fechar o
// painel nem mostrar o estado do Início.
let statusOpenedFromClientMenu=false;
function toggleStatusList(mode){
 const shortcuts=document.getElementById('homeShortcuts');
 const p=document.getElementById('todosClientes');
 const homeClients=document.querySelector('#clientes .layout');
 const fs=document.getElementById('fullSearch');
 const fl=document.getElementById('fullClientList');
 const title=document.getElementById('listTitle');
 const cb=document.getElementById('listCloseBtn');
 if(!p)return;

 const isOpen=!p.classList.contains('hidden');
 // V535 — quando a lista de estado já está aberta, o painel principal fica
 // escondido tanto no Início como em Clientes. Por isso, não podemos usar
 // apenas o estado visual do painel para decidir a indicação do menu.
 // A origem guardada é a referência correta: no segundo clique deve manter
 // exatamente o mesmo menu que abriu a lista no primeiro clique.
 const wasInClientMenu = isOpen
   ? statusOpenedFromClientMenu
   : (!!homeClients && homeClients.classList.contains('hidden'));

 // A indicação visual do menu depende da origem real da lista de estado.
 if(wasInClientMenu) setActiveNav('clientes');
 else setActiveNav('inicio');

 // Se estamos no menu Clientes e voltamos a tocar no mesmo estado,
 // regressar exatamente à lista completa de Clientes.
 if(isOpen && currentListMode===mode && statusOpenedFromClientMenu){
   clearFullClientDetail();
   p.classList.remove('status-title-expired');
   p.dataset.listCollapsed='0';
   if(fs){fs.value='';fs.classList.remove('hidden');}
   if(fl)fl.classList.remove('hidden');
   currentListMode='all';
   if(title)title.textContent='📋 Clientes';
   if(cb)cb.textContent='Fechar';
   fullListWasClosedByUser=false;
   renderFullClients();
   return;
 }

 // Manter o comportamento original do Início: se a lista de estado foi aberta
 // a partir do Início, voltar a tocar no mesmo cartão fecha apenas essa lista.
 if(isOpen && currentListMode===mode && !statusOpenedFromClientMenu){
   p.classList.remove('status-title-expired');
   p.classList.add('hidden');
   if(homeClients)homeClients.classList.remove('hidden');
   return;
 }

 // Guardar de onde esta navegação por estado começou, para não misturar os
 // comportamentos do menu Clientes e do Início.
 if(wasInClientMenu) statusOpenedFromClientMenu=true;
 else if(!isOpen) statusOpenedFromClientMenu=false;

 if(shortcuts) shortcuts.classList.add('hidden');
 clearHomeClientDetail();
 clearFullClientDetail();
 p.classList.remove('hidden');
 if(homeClients)homeClients.classList.add('hidden');
 // Ao abrir qualquer estado a partir dos cartões, a lista tem de ficar
 // efetivamente visível, mesmo que o utilizador tenha anteriormente
 // recolhido o painel Clientes pelo botão Fechar.
 p.dataset.listCollapsed='0';
 if(fs) fs.classList.remove('hidden');
 if(fl) fl.classList.remove('hidden');
 fullListWasClosedByUser=false;
 currentListMode=mode;
 p.classList.toggle('status-title-expired', mode==='expired');
 if(fs) fs.value='';
 const titles={active:'🟢 Clientes ativos',warning:'🟠 Clientes a expirar',expired:'🔴 Clientes expirados'};
 if(title)title.textContent=titles[mode];
 if(cb)cb.textContent='Fechar';
 renderFullClients();
}
function renderFullClients(){
 const q=(document.getElementById('fullSearch')?.value||'').trim().toLowerCase();
 let filtered=DATA.filter(c=>Object.values(c).join(' ').toLowerCase().includes(q));
 if(currentListMode!=='all') filtered=filtered.filter(c=>status(c)===currentListMode);
 const el=document.getElementById('fullClientList');
 if(!el)return;
 el.innerHTML=filtered.length?filtered.map(c=>{
   const s=status(c);
   return `<div class="client" data-client-preview-id="${esc(c['ID Cliente'])}"><div><strong>${esc(clientName(c))}</strong><small class="client-service">${esc(c['Serviço']||'—')}</small><small class="client-contact">${esc(c['Contacto']||'—')}</small></div><span class="badge ${s==='active'?'green':s==='warning'?'orange':'red'}">${statusLabel(c)}</span></div>`
 }).join(''):'<div class="muted" style="padding:20px">Nenhum resultado.</div>';
 bindClientPreviewCards(el);
}


/* V717 — toque dos cartões de cliente: uma única ação, sem pointerup.
   A V715 usava pointerup + click no mesmo cartão e ainda tinha um bloqueio
   temporal de 700 ms. No Android isso podia deixar o toque a ser interpretado
   como gesto/scroll ou consumir a ativação antes do click seguinte.
   A abertura/fecho volta a ser uma ação simples de click, uma vez por toque. */
function bindClientPreviewCards(root){
  const scope=root||document;
  scope.querySelectorAll('.client[data-client-preview-id]').forEach(card=>{
    if(card.dataset.v717Bound==='1')return;
    card.dataset.v717Bound='1';
    card.addEventListener('click',function(ev){
      const id=card.getAttribute('data-client-preview-id');
      if(!id)return;
      ev.stopPropagation();
      window.toggleClientPreview(id);
    },false);
  });
}



function handleTopSearch(){
  const topSearch=document.getElementById('search');
  const q=(topSearch?.value||'').trim();

  // A pesquisa do topo é independente da pesquisa da lista aberta.
  // Se estiver aberta uma lista (Ativos/A expirar/Expirados/Clientes),
  // o topo volta ao painel principal e pesquisa aí, sem alterar fullSearch.
  const p=document.getElementById('todosClientes');
  const homeClients=document.querySelector('#clientes .layout');

  if(p && !p.classList.contains('hidden')){
    p.classList.add('hidden');
    if(homeClients)homeClients.classList.remove('hidden');

    const fullDetail=document.getElementById('fullClientDetail');
    if(fullDetail){
      fullDetail.classList.add('hidden');
      fullDetail.innerHTML='';
    }

    selected=null;
    currentListMode='all';
  }

  render();
}

function render(){
 let q=document.getElementById('search').value.trim().toLowerCase();
 let a=0,w=0,e=0;DATA.forEach(c=>{let s=status(c);if(s==='active')a++;else if(s==='warning')w++;else e++});
 nActive.textContent=a;nWarn.textContent=w;nExpired.textContent=e;
 let filtered=DATA.filter(c=>Object.values(c).join(' ').toLowerCase().includes(q));
 // No ecrã inicial, sem pesquisa, o painel mostra primeiro os expirados
 // e os que estão a expirar. Quando o utilizador escreve na pesquisa do topo,
 // devem aparecer TODOS os clientes encontrados — e não apenas os 3 ativos.
 let alerts = filtered.filter(c=>{const s=status(c);return s==='expired'||s==='warning'}).sort((a,b)=>days(a)-days(b));
 let homeList = q
   ? filtered
   : (alerts.length ? alerts : [...filtered].filter(c=>status(c)==='active').sort((a,b)=>days(a)-days(b)).slice(0,3));
 list.classList.add('home-client-scroll');
 list.innerHTML=homeList.length?homeList.map(c=>{let s=status(c);return `<div class="client" data-client-preview-id="${esc(c['ID Cliente'])}"><div><strong>${esc(clientName(c))}</strong><small class="client-service">${esc(c['Serviço']||'—')}</small><small class="client-contact">${esc(c['Contacto']||'—')}</small></div><span class="badge ${s==='active'?'green':s==='warning'?'orange':'red'}">${statusLabel(c)}</span></div>`}).join(''):'<div class="muted" style="padding:20px">Nenhum cliente.</div>';
 bindClientPreviewCards(list);
 table.innerHTML=filtered.map(c=>`<tr><td>${esc(c['ID Cliente'])}</td><td>${esc(c['Nome'])}</td><td>${esc(c['Nome Empresa'])}</td><td>${esc(c['Contacto'])}</td><td>${esc(c['Serviço'])}</td><td>${esc(c['Validade'])}</td><td class="${status(c)==='active'?'green':status(c)==='warning'?'orange':'red'}">${statusLabel(c)}</td></tr>`).join('');
 renderHomeShortcuts();
 if(selected){ /* manter ficha aberta sem a alternar */ }
}
function v124GetEquipmentSummary(c){
  const list=Array.isArray(c?.equipamentos)?c.equipamentos:[];
  const e=list[0]||{};
  const vpns=Array.isArray(e.vpns)?e.vpns:[];
  const v=vpns[0]||{};
  return {
    equipamento:String(c?.Equipamento||e.marca||''),
    mac:String(c?.['Mac Adress']||e.mac||''),
    utilizador:String(c?.Utilizador||e.utilizador||''),
    senha:String(c?.Senha||e.senha||''),
    link:String(c?.Link||e.link||''),
    vpn:String(v.nome||e.vpn||c?.VPN||''),
    vpnUtilizador:String(v.utilizador||c?.['Utilizador VPN']||''),
    vpnSenha:String(v.senha||c?.['Password VPN']||''),
    subscricao:String(v.subscricao||e.subscricao||c?.Subscrição||'')
  };
}

// V168 — resumo dinâmico do cliente com 14 campos prioritários.
// V256 — toque no cartão do cliente alterna a pré-visualização.
// Um toque abre; tocar novamente no mesmo cliente fecha.
// Esta função é a regra única usada pelas listas de Clientes.

function setHomeClientPreviewExpanded(open){
  const card=document.getElementById('homeClientsCard');
  if(card) card.classList.toggle('home-client-preview-open',!!open);
}

function toggleClientPreview(id){
 const inFullList=!document.getElementById('todosClientes')?.classList.contains('hidden');
 const target=inFullList?document.getElementById('fullClientDetail'):document.getElementById('detail');
 if(!target)return;

 // No Início, posicionar a ficha logo depois do cartão tocado.
 if(!inFullList){
   placeHomeClientDetailAfter(id);
 }

 // V258 — o cabeçalho/nome da pré-visualização também é clicável: tocar no
 // cliente em grande fecha a ficha. O cartão original continua com a mesma regra.
 // V257 — o estado aberto fica guardado no próprio painel da pré-visualização.
 // Assim o segundo toque no mesmo cartão fecha sempre, mesmo que outra rotina
 // tenha alterado a variável global selected.
 const openId=String(target.dataset.openClientId||'');
 const clickedId=String(id||'');
 if(openId && openId===clickedId && !target.classList.contains('hidden')){
   target.classList.add('hidden');
   target.innerHTML='';
   target.dataset.openClientId='';
   selected=null;
   if(!inFullList){
     setHomeClientPreviewExpanded(false);
     const body=document.getElementById('homeClientsBody');
     const list=document.getElementById('list');
     if(body && list && target.parentElement===body) body.appendChild(target);
   }
   const cb=document.getElementById('listCloseBtn');
   if(cb) cb.textContent='Fechar';
   return;
 }

 if(!inFullList) setHomeClientPreviewExpanded(true);
 selectClient(id);
}

function v168PreviewField(labelText,value){
 const v=String(value??'').trim();
 return v ? field(labelText,v) : '';
}

function v169PreviewMoneyField(labelText,value){
 const raw=String(value??'').trim();
 if(!raw) return '';
 const n=Number(raw.replace(',','.'));
 if(!Number.isFinite(n) || n===0) return '';
 return field(labelText,euroAfter(value));
}

function v168PreviewSection(title,fields){
 const content=fields.filter(Boolean).join('');
 return content ? `<h3>${title}</h3><div class="row">${content}</div>` : '';
}

function v169PreviewPlainSection(fields){
 const content=fields.filter(Boolean).join('');
 return content ? `<div class="row">${content}</div>` : '';
}

function selectClient(id){
 const inFullList=!document.getElementById('todosClientes')?.classList.contains('hidden');
 const target=inFullList?document.getElementById('fullClientDetail'):document.getElementById('detail');
 if(!target)return;

 selected=id;
 if(target) target.dataset.openClientId=String(id);
 let c=DATA.find(x=>String(x['ID Cliente'])===String(id));if(!c)return;
 let s=status(c);
 const eqSummary=v124GetEquipmentSummary(c);
 const eq=(Array.isArray(c.equipamentos)?c.equipamentos:[])[0]||{};
 const nomeEquipamento=String(eq.nome||c.Equipamento||'').trim();

 // V168 — resumo dinâmico do cliente.
 // Mostra apenas os 14 campos definidos como relevantes para a consulta diária,
 // pela ordem acordada. Campos vazios não ocupam espaço nem mostram tracinhos.
 // Os restantes dados continuam guardados e disponíveis em Editar Cliente.
 const clienteFields=[
   v168PreviewField('Observações',c['Observações']),
   v168PreviewField('Contacto',c['Contacto'])
 ];
 const equipamentoFields=[
   v168PreviewField('Nome do equipamento',nomeEquipamento),
   v168PreviewField('MAC',eqSummary.mac),
   v168PreviewField('Utilizador',eqSummary.utilizador),
   v168PreviewField('Password',eqSummary.senha),
   v168PreviewField('Link',eqSummary.link)
 ];
 const numericMeaningful=v=>{
   const raw=String(v??'').trim();
   if(!raw) return false;
   const n=Number(raw.replace(',','.'));
   return Number.isFinite(n) ? n!==0 : true;
 };
 const hasServiceOrSubscription=[
   c['Serviço'],c['Subscrição'],c['Validade'],c['Periodicidade']
 ].some(v=>String(v??'').trim()!=='') || numericMeaningful(c['Preço']) || numericMeaningful(c['Saldo']);
 const servicoSubscricaoFields=[
   v168PreviewField('Serviço',c['Serviço']),
   v168PreviewField('Subscrição',c['Subscrição']),
   v168PreviewField('Validade',c['Validade']),
   v168PreviewField('Periodicidade',c['Periodicidade']),
   v169PreviewMoneyField('Valor',c['Preço']),
   hasServiceOrSubscription ? v168PreviewField('Saldo',euroAfter(c['Saldo'])) : ''
 ];

 target.innerHTML=`<div onclick="toggleClientPreview('${esc(id)}')" title="Tocar para fechar" style="display:flex;justify-content:space-between;gap:8px;align-items:center;cursor:pointer"><h2 style="margin:0">${esc(c['Nome']||'Sem nome')}</h2><span class="badge ${s==='active'?'green':s==='warning'?'orange':'red'}">${statusLabel(c)}</span></div>

 ${v169PreviewPlainSection(clienteFields)}
 ${v168PreviewSection('🛠️ Equipamento',equipamentoFields)}
 ${v168PreviewSection('🔐 Serviço e subscrição',servicoSubscricaoFields)}

 <div class="actions client-vpn-actions">
 <button class="primary" onclick="editClient('${esc(id)}')">✏️ Editar cliente</button>
 <button onclick="archiveClient(selected)">📦 Arquivar</button>
</div>
 <h3>📩 Contactar cliente</h3>
 <div class="actions"><button class="primary" onclick="prepare('WhatsApp')">WhatsApp</button><button class="primary" onclick="prepare('Telegram')">Telegram</button><button class="primary" onclick="prepare('Signal')">Signal</button><button class="primary" onclick="prepare('Email')">E-mail</button></div>
 <div style="margin-top:9px"><label class="muted">Modelo</label><select class="select" id="clientTemplate" onchange="updateClientMessage()">${Object.keys(templates).map(k=>`<option value="${k}">${label(k)}</option>`).join('')}</select></div>
 <textarea id="clientMessage" class="message" style="margin-top:8px"></textarea><div class="actions"><button onclick="copyClientMessage()">Copiar mensagem</button></div>

 `;
 target.dataset.openClientId=String(id);
 target.classList.remove('hidden');
 if(!inFullList) setHomeClientPreviewExpanded(true);
 setTimeout(()=>{
   try{
     const r=target.getBoundingClientRect();
     const top=r.top + window.scrollY - 18;
     window.scrollTo({top:Math.max(0,top),behavior:'smooth'});
   }catch(e){}
 },40);
 const cb=document.getElementById('listCloseBtn'); if(cb) cb.textContent='Fechar Cliente';
 updateClientMessage();
}

function archiveClient(id){
 const c=DATA.find(x=>String(x['ID Cliente'])===String(id));
 if(!c)return;
 if(!confirm('Arquivar '+clientName(c)+'?\\n\\nO cliente será retirado da lista de clientes e ficará guardado no Histórico com todos os dados atuais.'))return;
 const before=snapshotState();

 const copy=structuredClone(c);
 copy['Data Arquivo']=new Date().toISOString();
 copy['Estado Arquivo']='Arquivado';

 // Mantém o histórico sem duplicar o mesmo cliente/versão.
 ARCHIVED.push(copy);
 DATA=DATA.filter(x=>String(x['ID Cliente'])!==String(id));
 recordAction('Cliente arquivado','Cliente arquivado: '+clientName(c),before);
 saveDB();

 selected=null;
 const ctx=currentListMode;
 view('clientes');

 const p=document.getElementById('todosClientes');
 const homeLayout=document.querySelector('#clientes .layout');

 if(p && ctx!=='all'){
   p.classList.remove('hidden');
   if(homeLayout)homeLayout.classList.add('hidden');
   const title=document.getElementById('listTitle');
   if(title) title.textContent=
     ctx==='active'?'🟢 Clientes ativos':
     ctx==='warning'?'🟠 Clientes a expirar':'🔴 Clientes expirados';
   currentListMode=ctx;
   const fs=document.getElementById('fullSearch'); if(fs)fs.value='';
   renderFullClients();
 }else{
   if(p)p.classList.add('hidden');
   if(homeLayout)homeLayout.classList.remove('hidden');
   currentListMode='all';
   
   render();
 }
 alert('Cliente arquivado no Histórico.');
}

function syncArchivedPanelUI(){
 const p=document.getElementById('historico');
 const list=document.getElementById('history');
 const search=document.getElementById('archivedSearch');
 const detail=document.getElementById('historyDetail');
 const btn=document.getElementById('archivedCloseBtn');
 if(!p)return;

 const collapsed=p.dataset.archivedCollapsed==='1';

 // The search bar remains visible when the list is collapsed,
 // exactly like the Clientes panel.
 if(list){
   list.classList.toggle('hidden', collapsed);
   list.style.display=collapsed ? 'none' : '';
 }
 if(search){
   search.classList.remove('hidden');
   search.style.display='';
 }
 if(detail && collapsed){
   detail.classList.add('hidden');
   detail.innerHTML='';
   delete detail.dataset.historyIndex;
 }
 if(btn) btn.textContent=collapsed ? 'Abrir' : 'Fechar';
}

function toggleArchivedPanel(){
 const p=document.getElementById('historico');
 const detail=document.getElementById('historyDetail');
 if(!p)return;

 // If a client ficha is open, close only the ficha first.
 if(detail && !detail.classList.contains('hidden')){
   detail.classList.add('hidden');
   detail.innerHTML='';
   delete detail.dataset.historyIndex;
   p.dataset.archivedLevel='list';
   p.dataset.archivedCollapsed='0';
   syncArchivedPanelUI();
   return;
 }

 const collapsed=p.dataset.archivedCollapsed==='1';

 if(collapsed){
   p.dataset.archivedCollapsed='0';
   p.dataset.archivedLevel='list';
   syncArchivedPanelUI();
   renderHistory();
   return;
 }

 // Collapse only the archived list. Keep the panel title and search bar.
 p.dataset.archivedCollapsed='1';
 p.dataset.archivedLevel='closed';
 syncArchivedPanelUI();
}


function bindArchivedToggleControls(){
 const btn=document.getElementById('archivedCloseBtn');
 const title=document.getElementById('archivedTitle');

 if(btn && !btn.dataset.bound){
   btn.dataset.bound='1';
   btn.addEventListener('click',function(e){
     e.preventDefault();
     e.stopPropagation();
     toggleArchivedPanel();
   },true);
 }

 if(title && !title.dataset.bound){
   title.dataset.bound='1';
   title.addEventListener('click',function(e){
     e.preventDefault();
     e.stopPropagation();
     toggleArchivedPanel();
   },true);
 }
}


function openArchivedNav(){
 const p=document.getElementById('historico');
 if(p && !p.classList.contains('hidden')){
   if(p.dataset.archivedCollapsed==='1') toggleArchivedPanel();
   return;
 }
 view('historico');
 if(p){
   p.dataset.archivedCollapsed='0';
   p.dataset.archivedLevel='list';
 }
}

function deleteArchived(index){
 const c=ARCHIVED[index];
 if(!c)return;

 if(!confirm('Apagar definitivamente '+clientName(c)+'?\\n\\nEsta ação remove o cliente dos Arquivados e não pode ser desfeita.'))return;

 const before=snapshotState();
 ARCHIVED=ARCHIVED.filter((_,i)=>i!==index);
 recordAction('Cliente apagado dos arquivados','Cliente apagado definitivamente: '+clientName(c),before);
 saveDB();

 const detail=document.getElementById('historyDetail');
 if(detail){
   detail.classList.add('hidden');
   detail.innerHTML='';
   delete detail.dataset.historyIndex;
 }
 renderHistory();
}

function renderHistory(){
 bindArchivedToggleControls();
 const box=document.getElementById('history');
 const detail=document.getElementById('historyDetail');
 const search=document.getElementById('archivedSearch');
 const p=document.getElementById('historico');
 const btn=document.getElementById('archivedCloseBtn');
 if(!box)return;

 if(detail){detail.classList.add('hidden');detail.innerHTML='';delete detail.dataset.historyIndex;}

 const q=(search?.value||'').trim().toLowerCase();

 if(p && p.dataset.archivedCollapsed==='1'){
   p.dataset.archivedLevel='closed';
   syncArchivedPanelUI();
   return;
 }

 if(p) p.dataset.archivedLevel='list';
 syncArchivedPanelUI();

 if(!ARCHIVED.length){
   box.innerHTML='<div class="muted" style="padding:20px">Ainda não existem clientes arquivados.</div>';
   return;
 }

 const filtered=ARCHIVED
   .map((c,idx)=>({c,idx}))
   .filter(({c})=>!q || Object.values(c).join(' ').toLowerCase().includes(q))
   .reverse();

 box.innerHTML=filtered.length ? filtered.map(({c,idx})=>{
   return `<div class="client" onclick="selectArchivedClient(${idx})">
     <div><strong>${esc(clientName(c))}</strong>
     <small>${esc(c['Serviço']||'')} · Arquivado em ${esc(c['Data Arquivo']?dateOf(c['Data Arquivo']).toLocaleDateString('pt-PT'):'—')}</small></div>
     <div class="actions" style="margin:0">
       <button type="button" onclick="event.stopPropagation();reactivateArchived(${idx})">🔄 Reativar</button>
       <button type="button" onclick="event.stopPropagation();deleteArchived(${idx})">🗑️</button>
     </div>
   </div>`;
 }).join(''):'<div class="muted" style="padding:20px">Nenhum resultado.</div>';
}

function selectArchivedClient(index){
 const c=ARCHIVED[index];
 const detail=document.getElementById('historyDetail');
 if(!c||!detail)return;

 // Segundo toque no mesmo cliente fecha a ficha, tal como acontece
 // no menu inicial e nas listas de clientes.
 if(!detail.classList.contains('hidden') && String(detail.dataset.historyIndex)===String(index)){
   detail.classList.add('hidden');
   detail.innerHTML='';
   delete detail.dataset.historyIndex;
   const archivedPanel=document.getElementById('historico');
   if(archivedPanel){archivedPanel.dataset.archivedLevel='list';archivedPanel.dataset.archivedCollapsed='0';}
   const archivedBtn=document.getElementById('archivedCloseBtn');
   if(archivedBtn)archivedBtn.textContent='Fechar';
   return;
 }

 const archivedPanel2=document.getElementById('historico');
 if(archivedPanel2){
   archivedPanel2.dataset.archivedCollapsed='0';
   archivedPanel2.dataset.archivedLevel='detail';
   syncArchivedPanelUI();
 }
 detail.dataset.historyIndex=String(index);
 detail.innerHTML=`<div style="display:flex;justify-content:space-between;gap:8px;align-items:center">
   <h2>${esc(clientName(c))}</h2><span class="badge">${esc(c['Estado Arquivo']||'Arquivado')}</span>
 </div>
 <div class="row">
   ${field('Observações',c['Observações'])}
   ${field('Serviço',c['Serviço'])}
   ${field('Periodicidade',c['Periodicidade'])}
   ${field('Pagamento',c['Pagamento'])}
   ${field('Método de Pagamento',c['Método Pagamento'])}
   ${field('Valor pago',euroAfter(c['Preço']))}
   ${field('Validade',c['Validade'])}
   ${field('Saldo',euroAfter(c['Saldo']))}
 </div>
 <h3>🔐 Serviços VPN</h3>
 ${((Array.isArray(c.equipamentos)?c.equipamentos:[]).map((e,ei)=>{
   const vpns=Array.isArray(e.vpns)?e.vpns:[];
   if(!vpns.length)return '';
   return `<div style="margin-bottom:10px">
     <div class="row">${vpns.map(v=>`${field('Serviço VPN',v.nome)}${field('Utilizador VPN',v.utilizador)}${field('Senha VPN',v.senha)}${field('Subscrição',v.subscricao)}`).join('')}</div></div>`;
 }).join('')) || `<div class="muted client-vpn-empty">Nenhuma VPN associada.</div>`}
 <h3>🛠️ Equipamento</h3>
 <div class="row">${field('Equipamento',c['Equipamento'])}${field('MAC',c['Mac Adress'])}${field('Utilizador',c['Utilizador'])}${field('Senha',c['Senha'])}${field('Link',c['Link'])}</div>
 <div class="actions" style="margin-top:10px">
   <button class="primary" onclick="reactivateArchived(${index})">🔄 Reativar cliente</button>
   <button onclick="deleteArchived(${index})">🗑️ Apagar</button>
 </div>`;
 detail.classList.remove('hidden');
 const archivedPanel=document.getElementById('historico');
 if(archivedPanel){archivedPanel.dataset.archivedLevel='detail';archivedPanel.dataset.archivedCollapsed='0';}
 const archivedBtn=document.getElementById('archivedCloseBtn');
 if(archivedBtn)archivedBtn.textContent='Fechar cliente';
 detail.scrollIntoView({behavior:'smooth',block:'start'});
}

function reactivateArchived(index){
 const c=ARCHIVED[index];
 if(!c)return;
 if(DATA.some(x=>String(x['ID Cliente'])===String(c['ID Cliente']))){
   alert('Este cliente já existe na lista de clientes ativos.');
   return;
 }
 if(!confirm('Reativar '+clientName(c)+'?\\n\\nSerá criada uma cópia nos Clientes. O registo original continuará no Histórico.'))return;
 const before=snapshotState();

 const copy=structuredClone(c);
 delete copy['Data Arquivo'];
 delete copy['Estado Arquivo'];
 DATA.push(copy);
 recordAction('Cliente reativado','Cliente reativado: '+clientName(c),before);
 saveDB();
 alert('Cliente reativado. O registo original continua no Histórico.');
 view('historico');
 renderHistory();
}


function euroAverage(v){
  const n = Number(String(v ?? '').replace(',','.'));
  if(!Number.isFinite(n)) return '—';
  return new Intl.NumberFormat('pt-PT',{
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(n)+' €';
}

function euroAfter(v){
  if(v===null||v===undefined||String(v).trim()==='') return '—';
  const n=Number(String(v).replace(',','.'));
  if(!Number.isFinite(n)) return '—';
  return String(n).replace('.',',')+' €';
}

function field(a,b){
 const raw=(b===null||b===undefined||b==='')?'—':String(b);
 const encoded=encodeURIComponent(raw);
 return `<div class="field"><label>${esc(a)}</label><div class="field-copy-row"><div class="value">${esc(raw)}</div><button type="button" class="copy-field" title="Copiar" aria-label="Copiar ${esc(a)}" onclick="copyFieldValue('${encoded}',this)">📋</button></div></div>`;
}
function label(k){return ({renewal:'🔔 Renovação',expired:'⚠️ Expirado',payment:'💶 Pagamento',maintenance:'🛠️ Manutenção',custom:'✏️ Personalizada'})[k]||k}
function fill(t,c){return t.replaceAll('[CLIENTE]',clientName(c)).replaceAll('[SERVIÇO]',c['Serviço']||'').replaceAll('[DATA]',dateOf(c['Validade']).toLocaleDateString('pt-PT')).replaceAll('[DIAS_RESTANTES]',days(c)).replaceAll('[VALOR]',c['Preço']||'0').replaceAll('[SALDO]',c['Saldo']||'0')}
function updateClientMessage(){
 if(!selected)return;
 const msg=document.getElementById('clientMessage');
 const sel=document.getElementById('clientTemplate');
 if(!msg||!sel)return;
 const c=DATA.find(x=>String(x['ID Cliente'])===String(selected));
 if(!c)return;
 const key=sel.value;
 const tpl=templates[key] ?? '';
 msg.value=fill(tpl,c);
}
function normalizePhone(v){
 const raw=String(v||'').trim();
 let digits=raw.replace(/\D/g,'');
 if(!digits)return '';
 // Portugal: aceita 9 dígitos nacionais e acrescenta +351.
 if(digits.length===9 && /^[29]/.test(digits)) digits='351'+digits;
 // Se vier com 00, remove o prefixo internacional.
 if(digits.startsWith('00')) digits=digits.slice(2);
 return digits;
}
function openExternal(primary,fallback){
 let opened=false;
 const mark=()=>{opened=true;};
 window.addEventListener('blur',mark,{once:true});
 try{ window.location.href=primary; }catch(e){}
 if(fallback){
   setTimeout(()=>{ if(!opened && document.visibilityState==='visible') window.location.href=fallback; },1400);
 }
}
function emailSubjectFromTemplate(){
 const sel=document.getElementById('clientTemplate');
 const key=sel?.value || '';
 return ({renewal:'Renovação',expired:'Expirado',payment:'Pagamento',maintenance:'Manutenção',custom:'Mensagem personalizada'})[key] || 'Contacto';
}
function prepare(ch){
 updateClientMessage();
 const c=DATA.find(x=>String(x['ID Cliente'])===String(selected));
 if(!c){ alert('Não foi possível identificar o cliente.'); return; }

 const msg=(document.getElementById('clientMessage')?.value || '').trim();

 if(ch==='Email'){
   const email=String(c['Email']||'').trim();
   if(!email){
     alert('Este cliente não tem um e-mail válido.');
     return;
   }
   const subject=emailSubjectFromTemplate();
   window.location.href='mailto:'+encodeURIComponent(email)+'?subject='+encodeURIComponent(subject)+'&body='+encodeURIComponent(msg);
   return;
 }

 const phone=normalizePhone(c['Contacto']);
 if(!phone){
   alert('Este cliente não tem um contacto válido.');
   return;
 }

 const encoded=encodeURIComponent(msg);

 if(ch==='WhatsApp'){
   // WhatsApp: abre diretamente a conversa com a mensagem já preenchida.
   window.location.href='https://wa.me/'+phone+'?text='+encoded;
   return;
 }

 if(ch==='Telegram'){
   // Telegram Android: deep link por número + mensagem pré-preenchida.
   // Se a pesquisa por número não for permitida pelas definições de privacidade,
   // abre o perfil/link do número como alternativa.
   openExternal(
     'tg://resolve?phone='+phone+'&text='+encoded,
     'https://t.me/+'+phone
   );
   return;
 }

 if(ch==='Signal'){
   // Signal Android: tenta abrir a conversa diretamente com mensagem preparada.
   // O fallback abre o perfil/link do contacto.
   openExternal(
     'sgnl://send?phone='+phone+'&text='+encoded,
     'https://signal.me/#p/%2B'+phone
   );
 }
}

async function copyTextRobust(text){
  try{
    if(navigator.clipboard && window.isSecureContext){
      await navigator.clipboard.writeText(text);
      return true;
    }
  }catch(e){}
  try{
    const ta=document.createElement('textarea');
    ta.value=text;
    ta.setAttribute('readonly','');
    ta.style.position='fixed';
    ta.style.left='-9999px';
    ta.style.top='0';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    const ok=document.execCommand('copy');
    ta.remove();
    return ok;
  }catch(e){
    return false;
  }
}
async function copyClientMessage(){
  const ok=await copyTextRobust(document.getElementById('clientMessage')?.value||'');
  alert(ok?'Mensagem copiada.':'Não foi possível copiar a mensagem.');
}
async function copyFieldValue(encoded,btn){
  const text=decodeURIComponent(encoded||'');
  const ok=await copyTextRobust(text);
  if(btn){
    const old=btn.textContent;
    btn.textContent=ok?'✓':'!';
    setTimeout(()=>btn.textContent=old,900);
  }
  if(!ok) alert('Não foi possível copiar este campo.');
}
function setupTabs(){
 tabs.innerHTML=Object.keys(templates).map(k=>`<button class="${currentTemplate===k?'primary active':''}" onclick="chooseTemplate('${k}')">${label(k)}</button>`).join('');
 template.value=templates[currentTemplate];
}
function chooseTemplate(k){currentTemplate=k;setupTabs()}
function saveTemplate(){const before=snapshotState();templates[currentTemplate]=template.value;recordAction('Mensagem alterada','Modelo de mensagem alterado: '+currentTemplate,before,snapshotState());localStorage.setItem('amTemplates',JSON.stringify(templates));alert('Modelo guardado.')}
function previewTemplate(){templatePreview.classList.remove('hidden');templatePreview.textContent=fill(template.value,DATA[0])}
function syncActivityPanelUI(){
 const p=document.getElementById('atividade');
 const list=document.getElementById('activityList');
 const search=document.getElementById('activitySearch');
 const btn=document.getElementById('activityCloseBtn');
 if(!p)return;

 const collapsed=p.dataset.activityCollapsed==='1';

 if(list){
   list.classList.toggle('hidden',collapsed);
   list.style.display=collapsed?'none':'';
 }
 if(search){
   search.classList.remove('hidden');
   search.style.display='';
 }
 if(btn)btn.textContent=collapsed?'Abrir':'Fechar';
}

function toggleActivityPanel(){
 const p=document.getElementById('atividade');
 if(!p)return;

 const collapsed=p.dataset.activityCollapsed==='1';
 p.dataset.activityCollapsed=collapsed?'0':'1';
 syncActivityPanelUI();

 if(collapsed) renderActivity();
}

function bindActivityToggleControls(){
 const btn=document.getElementById('activityCloseBtn');
 const title=document.getElementById('activityTitle');

 if(btn && !btn.dataset.bound){
   btn.dataset.bound='1';
   btn.addEventListener('click',function(e){
     e.preventDefault();
     e.stopPropagation();
     toggleActivityPanel();
   },true);
 }

 if(title && !title.dataset.bound){
   title.dataset.bound='1';
   title.addEventListener('click',function(e){
     e.preventDefault();
     e.stopPropagation();
     toggleActivityPanel();
   },true);
 }
}



// V697 — diálogo próprio e compacto da app para confirmações do Histórico.
// Evita o cabeçalho do navegador "Esta página indica" e mantém o visual consistente.
function showAppConfirm(title,message,okText='Sim',cancelText='Cancelar'){
  return new Promise(resolve=>{
    const old=document.getElementById('amConfirmOverlay');
    if(old) old.remove();
    const overlay=document.createElement('div');
    overlay.id='amConfirmOverlay';
    overlay.className='am-confirm-overlay';
    const normalizedTitle=String(title||'').trim();
    const managementCentered=/^(Repor|Limpar) base de dados\?$/i.test(normalizedTitle);
    const undoDialog=/^Pretende desfazer esta alteração\?$/i.test(normalizedTitle);
    overlay.innerHTML=`<div class="am-confirm-dialog${managementCentered?' am-management-centered':''}${undoDialog?' am-undo-dialog':''}" role="dialog" aria-modal="true" aria-labelledby="amConfirmTitle">
      <div class="${undoDialog?'am-undo-copy':''}"><h3 id="amConfirmTitle"></h3><p id="amConfirmMessage"></p></div>
      <div class="am-confirm-actions">
        <button type="button" class="am-confirm-cancel"></button>
        <button type="button" class="am-confirm-ok"></button>
      </div>
    </div>`;
    const finish=(value)=>{overlay.remove();resolve(value)};
    const titleEl=overlay.querySelector('#amConfirmTitle');
    if(undoDialog){
      // Mantém apenas a primeira linha centrada visualmente; "alteração?" começa exatamente por baixo de "Pretende".
      titleEl.innerHTML='Pretende desfazer esta<br>alteração?';
    }else{
      titleEl.textContent=title;
    }
    overlay.querySelector('#amConfirmMessage').textContent=message;
    const cancel=overlay.querySelector('.am-confirm-cancel');
    const ok=overlay.querySelector('.am-confirm-ok');
    cancel.textContent=cancelText; ok.textContent=okText;
    cancel.onclick=()=>finish(false); ok.onclick=()=>finish(true);
    overlay.addEventListener('click',e=>{if(e.target===overlay)finish(false)});
    const onKey=e=>{if(e.key==='Escape'){document.removeEventListener('keydown',onKey);finish(false)}};
    document.addEventListener('keydown',onKey);
    document.body.appendChild(overlay);
    ok.focus();
  });
}

function applyActivityUndo(a){
  if(!a || !a.before) return false;

  // Restaura o estado guardado imediatamente antes da ação selecionada.
  DATA=structuredClone(a.before.clientes||[]);
  ARCHIVED=structuredClone(a.before.arquivados||[]);
  CONFIG_LISTS=structuredClone(a.before.listas||DEFAULT_LISTS);
  templates=structuredClone(a.before.mensagens||templates);
  if(a.before.appSettings){ APP_SETTINGS=structuredClone(a.before.appSettings); saveAppSettings(); }

  // Nas novas interações o estado das subscrições também fica guardado.
  // Para renovações antigas, remove a renovação mais recente correspondente.
  if(Array.isArray(a.before.subscricoes)){
    SUBSCRIPTIONS=structuredClone(a.before.subscricoes);
  }else if(String(a.action||'').toLowerCase()==='cliente renovado'){
    const detail=String(a.detail||'');
    const parts=detail.replace(/^Renovação de\s*/i,'').split(' · ').map(v=>v.trim());
    const clientName=parts[0]||'';
    const subName=parts[1]||'';
    const target=SUBSCRIPTIONS.find(s=>String(s?.name||'').trim()===subName);
    if(target && Array.isArray(target.movements)){
      for(let i=target.movements.length-1;i>=0;i--){
        const m=target.movements[i]||{};
        if(m.type==='renewal' && String(m.client||'').trim()===clientName){
          target.movements.splice(i,1);
          break;
        }
      }
    }
  }

  v592SaveCompanyData('amClientesDB',DATA);
  v592SaveCompanyData('amClientesArchived',ARCHIVED);
  localStorage.setItem('amClientesConfigLists',JSON.stringify(CONFIG_LISTS));
  localStorage.setItem('amTemplates',JSON.stringify(templates));
  if(typeof saveSubscriptions==='function') saveSubscriptions();
  if(typeof renderSubscriptions==='function') renderSubscriptions();
  selected=null;
  // Mantém o utilizador exatamente no menu onde estava (por exemplo, Histórico).
  if(typeof render==='function') render();
  return true;
}

async function undoActivity(id){
 pruneActivity();
 const index=ACTIVITY.findIndex(a=>String(a.id)===String(id));
 if(index<0)return;

 const a=ACTIVITY[index];
 const latest=v172LatestUndoable();
 if(latest && String(latest.id)!==String(a.id)){
   await showAppAlert('Desfazer alterações','Para manter o histórico coerente, primeiro desfaz a alteração mais recente. Depois podes continuar a andar para trás.');
   return;
 }
 const detail=a.detail||a.action||'esta alteração';

 // Apresentação mais legível e visualmente organizada para a confirmação
 // de retroceder no Histórico.
 let confirmDetail=detail;
 if(String(a.action||'').toLowerCase()==='cliente renovado'){
   const parts=String(detail).replace(/^Renovação de\s*/i,'').split(' · ').map(v=>v.trim()).filter(Boolean);
   const clientName=String(parts[0]||'').replace(/^Cliente de\s*/i,'').trim();
   const subscriptionName=String(parts[1]||'').replace(/^Subscrição de\s*/i,'').trim();
   const licenseText=String(parts[2]||'').trim();
   const lines=['Renovação do cliente'];
   if(clientName) lines.push(clientName);
   lines.push('Subscrição do cliente');
   if(subscriptionName) lines.push(subscriptionName);
   if(licenseText) lines.push(licenseText);
   confirmDetail=lines.join('\n');
 }
 const confirmed=await showAppConfirm(
   'Pretende desfazer esta alteração?',
   confirmDetail,
   'Confirmar',
   'Cancelar'
 );
 if(!confirmed)return;

 try{
   if(typeof applyActivityUndo==='function'){
     const ok=applyActivityUndo(a);
     if(ok===false)return;
   }else if(typeof undoActivityByRecord==='function'){
     const ok=undoActivityByRecord(a);
     if(ok===false)return;
   }else{
     alert('Esta alteração não pode ser desfeita individualmente.');
     return;
   }

   // Mantém o registo e marca-o como desfeito, sem mudar para o menu Clientes.
   a.undone=true;
   a.undoneAt=new Date().toISOString();
   saveActivity();
   if(typeof view==='function') view('atividade');
   else renderActivity();
 }catch(err){
   console.error(err);
   alert('Não foi possível desfazer esta alteração.');
 }
}

function deleteActivity(id){
 pruneActivity();
 const index=ACTIVITY.findIndex(a=>String(a.id)===String(id));
 if(index<0)return;
 const a=ACTIVITY[index];

 if(!confirm('Apagar este registo do histórico?\\n\\n'+(a.detail||a.action||'Alteração')+'\\n\\nA alteração feita na aplicação não será desfeita; apenas este registo será removido do histórico.'))return;

 ACTIVITY.splice(index,1);
 saveActivity();
 renderActivity();
}

function v172ActivityClientName(a){
  const after=a?.after?.clientes;
  const before=a?.before?.clientes;
  if(Array.isArray(after)){
    const beforeList=Array.isArray(before)?before:[];
    for(const c of after){
      const b=v172ClientForSnapshot(beforeList,c);
      if(b && !v172ActivitySame(b,c)) return clientName(c);
    }
    if(String(a?.action||'').toLowerCase()==='cliente criado'){
      const id=String(a?.detail||'').match(/CLI\d+/)?.[0];
      const c=id?after.find(x=>String(x?.['ID Cliente']||'')===id):null;
      if(c)return clientName(c);
    }
  }
  const detail=String(a?.detail||'');
  const m=detail.match(/cliente(?: alterado| renovado| arquivado| reativado)?[:\s]+(.+?)(?:\s+—|\s+·|$)/i);
  return m?.[1]?.trim() || detail.replace(/^.*?:\s*/,'').trim() || 'Alteração';
}
function v172ActivityArea(a){
  const before=Array.isArray(a?.before?.clientes)?a.before.clientes:[];
  const after=Array.isArray(a?.after?.clientes)?a.after.clientes:[];
  let beforeClient=null,afterClient=null;
  for(const c of after){
    const b=v172ClientForSnapshot(before,c);
    if(b && !v172ActivitySame(b,c)){beforeClient=b;afterClient=c;break;}
  }
  if(!afterClient) return String(a?.detail||a?.action||'Alteração').replace(/^.*?—\s*/,'').replace(/\s*—.*$/,'').trim() || 'Alteração';
  const lines=v172DescribeClientChanges(beforeClient,afterClient);
  const areas=[];
  const add=(label)=>{if(!areas.includes(label))areas.push(label)};
  lines.forEach(line=>{
    if(/^Equipamento(?:\s+\d+|\s*:)/.test(line)) add('Equipamento');
    else if(/^(Serviço|Subscrição|Validade|Periodicidade|Valor|Saldo|Método de pagamento|Data de pagamento|Data de início)/.test(line)) add('Serviço e subscrição');
    else if(/^(VPN|Utilizador VPN|Password VPN)/.test(line)) add('VPN');
    else add('Dados do cliente');
  });
  return areas.join(' · ') || 'Alteração';
}

function renderActivity(){
 bindActivityToggleControls();

 const box=document.getElementById('activityList');
 const search=document.getElementById('activitySearch');
 const p=document.getElementById('atividade');
 if(!box)return;

 pruneActivity();
 saveActivity();

 if(p && p.dataset.activityCollapsed==='1'){
   syncActivityPanelUI();
   return;
 }

 syncActivityPanelUI();

 const q=(search?.value||'').trim().toLowerCase();
 const filtered=ACTIVITY.slice().reverse().filter(a=>{
   if(!q)return true;
   return String(a.action||'').toLowerCase().includes(q) ||
          String(a.detail||'').toLowerCase().includes(q) ||
          new Date(a.at).toLocaleString('pt-PT').toLowerCase().includes(q);
 });

 if(!filtered.length){
   box.innerHTML='<div class="muted" style="padding:20px">'+
     (ACTIVITY.length?'Nenhum resultado.':'Ainda não existem alterações registadas nos últimos 30 dias.')+
     '</div>';
   return;
 }

 box.innerHTML=filtered.map((a)=>{
   const d=new Date(a.at);
   const when=d.toLocaleString('pt-PT',{dateStyle:'short',timeStyle:'short'});
   const id=esc(a.id||'');
   const undone=!!a.undone;
   const redoDisabled=!!a.redoInvalid;
   const cardTitle=String(a.action||'Alteração');
   const cardName=v172ActivityClientName(a);
   const cardArea=v172ActivityArea(a);
   return `<div class="history historico-scroll-list activity-item${undone?' activity-undone':''}">
     <div class="activity-content" role="button" tabindex="0" title="Ver o que foi alterado" onclick="event.stopPropagation();showActivityDetail('${id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();event.stopPropagation();showActivityDetail('${id}')}">
       <b>${esc(cardTitle)}${undone?' · desfeito':''}</b>
       <div>${esc(cardName)}</div>
       <div>${esc(cardArea)}</div>
       <div class="muted">${esc(when)}</div>
     </div>
     <div class="activity-actions">
       ${undone ? `<button type="button" class="activity-redo" title="Refazer esta alteração" ${redoDisabled?'disabled':''} onclick="event.stopPropagation();redoActivity('${id}')">↪️</button>` : `<button type="button" class="activity-undo" title="Desfazer esta alteração" onclick="event.stopPropagation();undoActivity('${id}')">↩️</button>`}
       <button type="button" class="activity-delete" title="Apagar este registo" onclick="event.stopPropagation();deleteActivity('${id}')">🗑️</button>
     </div>
   </div>`;
 }).join('');
}

function undoLastChange(){
 pruneActivity();
 if(!ACTIVITY.length){
   alert('Não existem alterações para desfazer nos últimos 30 dias.');
   return;
 }
 const a=ACTIVITY[ACTIVITY.length-1];
 if(!a.before){
   alert('Esta alteração não tem um estado anterior disponível.');
   return;
 }
 if(!confirm('Voltar atrás na última alteração?\\n\\n'+a.detail+'\\n\\nO estado atual será substituído pelo estado imediatamente anterior.'))return;

 DATA=structuredClone(a.before.clientes||[]);
 ARCHIVED=structuredClone(a.before.arquivados||[]);
 CONFIG_LISTS=structuredClone(a.before.listas||DEFAULT_LISTS);
 templates=structuredClone(a.before.mensagens||templates);
 if(a.before.appSettings){ APP_SETTINGS=structuredClone(a.before.appSettings); saveAppSettings(); }
 if(Array.isArray(a.before.subscricoes)){ SUBSCRIPTIONS=structuredClone(a.before.subscricoes); if(typeof saveSubscriptions==='function') saveSubscriptions(); }

 v592SaveCompanyData('amClientesDB',DATA);
 v592SaveCompanyData('amClientesArchived',ARCHIVED);
 localStorage.setItem('amClientesConfigLists',JSON.stringify(CONFIG_LISTS));
 localStorage.setItem('amTemplates',JSON.stringify(templates));

 ACTIVITY.pop();
 saveActivity();
 selected=null;
 view('clientes');
 render();
 alert('Última alteração desfeita.');
}
function setActiveNav(id){
 const map={
   inicio:'navInicio',
   clientes:'navClientes',
   lista:'navClientes',
   todosClientes:'navClientes',
   mensagens:'navMensagens',
   historico:'navArquivados',
   atividade:'navHistorico',
   base:'navBase',
   config:'navConfig',
   gestao:'navGestao',
   subscricoes:'navSubscricoes',
   estatisticas:'navEstatisticas'
 };
 document.querySelectorAll('.nav button').forEach(b=>b.classList.remove('active'));
 const el=document.getElementById(map[id]||'');
 if(el)el.classList.add('active');
}


/* ===== Módulo Subscrições ===== */
let SUBSCRIPTIONS=[];
function v618SubscriptionsStorageKey(){
  return v592CompanyStorageKey('amClientesSubscriptions');
}
function loadSubscriptions(){
  try{
    const scopedKey=v618SubscriptionsStorageKey();
    let raw=localStorage.getItem(scopedKey);
    // Migração única: a base antiga global passa para a Empresa 1.
    if(raw===null && v586GetActiveCompany()?.id==='company_1'){
      const legacy=localStorage.getItem('amClientesSubscriptions');
      if(legacy!==null){
        localStorage.setItem(scopedKey,legacy);
        raw=legacy;
      }
    }
    SUBSCRIPTIONS=JSON.parse(raw||'[]');
  }
  catch(e){SUBSCRIPTIONS=[];}
  if(!Array.isArray(SUBSCRIPTIONS)) SUBSCRIPTIONS=[];
  // Se a base local estiver sem subscrições, criar os 5 exemplos padrão.
  // Não substitui subscrições existentes.
  if(SUBSCRIPTIONS.length===0 && !(typeof v675IsBaseEmpty==='function' && v675IsBaseEmpty())){
    SUBSCRIPTIONS=structuredClone(DEMO_SUBSCRIPTIONS);
    saveSubscriptions();
  }
  SUBSCRIPTIONS=SUBSCRIPTIONS.map(s=>({
    id:s.id||('SUB-'+Date.now()),
    type:s.type||'',
    name:s.name||'',
    client:s.client||'',
    limit:Math.max(1,Number(s.limit)||10),
    validityType:s.validityType||'purchase',
    licenseUsed:Math.max(0,Math.min(Number(s.licenseUsed)||0,Math.max(1,Number(s.limit)||10))),
    purchaseDate:s.purchaseDate||'',
    startDate:s.startDate||'',
    validityMonths:Math.max(0,Number(s.validityMonths)||0),
    endDate:s.endDate||'',
    cost:Math.max(0,Number(s.cost)||0),
    revenue:Math.max(0,Number(s.revenue)||0),
    movements:Array.isArray(s.movements)?s.movements.map(m=>({
      type:(m.type==='activation'||m.type==='renewal')?m.type:'purchase',
      quantity:Math.max(0,Number(m.quantity)||0),
      date:String(m.date||''),
      cost:Math.max(0,Number(m.cost)||0),
      client:String(m.client||''),
      months:Math.max(0,Number(m.months)||0),
      startDate:String(m.startDate||''),
      endDate:String(m.endDate||''),
      initial:!!m.initial
    })).filter(m=>m.quantity>0):[],
    initialPurchaseRecorded:!!s.initialPurchaseRecorded,
    devices:Array.isArray(s.devices)?s.devices.map(d=>({
      name:String(d.name||''),person:String(d.person||''),location:String(d.location||'')
    })):[]
  }));

  // V671 — As utilizações associadas também atualizam Utilizadas e Disponíveis.
  // V670 — Corrige a origem do erro: a primeira compra passa sempre a existir
  // também no histórico de movimentos. Para subscrições criadas antes desta
  // versão, faz uma migração única do stock inicial sem apagar movimentos já
  // registados. Assim, uma subscrição antiga com 300 iniciais + 10 comprados
  // passa a mostrar 310, tal como esperado.
  let repairedInitialMovements=false;
  SUBSCRIPTIONS.forEach(s=>{
    if(s.initialPurchaseRecorded) return;
    const initialQuantity=Math.max(1,Number(s.limit)||1);
    const date=String(s.purchaseDate||new Date().toISOString().slice(0,10));
    const cost=Math.max(0,Number(s.cost)||0);
    if(!Array.isArray(s.movements)) s.movements=[];
    const hasInitial=s.movements.some(m=>m&&m.initial===true);
    if(!hasInitial){
      s.movements.push({type:'purchase',quantity:initialQuantity,date,cost,client:'',months:0,startDate:'',endDate:'',initial:true});
      repairedInitialMovements=true;
    }
    s.initialPurchaseRecorded=true;
  });
  if(repairedInitialMovements) saveSubscriptions();
}
function saveSubscriptions(){
  localStorage.setItem(v618SubscriptionsStorageKey(),JSON.stringify(SUBSCRIPTIONS));
}
function subUsed(s){return Array.isArray(s.devices)?s.devices.length:0;}
function subState(s){
  const u=subUsed(s), l=Math.max(1,Number(s.limit)||10);
  return u>=l?'full':(u===l-1?'warning':'ok');
}
function subEsc(v){
  return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}
/* V179 — Ao editar um cliente a partir de Subscrições, o regresso abre a lista completa de Clientes, tal como o botão Clientes do menu superior. */
/* Cliente associado à subscrição: clicável para abrir diretamente a edição do cliente. */
if(!document.getElementById('v178SubClientStyle')){
  const st=document.createElement('style');
  st.id='v178SubClientStyle';
  st.textContent='.sub-client-link{display:inline;padding:0;border:0;background:none;color:inherit;font:inherit;text-align:left;cursor:pointer;text-decoration:none}.sub-client-link:hover{text-decoration:underline}';
  document.head.appendChild(st);
}

function subMovementSummary(s){
  const movements=Array.isArray(s?.movements)?s.movements:[];
  if(!movements.length){
    const purchased=Math.max(0,Number(s?.limit)||0);
    const consumed=Math.max(subUsed(s),Number(s?.licenseUsed)||0);
    return {purchased,consumed,available:Math.max(0,purchased-consumed),purchaseCost:Math.max(0,Number(s?.cost)||0)};
  }
  const purchased=movements.filter(m=>m.type==='purchase').reduce((n,m)=>n+Math.max(0,Number(m.quantity)||0),0);
  const movementConsumed=movements.filter(m=>m.type==='activation'||m.type==='renewal').reduce((n,m)=>n+Math.max(0,Number(m.quantity)||0),0);

  // V671 — Uma licença associada manualmente a um cliente/equipamento também
  // conta imediatamente como utilizada. Mantemos o maior dos dois valores para
  // não duplicar a mesma utilização quando ela já existe em Movimentos.
  const linkedConsumed=typeof subscriptionLinkedCount==='function'
    ? Math.max(0,Number(subscriptionLinkedCount(s))||0)
    : Math.max(0,Array.isArray(s?.devices)?s.devices.length:0);
  const consumed=Math.max(movementConsumed,linkedConsumed);

  const purchaseCost=movements.filter(m=>m.type==='purchase').reduce((n,m)=>n+Math.max(0,Number(m.cost)||0),0);
  return {purchased,consumed,available:Math.max(0,purchased-consumed),purchaseCost};
}
function subFormatDate(v){
  if(!v)return '';
  const d=new Date(String(v)+'T00:00:00');
  if(Number.isNaN(d.getTime()))return String(v);
  return d.toLocaleDateString('pt-PT');
}
function subMovementLabel(type){return type==='purchase'?'Compra':type==='activation'?'Ativação':'Renovação';}
function addSubscriptionMovement(si){
  const s=SUBSCRIPTIONS[si]; if(!s)return;
  const type=prompt('Tipo de movimento: Compra, Ativação ou Renovação','Compra');
  if(type===null)return;
  const normalized=String(type).trim().toLowerCase();
  const movementType=normalized.startsWith('a')?'activation':normalized.startsWith('r')?'renewal':'purchase';
  const quantity=Math.max(0,parseInt(prompt(movementType==='purchase'?'Quantidade comprada:':'Quantidade de licenças consumidas:',movementType==='purchase'?'10':'1')||'0',10));
  if(!quantity)return;
  const current=subMovementSummary(s);
  if((movementType==='activation'||movementType==='renewal') && quantity>current.available){
    alert('Não tens licenças suficientes disponíveis. Disponíveis: '+current.available+'.'); return;
  }
  const date=prompt('Data do movimento (AAAA-MM-DD):',new Date().toISOString().slice(0,10));
  if(date===null)return;
  let cost=0,client='',months=0,startDate='',endDate='';
  if(movementType==='purchase'){
    cost=Math.max(0,Number(prompt('Custo total desta compra (€):','0')||'0'));
  }else{
    client=String(prompt('Cliente (opcional):','')||'').trim();
    months=Math.max(0,parseInt(prompt('Validade em meses:','1')||'0',10));
    startDate=String(prompt('Data de ativação (AAAA-MM-DD):',date)||date);
    if(months>0){
      const d=new Date(startDate+'T00:00:00');
      if(!Number.isNaN(d.getTime())){ d.setMonth(d.getMonth()+months); endDate=d.toISOString().slice(0,10); }
    }
  }
  if(!Array.isArray(s.movements))s.movements=[];
  s.movements.push({type:movementType,quantity,date:String(date),cost,client,months,startDate,endDate});
  saveSubscriptions(); renderSubscriptions();
}
function editSubscriptionMovement(si,mi){
  const s=SUBSCRIPTIONS[si]; if(!s || !Array.isArray(s.movements) || !s.movements[mi])return;
  const m=s.movements[mi];
  const typeLabel=prompt('Tipo de movimento: Compra, Ativação ou Renovação',subMovementLabel(m.type));
  if(typeLabel===null)return;
  const normalized=String(typeLabel).trim().toLowerCase();
  const movementType=normalized.startsWith('a')?'activation':normalized.startsWith('r')?'renewal':'purchase';
  const quantity=Math.max(0,parseInt(prompt(movementType==='purchase'?'Quantidade comprada:':'Quantidade de licenças consumidas:',String(m.quantity||0))||'0',10));
  if(!quantity)return;
  const date=prompt('Data do movimento (AAAA-MM-DD):',String(m.date||new Date().toISOString().slice(0,10)));
  if(date===null)return;
  let cost=0,client='',months=0,startDate='',endDate='';
  if(movementType==='purchase'){
    cost=Math.max(0,Number(prompt('Custo total desta compra (€):',String(Number(m.cost)||0))||'0'));
  }else{
    client=String(prompt('Cliente (opcional):',String(m.client||''))||'').trim();
    months=Math.max(0,parseInt(prompt('Validade em meses:',String(Number(m.months)||1))||'0',10));
    startDate=String(prompt('Data de ativação (AAAA-MM-DD):',String(m.startDate||date))||date);
    if(months>0){
      const d=new Date(startDate+'T00:00:00');
      if(!Number.isNaN(d.getTime())){ d.setMonth(d.getMonth()+months); endDate=d.toISOString().slice(0,10); }
    }
  }
  s.movements[mi]={type:movementType,quantity,date:String(date),cost,client,months,startDate,endDate};
  saveSubscriptions(); renderSubscriptions();
}
function deleteSubscriptionMovement(si,mi){
  const s=SUBSCRIPTIONS[si]; if(!s || !Array.isArray(s.movements) || !s.movements[mi])return;
  if(!confirm('Apagar este movimento?'))return;
  s.movements.splice(mi,1);
  saveSubscriptions(); renderSubscriptions();
}
function renderSubscriptionMovements(s,i){
  const box=(s.movements||[]).map((m,index)=>({m,index})).sort((a,b)=>String(b.m.date||'').localeCompare(String(a.m.date||'')));
  if(!box.length)return '<div class="muted" style="padding:8px 0">Ainda não existem movimentos registados.</div>';
  return box.map(({m,index})=>{
    const sign=m.type==='purchase'?'+':'−';
    const detail=m.type==='purchase'
      ? (m.cost>0?' · '+euroAfter(m.cost):'')
      : (m.client?' · '+subEsc(m.client):'')+(m.endDate?' · termina '+subFormatDate(m.endDate):'');
    return `<div class="sub-movement-row"><div class="sub-movement-main"><span><strong>${subMovementLabel(m.type)}</strong> · ${subFormatDate(m.date)}</span><strong>${sign}${m.quantity}${detail}</strong></div><div class="sub-movement-actions"><button type="button" title="Editar movimento" onclick="event.stopPropagation();editSubscriptionMovement(${i},${index})">✎</button><button type="button" title="Apagar movimento" onclick="event.stopPropagation();deleteSubscriptionMovement(${i},${index})">🗑</button></div></div>`;
  }).join('');
}
function toggleSubscriptionMovements(titleEl){
  const section=titleEl?.closest('.sub-movements');
  if(!section)return;
  section.classList.toggle('v672-collapsed');
}

function renderSubscriptions(){
  const box=document.getElementById('subscriptionsContent');
  if(!box)return;
  if(!SUBSCRIPTIONS.length){
    box.innerHTML='<div class="muted" style="padding:18px 4px">Ainda não existem subscrições.</div>';
    return;
  }
  box.innerHTML=SUBSCRIPTIONS.map((s,i)=>{
    const summary=subMovementSummary(s);
    const used=Math.max(subscriptionLinkedCount(s),summary.consumed), lim=Math.max(1,summary.purchased||Number(s.limit)||10), state=summary.available<=0?'full':(summary.available<=1?'warning':'ok');
    const linkedClients=linkedSubscriptionClients(s.name);
    const displayClient=String(s.client||'').trim();
    const linked=linkedClients.map(c=>{
      const clientId=String(c['ID Cliente']||'');
      const clientNameValue=String(c['Nome']||'').trim();
      const clientLink=clientId && clientNameValue
        ? `<button type="button" class="sub-client-link" onclick="event.stopPropagation();editClient('${subEsc(clientId)}','subscription')">${subEsc(clientNameValue)}</button>`
        : `<span>${subEsc(clientNameValue)}</span>`;
      return `
      <div class="sub-device">
        <div class="sub-device-main">
          <strong>${subEsc(c['Equipamento']||'Equipamento')}</strong>
          ${clientLink}
        </div>
        <div class="sub-device-actions">
          <button type="button" class="sub-edit" title="Editar cliente" onclick="event.stopPropagation();editClient('${subEsc(clientId)}','subscription')">✎</button>
          <button type="button" class="sub-remove" title="Remover associação" onclick="event.stopPropagation();removeLinkedSubDevice(${i},'${subEsc(clientId)}')">🗑️</button>
        </div>
      </div>`;
    }).join('');
    const manual=(s.devices||[]).map((d,di)=>`
      <div class="sub-device">
        <div class="sub-device-main">
          <strong>${subEsc(d.name)}</strong>
          <span>${subEsc(d.person)}${d.location?' · '+subEsc(d.location):''}</span>
        </div>
        <div class="sub-device-actions">
          <button type="button" class="sub-edit" title="Editar equipamento" onclick="editSubDevice(${i},${di})">✎</button>
          <button type="button" class="sub-remove" title="Remover equipamento" onclick="removeSubDevice(${i},${di})">🗑️</button>
        </div>
      </div>`).join('');
    const devices=linked+manual;
    return `
      <div class="subscription-card v194-sub-card" draggable="true" ondragstart="v194SubDragStart(event,this)" ondragover="v194SubDragOver(event,this)" ondragleave="v194SubDragLeave(this)" ondrop="v194SubDrop(event,this)" ondragend="v194SubDragEnd(this)">
        <div class="sub-head">
          <div>
            <div class="v194-sub-title-row"><span class="v194-sub-sort-handle" title="Arrastar para ordenar">☷</span><h3 class="sub-title-link" title="Fechar lista de equipamentos" onclick="event.stopPropagation();toggleSubscriptionDevices(this)">${subEsc(s.name)}</h3></div>
            ${displayClient ? `<div class="muted">${subEsc(displayClient)}</div>` : ''}
            <div class="muted">Compradas: ${summary.purchased} · Utilizadas: ${summary.consumed} · Disponíveis: ${summary.available}</div>
            ${s.endDate ? `<div class="muted">Validade: ${subEsc(s.endDate)}</div>` : ''}
          </div>
          <div class="sub-counter sub-${state}">${used}/${lim}</div>
        </div>
        <div class="sub-actions">
          <button type="button" class="primary" onclick="addSubDevice(${i})">+ Equipamento</button>
          <button type="button" onclick="addSubscriptionMovement(${i})">+ Movimento</button>
          <button type="button" onclick="editSubscription(${i})">✎ Editar</button>
          <button type="button" onclick="deleteSubscription(${i})">🗑 Apagar</button>
        </div>
        <div class="sub-movements v672-collapsed"><button type="button" class="sub-movements-title" onclick="event.stopPropagation();toggleSubscriptionMovements(this)">Movimentos</button><div class="sub-movements-content">${renderSubscriptionMovements(s,i)}</div></div>
        <div class="sub-device-list">${devices||'<div class="muted" style="padding-top:10px">Nenhum equipamento associado.</div>'}</div>
      </div>`;
  }).join('');
}


function toggleSubscriptionDevices(titleEl){
  const card=titleEl?.closest('.subscription-card');
  if(!card)return;
  const list=card.querySelector('.sub-device-list');
  if(!list)return;
  const closed=list.classList.toggle('v193-collapsed');
  titleEl.title=closed?'Mostrar equipamentos':'Fechar lista de equipamentos';
}


function v194SubDragStart(ev,card){
  window.v194DraggingSubscription=card;
  card.classList.add('v194-sub-dragging');
  if(ev.dataTransfer){ev.dataTransfer.effectAllowed='move';try{ev.dataTransfer.setData('text/plain','move')}catch(_){}}
}
function v194SubDragOver(ev,card){
  if(!window.v194DraggingSubscription||window.v194DraggingSubscription===card)return;
  ev.preventDefault(); card.classList.add('v194-sub-drag-over');
}
function v194SubDragLeave(card){card.classList.remove('v194-sub-drag-over')}
function v194SubDrop(ev,card){
  ev.preventDefault();
  const from=window.v194DraggingSubscription;
  if(!from||from===card)return;
  const container=card.parentElement, r=card.getBoundingClientRect();
  if(ev.clientY>r.top+r.height/2)container.insertBefore(from,card.nextSibling);
  else container.insertBefore(from,card);
  const cards=[...container.querySelectorAll('.v194-sub-card')];
  const ids=cards.map((c,i)=>c.dataset.subscriptionId||String(i));
  v194SaveSubscriptionOrder(ids);
}
function v194SubDragEnd(card){
  document.querySelectorAll('.v194-sub-drag-over').forEach(x=>x.classList.remove('v194-sub-drag-over'));
  card.classList.remove('v194-sub-dragging'); window.v194DraggingSubscription=null;
}
function v194PrepareSubscriptionCards(){
  const cards=[...document.querySelectorAll('#subscricoes .subscription-card')];
  cards.forEach((card,i)=>{
    if(!card.dataset.subscriptionId){
      const s=(Array.isArray(SUBSCRIPTIONS)?SUBSCRIPTIONS:[])[i];
      card.dataset.subscriptionId=String(s?.id||s?.ID||s?.nome||s?.name||i);
    }
  });
}
function v194SaveSubscriptionOrder(ids){
  try{
    const current=Array.isArray(SUBSCRIPTIONS)?SUBSCRIPTIONS:[];
    const key=s=>String(s?.id||s?.ID||s?.nome||s?.name||'');
    const map=new Map(current.map(s=>[key(s),s]));
    const reordered=[];
    ids.forEach(id=>{const s=map.get(String(id));if(s)reordered.push(s)});
    current.forEach(s=>{if(!ids.includes(key(s)))reordered.push(s)});
    if(Array.isArray(SUBSCRIPTIONS))SUBSCRIPTIONS.splice(0,SUBSCRIPTIONS.length,...reordered);
    try{localStorage.setItem('am_subscriptions_order',JSON.stringify(ids))}catch(_){}
    if(typeof saveDB==='function')saveDB();
  }catch(_){}
}
function updateEstatisticasOpenCloseButton(){
  const body=document.getElementById('statsBody');
  const btn=document.getElementById('statsOpenCloseBtn');
  const panel=document.getElementById('estatisticas');
  if(!body||!btn)return;
  const closed=body.classList.contains('hidden');
  btn.textContent=closed?'Abrir':'Fechar';
  if(panel)panel.classList.toggle('stats-panel-collapsed',closed);
}
function toggleEstatisticasPanel(){
  const body=document.getElementById('statsBody');
  if(!body)return;
  body.classList.toggle('hidden');
  updateEstatisticasOpenCloseButton();
}
function toggleStatsSection(name){
  const section=document.getElementById('statsSection_'+name);
  if(!section)return;
  section.classList.toggle('hidden');
  const card=section.closest('.stats-section-card');
  if(card)card.classList.toggle('stats-section-collapsed',section.classList.contains('hidden'));
}
function openEstatisticas(){
  view('estatisticas');
  const panel=document.getElementById('estatisticas');
  const body=document.getElementById('statsBody');
  if(panel) panel.classList.remove('hidden');
  if(body) body.classList.remove('hidden');
  ['status','services','subscriptions','vpns','stock','revenue'].forEach(name=>{
    const section=document.getElementById('statsSection_'+name);
    if(!section)return;
    section.classList.add('hidden');
    const card=section.closest('.stats-section-card');
    if(card)card.classList.add('stats-section-collapsed');
  });
  updateEstatisticasOpenCloseButton();
  renderEstatisticas();
}
function renderEstatisticas(){
  const summary=document.getElementById('statsSummary');
  const stockBox=document.getElementById('statsStock');
  const statusBox=document.getElementById('statsClientStatus');
  const services=document.getElementById('statsServices');
  const subBox=document.getElementById('statsSubscriptions');
  const vpnBox=document.getElementById('statsVpns');
  const revenueBox=document.getElementById('statsRevenue');
  if(!summary||!services)return;

  // ===== Clientes =====
  const total=DATA.length;
  let active=0,warning=0,expired=0;
  DATA.forEach(c=>{
    const st=status(c);
    if(st==='active')active++;
    else if(st==='warning')warning++;
    else expired++;
  });

  // ===== Subscrições =====
  const subs=Array.isArray(SUBSCRIPTIONS)?SUBSCRIPTIONS:[];
  const totalSubs=subs.length;
  const totalCapacity=subs.reduce((n,s)=>n+Math.max(1,Number(s.limit)||0),0);
  const totalUsed=subs.reduce((n,s)=>n+subUsed(s),0);
  const totalAvailable=Math.max(0,totalCapacity-totalUsed);

  // ===== Stock dos catálogos =====
  const equipamentos=getCatalog('equipamentos');
  const produtos=getCatalog('produtos');
  const stockItems=[];
  [...equipamentos,...produtos].forEach(r=>{
    const comprada=Number(r.quantidade_comprada)||0;
    const utilizada=Number(r.quantidade_utilizada)||0;
    const stock=Math.max(0,comprada-utilizada);
    const minimo=Number(r.stock_minimo)||0;
    const state=stock===0?'red':(minimo>0 && stock<=minimo?'orange':'green');
    stockItems.push({nome:String(r.nome||'Sem nome'),stock,minimo,state,tipo:equipamentos.includes(r)?'Equipamento':'Produto'});
  });
  const totalStockUnits=stockItems.reduce((n,r)=>n+r.stock,0);
  const noStock=stockItems.filter(r=>r.stock===0).length;
  const lowStock=stockItems.filter(r=>r.stock>0 && r.minimo>0 && r.stock<=r.minimo).length;

  // Resumo rápido: apenas indicadores que já existem e são fiáveis nos dados atuais.
  summary.innerHTML=`
    <div class="stat-card"><strong>${total}</strong><span>Total de clientes</span></div>
    <div class="stat-card"><strong>${active}</strong><span>Clientes ativos</span></div>
    <div class="stat-card"><strong>${totalSubs}</strong><span>Subscrições</span></div>
    <div class="stat-card"><strong>${noStock+lowStock}</strong><span>Alertas de stock</span></div>
  `;

  if(statusBox){
    statusBox.innerHTML=`
      <div class="stats-row"><span>🟢 Ativos</span><strong>${active}</strong></div>
      <div class="stats-row"><span>🟠 A expirar</span><strong>${warning}</strong></div>
      <div class="stats-row"><span>🔴 Expirados</span><strong>${expired}</strong></div>`;
  }

  // ===== Clientes por serviço =====
  const counts={};
  DATA.forEach(c=>{
    const service=String(c['Serviço']||'').trim();
    if(!service)return;
    counts[service]=(counts[service]||0)+1;
  });
  const rows=Object.entries(counts).sort((a,b)=>b[1]-a[1]);
  services.innerHTML=rows.length
    ? rows.map(([name,count])=>`<div class="stats-row"><span>${esc(name)}</span><strong>${count}</strong></div>`).join('')
    : '<div class="muted" style="padding:12px 0">Ainda não existem serviços atribuídos.</div>';

  // ===== Subscrições =====
  if(subBox){
    const today=new Date();
    today.setHours(0,0,0,0);
    const expiryRows=subs.map(s=>{
      if(!s.endDate)return '';
      const d=new Date(String(s.endDate)+'T00:00:00');
      if(Number.isNaN(d.getTime()))return '';
      const days=Math.ceil((d-today)/86400000);
      if(days<0)return `<div class="stats-row"><span>🔴 ${esc(s.name||s.type||'Subscrição')}</span><strong>Expirada</strong></div>`;
      if(days<=30)return `<div class="stats-row"><span>🟠 ${esc(s.name||s.type||'Subscrição')}</span><strong>${days} dias</strong></div>`;
      return '';
    }).join('');
    const subRows=subs.map(s=>{
      const sm=subMovementSummary(s);
      return `<div class="stats-row"><span>🔐 ${esc(s.name||s.type||'Subscrição')}</span><strong>${sm.consumed}/${sm.purchased} · ${sm.available} livres</strong></div>`;
    }).join('');
    const monthNames=['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
    const purchaseMonthly=Array(12).fill(0), purchaseCostMonthly=Array(12).fill(0), consumeMonthly=Array(12).fill(0);
    subs.forEach(s=>(Array.isArray(s.movements)?s.movements:[]).forEach(m=>{
      const d=new Date(String(m.date||'')+'T00:00:00'); if(Number.isNaN(d.getTime()))return;
      const idx=d.getMonth();
      if(m.type==='purchase'){purchaseMonthly[idx]+=Number(m.quantity)||0; purchaseCostMonthly[idx]+=Number(m.cost)||0;}
      else {consumeMonthly[idx]+=Number(m.quantity)||0;}
    }));
    const monthlyRows=monthNames.map((m,idx)=>{
      if(!purchaseMonthly[idx]&&!consumeMonthly[idx]&&!purchaseCostMonthly[idx])return '';
      return `<div class="stats-row"><span>${m}</span><strong>+${purchaseMonthly[idx]} compradas · −${consumeMonthly[idx]} consumidas · ${euroAfter(purchaseCostMonthly[idx])}</strong></div>`;
    }).join('');
    const expiryBlock=expiryRows
      ? `<div style="margin-top:10px"><strong>⚠️ A expirar / expiradas</strong>${expiryRows}</div>`
      : `<div class="muted" style="padding:10px 0">Nenhuma subscrição a expirar nos próximos 30 dias.</div>`;
    subBox.innerHTML=`
      <div class="stats-row"><span>Total de subscrições</span><strong>${totalSubs}</strong></div>
      ${expiryBlock}
      ${subRows?`<div style="margin-top:10px"><strong>Licenças por subscrição</strong>${subRows}</div>`:''}
      ${monthlyRows?`<div style="margin-top:10px"><strong>Movimento mensal</strong>${monthlyRows}</div>`:''}`;
  }

  // ===== VPN =====
  // Não contar o simples campo VPN dos clientes: isso pode representar apenas
  // uma configuração do cliente. A estatística mostra apenas VPNs/subscrições
  // explicitamente registadas como VPN.
  const vpnSubs=subs.filter(s=>{
    const text=(String(s.type||'')+' '+String(s.name||'')).toLowerCase();
    return /\bvpn\b/.test(text);
  });
  if(vpnBox){
    vpnBox.innerHTML=`
      <div class="stats-row"><span>VPNs registadas</span><strong>${vpnSubs.length}</strong></div>
      ${vpnSubs.length
        ? vpnSubs.map(s=>`<div class="stats-row"><span>🌐 ${esc(s.name||s.type||'VPN')}</span><strong>${subUsed(s)}/${Math.max(1,Number(s.limit)||10)}</strong></div>`).join('')
        : '<div class="muted" style="padding:12px 0">Ainda não existem VPNs registadas como subscrição.</div>'}`;
  }

  // ===== Stock =====
  if(stockBox){
    const lowRows=stockItems.filter(r=>r.state!=='green');
    stockBox.innerHTML=`
      <div class="stats-row"><span>Equipamentos em catálogo</span><strong>${equipamentos.length}</strong></div>
      <div class="stats-row"><span>Produtos / consumíveis em catálogo</span><strong>${produtos.length}</strong></div>
      <div class="stats-row"><span>Stock total</span><strong>${totalStockUnits}</strong></div>
      <div class="stats-row"><span>🟠 Stock baixo</span><strong>${lowStock}</strong></div>
      <div class="stats-row"><span>🔴 Sem stock</span><strong>${noStock}</strong></div>
      ${lowRows.length?`<div style="margin-top:10px"><strong>Itens a acompanhar</strong>${lowRows.map(r=>`<div class="stats-row"><span><span class="catalog-stock-dot ${r.state}"></span>${esc(r.nome)}</span><strong>${r.stock}</strong></div>`).join('')}</div>`:''}`;
  }

  // ===== Faturação mensal =====
  const now=new Date();
  const year=now.getFullYear();
  const monthly=Array(12).fill(0);
  let annual=0;
  DATA.forEach(c=>{
    const raw=String(c['Pagamento']||'').trim();
    if(!raw)return;
    const d=new Date(raw);
    if(Number.isNaN(d.getTime()) || d.getFullYear()!==year)return;
    const value=Number(String(c['Preço']??'').replace(',','.'));
    if(!Number.isFinite(value))return;
    monthly[d.getMonth()]+=value;
    annual+=value;
  });

  const maxMonth=Math.max(...monthly,0);
  const monthNames=['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
  if(revenueBox){
    revenueBox.innerHTML=`
      <div class="revenue-summary">
        <div class="revenue-total"><strong>${euroAfter(annual)}</strong><span>Total ${year}</span></div>
        <div class="revenue-average"><strong>${euroAverage(annual/12)}</strong><span>Média mensal</span></div>
      </div>
      <div class="revenue-table">
        ${monthly.map((amount,i)=>{
          const width=maxMonth?Math.max(3,(amount/maxMonth)*100):0;
          return `<div class="revenue-row">
            <div class="revenue-month"><span>${monthNames[i]}</span><strong>${euroAfter(amount)}</strong></div>
            <div class="revenue-bar"><span style="width:${width}%"></span></div>
          </div>`;
        }).join('')}
      </div>`;
  }
}

function toggleSubscriptionCreatePanel(){
  const root=document.getElementById('subscricoes');
  const panel=document.getElementById('subscriptionCreatePanel');
  if(!root || !panel)return;
  const btn=root.querySelector('#subscriptionCreateToggleBtn');
  const wasOpen=!panel.classList.contains('hidden');
  panel.classList.toggle('hidden', wasOpen);
  if(btn) btn.textContent=wasOpen ? 'Abrir' : 'Fechar';
}
function openSubscriptions(){
  loadSubscriptions();
  try{ v75RenderServiceBuilder(); }catch(e){}
  view('subscricoes');

  // V155 — ao entrar no módulo, os dois blocos internos começam fechados.
  // As subscrições existentes permanecem visíveis; apenas o formulário de
  // criação de nova subscrição fica recolhido.
  const services=document.getElementById('servicesManagement');
  const panel=document.getElementById('subscriptionCreatePanel');
  const btn=document.getElementById('subscriptionCreateToggleBtn');
  if(services) services.classList.add('v146-inner-collapsed');
  if(panel){
    panel.classList.remove('v146-inner-collapsed');
    panel.classList.add('v153-form-collapsed');
  }
  if(btn) btn.textContent='Fechar';

  renderSubscriptions();

  // V545 — ao entrar no menu Subscrições, todas as listas de equipamentos
  // começam fechadas. Cada subscrição pode depois ser aberta individualmente.
  document.querySelectorAll('#subscriptionsContent .subscription-card').forEach(card=>{
    const list=card.querySelector('.sub-device-list');
    const title=card.querySelector('.sub-title-link');
    if(list) list.classList.add('v193-collapsed');
    if(title) title.title='Mostrar equipamentos';
  });
}
function addSubscription(){
  const type=(document.getElementById('subType')?.value||'').trim();
  const name=(document.getElementById('subName')?.value||'').trim();
  const client=(document.getElementById('subClient')?.value||'').trim();
  const limit=Math.max(1,parseInt(document.getElementById('subLimit')?.value||'1',10));
  const validityType=document.getElementById('subValidityType')?.value||'purchase';
  const licenseUsed=Math.max(0,Math.min(parseInt(document.getElementById('subLicenseUsed')?.value||'0',10),limit));
  const purchaseDate=document.getElementById('subPurchaseDate')?.value||'';
  const startDate=document.getElementById('subStartDate')?.value||'';
  const validityMonths=Math.max(0,parseInt(document.getElementById('subValidityMonths')?.value||'0',10));
  const endDate=document.getElementById('subEndDate')?.value||'';
  const cost=Math.max(0,Number(document.getElementById('subCost')?.value||'0'));
  const revenue=Math.max(0,Number(document.getElementById('subRevenue')?.value||'0'));
  if(!name){alert('Indica o nome da subscrição.');return;}
  const initialMovementDate=String(purchaseDate||new Date().toISOString().slice(0,10));
  const initialMovement={type:'purchase',quantity:limit,date:initialMovementDate,cost,client:'',months:0,startDate:'',endDate:'',initial:true};
  SUBSCRIPTIONS.push({id:'SUB-'+Date.now(),type,name,client,limit,validityType,licenseUsed,purchaseDate,startDate,validityMonths,endDate,cost,revenue,movements:[initialMovement],initialPurchaseRecorded:true,devices:[]});
  saveSubscriptions(); renderSubscriptions();
  ['subType','subName','subClient','subLimit','subLicenseUsed','subPurchaseDate','subStartDate','subValidityMonths','subEndDate','subCost','subRevenue'].forEach(id=>{
    const el=document.getElementById(id); if(el) el.value='';
  });
  const validity=document.getElementById('subValidityType'); if(validity) validity.value='';
}
function editSubscription(i){
  const s=SUBSCRIPTIONS[i];
  if(!s)return;

  const set=(id,v)=>{
    const el=document.getElementById(id);
    if(el)el.value=v ?? '';
  };

  set('subType',s.type||'');
  set('subName',s.name||'');
  set('subClient',s.client||'');
  set('subLimit',Math.max(1,Number(s.limit)||10));
  set('subValidityType',s.validityType||'purchase');
  set('subLicenseUsed',Math.max(0,Number(s.licenseUsed)||0));
  set('subPurchaseDate',s.purchaseDate||'');
  set('subStartDate',s.startDate||'');
  set('subValidityMonths',Math.max(0,Number(s.validityMonths)||0));
  set('subEndDate',s.endDate||'');
  set('subCost',Math.max(0,Number(s.cost)||0));
  set('subRevenue',Math.max(0,Number(s.revenue)||0));

  window.editingSubscriptionIndex=i;

  const panel=document.getElementById('subscriptionCreatePanel');
  const title=document.querySelector('#subscricoes .subscricoes-title-close');
  const addBtn=panel ? panel.querySelector('.actions button') : null;

  if(panel) panel.classList.remove('hidden');
  const toggle=document.getElementById('subscriptionCreateToggleBtn');
  if(toggle) toggle.textContent='Fechar';

  if(title) title.innerHTML='🔐 Editar subscrição';

  if(addBtn){
    addBtn.textContent='💾 Guardar';
    addBtn.onclick=function(){ saveEditedSubscription(); };
    if(addBtn.parentNode){
      addBtn.parentNode.style.display='flex';
      addBtn.parentNode.style.flexWrap='wrap';
      addBtn.parentNode.style.alignItems='center';
      addBtn.parentNode.style.gap='10px';
    }

    let cancelBtn=document.getElementById('cancelSubscriptionEditBtn');
    if(!cancelBtn){
      cancelBtn=document.createElement('button');
      cancelBtn.id='cancelSubscriptionEditBtn';
      cancelBtn.type='button';
      cancelBtn.textContent='Cancelar';
      cancelBtn.style.marginLeft='0';
      cancelBtn.onclick=function(){ cancelSubscriptionEdit(); };
      addBtn.parentNode.appendChild(cancelBtn);
    }
    cancelBtn.style.display='inline-block';
  }

  if(panel){
    panel.scrollIntoView({behavior:'smooth',block:'start'});
  }
}
function deleteSubscription(i){
  const s=SUBSCRIPTIONS[i];if(!s)return;
  if(!confirm('Apagar a subscrição "'+s.name+'"?'))return;
  SUBSCRIPTIONS.splice(i,1);saveSubscriptions();renderSubscriptions();
}
function addSubDevice(i){
  const s=SUBSCRIPTIONS[i];if(!s)return;
  const used=subscriptionLinkedCount(s),lim=Math.max(1,Number(s.limit)||10);
  if(used>=lim){
    alert('⚠️ Esta subscrição já atingiu o limite de '+lim+' equipamentos.');
    return;
  }
  const name=prompt('Nome do equipamento:','');if(name===null||!name.trim())return;
  const person=prompt('Pessoa/utilizador:','');if(person===null)return;
  const location=prompt('Local:','');if(location===null)return;
  s.devices.push({name:name.trim(),person:person.trim(),location:location.trim()});
  saveSubscriptions();renderSubscriptions();
}
function editSubDevice(si,di){
  const s=SUBSCRIPTIONS[si], d=s?.devices?.[di];
  if(!d)return;
  const name=prompt('Nome do equipamento:',String(d.name||''));
  if(name===null||!name.trim())return;
  const person=prompt('Pessoa/utilizador:',String(d.person||''));
  if(person===null)return;
  const location=prompt('Local:',String(d.location||''));
  if(location===null)return;
  d.name=name.trim();
  d.person=person.trim();
  d.location=location.trim();
  saveSubscriptions();
  renderSubscriptions();
}
function removeSubDevice(si,di){
  const s=SUBSCRIPTIONS[si];if(!s||!s.devices[di])return;
  if(!confirm('Remover este equipamento da subscrição?'))return;
  s.devices.splice(di,1);saveSubscriptions();renderSubscriptions();
}
function removeLinkedSubDevice(si,clientId){
  const s=SUBSCRIPTIONS[si];
  const c=DATA.find(x=>String(x['ID Cliente'])===String(clientId));
  if(!s||!c)return;
  if(!confirm('Remover a associação deste cliente à subscrição \"'+s.name+'\"?'))return;

  const target=String(s.name||'').trim();
  if(Array.isArray(c.equipamentos)){
    c.equipamentos.forEach(e=>{
      if(String(e?.subscricao||'').trim()===target)e.subscricao='';
      if(Array.isArray(e?.vpns)) e.vpns.forEach(v=>{
        if(String(v?.subscricao||'').trim()===target)v.subscricao='';
      });
    });
  }

  // Reconstroi os campos antigos a partir do primeiro equipamento/VPN ainda associado.
  const eqs=Array.isArray(c.equipamentos)?c.equipamentos:[];
  const eq0=eqs[0]||{};
  c['Equipamento']=String(eq0.nome||'');
  c['Mac Adress']=String(eq0.mac||'');
  c['Utilizador']=String(eq0.utilizador||'');
  c['Senha']=String(eq0.senha||'');
  c['Link']=String(eq0.link||'');
  const vpn=eqs.flatMap(e=>Array.isArray(e?.vpns)?e.vpns:[]).find(v=>String(v?.nome||'').trim()||String(v?.subscricao||'').trim());
  c['VPN']=String(vpn?.nome||'');
  c['Utilizador VPN']=String(vpn?.utilizador||'');
  c['Password VPN']=String(vpn?.senha||'');
  c['Subscrição']=String(vpn?.subscricao||'');

  saveDB();
  renderSubscriptions();
  render();
}


function toggleGestao(){
  const body = document.getElementById('gestaoBody');
  const closeBtn = document.getElementById('gestaoCloseBtn');
  if(!body) return;
  body.hidden = !body.hidden;
  if(closeBtn) closeBtn.textContent = body.hidden ? 'Abrir' : 'Fechar';
}




const CATALOGS = {
  equipamentos:{title:'Equipamentos',icon:'📹'},
  produtos:{title:'Produtos / Consumíveis',icon:'📦'},
  servicos:{title:'Serviços',icon:'🛠️'},
  marcas:{title:'Marcas',icon:'🏷️'}
};

function catalogStoreKey(t){return 'am_catalog_'+t}
function v618CatalogStorageKey(t){
  return v592CompanyStorageKey(catalogStoreKey(t));
}
function getCatalog(t){
  try{
    const scopedKey=v618CatalogStorageKey(t);
    let raw=localStorage.getItem(scopedKey);
    // Migração única: o catálogo global antigo fica associado à Empresa 1.
    if(raw===null && v586GetActiveCompany()?.id==='company_1'){
      const legacy=localStorage.getItem(catalogStoreKey(t));
      if(legacy!==null){
        localStorage.setItem(scopedKey,legacy);
        raw=legacy;
      }
    }
    return JSON.parse(raw||'[]');
  }
  catch(e){return []}
}
function setCatalog(t,r){
  localStorage.setItem(v618CatalogStorageKey(t),JSON.stringify(r));
}

function seedCatalogExamples(){
  const examples={
    equipamentos:[
      {nome:'Equipamento 1',tipo:'Câmara',marca:'Marca 1',modelo:'Modelo 1',referencia:'REF-001',categoria:'Câmara IP',custo:'0',pvp:'0',venda:'0',foto:''},
      {nome:'Equipamento 2',tipo:'NVR',marca:'Marca 2',modelo:'Modelo 2',referencia:'REF-002',categoria:'NVR',custo:'0',pvp:'0',venda:'0',foto:''},
      {nome:'Equipamento 3',tipo:'Router',marca:'Marca 3',modelo:'Modelo 3',referencia:'REF-003',categoria:'Router',custo:'0',pvp:'0',venda:'0',foto:''},
      {nome:'Equipamento 4',tipo:'Alarme',marca:'Marca 4',modelo:'Modelo 4',referencia:'REF-004',categoria:'Alarme',custo:'0',pvp:'0',venda:'0',foto:''},
      {nome:'Equipamento 5',tipo:'Acessório',marca:'Marca 5',modelo:'Modelo 5',referencia:'REF-005',categoria:'Acessório',custo:'0',pvp:'0',venda:'0',foto:''}
    ],
    produtos:[
      {nome:'Produto 1',marca:'Marca 1',tipo:'Consumível',unidade:'unidade',quantidade:'0',custo:'0',venda:'0'},
      {nome:'Produto 2',marca:'Marca 2',tipo:'Consumível',unidade:'metro',quantidade:'0',custo:'0',venda:'0'},
      {nome:'Produto 3',marca:'Marca 3',tipo:'Material',unidade:'caixa',quantidade:'0',custo:'0',venda:'0'},
      {nome:'Produto 4',marca:'Marca 4',tipo:'Material',unidade:'unidade',quantidade:'0',custo:'0',venda:'0'},
      {nome:'Produto 5',marca:'Marca 5',tipo:'Consumível',unidade:'unidade',quantidade:'0',custo:'0',venda:'0'}
    ],
    servicos:[
      {nome:'Serviço 1',tipo:'Mão de obra',unidade:'Hora',venda:'10'},
      {nome:'Serviço 2',tipo:'Mão de obra',unidade:'Hora',venda:'20'},
      {nome:'Serviço 3',tipo:'Configuração',unidade:'Serviço',venda:'30'},
      {nome:'Serviço 4',tipo:'Manutenção',unidade:'Serviço',venda:'40'},
      {nome:'Serviço 5',tipo:'Instalação',unidade:'Serviço',venda:'50'}
    ],
    marcas:[
      {nome:'Marca 1'},
      {nome:'Marca 2'},
      {nome:'Marca 3'},
      {nome:'Marca 4'},
      {nome:'Marca 5'}
    ]
  };

  Object.keys(examples).forEach(type=>{
    if(getCatalog(type).length===0) setCatalog(type,examples[type]);
  });
}

function escHtml(v){
  return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))
}

function openCatalogos(){
  document.querySelectorAll('button[id^="nav"]').forEach(b=>b.classList.remove('active'));
  const nav=document.getElementById('navCatalogos');
  if(nav) nav.classList.add('active');

  const host=document.getElementById('catalogos');
  if(!host)return;

  // O botão superior apenas seleciona/abre o módulo.
  // Abrir/fechar o conteúdo é feito pelo botão dentro do próprio módulo.
  host.classList.remove('hidden');
  host.dataset.catalogReady='1';
  host.dataset.catalogCollapsed='0';

  ['clientes','lista','mensagens','historico','atividade','base','gestao','subscricoes','estatisticas','todosClientes','config'].forEach(id=>{
    const el=document.getElementById(id);
    if(el && id!=='catalogos') el.classList.add('hidden');
  });

  host.innerHTML=`
    <div class="card">
      <div id="catalogosHeader" style="display:flex;justify-content:space-between;align-items:center;gap:10px;cursor:pointer">
        <div>
          <h2 id="catalogosTitle" style="margin:0;cursor:pointer;user-select:none" title="Abrir/fechar catálogos">📦 Catálogos</h2>
          
        </div>
        <button type="button" class="primary" id="catalogosToggleBtn">Fechar</button>
      </div>

      <div id="catalogosBody">
        <div style="margin-top:14px;display:flex;flex-direction:column;gap:10px;width:100%">
          <button type="button" class="card catalog-option" data-catalog="equipamentos">
            <strong>📹 Equipamentos</strong><div class="muted">Para instalação em clientes</div>
          </button>
          <button type="button" class="card catalog-option" data-catalog="produtos">
            <strong>📦 Produtos / Consumíveis</strong><div class="muted">Material e consumíveis com stock</div>
          </button>
          <button type="button" class="card catalog-option" data-catalog="marcas">
            <strong>🏷️ Marcas</strong><div class="muted">De equipamentos e produtos</div>
          </button>
        </div>
        <div id="catalogWork" class="card" style="margin-top:14px;display:none"></div>
      </div>
    </div>`;

  host.querySelectorAll("[data-catalog]").forEach(btn=>{
    btn.addEventListener("click",()=>openCatalog(btn.dataset.catalog));
  });

  const toggle=document.getElementById('catalogosToggleBtn');
  const title=document.getElementById('catalogosTitle');
  const header=document.getElementById('catalogosHeader');

  if(toggle) toggle.addEventListener('click',e=>{
    e.preventDefault(); e.stopPropagation(); toggleCatalogosPanel();
  });
  if(title) title.addEventListener('click',e=>{
    e.preventDefault(); e.stopPropagation(); toggleCatalogosPanel();
  });
  if(header) header.addEventListener('click',e=>{
    if(e.target.closest('button')) return;
    toggleCatalogosPanel();
  });
}

function toggleCatalogosPanel(){
  const host=document.getElementById('catalogos');
  const body=document.getElementById('catalogosBody');
  const btn=document.getElementById('catalogosToggleBtn');
  if(!host || !body)return;

  const isClosed = host.dataset.catalogCollapsed === '1';

  if(isClosed){
    // Abrir
    host.dataset.catalogCollapsed='0';
    body.classList.remove('hidden');
    body.style.display='';
    if(btn) btn.textContent='Fechar';
  }else{
    // Fechar
    host.dataset.catalogCollapsed='1';
    body.classList.add('hidden');
    body.style.display='none';
    if(btn) btn.textContent='Abrir';
  }
}


function catalogBrandOptions(selected=''){
  const marcas=getCatalog('marcas');
  const opts=['<option value="">— Selecionar marca —</option>'];
  marcas.forEach(m=>{
    const nome=String(m.nome||'').trim();
    if(!nome)return;
    const sel=nome===String(selected||'').trim()?' selected':'';
    opts.push(`<option value="${escHtml(nome)}"${sel}>${escHtml(nome)}</option>`);
  });
  return opts.join('');
}

function equipmentConfigOptions(key,current=''){
  const arr=Array.isArray(CONFIG_LISTS?.[key])?CONFIG_LISTS[key]:[];
  const cur=String(current||'').trim();
  const labels={equipamentos:'tipo de equipamento',nome_equipamentos:'marca do equipamento'};
  const out=[`<option value="">— Selecionar${labels[key]?' '+labels[key]:''} —</option>`];
  const seen=new Set();
  arr.forEach(v=>{
    const text=String(v||'').trim();
    const norm=text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    if(!text||seen.has(norm))return;
    seen.add(norm);
    out.push(`<option value="${escHtml(text)}"${text===cur?' selected':''}>${escHtml(text)}</option>`);
  });
  out.push('<option value="__custom__">✏️ Outro...</option>');
  return out.join('');
}
function equipmentConfigSelect(key,id,current,placeholder){
  const cur=String(current||'');
  const arr=Array.isArray(CONFIG_LISTS?.[key])?CONFIG_LISTS[key]:[];
  const found=arr.some(v=>String(v)===cur);
  const displayCustom=cur && !found ? 'block' : 'none';
  return `<select id="${id}_select" onchange="
      const val=this.value;
      const input=document.getElementById('${id}');
      if(val==='__custom__'){
        input.style.display='block'; input.value=''; input.focus();
      }else{
        input.style.display='none'; input.value=val;
      }
    ">${equipmentConfigOptions(key,cur)}</select>
    <input id="${id}" type="text" value="${escHtml(cur)}" placeholder="${escHtml(placeholder)}"
      style="margin-top:6px;display:${displayCustom};width:100%;box-sizing:border-box"
      oninput="this.value=this.value">`;
}
function catalogFields(type,item={}){
  const v=k=>escHtml(item[k]||'');
  if(type==='equipamentos')return `
    <div class="field"><label>Tipo de equipamento</label>
      ${equipmentConfigSelect('equipamentos','cat_tipo',item.tipo,'Ex.: Tipo de equipamento')}
    </div>
    <div class="field"><label>Nome do equipamento</label><input id="cat_nome" placeholder="Ex.: Nome do equipamento" value="${v('nome')}"></div>
    <div class="field"><label>Marca do equipamento</label>
      ${equipmentConfigSelect('nome_equipamentos','cat_marca',item.marca,'Ex.: Marca do equipamento')}
    </div>
    <div class="field"><label>Modelo</label><input id="cat_modelo" placeholder="Ex.: Modelo do equipamento" value="${v('modelo')}"></div>
    <div class="field"><label>Referência</label><input id="cat_ref" placeholder="Ex.: Referência do fabricante" value="${v('referencia')}"></div>
    
    <div class="field"><label>Quantidade comprada</label><input id="cat_quantidade_comprada" type="number" step="1" min="0" placeholder="0" value="${v('quantidade_comprada')}"></div>
    <div class="field"><label>Quantidade utilizada/vendida</label><input id="cat_quantidade_utilizada" type="number" step="1" min="0" placeholder="0" value="${v('quantidade_utilizada')}"></div>
    <div class="field"><label>Stock mínimo</label><input id="cat_stock_minimo" type="number" step="1" min="0" placeholder="0" value="${v('stock_minimo')}"></div>
    <div class="field"><label>Custo total</label><input id="cat_custo" type="number" step="0.01" min="0" placeholder="0,00" value="${v('custo')}"></div>
    <div class="field"><label>PVP</label><input id="cat_pvp" type="number" step="0.01" placeholder="0,00" value="${v('pvp')}"></div>
    <div class="field"><label>Preço de venda</label><input id="cat_venda" type="number" step="0.01" placeholder="0,00" value="${v('venda')}"></div>
    <div class="field"><label>Stock atual (calculado)</label><input type="number" value="${Math.max(0,(Number(item.quantidade_comprada)||0)-(Number(item.quantidade_utilizada)||0))}" readonly></div>
    <div class="field"><label>Custo unitário (calculado)</label><input type="number" value="${(Number(item.quantidade_comprada)||0)>0?((Number(item.custo)||0)/(Number(item.quantidade_comprada)||0)).toFixed(2):'0.00'}" readonly></div>
    <div class="field"><label>Margem (calculada)</label><input type="text" value="${(()=>{const q=Number(item.quantidade_comprada)||0;const c=Number(item.custo)||0;const v=Number(item.venda)||0;const u=q>0?c/q:0;return (v-u).toFixed(2)+' € por unidade'})()}" readonly></div>
    <div class="field">
      <label>Fotografia</label>
      <label for="cat_foto_file" style="display:block;width:100%;box-sizing:border-box;padding:11px 14px;border:1px solid #29456f;border-radius:8px;background:#fff;color:#111;font-size:16px;cursor:pointer;text-align:center">Escolher ficheiro</label>
      <input id="cat_foto_file" type="file" accept="image/*" onchange="v232LoadEquipmentPhoto(this)" style="display:none">
      <input id="cat_foto" type="hidden" value="${v('foto')}">
      <div id="cat_foto_preview" style="margin-top:8px">
        ${v('foto') ? `<img src="${esc(v('foto'))}" alt="Fotografia" style="max-width:180px;max-height:120px;border-radius:10px;border:1px solid #29456f;object-fit:contain">` : ''}
      </div>
    </div>`;
  if(type==='produtos')return `
    <div class="field"><label>Nome do produto / consumível</label><input id="cat_nome" placeholder="Ex.: Produto / Consumível" value="${v('nome')}"></div>
    <div class="field"><label>Marca</label><select id="cat_marca">${catalogBrandOptions(item.marca)}</select></div>
    <div class="field"><label>Tipo</label><input id="cat_tipo" placeholder="Ex.: Consumível" value="${v('tipo')}"></div>
    <div class="field"><label>Unidade</label><input id="cat_unidade" placeholder="Ex.: unidade, metro, caixa" value="${v('unidade')}"></div>
    <div class="field"><label>Quantidade comprada</label><input id="cat_quantidade_comprada" type="number" step="1" min="0" placeholder="0" value="${v('quantidade_comprada')||v('quantidade')}"></div>
    <div class="field"><label>Quantidade vendida/utilizada</label><input id="cat_quantidade_utilizada" type="number" step="1" min="0" placeholder="0" value="${v('quantidade_utilizada')}"></div>
    <div class="field"><label>Stock mínimo</label><input id="cat_stock_minimo" type="number" step="1" min="0" placeholder="0" value="${v('stock_minimo')}"></div>
    <div class="field"><label>Custo total</label><input id="cat_custo" type="number" step="0.01" placeholder="0,00" value="${v('custo')}"></div>
    <div class="field"><label>Preço de venda unitário</label><input id="cat_venda" type="number" step="0.01" placeholder="0,00" value="${v('venda')}"></div>
    <div class="field"><label>Stock atual (calculado)</label><input type="number" value="${Math.max(0,(Number(item.quantidade_comprada)||0)-(Number(item.quantidade_utilizada)||0))}" readonly></div>
    <div class="field"><label>Custo unitário (calculado)</label><input type="number" value="${(Number(item.quantidade_comprada)||0)>0?((Number(item.custo)||0)/(Number(item.quantidade_comprada)||0)).toFixed(2):'0.00'}" readonly></div>
    <div class="field"><label>Margem (calculada)</label><input type="text" value="${(()=>{const q=Number(item.quantidade_comprada)||0;const c=Number(item.custo)||0;const v=Number(item.venda)||0;const u=q>0?c/q:0;return (v-u).toFixed(2)+' € por unidade'})()}" readonly></div>`;
  if(type==='servicos'){
    const fields=Array.isArray(item.campos)?item.campos:[];
    return `
    <div class="field"><label>Nome do serviço</label><input id="cat_nome" placeholder="Ex.: VPN" value="${v('nome')}"></div>
    <div class="field"><label>Tipo</label><input id="cat_tipo" placeholder="Ex.: Tipo de serviço" value="${v('tipo')}"></div>
    <div class="field"><label>Unidade</label><input id="cat_unidade" placeholder="Ex.: Unidade do serviço" value="${v('unidade')}"></div>
    <div class="field"><label>Valor</label><input id="cat_venda" type="number" step="0.01" placeholder="0,00" value="${v('venda')}"></div>
    <div class="card" style="margin-top:12px;padding:12px">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px">
        <div><strong>Campos personalizados</strong><div class="muted">Define os campos que este serviço deverá pedir quando for usado num cliente.</div></div>
        <button type="button" class="primary" onclick="v73AddServiceField()">＋ Adicionar campo</button>
      </div>
      <div id="v73ServiceFields" style="margin-top:10px"></div>
    </div>`;
  }
  return `<div class="field"><label>Nome da marca</label><input id="cat_nome" placeholder="Ex.: Marca do equipamento" value="${v('nome')}"></div>`;
}

function v73AddServiceField(){
  const box=document.getElementById('v73ServiceFields');
  if(!box)return;
  const row=document.createElement('div');
  row.style.cssText='display:flex;gap:8px;margin-top:8px;align-items:center';
  row.innerHTML='<input data-service-field type="text" placeholder="Ex.: Username" style="flex:1"><button type="button" onclick="this.parentElement.remove()">🗑️</button>';
  box.appendChild(row);
}

function v73RenderExistingServiceFields(){
  const work=document.getElementById('catalogWork');
  const type=work?.dataset.type;
  if(type!=='servicos')return;
  const idx=Number(work.dataset.editIndex||-1);
  const rows=getCatalog('servicos');
  const fields=idx>=0 && Array.isArray(rows[idx]?.campos)?rows[idx].campos:[];
  const box=document.getElementById('v73ServiceFields');
  if(!box)return;
  box.innerHTML='';
  fields.forEach(name=>{
    const row=document.createElement('div'); row.style.cssText='display:flex;gap:8px;margin-top:8px;align-items:center';
    row.innerHTML='<input data-service-field type="text" style="flex:1"><button type="button" onclick="this.parentElement.remove()">🗑️</button>';
    row.querySelector('input').value=String(name||''); box.appendChild(row);
  });
}

function readCatalogItem(type){
  const g=id=>document.getElementById(id)?.value?.trim()||'';
  if(type==='equipamentos')return {tipo:g('cat_tipo'),nome:g('cat_nome'),marca:g('cat_marca'),modelo:g('cat_modelo'),referencia:g('cat_ref'),categoria:g('cat_categoria'),quantidade_comprada:g('cat_quantidade_comprada'),quantidade_utilizada:g('cat_quantidade_utilizada'),stock_minimo:g('cat_stock_minimo'),custo:g('cat_custo'),pvp:g('cat_pvp'),venda:g('cat_venda'),foto:g('cat_foto')};
  if(type==='produtos')return {nome:g('cat_nome'),marca:g('cat_marca'),tipo:g('cat_tipo'),unidade:g('cat_unidade'),quantidade_comprada:g('cat_quantidade_comprada'),quantidade_utilizada:g('cat_quantidade_utilizada'),stock_minimo:g('cat_stock_minimo'),custo:g('cat_custo'),venda:g('cat_venda')};
  if(type==='servicos'){
    const campos=[...document.querySelectorAll('#v73ServiceFields input[data-service-field]')]
      .map(x=>String(x.value||'').trim()).filter(Boolean);
    return {nome:g('cat_nome'),tipo:g('cat_tipo'),unidade:g('cat_unidade'),venda:g('cat_venda'),campos};
  }
  return {nome:g('cat_nome')};
}

function v232LoadEquipmentPhoto(input){
  const file=input && input.files && input.files[0];
  if(!file)return;
  if(!file.type.startsWith('image/')){
    input.value='';
    alert('Seleciona uma imagem.');
    return;
  }
  const reader=new FileReader();
  reader.onload=function(){
    const hidden=document.getElementById('cat_foto');
    const preview=document.getElementById('cat_foto_preview');
    if(hidden)hidden.value=reader.result;
    if(preview)preview.innerHTML='<img src="'+reader.result+'" alt="Fotografia" style="max-width:180px;max-height:120px;border-radius:10px;border:1px solid #29456f;object-fit:contain">';
  };
  reader.readAsDataURL(file);
}

function v231MigrateEquipmentCatalog(){
  const rows=Array.isArray(getCatalog('equipamentos'))?getCatalog('equipamentos'):[];
  let changed=false;
  rows.forEach(e=>{
    if(e && !String(e.tipo||'').trim() && String(e.categoria||'').trim()){
      const cat=String(e.categoria).trim();
      const map={
        'Câmara IP':'Câmara',
        'NVR':'NVR',
        'Router':'Router',
        'Alarme':'Alarme',
        'Acessório':'Acessório'
      };
      e.tipo=map[cat]||cat;
      changed=true;
    }
  });
  if(changed)setCatalog('equipamentos',rows);
}
v231MigrateEquipmentCatalog();

function openCatalog(type){
  const work=document.getElementById('catalogWork');
  if(!work)return;

  // Clicar novamente no mesmo catálogo fecha o módulo.
  if(work.style.display!=='none' && work.dataset.type===type){
    work.style.display='none';
    work.dataset.type='';
    return;
  }

  // Escolher outro catálogo abre-o e leva automaticamente o utilizador
  // para o respetivo módulo.
  work.style.display='block';
  work.dataset.type=type;
  work.dataset.editIndex='-1';
  // Ao mudar de catálogo, limpar sempre a pesquisa anterior.
  work.dataset.search='';
  renderCatalogWork(type);

  requestAnimationFrame(()=>{
    setTimeout(()=>{
      work.scrollIntoView({behavior:'smooth', block:'start'});
    },50);
  });
}

function renderCatalogWork(type){
  const work=document.getElementById('catalogWork');
  const cfg=CATALOGS[type];
  const rows=getCatalog(type);
  const idx=Number(work.dataset.editIndex||-1);
  const item=idx>=0?rows[idx]:{};
  work.innerHTML=`
    <div id="catalogFormHeader" style="position:sticky;top:0;z-index:3;background:var(--card,#07162f);padding-bottom:10px;cursor:pointer" onclick="toggleCatalogForm()" title="Abrir/fechar formulário">
      <h2 style="margin:0">${cfg.icon} ${cfg.title}</h2>
    </div>
    <div id="catalogFormPanel" style="margin-top:12px">
      ${catalogFields(type,item)}
      <button type="button" class="primary" onclick="saveCatalogItem()">＋ ${idx>=0?'Guardar alterações':'Adicionar'}</button>
      ${idx>=0?'<button type="button" style="margin-left:8px" onclick="cancelCatalogEdit()">Cancelar</button>':''}
    </div>
    <div style="margin-top:18px">
      <div style="position:sticky;top:0;z-index:2;background:var(--card,#07162f);padding:8px 0;border-bottom:1px solid var(--border)">
        <strong>${cfg.title} registados</strong>
      </div>
      <div style="margin-top:10px">
        <input id="catalogSearch" type="search" placeholder="Pesquisar ${cfg.title.toLowerCase()}..." autocomplete="off"
          style="width:100%;box-sizing:border-box"
          oninput="document.getElementById('catalogWork').dataset.search=this.value;renderCatalogRows('${type}')">
      </div>
      <div id="catalogRows" class="catalog-scroll-3 v112-sort-list" data-v112-sort="catalog" style="max-height:520px;overflow-y:auto;padding-top:4px"></div>
    </div>`;
  renderCatalogRows(type);
  if(type==='servicos') v73RenderExistingServiceFields();
}

function saveCatalogItem(){
  const work=document.getElementById('catalogWork');
  const type=work.dataset.type;
  const item=readCatalogItem(type);
  if(!item.nome){
    if(type==='marcas') showAppAlert('Aviso','Preenche o campo antes de adicionar.');
    else showAppAlert('Aviso','Preenche os campos antes de adicionar.');
    return;
  }
  const rows=getCatalog(type);
  const idx=Number(work.dataset.editIndex||-1);
  if(idx>=0)rows[idx]=item;else rows.push(item);
  setCatalog(type,rows);
  work.dataset.editIndex='-1';
  renderCatalogWork(type);
}

function editCatalogItem(type,index){
  const work=document.getElementById('catalogWork');
  work.dataset.type=type;
  work.dataset.editIndex=String(index);
  renderCatalogWork(type);
  requestAnimationFrame(()=>{
    const form=document.getElementById('catalogFormPanel');
    if(form){ form.dataset.closed='0'; form.style.display=''; }
    const workPanel=document.getElementById('catalogWork');
    if(workPanel){
      // Usar exatamente a mesma posição usada quando se abre o catálogo.
      workPanel.scrollIntoView({behavior:'smooth',block:'start'});
    }
  });
}
async function deleteCatalogItem(type,index){
  const rows=getCatalog(type);
  const item=rows[index];
  if(!item)return;
  const confirmed=await showAppConfirm('Eliminar registo?','Tem a certeza que pretende eliminar este registo?','Eliminar','Cancelar');
  if(!confirmed)return;
  rows.splice(index,1);
  setCatalog(type,rows);
  renderCatalogWork(type);
}
function cancelCatalogEdit(){
  const work=document.getElementById('catalogWork');
  work.dataset.editIndex='-1';
  renderCatalogWork(work.dataset.type);
}
function renderCatalogRows(type){
  const box=document.getElementById('catalogRows');
  if(!box)return;
  const rows=getCatalog(type);
  const work=document.getElementById('catalogWork');
  const query=String(work?.dataset.search||'').trim().toLowerCase();

  const filtered=rows.map((r,i)=>({r,i})).filter(({r})=>{
    if(!query)return true;
    return Object.values(r||{}).some(v=>String(v??'').toLowerCase().includes(query));
  });

  if(!rows.length){
    box.innerHTML='<div class="muted" style="padding:12px 0">Ainda não existem registos.</div>';
    return;
  }
  if(!filtered.length){
    box.innerHTML='<div class="muted" style="padding:12px 0">Nenhum registo encontrado.</div>';
    return;
  }

  box.innerHTML=filtered.map(({r,i})=>{
    let detail='';
    let stockAlert='';
    let stockDot='';
    if(type==='equipamentos'){
      detail=[r.marca].filter(Boolean).map(escHtml).join('');
      const stock=Math.max(0,(Number(r.quantidade_comprada)||0)-(Number(r.quantidade_utilizada)||0));
      const minimo=Number(r.stock_minimo)||0;
      const status=stock===0?'red':(minimo>0 && stock<=minimo?'orange':'green');
      stockDot=`<span class="catalog-stock-dot ${status}" title="${status==='red'?'Stock abaixo do mínimo':status==='orange'?'Stock no mínimo':'Stock normal'}"></span>`;
      detail += `<br>${stockDot}Stock ${stock}`;
      if(minimo>0 && stock<=minimo) stockAlert=`<div style="margin-top:4px">⚠️ Stock baixo: ${stock} (mínimo ${minimo})</div>`;
    } else if(type==='produtos'){
      const stock=Math.max(0,(Number(r.quantidade_comprada)||0)-(Number(r.quantidade_utilizada)||0));
      const minimo=Number(r.stock_minimo)||0;
      detail=[r.marca].filter(Boolean).map(escHtml).join('');
      const status=stock===0?'red':(minimo>0 && stock<=minimo?'orange':'green');
      stockDot=`<span class="catalog-stock-dot ${status}" title="${status==='red'?'Stock abaixo do mínimo':status==='orange'?'Stock no mínimo':'Stock normal'}"></span>`;
      detail += `<br>${stockDot}Stock ${stock}`;
      if(minimo>0 && stock<=minimo) stockAlert=`<div style="margin-top:4px">⚠️ Stock baixo: ${stock} (mínimo ${minimo})</div>`;
    } else if(type==='servicos') detail=[r.tipo,r.venda?(r.venda+' €'):''].filter(Boolean).map(escHtml).join('<br>');
    else detail='Marca';

    return `<div class="card catalog-row v112-sort-item" data-cat-index="${i}" style="margin-top:8px;display:flex;align-items:center;gap:4px;cursor:pointer" onclick="editCatalogItem('${type}',${i})" title="Abrir para editar">
      <span class="v112-handle catalog-sort-handle" title="Arrastar para ordenar" aria-label="Arrastar para ordenar">☷</span>
      <div class="catalog-row-main" style="min-width:0;flex:1">
        <strong>${escHtml(r.nome)}</strong>
        <div class="muted">${detail}${stockAlert}</div>
      </div>
      <div class="catalog-row-actions" style="display:flex;flex-direction:column;gap:4px;flex-shrink:0">
        <button type="button" class="catalog-row-action" title="Editar" aria-label="Editar" onclick="event.stopPropagation();editCatalogItem('${type}',${i})">✏️</button>
        <button type="button" class="catalog-row-action" title="Eliminar" aria-label="Eliminar" onclick="event.stopPropagation();deleteCatalogItem('${type}',${i})">🗑️</button>
      </div>
    </div>`;
  }).join('');
}

function toggleCatalogForm(){
  const panel=document.getElementById('catalogFormPanel');
  if(!panel)return;
  const closed=panel.dataset.closed==='1';
  panel.dataset.closed=closed?'0':'1';
  panel.style.display=closed?'':'none';
}



function setActiveMainButton(id){
  const map = {
    inicio:'view(\'inicio\')',
    clientes:'view(\'clientes\')',
    subscricoes:'view(\'subscricoes\')',
    catalogos:'view(\'catalogos\')',
    arquivado:'view(\'arquivado\')',
    historico:'view(\'historico\')',
    estatisticas:'view(\'estatisticas\')',
    config:'view(\'config\')',
    gestao:'view(\'gestao\')'
  };
  document.querySelectorAll('button').forEach(b=>{
    b.classList.remove('active');
    b.removeAttribute('aria-current');
  });
  const wanted = map[id];
  if(!wanted) return;
  const target = Array.from(document.querySelectorAll('button')).find(b=>{
    const oc = b.getAttribute('onclick') || '';
    return oc.replace(/\s/g,'').includes(wanted.replace(/\s/g,''));
  });
  if(target){
    target.classList.add('active');
    target.setAttribute('aria-current','page');
  }
}
function view(id){
 setActiveNav(id);
 if(id==='clientes') clearHomeClientDetail();
 ['clientes','lista','mensagens','historico','atividade','base','gestao','catalogos','subscricoes','estatisticas','todosClientes','config'].forEach(x=>{
   const el=document.getElementById(x);
   if(el)el.classList.toggle('hidden',x!==id);
 });
 if(id==='inicio'){
   selected=null;
   ['detail','fullClientDetail'].forEach(x=>{
     const el=document.getElementById(x);
     if(el){el.classList.add('hidden');el.innerHTML='';}
   });
   const cb=document.getElementById('listCloseBtn');
   if(cb)cb.textContent='Fechar';
 }
 if(id==='gestao'){
   const gb=document.getElementById('gestaoBody');
   const gc=document.getElementById('gestaoChevron');
   if(gb) gb.hidden=false;
   if(gc) gc.textContent='▾';
 }
 if(id==='mensagens')setupTabs();
 if(id==='historico'){
   const hp=document.getElementById('historico');
   if(hp)hp.dataset.archivedCollapsed='0';
   const hs=document.getElementById('archivedSearch');
   const hl=document.getElementById('history');
   const hb=document.getElementById('archivedCloseBtn');
   if(hs)hs.classList.remove('hidden');
   if(hl)hl.classList.remove('hidden');
   if(hb)hb.textContent='Fechar';
   renderHistory();
 }
 if(id==='atividade'){
   const ap=document.getElementById('atividade');
   if(ap)ap.dataset.activityCollapsed='0';
   const as=document.getElementById('activitySearch');
   const al=document.getElementById('activityList');
   const ab=document.getElementById('activityCloseBtn');
   if(as)as.classList.remove('hidden');
   if(al)al.classList.remove('hidden');
   if(ab)ab.textContent='Fechar';
   renderActivity();
 }
 if(id==='estatisticas')renderEstatisticas();
}
// Manter a lista completa de clientes antes dos atalhos no menu Início.
// Assim, quando a lista de Clientes é aberta, os clientes ficam sempre acima
// dos atalhos, que permanecem no final da página.
(function(){
 const clientes=document.getElementById('clientes');
 const listaClientes=document.getElementById('todosClientes');
 const atalhos=document.getElementById('homeShortcuts');
 if(clientes && listaClientes && atalhos){
   clientes.insertBefore(listaClientes, atalhos);
 }

  // CORRIGIDO: esta função corre sozinha ao carregar a página, fora do
  // âmbito de view(id) — a variável "id" não existia aqui, o que causava
  // "Uncaught ReferenceError: id is not defined" e travava toda a
  // inicialização seguinte (incluindo o carregamento dos dados guardados).
  setActiveMainButton('inicio');
})();

/* V719/V69 — empresas realmente independentes.
   Depois de Limpar, a empresa estrutural vazia só é criada enquanto não existir
   configuração persistida. Assim, uma empresa criada pelo utilizador permanece
   guardada no arranque seguinte. */
const v719HadAppSettings = localStorage.getItem('amClientesAppSettings') !== null;
initialiseDemoBase();
loadAppSettings();
if(!v676IsGlobalDatabaseEmpty() && !v719HadAppSettings){
  // Primeira utilização apenas: criar a demonstração inicial.
  v593PrepareTestCompanies();
  v593SeedDistinctCompanyDataOnce();
  v624SeedAllCompanyConfigurationExamplesOnce();
  saveAppSettings();
}else if(v676IsGlobalDatabaseEmpty() && !v719HadAppSettings){
  // Só criar a empresa estrutural vazia quando não existe uma configuração
  // persistida. Se o utilizador já criou uma empresa depois de Limpar, a sua
  // configuração deve ser preservada no arranque seguinte.
  APP_SETTINGS.companyProfiles=[v676DefaultCompany()];
  APP_SETTINGS.activeCompanyId='company_1';
  APP_SETTINGS.shortcuts=[];
  saveAppSettings();
}
loadSubscriptions();
DATA=loadDB();
ARCHIVED=loadArchived();
ACTIVITY=loadActivity();
loadConfigLists();
applyAppSettings();
v589RenderCompanySwitcher();

// V351 — o refresh mantém o menu atual sem esconder o ecrã.
// A restauração acontece aqui, no bootstrap original, antes do primeiro paint.
(function(){
  const target=window.__AM_V351_RELOAD_TARGET||'inicio';

  try{
    if(target==='clientes'){
      if(typeof openClientsNav==='function') openClientsNav();
      else view('clientes');
    }else if(target==='catalogos'){
      if(typeof openCatalogos==='function') openCatalogos();
      else view('catalogos');
    }else if(target==='subscricoes'){
      if(typeof openSubscriptions==='function') openSubscriptions();
      else view('subscricoes');
    }else if(target==='historico'){
      if(typeof openArchivedNav==='function') openArchivedNav();
      else view('historico');
    }else if(target==='inicio'){
      goHome();
    }else if(target==='config'){
      // V518 — construir Configurações antes de a tornar visível.
      if(typeof renderSettings==='function') renderSettings();
      view('config');
    }else{
      view(target);
    }
  }catch(e){
    console.error('AM Clientes V351 bootstrap:',e);
    goHome();
  }

  render();
  const prepaint=document.getElementById('v525-prepaint-style');
  if(prepaint) prepaint.remove();
})();


window.v117EditorEquipments=[];
window.v117ServiceCatalog=[];

function v117LoadCatalog(){
  const defaults=[
    {id:'svc_demo_1',name:'Serviço 1',value:10},
    {id:'svc_demo_2',name:'Serviço 2',value:20},
    {id:'svc_demo_3',name:'Serviço 3',value:30},
    {id:'svc_demo_4',name:'Serviço 4',value:40},
    {id:'svc_demo_5',name:'Serviço 5',value:50}
  ];
  try{
    // V76: o catálogo de serviços passa a ser isolado por empresa.
    // Depois de Limpar base de dados, uma empresa vazia não pode voltar a
    // receber automaticamente os cinco serviços de demonstração.
    const serviceKey=typeof v592CompanyStorageKey==='function'
      ? v592CompanyStorageKey('am_v117_service_catalog')
      : 'am_v117_service_catalog';
    const raw=localStorage.getItem(serviceKey);
    let data=null;

    // IMPORTANTE: se o catálogo já foi criado, um catálogo vazio é válido.
    // Não voltar a repor os serviços por defeito depois de o utilizador os apagar.
    if(raw !== null){
      try { data=JSON.parse(raw); } catch(e){ data=[]; }
      if(!Array.isArray(data)) data=[];

      // Recuperação: se o catálogo próprio estiver vazio mas a configuração
      // geral tiver serviços, não deixar a secção aparecer vazia.
      if(!data.length && Array.isArray(CONFIG_LISTS?.servicos) && CONFIG_LISTS.servicos.length){
        const oldNames=CONFIG_LISTS.servicos;
        const oldValues=Array.isArray(CONFIG_LISTS?.valores)?CONFIG_LISTS.valores:[];
        data=oldNames.map((name,i)=>({
          id:'svc_old_'+i,
          name:String(name||'').trim(),
          value:Number(String(oldValues[i]??'').replace(',','.'))||0
        })).filter(s=>s.name);
      }
    } else {
      // Primeira utilização: migrar a configuração antiga apenas uma vez.
      // Se a base acabou de ser limpa, lista vazia é um estado válido e não
      // deve ser substituída pelos serviços de demonstração.
      if(typeof v676IsGlobalDatabaseEmpty==='function' && v676IsGlobalDatabaseEmpty()){
        data=[];
      }else{
        const oldNames=Array.isArray(CONFIG_LISTS?.servicos)?CONFIG_LISTS.servicos:[];
        const oldValues=Array.isArray(CONFIG_LISTS?.valores)?CONFIG_LISTS.valores:[];
        data=oldNames.map((name,i)=>({
          id:'svc_old_'+i,
          name:String(name||'').trim(),
          value:Number(String(oldValues[i]??'').replace(',','.'))||0
        })).filter(s=>s.name);
        if(!data.length) data=JSON.parse(JSON.stringify(defaults));
      }
    }

    // Remove entradas vazias/corrompidas e normaliza os dados.
    const clean=[];
    const seen=new Set();
    data.forEach((s,i)=>{
      const name=String(s?.name??'').trim();
      if(!name)return;
      const key=name.toLowerCase();
      if(seen.has(key))return;
      seen.add(key);
      // V76: um campo personalizado pode ser criado vazio para o utilizador
      // escrever o nome depois. Não o eliminar durante a normalização.
      const fields=Array.isArray(s?.fields)?s.fields.map((f,fi)=>({
        id:String(f?.id||('fld_'+i+'_'+fi+'_'+Date.now().toString(36))),
        label:String(f?.label||'').trim()
      })):[];
      clean.push({
        id:String(s?.id||('svc_'+i+'_'+Date.now().toString(36))),
        name:name,
        value:Number(s?.value)||0,
        fields,
        subscriptionId:String(s?.subscriptionId||''),
        subscriptionName:String(s?.subscriptionName||'')
      });
    });
    // Base de demonstração: os cinco serviços genéricos da versão 310
    // devem ter sempre os valores 10/20/30/40/50.
    // Só normaliza quando a lista é exatamente a lista de demonstração.
    const demoValues=[10,20,30,40,50];
    if(clean.length===5 && clean.every((s,i)=>s.name===`Serviço ${i+1}`)){
      clean.forEach((s,i)=>s.value=demoValues[i]);
    }

    v117ServiceCatalog=clean;
    localStorage.setItem(serviceKey,JSON.stringify(v117ServiceCatalog));
  }catch(e){
    v117ServiceCatalog=[];
  }
}


function v147SyncServicesFromCatalog(){
  try{
    if(typeof v117LoadCatalog==='function') v117LoadCatalog();
    if(!Array.isArray(v117ServiceCatalog)) v117ServiceCatalog=[];
    CONFIG_LISTS.servicos=v117ServiceCatalog.map(s=>String(s.name||'').trim()).filter(Boolean);
    saveConfigLists();
  }catch(e){ console.warn('Serviços:',e); }
}

function v117InitEquipments(c){
  v117LoadCatalog();
  let list = Array.isArray(c.equipamentos) ? JSON.parse(JSON.stringify(c.equipamentos)) : [];

  // Migração dos campos antigos para um primeiro equipamento.
  if(!list.length && (
      String(c['Equipamento']||'').trim() ||
      String(c['Mac Adress']||'').trim() ||
      String(c['Utilizador']||'').trim() ||
      String(c['Senha']||'').trim() ||
      String(c['Link']||'').trim() ||
      String(c['VPN']||'').trim() ||
      String(c['Subscrição']||'').trim()
  )){
    list=[{
      id:'eq_legacy_'+Date.now().toString(36),
      nome:String(c['Equipamento']||'').trim(),
      tipo:'',
      mac:String(c['Mac Adress']||'').trim(),
      utilizador:String(c['Utilizador']||'').trim(),
      senha:String(c['Senha']||'').trim(),
      link:String(c['Link']||'').trim(),
      vpn:String(c['VPN']||'').trim(),
      subscricao:String(c['Subscrição']||'').trim(),
      vpns:[],
      servicos:[]
    }];
  }

  window.v117EditorEquipments=list;
  window.v117EditorEquipments.forEach(e=>{
    if(!e.id)e.id='eq_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);
    if(!Array.isArray(e.servicos))e.servicos=[];
    // V170: versões anteriores guardavam a marca neste campo quando o nome
    // do equipamento ainda não era selecionável pelo catálogo. Preservar o
    // valor antigo como nome até o utilizador escolher o equipamento do catálogo.
    if(!String(e.nome||'').trim() && String(e.marca||'').trim()) e.nome=String(e.marca).trim();

    // A subscrição do equipamento é independente das subscrições associadas às VPNs.
    ['nome','tipo','mac','utilizador','senha','link','vpn','subscricao',
      'servico','periodicidade','metodoPagamento','dataInstalacao','dataPagamento','validade',
      'valorPago','servicoValor','saldo'].forEach(k=>{
      if(e[k]===undefined)e[k]='';
    });

    // Nova estrutura: cada equipamento pode ter uma ou várias VPNs.
    // Migra automaticamente a VPN antiga para a primeira entrada.
    if(!Array.isArray(e.vpns)) e.vpns=[];
    if(!e.metodoPagamento) e.metodoPagamento=String(c['Método Pagamento']||'').trim();

    if(!e.servico) e.servico=String(c['Serviço']||'').trim();
    if(!e.periodicidade) e.periodicidade=String(c['Periodicidade']||'').trim();
    if(!e.dataPagamento) e.dataPagamento=String(c['Pagamento']||'').trim();
    if(!e.validade) e.validade=String(c['Validade']||'').trim();
    if(e.valorPago===undefined || e.valorPago==='') e.valorPago=c['Preço']||'';
    if(!e.dataInstalacao) e.dataInstalacao=String(c['Data Instalação']||'').trim();

    if(!e.vpns.length && (String(e.vpn||'').trim() || String(e.subscricao||'').trim())){
      e.vpns.push({
        id:'vpn_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),
        nome:String(e.vpn||'').trim(),
        subscricao:String(e.subscricao||'').trim(),
        utilizador:String(c['Utilizador VPN']||'').trim(),
        senha:String(c['Password VPN']||'').trim()
      });
    }

    e.vpns.forEach(v=>{
      if(!v.id)v.id='vpn_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);
      ['nome','subscricao','utilizador','senha'].forEach(k=>{
        if(v[k]===undefined)v[k]='';
      });
      if(v.valor===undefined){
        const cat=Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[];
        const svc=cat.find(x=>String(x.name||'')===String(v.nome||''));
        v.valor=Number(svc?.value||0);
        if(svc?.id)v.serviceId=svc.id;
      }
    });
  });
}

function v125VPNTotal(e){
  return Array.isArray(e?.vpns) ? e.vpns.length : 0;
}

function v125AddVPN(i){
  const e=window.v117EditorEquipments?.[i];
  if(!e)return;
  if(!Array.isArray(e.vpns))e.vpns=[];
  e.vpns.push({
    id:'vpn_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),
    nome:'',
    subscricao:'',
    utilizador:'',
    senha:'',
    valor:0,
    serviceId:''
  });
  v117RenderEquipments();
  setTimeout(()=>{
    const cards=document.querySelectorAll('.v118-vpn-card');
    cards[cards.length-1]?.scrollIntoView({behavior:'smooth',block:'center'});
  },80);
}

function v125RemoveVPN(i,j){
  const e=window.v117EditorEquipments?.[i];
  if(!e?.vpns?.[j])return;
  if(!confirm('Remover esta VPN deste equipamento?'))return;
  e.vpns.splice(j,1);
  v117RenderEquipments();
}

function v117PeriodMonths(value){
  const s=String(value||'').toLowerCase().trim();
  if(!s) return 1;
  if(s.includes('12') || s.includes('ano')) return 12;
  if(s.includes('6') || s.includes('semest')) return 6;
  if(s.includes('3') || s.includes('trimest')) return 3;
  if(s.includes('2') || s.includes('bimes')) return 2;
  const n=s.match(/\d+/);
  return n ? Math.max(1,Number(n[0])) : 1;
}
function v117EditorPeriodMonths(){
  const el=document.getElementById('f_Periodicidade');
  return v117PeriodMonths(el ? el.value : '');
}
function v117SubscriptionRevenue(name){
  const target=String(name||'').trim();
  if(!target)return 0;
  const sub=(Array.isArray(SUBSCRIPTIONS)?SUBSCRIPTIONS:[]).find(s=>String(s?.name||'').trim()===target);
  return v183Money(sub?.revenue||0);
}
function v117EquipmentServiceTotal(e){
  const money=v=>v183Money(v);
  const main=money(e?.servicoValor);
  const services=(e?.servicos||[]).reduce((sum,x)=>sum+money(x.valor),0);
  const vpns=(e?.vpns||[]).reduce((sum,v)=>{
    let value=money(v.valor);
    if(!value){
      const svc=(Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[]).find(x=>String(x.name||'')===String(v.nome||''));
      value=money(svc?.value||0);
    }
    return sum+value;
  },0);
  const subscription=v117SubscriptionRevenue(e?.subscricao);
  return main+services+vpns+subscription;
}
function v117EquipmentExtraTotal(e){
  // Total apenas dos serviços extra adicionados manualmente neste equipamento.
  // As VPNs são contabilizadas separadamente no total geral do equipamento.
  return (e.servicos||[]).reduce((s, item)=>s+(money(item.valor)||0),0);
}
function v117EquipmentServicePeriodTotal(e){
  // Total do equipamento para o cálculo geral: serviços extra + VPNs.
  // O preço associado ao serviço já é o total do período escolhido.
  // Não multiplicar por meses/periodicidade.
  return v117EquipmentServiceTotal(e);
}
function v117EditorServiceTotal(){
  const base=Number(v150BaseServiceValue)||0;
  const equipment=(window.v117EditorEquipments||[]).reduce((s,e)=>s+v117EquipmentServicePeriodTotal(e),0);
  return base+equipment;
}
function v117UpdatePaymentBalance(){
  const paidEl=document.getElementById('f_Preço');
  const saldoEl=document.getElementById('f_Saldo');
  if(!paidEl || !saldoEl) return;
  const paid=Number(String(paidEl.value||'').replace(',','.'))||0;
  const total=v117EditorServiceTotal();
  // O preço dos serviços já é o total do período escolhido.
  // Saldo = Valor pago - Total do serviço.
  saldoEl.value=String(Math.round(paid-total))+' €';
}



function v150SyncMainServiceValue(){
  const sel=document.getElementById('f_Serviço_select');
  const out=document.getElementById('f_ServicoValor');
  if(!sel)return;
  const name=String(sel.value||'');
  const svc=(Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[]).find(s=>String(s.name||'')===name);
  v150BaseServiceValue=Number(svc?.value||0);
  if(out)out.value=v150BaseServiceValue ? String(Math.round(v150BaseServiceValue))+' €' : '';
  v117UpdatePaymentBalance();
}
function v150InitMainServiceValue(currentName,currentStored){
  v147SyncServicesFromCatalog();
  const svc=(Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[]).find(s=>String(s.name||'')===String(currentName||''));
  v150BaseServiceValue=Number(currentStored||svc?.value||0);
}

function v231EquipmentCatalogOptions(kind,current){
  // Fonte única para o equipamento do cliente:
  // Tipo de Equipamento -> Configurações > Tipo de Equipamentos
  // Marca do Equipamento -> Configurações > Marcas dos Equipamentos
  // O antigo "Nome do Equipamento" deixa de ser uma fonte de opções.
  const configKey=kind==='tipo'?'equipamentos':'nome_equipamentos';
  const values=[];
  const seen=new Set();
  const push=value=>{
    const text=String(value||'').trim();
    const key=text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    if(!text||seen.has(key))return;
    seen.add(key); values.push(text);
  };
  (Array.isArray(CONFIG_LISTS?.[configKey])?CONFIG_LISTS[configKey]:[]).forEach(push);
  push(current);
  return values;
}
function v231EquipmentCatalogSelect(kind,current,onchangeExpr,placeholder){
  const values=v231EquipmentCatalogOptions(kind,current);
  const cur=String(current||'');
  return `<select onchange="${onchangeExpr}">
    <option value="">Selecionar ${kind==='tipo'?'tipo de equipamento':'marca do equipamento'}</option>
    ${values.map(v=>`<option value="${esc(v)}" ${String(v)===cur?'selected':''}>${esc(v)}</option>`).join('')}
    <option value="__custom__">✏️ Outro...</option>
  </select>
  <input type="text" value="${esc(cur)}" placeholder="${esc(placeholder||'Escrever outro...')}"
    style="margin-top:6px;display:none"
    oninput="${onchangeExpr.replace(/this\.value/g,'this.value')}">`;
}

// V173 — no cliente, o segundo campo do equipamento é o nome atribuído ao
// equipamento no Catálogo. A lista é filtrada pelo Tipo de equipamento
// escolhido no campo imediatamente acima.
function v170EquipmentCatalogOptions(current,type){
  const rows=Array.isArray(getCatalog('equipamentos'))?getCatalog('equipamentos'):[];
  const cur=String(current||'').trim();
  const wantedType=String(type||'').trim().toLowerCase();
  const out=[]; const seen=new Set();
  rows.forEach(r=>{
    const nome=String(r?.nome||'').trim();
    if(!nome)return;
    if(wantedType && String(r?.tipo||'').trim().toLowerCase()!==wantedType)return;
    const key=nome.toLowerCase();
    if(seen.has(key))return;
    seen.add(key);
    out.push(r);
  });
  if(cur && !out.some(r=>String(r.nome||'').trim()===cur)){
    const currentRow=rows.find(r=>String(r?.nome||'').trim()===cur);
    if(!wantedType || String(currentRow?.tipo||'').trim().toLowerCase()===wantedType) out.push(currentRow||{nome:cur,tipo:type||''});
  }
  return out;
}
function v170EquipmentTypeSelect(index,current){
  const cur=String(current||'').trim();
  const arr=Array.isArray(CONFIG_LISTS?.equipamentos)?CONFIG_LISTS.equipamentos:[];
  const values=[]; const seen=new Set();
  arr.forEach(v=>{
    const text=String(v||'').trim();
    const key=text.toLowerCase();
    if(text&&!seen.has(key)){seen.add(key);values.push(text);}
  });
  if(cur&&!values.some(v=>v.toLowerCase()===cur.toLowerCase())) values.push(cur);
  return `<select onchange="v170SelectEquipmentType(${index},this.value)">
    <option value="">Selecionar tipo de equipamento</option>
    ${values.map(v=>`<option value="${esc(v)}" ${v===cur?'selected':''}>${esc(v)}</option>`).join('')}
    <option value="__custom__">✏️ Outro...</option>
  </select>
  <input id="v170_custom_type_${index}" type="text" value="${esc(cur&&!values.some(v=>v===cur)?cur:'')}" placeholder="Ex.: Câmara / NVR / Router" style="margin-top:6px;display:none" onchange="v170CustomEquipmentType(${index},this.value)">`;
}
function v170SelectEquipmentType(index,value){
  const e=window.v117EditorEquipments?.[index];
  if(!e)return;
  if(value==='__custom__'){
    const input=document.getElementById('v170_custom_type_'+index);
    if(input){input.style.display='block';input.value='';input.focus();}
    e.tipo='';
    e.nome='';
    v117RenderEquipments();
    return;
  }
  e.tipo=value||'';
  const currentName=String(e.nome||'').trim();
  const rows=v170EquipmentCatalogOptions('',e.tipo);
  const matching=currentName && rows.find(r=>String(r?.nome||'').trim().toLowerCase()===currentName.toLowerCase());
  if(!matching){
    e.nome='';
    e.marca='';
    e.modelo='';
  }
  v117RenderEquipments();
}
function v170CustomEquipmentType(index,value){
  const e=window.v117EditorEquipments?.[index];
  if(!e)return;
  e.tipo=String(value||'').trim();
  e.nome='';
  e.marca='';
  e.modelo='';
  v117RenderEquipments();
}
function v170EquipmentCatalogSelect(index,current,type){
  const cur=String(current||'').trim();
  const rows=v170EquipmentCatalogOptions(cur,type);
  return `<select onchange="v170SelectEquipment(${index},this.value)">
    <option value="">Selecionar nome do equipamento</option>
    ${rows.map(r=>{const nome=String(r.nome||'').trim(); return `<option value="${esc(nome)}" ${nome===cur?'selected':''}>${esc(nome)}</option>`;}).join('')}
    <option value="__custom__">✏️ Outro...</option>
  </select>
  <input id="v170_custom_equipment_${index}" type="text" value="${esc(cur)}" placeholder="Ex.: Nome atribuído ao equipamento" style="margin-top:6px;display:none" oninput="v117EditorEquipments[${index}].nome=this.value">`;
}
function v170SelectEquipment(index,value){
  const e=window.v117EditorEquipments?.[index];
  if(!e)return;
  if(value==='__custom__'){
    const input=document.getElementById('v170_custom_equipment_'+index);
    if(input){input.style.display='block';input.value='';input.focus();}
    e.nome='';
    return;
  }
  const input=document.getElementById('v170_custom_equipment_'+index);
  if(input){input.style.display='none';input.value=value||'';}
  e.nome=value||'';
  const row=v170EquipmentCatalogOptions('',e.tipo).find(r=>String(r?.nome||'').trim()===String(value||'').trim());
  if(row){
    e.tipo=String(row.tipo||e.tipo||'');
    e.marca=String(row.marca||'');
    e.modelo=String(row.modelo||'');
  }
  v117RenderEquipments();
}
function v231SyncEquipmentListsFromCatalog(){
  const rows=Array.isArray(getCatalog('equipamentos'))?getCatalog('equipamentos'):[];
  const merge=(key,field)=>{
    const out=[]; const seen=new Set();
    const push=value=>{
      const text=String(value||'').trim();
      const norm=text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
      if(!text||seen.has(norm))return;
      seen.add(norm); out.push(text);
    };
    (Array.isArray(CONFIG_LISTS?.[key])?CONFIG_LISTS[key]:[]).forEach(push);
    rows.forEach(e=>push(e?.[field]||''));
    CONFIG_LISTS[key]=out;
  };
  merge('equipamentos','tipo');
  // O antigo campo "Nome dos Equipamentos" passou a representar
  // "Marcas dos Equipamentos". Não misturar nomes de equipamentos nessa lista.
  if(typeof saveConfigLists==='function')saveConfigLists();
}
function v149EquipmentSelect(key,current,onchangeExpr,placeholder){
  const arr=Array.isArray(CONFIG_LISTS[key])?CONFIG_LISTS[key]:[];
  const cur=String(current||'');
  const found=arr.some(v=>String(v)===cur);
  return `<select onchange="${onchangeExpr}">
    <option value="">— Selecionar —</option>
    ${arr.map(v=>`<option value="${esc(v)}" ${String(v)===cur?'selected':''}>${esc(v)}</option>`).join('')}
    ${cur&&!found?`<option value="${esc(cur)}" selected>${esc(cur)}</option>`:''}
    <option value="__custom__">✏️ Outro...</option>
  </select>
  <input type="text" value="${esc(cur)}" placeholder="${esc(placeholder||'Escrever outro...')}"
    style="margin-top:6px;display:${cur&&!found?'block':'none'}"
    oninput="${onchangeExpr.replace(/this\.value/g,'this.value')}">`;
}

function v183RefreshEquipmentTotals(i){
  const e=window.v117EditorEquipments?.[i];
  if(!e)return;

  // Atualiza imediatamente o valor do serviço selecionado.
  const svc=(Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[])
    .find(s=>String(s.name||'')===String(e.servico||''));
  if(svc) e.servicoValor=Number(svc.value||0);

  // Atualiza imediatamente o valor de cada VPN selecionada.
  (e.vpns||[]).forEach(v=>{
    const s=(Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[])
      .find(x=>String(x.name||'')===String(v.nome||''));
    if(s){
      v.valor=Number(s.value||0);
      v.serviceId=s.id||v.serviceId||'';
    }
  });

  // Mostra logo o valor do serviço.
  const sv=document.getElementById('v183_servico_valor_'+i);
  if(sv) sv.value=e.servicoValor ? Math.round(v183Money(e.servicoValor))+' €' : '';

  // Mostra logo os valores das VPNs.
  (e.vpns||[]).forEach((v,j)=>{
    const el=document.getElementById(`v183_vpn_valor_${i}_${j}`);
    if(el) el.value=v.valor ? Math.round(v183Money(v.valor))+' €' : '';
  });

  const subValue=document.getElementById(`v183_subscricao_valor_${i}`);
  if(subValue){
    const revenue=v117SubscriptionRevenue(e.subscricao);
    subValue.value=revenue ? Math.round(revenue)+' €' : '';
  }

  // Atualiza logo o saldo do equipamento.
  const sal=document.getElementById('v183_saldo_'+i);
  if(sal) sal.value=Math.round(v183EquipmentBalance(e))+' €';

  // Atualiza logo o total deste equipamento.
  const eqTotal=document.getElementById('v183_equipment_total_'+i);
  if(eqTotal){
    eqTotal.innerHTML=`Total deste equipamento: <strong>${Math.round(v183EquipmentTotal(e))} €</strong>`;
  }

  // Atualiza logo o total geral de serviço.
  const list=window.v117EditorEquipments||[];
  const totals=document.querySelectorAll('.v118-grand-total');
  const last=totals[totals.length-1];
  if(last && last.id!=='v183_equipment_total_'+i){
    last.innerHTML=`Total de serviço: <strong>${Math.round(list.reduce((sum,x)=>sum+v183EquipmentTotal(x),0))} €</strong>`;
  }
}

function v109SyncEquipmentPlaceholderStyles(){
  const root=document.getElementById('v117EquipmentBox');
  if(!root)return;
  root.querySelectorAll('select').forEach(s=>{
    s.classList.add('am-placeholder-select');
    s.classList.toggle('has-value',!!s.value);
  });
}

function v117RenderEquipments(){
  const box=document.getElementById('v117EquipmentBox');
  if(!box)return;
  v117LoadCatalog();
  v231SyncEquipmentListsFromCatalog();
  const list=window.v117EditorEquipments||[];

  const serviceOptions=(current)=>{
    const arr=Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[];
    const cur=String(current||'');
    return `<option value="">Selecionar serviço</option>`+
      arr.map(s=>`<option value="${esc(String(s.name||''))}" ${String(s.name||'')===cur?'selected':''}>${esc(String(s.name||''))}</option>`).join('')+
      (cur && !arr.some(s=>String(s.name||'')===cur) ? `<option value="${esc(cur)}" selected>${esc(cur)}</option>` : '')+
      `<option value="__custom__">✏️ Outro...</option>`;
  };

  const paymentOptions=(current)=>{
    const arr=Array.isArray(CONFIG_LISTS.pagamentos)?CONFIG_LISTS.pagamentos:[];
    const cur=String(current||'');
    return `<option value="">Selecionar método de pagamento</option>`+
      arr.map(v=>`<option value="${esc(String(v))}" ${String(v)===cur?'selected':''}>${esc(String(v))}</option>`).join('')+
      (cur && !arr.some(v=>String(v)===cur) ? `<option value="${esc(cur)}" selected>${esc(cur)}</option>` : '')+
      `<option value="__custom__">✏️ Outro...</option>`;
  };

  const periodicityOptions=(current)=>{
    const arr=Array.isArray(CONFIG_LISTS.periodicidades)?CONFIG_LISTS.periodicidades:[];
    const cur=String(current||'');
    return `<option value="">Selecionar periodicidade</option>`+
      arr.map(v=>`<option value="${esc(String(v))}" ${String(v)===cur?'selected':''}>${esc(String(v))}</option>`).join('')+
      (cur && !arr.some(v=>String(v)===cur) ? `<option value="${esc(cur)}" selected>${esc(cur)}</option>` : '')+
      `<option value="__custom__">✏️ Outra...</option>`;
  };

  const valueOptions=(current)=>{
    const arr=Array.isArray(CONFIG_LISTS.valores)?CONFIG_LISTS.valores:[];
    const cur=String(current??'');
    return `<option value="">Selecionar valor pago</option>`+
      arr.map(v=>`<option value="${esc(String(v))}" ${String(v)===cur?'selected':''}>${esc(String(v))} €</option>`).join('')+
      (cur && !arr.some(v=>String(v)===cur) ? `<option value="${esc(cur)}" selected>${esc(cur)} €</option>` : '')+
      `<option value="__custom__">✏️ Outro...</option>`;
  };

  const vpnOptions=(current)=>{
    const arr=Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[];
    const cur=String(current||'');
    return `<option value="">Selecionar serviço</option>`+
      arr.map(s=>`<option value="${esc(String(s.name||''))}" ${String(s.name||'')===cur?'selected':''}>${esc(String(s.name||''))}</option>`).join('')+
      (cur && !arr.some(s=>String(s.name||'')===cur) ? `<option value="${esc(cur)}" selected>${esc(cur)}</option>` : '')+
      `<option value="__custom__">✏️ Outro...</option>`;
  };

  const subOptions=(current)=>{
    const arr=Array.isArray(SUBSCRIPTIONS)?SUBSCRIPTIONS:[];
    const cur=String(current||'');
    return `<option value="">Selecionar subscrição</option>`+
      arr.map(s=>`<option value="${esc(String(s.name||''))}" ${String(s.name||'')===cur?'selected':''}>${esc(String(s.name||''))}</option>`).join('')+
      (cur && !arr.some(s=>String(s.name||'')===cur) ? `<option value="${esc(cur)}" selected>${esc(cur)}</option>` : '')+
      `<option value="__custom__">✏️ Outra...</option>`;
  };

  // Normaliza valores do catálogo antes de desenhar os totais.
  list.forEach(e=>{
    const svc=(Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[])
      .find(s=>String(s.name||'')===String(e.servico||''));
    if(svc)e.servicoValor=Number(svc.value||0);
    (e.vpns||[]).forEach(v=>{
      const vs=(Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[])
        .find(s=>String(s.name||'')===String(v.nome||''));
      if(vs)v.valor=Number(vs.value||0);
    });
  });

  box.innerHTML=`
    <div class="v118-eq-manager">
      <div class="v118-eq-manager-head">
        <div><h3>📦 Equipamentos do cliente</h3></div>
        <button type="button" class="primary v118-add-eq" onclick="v117AddEquipment()">＋ Novo equipamento</button>
      </div>

      ${list.length ? list.map((e,i)=>`
        <div class="v118-eq-card">
          <div class="v118-eq-title">
            <strong>Equipamento ${i+1}</strong>
            <button type="button" class="v118-delete-eq" onclick="v117RemoveEquipment(${i})">🗑️ Remover</button>
          </div>

          <div class="row">
            <div class="field"><label>Tipo de Equipamento</label>
              ${v170EquipmentTypeSelect(i,e.tipo||'')}
            </div>
            <div class="field"><label>Nome do Equipamento</label>
              ${v170EquipmentCatalogSelect(i,e.nome||'',e.tipo||'')}
            </div>
          </div>

          <div class="row">
            <div class="field"><label>Identificação MAC</label>
              <input value="${esc(e.mac||'')}" placeholder="Ex.: 00:11:22:33:44:55" oninput="v117EditorEquipments[${i}].mac=this.value">
            </div>
            <div class="field"><label>Utilizador</label>
              <input value="${esc(e.utilizador||'')}" placeholder="Ex.: Nome de utilizador" oninput="v117EditorEquipments[${i}].utilizador=this.value">
            </div>
          </div>

          <div class="row">
            <div class="field"><label>Senha</label>
              <input type="text" value="${esc(e.senha||'')}" placeholder="Ex.: Senha do equipamento" oninput="v117EditorEquipments[${i}].senha=this.value">
            </div>
            <div class="field"><label>Link</label>
              <input value="${esc(e.link||'')}" placeholder="Ex.: https://exemplo.pt" oninput="v117EditorEquipments[${i}].link=this.value">
            </div>
          </div>

          <div class="row">
            <div class="field"><label>${Array.isArray(e.servicos)&&e.servicos.length ? 'Serviço 1' : 'Serviço'}</label>
              <select onchange="
                const val=this.value;
                if(val==='__custom__'){
                  this.nextElementSibling.style.display='block';
                  this.nextElementSibling.value='';
                  this.nextElementSibling.focus();
                  v117EditorEquipments[${i}].servico='';
                  v117EditorEquipments[${i}].servicoValor=0;
                  v75SyncServiceFields(${i},'');
                }else{
                  this.nextElementSibling.style.display='none';
                  v117EditorEquipments[${i}].servico=val;
                  const svc=(Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[]).find(s=>String(s.name||'')===String(val));
                  v117EditorEquipments[${i}].servicoValor=Number(svc?.value||0);
                  v75SyncServiceFields(${i},val);
                }
                v183RefreshEquipmentTotals(${i});
              ">${serviceOptions(e.servico)}</select>
              <input type="text" value="${esc(e.servico||'')}" placeholder="Ex.: Escrever outro"
                style="margin-top:6px;display:${e.servico&&!((v117ServiceCatalog||[]).some(s=>String(s.name)===String(e.servico)))?'block':'none'}"
                oninput="v117EditorEquipments[${i}].servico=this.value;v117EditorEquipments[${i}].servicoValor=0;v183RefreshEquipmentTotals(${i})">
              <input id="v183_servico_valor_${i}" type="text" readonly value="${e.servicoValor?Math.round(v183Money(e.servicoValor))+' €':''}" placeholder="Ex.: Valor do serviço automático" style="margin-top:6px">
              <div id="v75_service_fields_${i}">${v75ServiceFieldsHtml(e.servico,e.serviceFields)}</div>
            </div>
            <div class="field"><label>Subscrição</label>
              <select onchange="
                if(this.value==='__custom__'){
                  this.nextElementSibling.style.display='block';
                  this.nextElementSibling.value='';
                  this.nextElementSibling.focus();
                  v117EditorEquipments[${i}].subscricao='';
                }else{
                  this.nextElementSibling.style.display='none';
                  v117EditorEquipments[${i}].subscricao=this.value;
                }
                v183RefreshEquipmentTotals(${i});
              ">${subOptions(e.subscricao)}</select>
              <input type="text" value="${esc(e.subscricao||'')}" placeholder="Ex.: Nome da subscrição"
                style="margin-top:6px;display:${e.subscricao && !(SUBSCRIPTIONS||[]).some(s=>String(s.name)===String(e.subscricao))?'block':'none'}"
                oninput="v117EditorEquipments[${i}].subscricao=this.value;v183RefreshEquipmentTotals(${i})">
              <input id="v183_subscricao_valor_${i}" type="text" readonly
                value="${v117SubscriptionRevenue(e.subscricao)?Math.round(v117SubscriptionRevenue(e.subscricao))+' €':''}"
                placeholder="Ex.: Valor da subscrição automático" style="margin-top:6px">
            </div>
          </div>

          <div class="row">
            <div class="field"><label>Periodicidade</label>
              <select onchange="v117EditorEquipments[${i}].periodicidade=this.value;v183RefreshEquipmentTotals(${i})">${periodicityOptions(e.periodicidade)}</select>
            </div>
          </div>

          <div class="row">
            <div class="field"><label>Tipo de pagamento</label>
              <select onchange="v117EditorEquipments[${i}].metodoPagamento=this.value">${paymentOptions(e.metodoPagamento)}</select>
            </div>
            <div class="field v128-date-start-field"><label>Data de início de serviço</label>
              <div class="v109-date-input-wrap ${e.dataInstalacao?'has-value':''}"><input type="date" value="${esc(e.dataInstalacao||'')}" onfocus="this.parentElement.classList.add('is-focused')" onblur="this.parentElement.classList.remove('is-focused')" onchange="
                const eq=v117EditorEquipments[${i}];
                eq.dataInstalacao=this.value;
                if(eq.periodicidade && typeof window.v685RefreshEquipmentValidity==='function'){
                  eq.validade=window.v685CalculatedEndDate?window.v685CalculatedEndDate(eq,eq.periodicidade):eq.validade;
                  window.v117RenderEquipments();
                }
                this.parentElement.classList.toggle('has-value',!!this.value);
              "> <span class="v109-date-placeholder">Selecionar data</span></div>
            </div>
          </div>

          <div class="row">
            <div class="field v128-date-payment-field"><label>Data do pagamento</label>
              <div class="v109-date-input-wrap ${e.dataPagamento?'has-value':''}"><input type="date" value="${esc(e.dataPagamento||'')}" onfocus="this.parentElement.classList.add('is-focused')" onblur="this.parentElement.classList.remove('is-focused')" onchange="v117EditorEquipments[${i}].dataPagamento=this.value;this.parentElement.classList.toggle('has-value',!!this.value)"> <span class="v109-date-placeholder">Selecionar data</span></div>
            </div>
            <div class="field"><label>Validade</label>
              <div class="v109-date-input-wrap ${e.validade?'has-value':''}"><input type="date" value="${esc(e.validade||'')}" onfocus="this.parentElement.classList.add('is-focused')" onblur="this.parentElement.classList.remove('is-focused')" onchange="v117EditorEquipments[${i}].validade=this.value;this.parentElement.classList.toggle('has-value',!!this.value)"> <span class="v109-date-placeholder">Selecionar data</span></div>
            </div>
          </div>

          <div class="row">
            <div class="field"><label>Valor pago</label>
              <select onchange="
                if(this.value==='__custom__'){
                  this.nextElementSibling.style.display='block';
                  this.nextElementSibling.focus();
                  v117EditorEquipments[${i}].valorPago='';
                }else{
                  this.nextElementSibling.style.display='none';
                  v117EditorEquipments[${i}].valorPago=this.value;
                }
                v183RefreshEquipmentTotals(${i});
              ">${valueOptions(e.valorPago)}</select>
              <input type="number" step="1" inputmode="numeric" value="${esc(e.valorPago??'')}"
                style="margin-top:6px;display:${e.valorPago!=='' && !(CONFIG_LISTS.valores||[]).some(v=>String(v)===String(e.valorPago))?'block':'none'}"
                placeholder="Ex.: Outro valor"
                oninput="v117EditorEquipments[${i}].valorPago=this.value;v183RefreshEquipmentTotals(${i})">
            </div>
            <div class="field"><label>Saldo</label>
              <input id="v183_saldo_${i}" type="text" readonly value="${Math.round(v183EquipmentBalance(e))} €">
            </div>
          </div>

          <div class="v156-client-actions" style="margin-top:16px;padding-top:14px;border-top:1px solid rgba(120,150,190,.22)">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
              <button type="button" class="primary" onclick="v117AddService(${i})"><span>Adicionar</span><span>serviço</span></button>
              <button type="button" class="primary" onclick="v156AddSubscription(${i})"><span>Adicionar</span><span>subscrição</span></button>
            </div>
          </div>

          <div class="v118-grand-total" id="v183_equipment_total_${i}">
            Total deste equipamento:
            <strong>${Math.round(v183EquipmentTotal(e))} €</strong>
          </div>
        </div>`).join('') : `
        <div class="v118-empty-eq"><div class="v118-empty-icon">📦</div>
          <strong>Este cliente ainda não tem equipamentos.</strong>
          <span>Carrega em <b>＋ Novo equipamento</b> para adicionar o primeiro.</span>
        </div>`}

      ${list.length ? `<div class="v118-grand-total">
        Total de serviço:
        <strong>${Math.round(list.reduce((sum,e)=>sum+v183EquipmentTotal(e),0))} €</strong>
      </div>` : ''}
    </div>`;
  v109SyncEquipmentPlaceholderStyles();
}

function v117AddEquipment(){
  window.v117EditorEquipments=window.v117EditorEquipments||[];
  window.v117EditorEquipments.push({
    id:'eq_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),
    marca:'',tipo:'',mac:'',utilizador:'',senha:'',link:'',
    servico:'',servicoValor:0,periodicidade:'',metodoPagamento:'',dataInstalacao:'',
    dataPagamento:'',validade:'',valorPago:'',saldo:0,vpn:'',subscricao:'',vpns:[],servicos:[]
  });
  v117RenderEquipments();
  setTimeout(()=>{
    const cards=document.querySelectorAll('.v118-eq-card');
    cards[cards.length-1]?.scrollIntoView({behavior:'smooth',block:'center'});
  },80);
}

function v117RemoveEquipment(i){
  if(!confirm('Remover este equipamento do cliente?'))return;
  window.v117EditorEquipments.splice(i,1);
  v117RenderEquipments();
}

function v117AddService(i){
  v117LoadCatalog();
  const e=window.v117EditorEquipments[i];
  if(!e)return;

  const options=v117ServiceCatalog.map((s,n)=>
    `${n+1} — ${s.name} (${Number(s.value||0).toFixed(2).replace('.',',')} €)`
  ).join('\n');

  let choice=prompt(
    'Escolhe o serviço pelo número:\n\n'+
    (options||'Ainda não existem serviços configurados.')+
    '\n\nOu escreve 0 para criar um serviço novo.'
  );
  if(choice===null)return;

  const n=parseInt(choice,10);
  let service;

  if(n>=1 && n<=v117ServiceCatalog.length){
    service=v117ServiceCatalog[n-1];
  }else{
    const nome=prompt('Nome do serviço:');
    if(!nome)return;
    const valor=prompt('Valor do serviço (€):','0');
    service={
      id:'svc_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),
      name:nome.trim(),
      value:Number(String(valor||'0').replace(',','.'))||0
    };

    // A new service becomes part of the catalog, with its own price.
    v117ServiceCatalog.push(service);
    localStorage.setItem('am_v117_service_catalog',JSON.stringify(v117ServiceCatalog));
  }

  e.servicos=e.servicos||[];
  e.servicos.push({
    id:'assign_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),
    serviceId:service.id,
    nome:service.name,
    valor:Number(service.value)||0
  });
  v117RenderEquipments();
  v117UpdatePaymentBalance();
}
function v117RemoveService(i,j){
  window.v117EditorEquipments[i]?.servicos?.splice(j,1);
  v117RenderEquipments();
  v117UpdatePaymentBalance();
}

function v156AddSubscription(i){
  const e=window.v117EditorEquipments?.[i];
  if(!e)return;
  const arr=Array.isArray(SUBSCRIPTIONS)?SUBSCRIPTIONS:[];
  if(!arr.length){
    showAppAlert('Aviso','Ainda não existem subscrições configuradas.');
    return;
  }
  const options=arr.map((s,n)=>`${n+1} — ${s.name||s.type||'Subscrição'}`).join('\n');
  const choice=prompt('Escolhe a subscrição pelo número:\n\n'+options);
  if(choice===null)return;
  const n=parseInt(choice,10);
  if(!(n>=1&&n<=arr.length))return;
  const sub=arr[n-1];
  e.subscricoes=Array.isArray(e.subscricoes)?e.subscricoes:[];
  e.subscricoes.push({id:sub.id||('sub_'+Date.now()),name:String(sub.name||sub.type||'Subscrição')});
  if(!String(e.subscricao||'').trim()) e.subscricao=String(sub.name||sub.type||'');
  v117RenderEquipments();
}

function v117EquipmentStats(){
  const out={};
  (Array.isArray(DATA)?DATA:[]).forEach(c=>{
    (c.equipamentos||[]).forEach(e=>{
      (e.servicos||[]).forEach(s=>{
        const n=String(s.nome||'').trim();
        if(n)out[n]=(out[n]||0)+1;
      });
    });
  });
  return out;
}


function v75ServiceSubscriptionOptions(currentId,currentName){
  const arr=Array.isArray(SUBSCRIPTIONS)?SUBSCRIPTIONS:[];
  const cid=String(currentId||'');
  const cn=String(currentName||'');
  return `<option value="">— Sem associação —</option>`+arr.map(s=>{
    const id=String(s?.id||'');
    const name=String(s?.name||s?.type||'');
    const selected=(id&&id===cid)||(cn&&name===cn);
    return `<option value="${esc(id)}" ${selected?'selected':''}>${esc(name)}</option>`;
  }).join('');
}
function v75GetServiceConfig(i){
  // V77: não recarregar do localStorage quando já existe catálogo em memória.
  // O recarregamento aqui apagava alterações dos campos feitas no formulário.
  if(!Array.isArray(v117ServiceCatalog)) v117LoadCatalog();
  return Array.isArray(v117ServiceCatalog)?v117ServiceCatalog[i]:null;
}
function v75PersistServices(){
  v117PersistCatalog();
  try{saveAppSettings?.();}catch(_){}
}
function v75RenderServiceBuilder(){
  const box=document.getElementById('v75ServiceBuilderList');
  if(!box)return;
  if(!Array.isArray(v117ServiceCatalog)) v117LoadCatalog();
  const arr=Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[];
  if(!arr.length){box.innerHTML='<div class="muted" style="margin-top:10px">Ainda não existem serviços configurados.</div>';return;}
  box.innerHTML=arr.map((s,i)=>`
    <div class="v75-service-card">
      <div class="v75-service-card-head">
        <div class="v75-service-card-name">🛠️ ${esc(s.name)}</div>
        <div class="actions"><button type="button" onclick="v75RenameService(${i})">✏️</button><button type="button" onclick="v75DeleteService(${i})">🗑️</button></div>
      </div>
      <div class="row" style="margin-top:8px">
        <div class="field"><label>Nome do serviço</label><input id="v75_sname_${i}" value="${esc(s.name)}" oninput="v117ServiceCatalog[${i}].name=this.value;v75PersistServices()"></div>
        <div class="field"><label>Valor (€)</label><input id="v75_svalue_${i}" type="number" step="0.01" min="0" value="${Number(s.value||0)}" oninput="v117ServiceCatalog[${i}].value=Number(this.value)||0;v75PersistServices()"></div>
      </div>
      <div class="actions" style="margin-top:8px"><button type="button" class="primary" onclick="v75SaveServiceConfig(${i})">💾 Guardar serviço</button></div>
    </div>`).join('');
}
function v75AddServiceConfig(){
  const name=(document.getElementById('v75NewServiceName')?.value||'').trim();
  const value=Number(document.getElementById('v75NewServiceValue')?.value||0)||0;
  if(!name){showAppAlert('Aviso','Indica o nome do serviço.');return;}
  v117LoadCatalog();
  if(v117ServiceCatalog.some(s=>String(s.name||'').trim().toLowerCase()===name.toLowerCase())){showAppAlert('Aviso','Esse serviço já existe.');return;}
  v117ServiceCatalog.push({id:'svc_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),name,value});
  v75PersistServices();
  const n=document.getElementById('v75NewServiceName'),v=document.getElementById('v75NewServiceValue');if(n)n.value='';if(v)v.value='';
  v75RenderServiceBuilder();
  const state=v586CaptureSettingsSections();state.services=true;v586RestoreSettingsSections(state);
}
function v75SaveServiceConfig(i){
  const s=v75GetServiceConfig(i);if(!s)return;
  const name=(document.getElementById('v75_sname_'+i)?.value||'').trim();
  const value=Number(document.getElementById('v75_svalue_'+i)?.value||0)||0;
  if(!name){showAppAlert('Aviso','Indica o nome do serviço.');return;}
  if(v117ServiceCatalog.some((x,n)=>n!==i&&String(x.name||'').trim().toLowerCase()===name.toLowerCase())){showAppAlert('Aviso','Já existe outro serviço com esse nome.');return;}
  s.name=name;s.value=value;
  v75PersistServices();
  v75RenderServiceBuilder();
  const state=v586CaptureSettingsSections();state.services=true;v586RestoreSettingsSections(state);
  showAppAlert('Serviço guardado','As alterações ao serviço foram guardadas.');
}
function v75RenameService(i){
  const input=document.getElementById('v75_sname_'+i);if(input){input.focus();input.select();}
}
function v75AddServiceField(i){
  const s=v75GetServiceConfig(i);if(!s)return;
  if(!Array.isArray(s.fields))s.fields=[];
  s.fields.push({id:'fld_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),label:''});
  v75PersistServices();v75RenderServiceBuilder();
  const state=v586CaptureSettingsSections();state.services=true;v586RestoreSettingsSections(state);
  requestAnimationFrame(()=>{const inputs=document.querySelectorAll('.v75-service-field-row input');inputs[inputs.length-1]?.focus();});
}
function v75RemoveServiceField(i,j){
  const s=v75GetServiceConfig(i);if(!s?.fields)return;
  s.fields.splice(j,1);v75PersistServices();v75RenderServiceBuilder();
  const state=v586CaptureSettingsSections();state.services=true;v586RestoreSettingsSections(state);
}
function v75SetServiceSubscription(i,id){
  const s=v75GetServiceConfig(i);if(!s)return;
  const sub=(Array.isArray(SUBSCRIPTIONS)?SUBSCRIPTIONS:[]).find(x=>String(x?.id||'')===String(id));
  s.subscriptionId=id||'';s.subscriptionName=sub?String(sub.name||sub.type||''):'';
  v75PersistServices();
}
async function v75DeleteService(i){
  const s=v75GetServiceConfig(i);if(!s)return;
  const ok=await showAppConfirm('Apagar serviço?','Tem a certeza que pretende apagar o serviço "'+String(s.name||'')+'"?','Apagar','Cancelar');
  if(!ok)return;
  v117ServiceCatalog.splice(i,1);v75PersistServices();v75RenderServiceBuilder();
  const state=v586CaptureSettingsSections();state.services=true;v586RestoreSettingsSections(state);
}
function v75ServiceFieldsHtml(serviceName,values){
  const s=(Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[]).find(x=>String(x.name||'')===String(serviceName||''));
  if(!s||!Array.isArray(s.fields)||!s.fields.length)return '';
  const obj=values&&typeof values==='object'?values:{};
  return `<div class="v75-service-use-fields"><strong>Dados de ${esc(s.name)}</strong>${s.fields.map(f=>{
    const key=String(f.id||'');const val=String(obj[key]??'');
    return `<div class="field"><input type="text" value="${esc(val)}" placeholder="${esc(f.label||'Campo')}" data-v75-service-field-id="${esc(key)}"></div>`;
  }).join('')}</div>`;
}
function v75SyncServiceFields(i,serviceName){
  const e=window.v117EditorEquipments?.[i];if(!e)return;
  v117LoadCatalog();
  if(!e.serviceFields||typeof e.serviceFields!=='object')e.serviceFields={};
  const s=(v117ServiceCatalog||[]).find(x=>String(x.name||'')===String(serviceName||''));
  if(s){
    const keep={};(s.fields||[]).forEach(f=>{const k=String(f.id||'');if(k)keep[k]=e.serviceFields[k]??'';});e.serviceFields=keep;
  }else e.serviceFields={};
  const box=document.getElementById('v75_service_fields_'+i);
  if(box)box.innerHTML=v75ServiceFieldsHtml(serviceName,e.serviceFields);
  v75BindServiceFieldInputs(i);
}
function v75BindServiceFieldInputs(i){
  const box=document.getElementById('v75_service_fields_'+i);if(!box)return;
  box.querySelectorAll('[data-v75-service-field-id]').forEach(input=>{
    input.oninput=()=>{
      const e=window.v117EditorEquipments?.[i];if(!e)return;
      if(!e.serviceFields||typeof e.serviceFields!=='object')e.serviceFields={};
      e.serviceFields[String(input.dataset.v75ServiceFieldId||'')]=input.value;
    };
  });
}


function v117RenderCatalog(){
  const b=document.getElementById('v117ServiceCatalogList'); if(!b)return;
  v117LoadCatalog();

  if(!v117ServiceCatalog.length){
    b.innerHTML='<div class="muted">Ainda não existem serviços por equipamento.</div>';
    return;
  }

  b.className='config-items v112-sort-list';
  b.dataset.v112Sort='service-catalog';

  b.innerHTML=v117ServiceCatalog.map((s,i)=>`
    <div class="client v112-sort-item v117-catalog-item" data-id="${esc(String(s.id))}">
      <span class="v112-handle" title="Arrastar para ordenar">☷</span>
      <div class="v121-service-main" style="flex:1;min-width:0">
        <label>Nome do serviço</label>
        <input class="v121-service-name" type="text" value="${esc(s.name)}"
          oninput="v117ServiceCatalog[${i}].name=this.value">
        <label>Valor pago (€)</label>
        <input class="v121-service-value" type="number" step="1" inputmode="numeric"
          value="${Number(s.value||0)}"
          oninput="v117ServiceCatalog[${i}].value=Number(String(this.value).replace(',','.'))||0">
      </div>
      <div class="v121-service-actions" style="display:flex;flex-direction:column;gap:5px">
        <button type="button" onclick="v120SaveCatalogService(${i})" title="Guardar">💾</button>
        <button type="button" onclick="v117DeleteCatalogService(${i})" title="Apagar">🗑️</button>
      </div>
    </div>`).join('');

  setTimeout(()=>window.v112BindSorters?.(),0);
}

function v117PersistCatalog(){
  const serviceKey=typeof v592CompanyStorageKey==='function'
    ? v592CompanyStorageKey('am_v117_service_catalog')
    : 'am_v117_service_catalog';
  localStorage.setItem(serviceKey,JSON.stringify(v117ServiceCatalog));

  if(!Array.isArray(CONFIG_LISTS.servicos))CONFIG_LISTS.servicos=[];
  if(!Array.isArray(CONFIG_LISTS.valores))CONFIG_LISTS.valores=[];

  CONFIG_LISTS.servicos=v117ServiceCatalog.map(s=>String(s.name||'').trim());
  CONFIG_LISTS.valores=v117ServiceCatalog.map(s=>String(Number(s.value||0)));
  saveConfigLists();
}

function v120SaveCatalogService(i){
  // IMPORTANTE: não recarregar o catálogo antes de guardar.
  // Os inputs da lista editável atualizam diretamente v117ServiceCatalog.
  // Se fizermos v117LoadCatalog() aqui, substituímos as alterações em memória
  // pelos valores antigos do localStorage e parece que o botão Guardar não funciona.
  const s=v117ServiceCatalog[i];
  if(!s)return;

  s.name=String(s.name||'').trim();
  s.value=Number(String(s.value??'').replace(',','.'))||0;
  if(!s.name){alert('Indica o nome do serviço.');return;}

  const duplicate=v117ServiceCatalog.some((x,n)=>n!==i && String(x.name||'').trim().toLowerCase()===s.name.toLowerCase());
  if(duplicate){alert('Já existe outro serviço com esse nome.');return;}

  v117PersistCatalog();
  v117RenderCatalog();
}
function v117AddCatalogService(){
  const nameEl=document.getElementById('v117ServiceName');
  const valueEl=document.getElementById('v117ServiceValue');
  const n=String(nameEl?.value||'').trim();
  const v=Number(String(valueEl?.value||'').replace(',','.'))||0;

  if(!n){
    alert('Indica o nome do serviço.');
    nameEl?.focus();
    return;
  }

  v117LoadCatalog();
  const existing=v117ServiceCatalog.find(s=>String(s.name).trim().toLowerCase()===n.toLowerCase());
  if(existing){
    alert('Já existe um serviço com esse nome. Podes alterar o valor diretamente na lista.');
    return;
  }

  const service={
    id:'svc_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),
    name:n,
    value:v
  };
  v117ServiceCatalog.push(service);
  localStorage.setItem('am_v117_service_catalog',JSON.stringify(v117ServiceCatalog));

  if(!Array.isArray(CONFIG_LISTS.servicos))CONFIG_LISTS.servicos=[];
  if(!Array.isArray(CONFIG_LISTS.valores))CONFIG_LISTS.valores=[];
  CONFIG_LISTS.servicos.push(n);
  CONFIG_LISTS.valores.push(String(v));
  if(typeof saveConfigLists==='function')saveConfigLists();

  if(nameEl)nameEl.value='';
  if(valueEl)valueEl.value='';
  v117RenderCatalog();
}

async function v117DeleteCatalogService(i){
  v117LoadCatalog();
  const service=v117ServiceCatalog[i];
  if(!service)return;
  const confirmed=await showAppConfirm('Eliminar serviço?','Tem a certeza que pretende eliminar o serviço "'+service.name+'"?','Eliminar','Cancelar');
  if(!confirmed)return;

  // Remove do catálogo novo.
  v117ServiceCatalog.splice(i,1);
  localStorage.setItem('am_v117_service_catalog',JSON.stringify(v117ServiceCatalog));

  // Se o serviço já estiver atribuído a equipamentos, removê-lo também das
  // atribuições, para não ficar a aparecer como serviço fantasma.
  if(Array.isArray(DATA)){
    DATA.forEach(c=>{
      if(!Array.isArray(c.equipamentos)) return;
      c.equipamentos.forEach(e=>{
        if(!Array.isArray(e.servicos)) return;
        e.servicos=e.servicos.filter(x=>String(x?.serviceId||'')!==String(service.id||'') && String(x?.nome||'').trim().toLowerCase()!==String(service.name||'').trim().toLowerCase());
      });
    });
    try{ if(typeof saveData==='function') saveData(); }catch(e){}
  }

  // Remove também da estrutura antiga, se existir.
  if(Array.isArray(CONFIG_LISTS.servicos)){
    const pos=CONFIG_LISTS.servicos.findIndex(x=>String(x).trim().toLowerCase()===String(service.name).trim().toLowerCase());
    if(pos>=0){
      CONFIG_LISTS.servicos.splice(pos,1);
      if(Array.isArray(CONFIG_LISTS.valores))CONFIG_LISTS.valores.splice(pos,1);
      if(typeof saveConfigLists==='function')saveConfigLists();
    }
  }
  v117RenderCatalog();
}


document.addEventListener('change',function(ev){
  const s=ev.target;
  if(!s || !s.matches('.v118-eq-card select'))return;
  const card=s.closest('.v118-eq-card');
  const vpnInput=card?.querySelector('input[id^="v118_vpn_"]');
  if(!vpnInput)return;
  if(s.value==='__custom__'){
    vpnInput.style.display='block';
    vpnInput.value='';
    const idx=[...document.querySelectorAll('.v118-eq-card')].indexOf(card);
    if(idx>=0)window.v117EditorEquipments[idx].vpn='';
    vpnInput.focus();
  }else{
    vpnInput.style.display='none';
  }
});


function v119OpenServiceManager(){
  v117LoadCatalog();
  let panel=document.getElementById('v119ServiceManager');
  if(panel) panel.remove();

  panel=document.createElement('div');
  panel.id='v119ServiceManager';
  panel.className='v119-service-manager';
  panel.innerHTML=`
    <div class="v119-sm-head">
      <div>
        <h3>⚙️ Serviços e valores</h3>
        <small>Cada serviço tem o seu próprio valor. A ordem da lista já não define o preço.</small>
      </div>
      <button type="button" onclick="v119CloseServiceManager()">Fechar</button>
    </div>
    <div id="v119ServiceList"></div>
    <div class="v119-add-service-form">
      <input id="v119ServiceName" placeholder="Ex.: Nome do serviço">
      <input id="v119ServiceValue" inputmode="decimal" placeholder="Ex.: Valor (€)">
      <button type="button" class="primary" onclick="v119CreateService()">＋ Adicionar serviço</button>
    </div>`;
  document.body.appendChild(panel);
  v119RenderServiceList();
}

function v119CloseServiceManager(){
  document.getElementById('v119ServiceManager')?.remove();
}

function v119RenderServiceList(){
  v117LoadCatalog();
  const box=document.getElementById('v119ServiceList');
  if(!box)return;
  box.innerHTML=v117ServiceCatalog.map((s,i)=>`
    <div class="v119-service-item">
      <input value="${esc(s.name)}" oninput="v117ServiceCatalog[${i}].name=this.value">
      <input value="${Number(s.value||0).toFixed(2)}" inputmode="decimal"
             oninput="v117ServiceCatalog[${i}].value=Number(String(this.value).replace(',','.'))||0">
      <button type="button" onclick="v119SaveService(${i})">💾</button>
      <button type="button" onclick="v119DeleteService(${i})">🗑️</button>
    </div>`).join('');
}

function v119SaveService(i){
  const s=v117ServiceCatalog[i];
  if(!s)return;
  s.id=s.id||('svc_'+Date.now().toString(36));
  s.name=String(s.name||'Serviço').trim()||'Serviço';
  s.value=Number(s.value)||0;
  localStorage.setItem('am_v117_service_catalog',JSON.stringify(v117ServiceCatalog));
  v119RenderServiceList();
}

function v119CreateService(){
  const name=document.getElementById('v119ServiceName')?.value.trim();
  const value=Number(String(document.getElementById('v119ServiceValue')?.value||'0').replace(',','.'))||0;
  if(!name){alert('Indica o nome do serviço.');return;}
  v117LoadCatalog();
  v117ServiceCatalog.push({
    id:'svc_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),
    name,value
  });
  localStorage.setItem('am_v117_service_catalog',JSON.stringify(v117ServiceCatalog));
  document.getElementById('v119ServiceName').value='';
  document.getElementById('v119ServiceValue').value='';
  v119RenderServiceList();
}

async function v119DeleteService(i){
  const service=v117ServiceCatalog[i];
  if(!service)return;
  const confirmed=await showAppConfirm('Eliminar serviço?','Tem a certeza que pretende eliminar este serviço da lista de serviços?','Eliminar','Cancelar');
  if(!confirmed)return;
  v117ServiceCatalog.splice(i,1);
  localStorage.setItem('am_v117_service_catalog',JSON.stringify(v117ServiceCatalog));
  v119RenderServiceList();
}


window.openServiceValues=function(){v119OpenServiceManager();};


(function(){
function n(v){
  if(v==null||v==='')return 0;
  return Number(String(v).replace(/\s/g,'').replace(/€/g,'').replace(/\./g,'').replace(',','.'))||0;
}
function serviceCatalogValue(name){
  const cat=Array.isArray(window.v117ServiceCatalog)?window.v117ServiceCatalog:[];
  const svc=cat.find(x=>String(x?.name||'')===String(name||''));
  return n(svc?.value);
}
function equipmentTotal(e){
  if(!e)return 0;
  // O serviço principal do equipamento já entra em mainServiceTotal(c).
  // Aqui entram apenas os valores adicionais: serviços extra, VPNs e a
  // subscrição escolhida diretamente no equipamento.
  const manual=(Array.isArray(e.servicos)?e.servicos:[]).reduce((a,s)=>a+n(s?.valor),0);
  const vpns=(Array.isArray(e.vpns)?e.vpns:[]).reduce((a,v)=>{
    let value=n(v?.valor);
    if(!value)value=serviceCatalogValue(v?.nome);
    return a+value;
  },0);
  const subscription=(typeof v117SubscriptionRevenue==='function') ? v117SubscriptionRevenue(e?.subscricao) : 0;
  // V716: o serviço principal já é somado em mainServiceTotal(c).
  // Esta função trata apenas dos adicionais; "main" não existe neste escopo.
  return manual+vpns+subscription;
}
function mainServiceTotal(c){
  const stored=c?.['Serviço Valor'];
  if(stored!==undefined && stored!==null && String(stored)!=='')return n(stored);
  return serviceCatalogValue(c?.['Serviço']);
}
function total(c){
  const main=mainServiceTotal(c);
  const equipment=(Array.isArray(c?.equipamentos)?c.equipamentos:[]).reduce((a,e)=>a+equipmentTotal(e),0);
  return main+equipment;
}
function balance(c){return n(c?.['Preço'])-total(c);}
function setBal(c){
  if(!c)return;
  c['Saldo']=String(Math.round(balance(c)));
}
function normalize(){
  if(!Array.isArray(window.DATA))return;
  let ch=false;
  DATA.forEach(c=>{
    const before=String(c.Saldo??'');
    setBal(c);
    if(before!==String(c.Saldo??''))ch=true;
  });
  if(ch)v592SaveCompanyData('amClientesDB',DATA);
}
window.v117UpdatePaymentBalance=function(){
  const p=document.getElementById('f_Preço');
  const s=document.getElementById('f_Saldo');
  if(!p||!s)return;
  const paid=n(p.value);
  const main=n(window.v150BaseServiceValue);
  const equipment=(Array.isArray(window.v117EditorEquipments)?window.v117EditorEquipments:[])
    .reduce((a,e)=>a+equipmentTotal(e),0);
  s.value=String(Math.round(paid-(main+equipment)))+' €';
};
window.saveClient=function(id,isNew){try{
  const before=snapshotState(),old=DATA.find(x=>String(x['ID Cliente'])===String(id));
  const c=isNew?{}:JSON.parse(JSON.stringify(old||{}));
  if(isNew)FORM_FIELDS.forEach(([k])=>{if(!(k in c))c[k]='';});
  ['Nome','Observações','Contacto','Nome Empresa','Email','Morada','Periodicidade','Pagamento','Método Pagamento','Validade','Data Instalação'].forEach(k=>{
    const e=document.getElementById('f_'+css(k));if(e)c[k]=e.value||'';
  });
  const svcSel=document.getElementById('f_Serviço_select');
  const svcInput=document.getElementById('f_Serviço');
  c['Serviço']=(svcSel && svcSel.value!=='__custom__')?(svcSel.value||''):(svcInput?.value||'');
  c['Serviço Valor']=String(Number(window.v150BaseServiceValue)||0);
  const paidSelect=document.getElementById('f_Preço_select');
  const paidInput=document.getElementById('f_Preço');
  if(paidSelect){
    let paidValue=paidSelect.value==='__custom__'?(paidInput?.value||''):(paidSelect.value||'');
    c['Preço']=String(paidValue).replace(/\s/g,'').replace(/€/g,'').replace(/\./g,'').replace(',','.');
  }else if(paidInput){
    c['Preço']=String(paidInput.value||'').replace(/\s/g,'').replace(/€/g,'').replace(',','.');
  }
  c['ID Cliente']=id;
  c.equipamentos=JSON.parse(JSON.stringify(window.v117EditorEquipments||[]));
  const e=c.equipamentos[0]||{};

  // O formulário atual guarda os dados do serviço dentro do primeiro equipamento.
  // Antes desta correção, a função ativa tentava ler campos antigos do formulário
  // principal, que já não existem, e por isso Serviço, Periodicidade, Pagamento,
  // Método de Pagamento, Valor pago e Validade ficavam vazios depois de Guardar.
  // Mantemos aqui os campos de compatibilidade sincronizados com o primeiro serviço.
  c['Serviço']=String(e.servico||'');
  c['Periodicidade']=String(e.periodicidade||'');
  c['Método Pagamento']=String(e.metodoPagamento||'');
  c['Pagamento']=String(e.dataPagamento||'');
  c['Validade']=String(e.validade||'');
  c['Preço']=String(e.valorPago??'');
  c['Serviço Valor']=String(Number(e.servicoValor||0));
  c['Data Instalação']=String(e.dataInstalacao||'');
  c['Saldo']=String(Math.round(c.equipamentos.reduce((sum,item)=>sum+v183EquipmentBalance(item),0)));

  c.Equipamento=String(e.marca||'');c['Mac Adress']=String(e.mac||'');c.Utilizador=String(e.utilizador||'');c.Senha=String(e.senha||'');c.Link=String(e.link||'');
  const v=Array.isArray(e.vpns)&&e.vpns.length?e.vpns[0]:null;
  c.VPN=String(v?.nome||e.vpn||'');c['Utilizador VPN']=String(v?.utilizador||'');c['Password VPN']=String(v?.senha||'');c.Subscrição=String(v?.subscricao||e.subscricao||'');c['Estado Cliente']='';
  // O saldo acima já foi calculado a partir de todos os equipamentos. Não o
  // voltamos a recalcular com a lógica antiga, que usa os campos principais.
  if(isNew){DATA.push(c);recordAction('Cliente criado','Novo cliente criado: '+clientName(c),before,snapshotState());}
  else{const i=DATA.findIndex(x=>String(x['ID Cliente'])===String(id));if(i<0)throw Error('Cliente não encontrado');DATA[i]=c;recordAction('Cliente editado', (()=>{ const fields=changedFields(old,c); return 'Cliente alterado: '+clientName(c)+(fields.length?' — campos: '+fields.map(v172ActivityFieldName).join(', '):''); })(), before, snapshotState());}
  v592SaveCompanyData('amClientesDB',DATA);
  v592SaveCompanyData('amClientesArchived',ARCHIVED);
  v592SaveCompanyData('amClientesActivity',ACTIVITY);

  // IMPORTANTE: esta é a função de guardar que está ativa na versão final.
  // Atualizar os contadores e as listas antes de executar a saída do editor.
  if(typeof window.render==='function') window.render();
  if(typeof window.renderFullClients==='function') window.renderFullClients();

  // Usar a mesma lógica do Cancelar para fechar e esconder o editor.
  returnFromEditor(id);

  // Atualização final depois do fecho, para garantir que os números visíveis
  // já refletem o cliente acabado de guardar, sem necessidade de refresh.
  requestAnimationFrame(()=>{
    if(typeof window.render==='function') window.render();
    if(typeof window.renderFullClients==='function') window.renderFullClients();
  });
}catch(err){console.error(err);alert('Não foi possível guardar o cliente.\n\n'+(err.message||err));}};
const sc=window.selectClient;window.selectClient=function(id){const c=DATA.find(x=>String(x['ID Cliente'])===String(id));if(c)setBal(c);if(typeof sc==='function')sc(id);};
const r=window.render;window.render=function(){normalize();if(typeof r==='function')r();};
const rf=window.renderFullClients;window.renderFullClients=function(){normalize();if(typeof rf==='function')rf();};
setTimeout(normalize,0);
})();


(function(){
  const init=()=>{
    const root=document.getElementById('subscricoes');
    if(!root||root.__v194obs)return;
    root.__v194obs=true;
    new MutationObserver(()=>v194PrepareSubscriptionCards()).observe(root,{childList:true,subtree:true});
    v194PrepareSubscriptionCards();
  };
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();


document.addEventListener('DOMContentLoaded', function () {
  const headings = Array.from(document.querySelectorAll('h1,h2,h3,h4,div,span,button'));
  const target = headings.find(el => el.textContent.trim() === 'Gestão');
  if (!target) return;
  target.style.cursor = 'pointer';
  target.setAttribute('title', 'Abrir/fechar Gestão');
  target.addEventListener('click', function (ev) {
    if (ev.target.closest('button')) return;
    const parent = target.closest('.card, .section, .panel, section, div');
    if (!parent) return;
    const children = Array.from(parent.children);
    const content = children.find(el => el !== target && el.querySelector && (
      el.querySelector('button, input, select, textarea') ||
      /limpar|exportar|importar|backup|cliente/i.test(el.textContent)
    ));
    if (content) content.hidden = !content.hidden;
  });
});


(function(){
  function setupHamburger(){
    const btn=document.getElementById('menuHamburger');
    const close=document.getElementById('menuClose');
    const drawer=document.getElementById('sideMenu');
    const overlay=document.getElementById('menuOverlay');
    if(!btn||!close||!drawer||!overlay)return;
    function open(){drawer.classList.add('open');overlay.classList.add('open');drawer.setAttribute('aria-hidden','false');overlay.setAttribute('aria-hidden','false');btn.setAttribute('aria-expanded','true');}
    function shut(){drawer.classList.remove('open');overlay.classList.remove('open');drawer.setAttribute('aria-hidden','true');overlay.setAttribute('aria-hidden','true');btn.setAttribute('aria-expanded','false');}
    btn.addEventListener('click',open); close.addEventListener('click',shut); overlay.addEventListener('click',shut);
    drawer.querySelectorAll('.nav button').forEach(b=>b.addEventListener('click',()=>setTimeout(shut,80)));
    document.addEventListener('keydown',e=>{if(e.key==='Escape')shut();});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setupHamburger);else setupHamburger();
})();


(function(){
  function syncCloseButton(){
    const b=document.getElementById('listCloseBtn');
    if(!b)return;
    b.classList.toggle('v264p-close-only', (b.textContent||'').trim()==='Fechar');
  }
  function init(){
    const b=document.getElementById('listCloseBtn');
    if(!b)return;
    syncCloseButton();
    new MutationObserver(syncCloseButton).observe(b,{childList:true,characterData:true,subtree:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();


(function(){
  function syncOpenButton(){
    const b=document.getElementById('listCloseBtn');
    if(!b)return;
    const t=(b.textContent||'').trim();
    b.classList.toggle('v282-open-only', t==='Abrir');
  }
  function init(){
    const b=document.getElementById('listCloseBtn');
    if(!b)return;
    syncOpenButton();
    new MutationObserver(syncOpenButton).observe(b,{childList:true,characterData:true,subtree:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();


(function(){
  function syncStatusHeader(){
    const p=document.getElementById('todosClientes');
    if(!p)return;
    const title=document.getElementById('listTitle');
    const text=(title?.textContent||'').trim();
    const isStatus=/^(🟢|🟠|🔴)\s*Clientes\s+(ativos|a expirar|expirados)$/i.test(text);
    p.classList.toggle('status-list-open',isStatus);
  }
  function init(){
    const p=document.getElementById('todosClientes');
    const title=document.getElementById('listTitle');
    if(!p||!title)return;
    syncStatusHeader();
    new MutationObserver(syncStatusHeader).observe(title,{childList:true,characterData:true,subtree:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();


(function(){
  // V327 — Configurações é um menu próprio.
  // O botão Fechar fecha apenas os restantes balões/painéis e mantém
  // o utilizador dentro de Configurações. Nunca chama Início ou Clientes.
  window.closeSettingsPanel = function(){
    // V328 — Configurações permanece SEMPRE aberto como menu selecionado.
    // O Fechar deve apenas recolher as opções/formulário de Configurações,
    // tal como os restantes menus recolhem o seu conteúdo. Não muda de menu,
    // não faz scroll e não abre Clientes/Início.
    const config=document.getElementById('config');
    const form=document.getElementById('settingsForm');
    const btn=document.getElementById('settingsCloseBtn');
    if(!config || !form) return;

    const collapsed = config.dataset.settingsCollapsed === '1';
    if(collapsed){
      config.dataset.settingsCollapsed='0';
      form.classList.remove('hidden');
      form.style.display='';
      if(btn) btn.textContent='Fechar';
    }else{
      config.dataset.settingsCollapsed='1';
      form.classList.add('hidden');
      form.style.display='none';
      if(btn) btn.textContent='Abrir';
    }

    // Mantém Configurações como o menu ativo e preserva exatamente a posição
    // atual da página.
    if(typeof setActiveNav==='function') setActiveNav('config');
  };
})();


(function(){
  function box(){ return document.getElementById('homeShortcuts'); }
  function getGrid(b){ return b ? b.querySelector('.shortcut-grid') : null; }

  function sync(closed){
    const b=box();
    if(!b) return;
    const grid=getGrid(b);
    const btn=b.querySelector('[data-v552-shortcuts-toggle]');
    b.dataset.v552ShortcutsClosed=closed ? '1' : '0';
    if(grid) grid.style.display=closed ? 'none' : '';
    if(btn) btn.textContent=closed ? 'Abrir' : 'Fechar';
    if(closed){
      requestAnimationFrame(()=>{
        const max=Math.max(0,document.documentElement.scrollHeight-window.innerHeight);
        if(window.scrollY>max) window.scrollTo({top:max,left:0,behavior:'auto'});
      });
    }
  }

  function toggle(){
    const b=box();
    if(!b) return;
    sync(b.dataset.v552ShortcutsClosed !== '1');
  }

  function bind(){
    const b=box();
    if(!b) return;
    const header=b.querySelector('h2');
    const grid=getGrid(b);
    if(!header || !grid) return;
    const row=header.parentElement;
    if(!row) return;

    let btn=row.querySelector('[data-v552-shortcuts-toggle]');
    if(!btn){
      btn=document.createElement('button');
      btn.type='button';
      btn.className='primary';
      btn.dataset.v552ShortcutsToggle='1';
      row.appendChild(btn);
    }

    if(header.dataset.v552Bound!=='1'){
      header.dataset.v552Bound='1';
      header.style.cursor='pointer';
      header.addEventListener('click',function(ev){ ev.preventDefault(); toggle(); });
    }
    if(btn.dataset.v552Bound!=='1'){
      btn.dataset.v552Bound='1';
      btn.addEventListener('click',function(ev){ ev.preventDefault(); ev.stopPropagation(); toggle(); });
    }

    sync(b.dataset.v552ShortcutsClosed==='1');
  }

  const originalRender=window.renderHomeShortcuts;
  if(typeof originalRender==='function' && !originalRender.__v552Wrapped){
    const wrapped=function(){
      const result=originalRender.apply(this,arguments);
      bind();
      return result;
    };
    wrapped.__v552Wrapped=true;
    window.renderHomeShortcuts=wrapped;
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',bind,{once:true});
  else bind();
})();


(function(){
  function syncRefreshActiveNav(){
    const target=window.__AM_V351_RELOAD_TARGET||'inicio';
    if(typeof setActiveNav==='function') setActiveNav(target);
  }
  // Corre depois do bootstrap da V351 e não altera nenhuma secção nem estado interno.
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',syncRefreshActiveNav,{once:true});
  else syncRefreshActiveNav();
  // Última sincronização visual após renderizações tardias que possam repor o botão Início.
  setTimeout(syncRefreshActiveNav,0);
})();


(function(){
  function toggleSettingsCard(card){
    if(!card) return;
    card.classList.toggle('v577-collapsed');
  }

  document.addEventListener('click',function(e){
    if(e.target.closest('.v628-settings-handle')){
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    const settingsTitle=e.target.closest('#config > div:first-child h2');
    if(settingsTitle){
      if(typeof window.closeSettingsPanel==='function') window.closeSettingsPanel();
      return;
    }

    const heading=e.target.closest('#settingsForm > .card > h3');
    if(!heading) return;
    e.preventDefault();
    e.stopPropagation();
    toggleSettingsCard(heading.closest('.card'));
  });
})();


(function(){
  const KEY='amClientesGestaoMenuOrder';
  let drag=null,startX=0,startY=0;
  function list(){return document.querySelector('#gestao .v650-gestao-sort-list');}
  function rows(){return [...(list()?.querySelectorAll(':scope > .v650-gestao-sort-item')||[])];}
  function save(){localStorage.setItem(KEY,JSON.stringify(rows().map(x=>x.dataset.v650GestaoKey)));}
  function restore(){
    const l=list(); if(!l)return;
    let order=[]; try{order=JSON.parse(localStorage.getItem(KEY)||'[]')}catch(_){order=[]}
    if(!Array.isArray(order)||!order.length)return;
    const map=new Map(rows().map(x=>[x.dataset.v650GestaoKey,x]));
    order.forEach(k=>{const el=map.get(k); if(el)l.appendChild(el)});
  }
  function clear(){rows().forEach(x=>x.classList.remove('v650-gestao-dragging','v650-gestao-over'));}
  function finish(){if(!drag)return; save(); clear(); try{drag.handle.releasePointerCapture?.(drag.id)}catch(_){} drag=null;}
  document.addEventListener('DOMContentLoaded',restore);
  if(document.readyState!=='loading') setTimeout(restore,0);
  document.addEventListener('pointerdown',e=>{
    const handle=e.target.closest?.('#gestao .v650-gestao-handle'); if(!handle)return;
    const item=handle.closest('.v650-gestao-sort-item'), l=list(); if(!item||!l)return;
    e.preventDefault(); e.stopPropagation();
    drag={handle,item,list:l,id:e.pointerId}; startX=e.clientX; startY=e.clientY;
    item.classList.add('v650-gestao-dragging');
    try{handle.setPointerCapture(e.pointerId)}catch(_){}
  },{passive:false});
  document.addEventListener('pointermove',e=>{
    if(!drag||e.pointerId!==drag.id)return;
    e.preventDefault();
    const target=document.elementFromPoint(e.clientX,e.clientY)?.closest?.('#gestao .v650-gestao-sort-item');
    clear(); drag.item.classList.add('v650-gestao-dragging');
    if(!target||target===drag.item||target.parentElement!==drag.list)return;
    const r=target.getBoundingClientRect();
    drag.list.insertBefore(drag.item,e.clientY<r.top+r.height/2?target:target.nextSibling);
    target.classList.add('v650-gestao-over');
  },{passive:false});
  document.addEventListener('pointerup',e=>{if(drag&&e.pointerId===drag.id){e.preventDefault();finish();}},{passive:false});
  document.addEventListener('pointercancel',e=>{if(drag&&e.pointerId===drag.id)finish();},{passive:false});
})();


(function(){
  function v666Active(){
    return (typeof v586GetActiveCompany==='function' ? v586GetActiveCompany() : null)
      || {id:'company_1',name:'Empresa 1'};
  }
  function v666Num(){
    const a=v666Active(), m=String(a.name||a.id||'').match(/(\d+)/);
    return m ? Number(m[1]) : 1;
  }
  function v666ServiceKey(){
    return 'am_v117_service_catalog__'+String(v666Active().id||'company_1');
  }
  function v666MessageKey(){
    return 'amTemplates__'+String(v666Active().id||'company_1');
  }
  function v666DefaultServices(){
    const n=v666Num();
    return [1,2,3,4,5].map(i=>({
      id:'svc_company_'+n+'_'+i,
      name:'Serviço '+i+' da Empresa '+n,
      value:i*10
    }));
  }
  function v666LoadServices(){
    try{
      const raw=localStorage.getItem(v666ServiceKey());
      const data=raw?JSON.parse(raw):null;
      if(Array.isArray(data)){
        v117ServiceCatalog=data;
      }else if(typeof v675IsBaseEmpty==='function' && v675IsBaseEmpty()){
        v117ServiceCatalog=[];
        localStorage.setItem(v666ServiceKey(),JSON.stringify(v117ServiceCatalog));
      }else{
        v117ServiceCatalog=v666DefaultServices();
        localStorage.setItem(v666ServiceKey(),JSON.stringify(v117ServiceCatalog));
      }
    }catch(e){
      v117ServiceCatalog=v666DefaultServices();
    }
    CONFIG_LISTS.servicos=v117ServiceCatalog.map(s=>String(s.name||''));
    CONFIG_LISTS.valores=v117ServiceCatalog.map(s=>String(Number(s.value)||0));
  }
  function v666SaveServices(){
    localStorage.setItem(v666ServiceKey(),JSON.stringify(Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[]));
    CONFIG_LISTS.servicos=(v117ServiceCatalog||[]).map(s=>String(s.name||''));
    CONFIG_LISTS.valores=(v117ServiceCatalog||[]).map(s=>String(Number(s.value)||0));
    if(typeof saveConfigLists==='function') saveConfigLists();
  }

  // Substitui o carregamento global dos serviços por um carregamento por empresa.
  window.v117LoadCatalog=v666LoadServices;
  window.v117PersistCatalog=v666SaveServices;

  function v666LoadMessages(){
    try{
      const raw=localStorage.getItem(v666MessageKey());
      const data=raw?JSON.parse(raw):null;
      // V168: os modelos de mensagem são configuração funcional da aplicação,
      // não dados da base de dados. Devem existir mesmo quando a base foi limpa
      // ou numa instalação nova.
      templates=(data && typeof data==='object' && Object.keys(data).length)
        ? data
        : structuredClone(defaults);
      if(!raw || !(data && typeof data==='object' && Object.keys(data).length)){
        localStorage.setItem(v666MessageKey(),JSON.stringify(templates));
      }
    }catch(e){
      templates=structuredClone(defaults);
    }
  }
  function v666SaveMessages(){
    localStorage.setItem(v666MessageKey(),JSON.stringify(templates||{}));
  }

  // A função original gravava sempre na chave global. Passa a gravar na empresa ativa.
  window.saveTemplate=function(){
    const before=snapshotState();
    templates[currentTemplate]=template.value;
    recordAction('Mensagem alterada','Modelo de mensagem alterado: '+currentTemplate,before,snapshotState());
    v666SaveMessages();
    alert('Modelo guardado.');
  };

  function v666Refresh(){
    v666LoadServices();
    v666LoadMessages();
    currentTemplate = Object.prototype.hasOwnProperty.call(templates,'renewal')
      ? 'renewal'
      : (Object.keys(templates)[0]||'renewal');
    try{
      if(typeof setupTabs==='function') setupTabs();
      if(typeof v117RenderCatalog==='function') v117RenderCatalog();
      if(typeof v119RenderServiceList==='function') v119RenderServiceList();
    }catch(e){}
    if(typeof renderSettings==='function') renderSettings();
  }

  // Encadear à troca de empresa já existente na V665.
  const v666PrevSwitch=v586SwitchCompany;
  window.v586SwitchCompany=function(id){
    v666PrevSwitch(id);
    v666Refresh();
  };
  if(typeof v589SwitchCompanyFromMenu==='function'){
    const v666PrevMenuSwitch=v589SwitchCompanyFromMenu;
    window.v589SwitchCompanyFromMenu=function(id){
      v666PrevMenuSwitch(id);
      v666Refresh();
    };
  }

  v666Refresh();
})();


/* A criação da primeira subscrição regista imediatamente a compra inicial em Movimentos. */

/* V672 — Movimentos recolhíveis por defeito, sem seta, com edição e remoção individual. */

/* V684 — Clientes > Equipamentos: a Validade passa a usar as periodicidades
   definidas em Configurações e a opção 📅 Data abre o calendário manual. */
(function(){
  const esc=v=>String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  const DATE_MODE='__date__';

  function periodMonths(label){
    if(typeof window.v683PeriodMonths==='function') return window.v683PeriodMonths(label);
    const raw=String(label||'').trim();
    const t=raw.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    const fixed={mensal:1,bimensal:2,bimestral:2,trimestral:3,quadrimestral:4,semestral:6,anual:12,bienal:24,trienal:36};
    if(Object.prototype.hasOwnProperty.call(fixed,t)) return fixed[t];
    // Aceita nomes identificados por empresa, por exemplo: "Mensal 1",
    // "Trimestral - Empresa 2" ou "Anual (Empresa 5)".
    // O nome é livre para identificação; a duração é reconhecida pelo termo-base.
    const base=Object.keys(fixed).find(k=>new RegExp('^'+k+'(?:\\b|\\s|\\-|_|\\()').test(t));
    if(base) return fixed[base];
    let m=t.match(/(\d+(?:[.,]\d+)?)\s*(?:mes|meses|month|months)\b/);
    if(m) return Math.max(0,Math.round(Number(m[1].replace(',','.'))));
    m=t.match(/(\d+(?:[.,]\d+)?)\s*(?:ano|anos|year|years)\b/);
    return m?Math.max(0,Math.round(Number(m[1].replace(',','.'))*12)):0;
  }

  function calculatedEndDate(e,period){
    const months=periodMonths(period);
    // A validade é calculada exclusivamente a partir da Data de início de serviço.
    // A Data do pagamento é apenas informativa e nunca altera a validade.
    const base=String(e?.dataInstalacao||'').trim();
    if(!base||!months)return '';

    const m=base.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if(!m)return '';

    const year=Number(m[1]);
    const month=Number(m[2])-1;
    const day=Number(m[3]);

    // Soma meses de calendário sem usar toISOString() sobre uma data local,
    // evitando o desvio de um dia causado pelo fuso horário.
    const totalMonth=month+months;
    const targetYear=year+Math.floor(totalMonth/12);
    const targetMonth=((totalMonth%12)+12)%12;
    const lastDay=new Date(Date.UTC(targetYear,targetMonth+1,0)).getUTCDate();
    const targetDay=Math.min(day,lastDay);

    return String(targetYear).padStart(4,'0')+'-'+
      String(targetMonth+1).padStart(2,'0')+'-'+
      String(targetDay).padStart(2,'0');
  }

  function renderEquipmentValidity(i,field,e){
    const currentPeriod=String(e.periodicidade||'').trim();
    const currentDate=String(e.validade||'').trim();
    const periods=(Array.isArray(window.CONFIG_LISTS?.periodicidades)?window.CONFIG_LISTS.periodicidades:[])
      .map(v=>String(v||'').trim()).filter(Boolean);
    const mode=currentPeriod||DATE_MODE;
    field.innerHTML=`<label>Validade</label>
      <select id="v684_validity_mode_${i}">
        <option value="" disabled ${mode?'':'selected'}>Selecionar periodicidade</option>
        ${periods.map(v=>`<option value="${esc(v)}" ${v===currentPeriod?'selected':''}>${esc(v)}</option>`).join('')}
        <option value="${DATE_MODE}" ${mode===DATE_MODE?'selected':''}>📅 Data</option>
      </select>
      <div id="v684_validity_date_wrap_${i}" style="margin-top:6px;display:${mode===DATE_MODE?'block':'none'}">
        <input type="date" id="v684_validity_date_${i}" value="${esc(currentDate)}">
      </div>`;

    const select=field.querySelector('select');
    const wrap=field.querySelector('#v684_validity_date_wrap_'+i);
    const date=field.querySelector('#v684_validity_date_'+i);

    select.onchange=function(){
      const eq=window.v117EditorEquipments?.[i]; if(!eq)return;
      if(this.value===DATE_MODE){
        wrap.style.display='block';
        eq.periodicidade='';
        eq.validade=date.value||'';
        date.focus();
      }else{
        wrap.style.display='none';
        eq.periodicidade=this.value||'';
        eq.validade=calculatedEndDate(eq,eq.periodicidade);
        if(typeof window.v183RefreshEquipmentTotals==='function') window.v183RefreshEquipmentTotals(i);
      }
    };
    date.onchange=function(){
      const eq=window.v117EditorEquipments?.[i]; if(eq)eq.validade=this.value||'';
    };
  }

  function decorate(){
    const cards=document.querySelectorAll('#v117EquipmentBox .v118-eq-card');
    cards.forEach((card,i)=>{
      const eq=window.v117EditorEquipments?.[i]; if(!eq)return;
      const fields=Array.from(card.querySelectorAll('.field'));
      const validityField=fields.find(f=>f.querySelector('label')?.textContent.trim()==='Validade');
      if(validityField)renderEquipmentValidity(i,validityField,eq);
    });
  }

  const original=window.v117RenderEquipments;
  if(typeof original==='function'&&!original.__v684Wrapped){
    const wrapped=function(){
      const result=original.apply(this,arguments);
      decorate();
      return result;
    };
    wrapped.__v684Wrapped=true;
    window.v117RenderEquipments=wrapped;
  }
})();


/* V683 — correção da periodicidade nas Subscrições.
   Parte da V681: a lista vem das Configurações e "📅 Data" é a única opção
   que mostra o calendário para definir manualmente a data de fim. */
(function(){
  const esc=v=>String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

  window.v683PeriodMonths=function(label){
    const raw=String(label||'').trim();
    const t=raw.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    if(!t)return 0;
    const fixed={mensal:1,bimensal:2,bimestral:2,trimestral:3,quadrimestral:4,semestral:6,anual:12,bienal:24,trienal:36};
    if(Object.prototype.hasOwnProperty.call(fixed,t))return fixed[t];
    const base=Object.keys(fixed).find(k=>new RegExp('^'+k+'(?:\\b|\\s|\\-|_|\\()').test(t));
    if(base)return fixed[base];
    let m=t.match(/(\d+(?:[.,]\d+)?)\s*(?:mes|meses|month|months)\b/);
    if(m)return Math.max(0,Math.round(Number(m[1].replace(',','.'))));
    m=t.match(/(\d+(?:[.,]\d+)?)\s*(?:ano|anos|year|years)\b/);
    if(m)return Math.max(0,Math.round(Number(m[1].replace(',','.'))*12));
    return 0;
  };

  window.v683PeriodFromMonths=function(months){
    const n=Math.max(0,Number(months)||0);
    const arr=Array.isArray(window.CONFIG_LISTS?.periodicidades)?window.CONFIG_LISTS.periodicidades:[];
    return arr.map(v=>String(v||'').trim()).filter(Boolean).find(v=>window.v683PeriodMonths(v)===n)||'';
  };

  window.v683RenderSubscriptionPeriods=function(selected){
    const sel=document.getElementById('subValidityPeriod');
    if(!sel)return;
    const current=selected!==undefined?String(selected||''):String(sel.value||'');
    const arr=(Array.isArray(window.CONFIG_LISTS?.periodicidades)?window.CONFIG_LISTS.periodicidades:[])
      .map(v=>String(v||'').trim()).filter(Boolean);
    sel.innerHTML='<option value="" selected disabled>Selecionar periodicidade</option>'+
      arr.map(v=>'<option value="'+esc(v)+'">'+esc(v)+'</option>').join('')+
      '<option value="__date__">📅 Data</option>';
    if(current && Array.from(sel.options).some(o=>o.value===current))sel.value=current;
    else sel.value='';
    window.v683SyncSubscriptionPeriod();
  };

  window.v683SyncSubscriptionPeriod=function(){
    const sel=document.getElementById('subValidityPeriod');
    const wrap=document.getElementById('subEndDateField');
    const input=document.getElementById('subEndDate');
    const manual=!!sel && sel.value==='__date__';
    if(wrap)wrap.style.display=manual?'block':'none';
    if(input && !manual)input.value='';
  };

  window.v683CalculatedEndDate=function(validityType,purchaseDate,startDate,months){
    const base=validityType==='activation'?(startDate||purchaseDate):(purchaseDate||startDate);
    const n=Math.max(0,Number(months)||0);
    if(!base || !n)return '';
    const d=new Date(String(base)+'T00:00:00');
    if(Number.isNaN(d.getTime()))return '';
    d.setMonth(d.getMonth()+n);
    return d.toISOString().slice(0,10);
  };

  const originalOpen=window.openSubscriptions;
  window.openSubscriptions=function(){
    window.v683RenderSubscriptionPeriods('');
    return originalOpen.apply(this,arguments);
  };

  window.addSubscription=function(){
    const type=(document.getElementById('subType')?.value||'').trim();
    const name=(document.getElementById('subName')?.value||'').trim();
    const client=(document.getElementById('subClient')?.value||'').trim();
    const limit=Math.max(1,parseInt(document.getElementById('subLimit')?.value||'1',10));
    const validityType=document.getElementById('subValidityType')?.value||'purchase';
    const licenseUsed=Math.max(0,Math.min(parseInt(document.getElementById('subLicenseUsed')?.value||'0',10),limit));
    const purchaseDate=document.getElementById('subPurchaseDate')?.value||'';
    const startDate=document.getElementById('subStartDate')?.value||'';
    const period=document.getElementById('subValidityPeriod')?.value||'';
    const manual=period==='__date__';
    const validityMonths=manual?0:window.v683PeriodMonths(period);
    const manualEnd=manual?(document.getElementById('subEndDate')?.value||''):'';
    const endDate=manualEnd||window.v683CalculatedEndDate(validityType,purchaseDate,startDate,validityMonths);
    const cost=Math.max(0,Number(document.getElementById('subCost')?.value||'0'));
    const revenue=Math.max(0,Number(document.getElementById('subRevenue')?.value||'0'));
    if(!name){alert('Indica o nome da subscrição.');return;}
    if(!period){alert('Seleciona a periodicidade ou a opção Data.');return;}
    if(manual && !manualEnd){alert('Indica a data de fim.');return;}
    const initialMovementDate=String(purchaseDate||new Date().toISOString().slice(0,10));
    const initialMovement={type:'purchase',quantity:limit,date:initialMovementDate,cost,client:'',months:0,startDate:'',endDate:'',initial:true};
    SUBSCRIPTIONS.push({id:'SUB-'+Date.now(),type,name,client,limit,validityType,licenseUsed,purchaseDate,startDate,validityMonths,endDate,cost,revenue,movements:[initialMovement],initialPurchaseRecorded:true,devices:[],v683Period:period});
    saveSubscriptions();renderSubscriptions();
    ['subType','subName','subClient','subLimit','subLicenseUsed','subPurchaseDate','subStartDate','subEndDate','subCost','subRevenue'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
    const validity=document.getElementById('subValidityType');if(validity)validity.value='';
    window.v683RenderSubscriptionPeriods('');
  };

  window.editSubscription=function(i){
    const s=SUBSCRIPTIONS[i]; if(!s)return;
    const set=(id,v)=>{const el=document.getElementById(id);if(el)el.value=v??'';};
    set('subType',s.type||''); set('subName',s.name||''); set('subClient',s.client||'');
    set('subLimit',Math.max(1,Number(s.limit)||1)); set('subValidityType',s.validityType||'');
    set('subLicenseUsed',Math.max(0,Number(s.licenseUsed)||0)); set('subPurchaseDate',s.purchaseDate||''); set('subStartDate',s.startDate||'');
    const period=String(s.v683Period||window.v683PeriodFromMonths(s.validityMonths)||((s.endDate&&!(Number(s.validityMonths)>0))?'__date__':'')||'');
    window.v683RenderSubscriptionPeriods(period);
    set('subEndDate',period==='__date__'?(s.endDate||''):'' ); window.v683SyncSubscriptionPeriod();
    set('subCost',Math.max(0,Number(s.cost)||0)); set('subRevenue',Math.max(0,Number(s.revenue)||0));
    window.editingSubscriptionIndex=i;
    const panel=document.getElementById('subscriptionCreatePanel'); const title=document.querySelector('#subscricoes .subscricoes-title-close'); const addBtn=panel?panel.querySelector('.actions button'):null;
    if(panel)panel.classList.remove('hidden'); const toggle=document.getElementById('subscriptionCreateToggleBtn'); if(toggle)toggle.textContent='Fechar'; if(title)title.innerHTML='🔐 Editar subscrição';
    if(addBtn){addBtn.textContent='💾 Guardar';addBtn.onclick=function(){window.saveEditedSubscription();};let cancelBtn=document.getElementById('cancelSubscriptionEditBtn');if(!cancelBtn){cancelBtn=document.createElement('button');cancelBtn.id='cancelSubscriptionEditBtn';cancelBtn.type='button';cancelBtn.textContent='Cancelar';cancelBtn.onclick=function(){window.cancelSubscriptionEdit();};addBtn.parentNode.appendChild(cancelBtn);}cancelBtn.style.display='inline-block';}
    if(panel)panel.scrollIntoView({behavior:'smooth',block:'start'});
  };

  window.saveEditedSubscription=function(){
    const i=window.editingSubscriptionIndex; if(i===null||i===undefined)return; const s=SUBSCRIPTIONS[i]; if(!s)return;
    const val=id=>document.getElementById(id)?.value||''; const name=String(val('subName')).trim(); const limit=Math.max(1,parseInt(val('subLimit')||'1',10));
    if(!name){alert('Indica o nome da subscrição.');return;} if(limit<subscriptionLinkedCount(s)){alert('O novo limite não pode ser inferior aos equipamentos já associados ('+subscriptionLinkedCount(s)+').');return;}
    const period=val('subValidityPeriod'); if(!period){alert('Seleciona a periodicidade ou a opção Data.');return;}
    const manual=period==='__date__'; const manualEnd=manual?val('subEndDate'):''; if(manual&&!manualEnd){alert('Indica a data de fim.');return;}
    s.type=String(val('subType')).trim();s.name=name;s.client=String(val('subClient')).trim();s.limit=limit;s.validityType=val('subValidityType')||'purchase';s.licenseUsed=Math.max(0,Math.min(parseInt(val('subLicenseUsed')||'0',10),limit));s.purchaseDate=val('subPurchaseDate');s.startDate=val('subStartDate');
    s.validityMonths=manual?0:window.v683PeriodMonths(period);s.endDate=manualEnd||window.v683CalculatedEndDate(s.validityType,s.purchaseDate,s.startDate,s.validityMonths);s.v683Period=period;s.cost=Math.max(0,Number(val('subCost')||'0'));s.revenue=Math.max(0,Number(val('subRevenue')||'0'));
    saveSubscriptions();renderSubscriptions();window.editingSubscriptionIndex=null;const panel=document.getElementById('subscriptionCreatePanel');const title=document.querySelector('#subscricoes .subscricoes-title-close');const addBtn=panel?panel.querySelector('.actions button'):null;if(title)title.innerHTML='🔐 Serviços e subscrições';if(addBtn){addBtn.textContent='+ Adicionar';addBtn.onclick=function(){window.addSubscription();};}const cancelBtn=document.getElementById('cancelSubscriptionEditBtn');if(cancelBtn)cancelBtn.style.display='none';
  };

  window.cancelSubscriptionEdit=function(){
    window.editingSubscriptionIndex=null; const panel=document.getElementById('subscriptionCreatePanel');const title=document.querySelector('#subscricoes .subscricoes-title-close');const addBtn=panel?panel.querySelector('.actions button'):null;const cancelBtn=document.getElementById('cancelSubscriptionEditBtn');if(title)title.innerHTML='🔐 Serviços e subscrições';if(addBtn){addBtn.textContent='+ Adicionar';addBtn.onclick=function(){window.addSubscription();};}if(cancelBtn)cancelBtn.style.display='none';['subType','subName','subClient','subLimit','subLicenseUsed','subPurchaseDate','subStartDate','subEndDate','subCost','subRevenue'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});const validity=document.getElementById('subValidityType');if(validity)validity.value='';window.v683RenderSubscriptionPeriods('');
  };

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>window.v683RenderSubscriptionPeriods(''),{once:true});else window.v683RenderSubscriptionPeriods('');
})();


/* V685 — ligação real entre Configurações > Periodicidades e os menus
   Subscrições e Clientes > Equipamentos. A lista é sempre lida do estado
   atual e também do localStorage, para evitar opções antigas ou vazias. */
(function(){
  const DATE_MODE='__date__';
  const esc=v=>String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

  function currentPeriods(){
    let saved=[];
    try{
      const raw=localStorage.getItem('amClientesConfigLists');
      const parsed=raw?JSON.parse(raw):null;
      if(parsed && Array.isArray(parsed.periodicidades)) saved=parsed.periodicidades;
    }catch(_){}
    const live=(typeof CONFIG_LISTS!=='undefined' && Array.isArray(CONFIG_LISTS.periodicidades))?CONFIG_LISTS.periodicidades:[];
    const source=saved.length?saved:live;
    return source.map(v=>String(v||'').trim()).filter(Boolean);
  }

  function periodMonths(label){
    if(typeof window.v683PeriodMonths==='function') return window.v683PeriodMonths(label);
    const t=String(label||'').trim().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    const fixed={mensal:1,bimestral:2,trimestral:3,quadrimestral:4,semestral:6,anual:12,bienal:24,trienal:36};
    if(Object.prototype.hasOwnProperty.call(fixed,t)) return fixed[t];
    let m=t.match(/(\d+(?:[.,]\d+)?)\s*(?:mes|meses|month|months)\b/);
    if(m) return Math.max(0,Math.round(Number(m[1].replace(',','.'))));
    m=t.match(/(\d+(?:[.,]\d+)?)\s*(?:ano|anos|year|years)\b/);
    return m?Math.max(0,Math.round(Number(m[1].replace(',','.'))*12)):0;
  }

  /* SUBSCRIÇÕES */
  window.v683RenderSubscriptionPeriods=function(selected){
    const sel=document.getElementById('subValidityPeriod');
    if(!sel)return;
    const current=selected!==undefined?String(selected||''):String(sel.value||'');
    const arr=currentPeriods();
    sel.innerHTML='<option value="" selected disabled>Selecionar periodicidade</option>'+arr.map(v=>'<option value="'+esc(v)+'">'+esc(v)+'</option>').join('')+'<option value="'+DATE_MODE+'">📅 Data</option>';
    if(current && Array.from(sel.options).some(o=>o.value===current)) sel.value=current;
    else sel.value='';
    if(typeof window.v683SyncSubscriptionPeriod==='function') window.v683SyncSubscriptionPeriod();
  };

  const previousOpenSubscriptions=window.openSubscriptions;
  if(typeof previousOpenSubscriptions==='function' && !previousOpenSubscriptions.__v685Wrapped){
    window.openSubscriptions=function(){
      const result=previousOpenSubscriptions.apply(this,arguments);
      window.v683RenderSubscriptionPeriods('');
      return result;
    };
    window.openSubscriptions.__v685Wrapped=true;
  }

  /* CLIENTES > EQUIPAMENTOS */
  function calculatedEndDate(eq,period){
    const raw=String(period||'').trim();
    const months=periodMonths(raw);
    // V712: nas periodicidades mensais, a validade do cliente é expressa
    // em dias corridos. "Mensal" = 30 dias, em vez de 1 mês de calendário.
    // As restantes periodicidades continuam a usar meses de calendário.
    const isMonthly=/^mensal(?:\b|\s|\-|_|\()/i.test(raw.normalize('NFD').replace(/[\u0300-\u036f]/g,''));
    const base=String(eq?.dataInstalacao||'').trim();
    if(!base || (!months && !isMonthly))return '';

    const m=base.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if(!m)return '';

    const year=Number(m[1]);
    const month=Number(m[2])-1;
    const day=Number(m[3]);
    const d=new Date(Date.UTC(year,month,day));
    if(Number.isNaN(d.getTime()))return '';

    if(isMonthly){
      d.setUTCDate(d.getUTCDate()+30);
    }else{
      // Soma meses de calendário sem usar toISOString() sobre uma data local,
      // evitando desvios de dia causados pelo fuso horário.
      const totalMonth=month+months;
      const targetYear=year+Math.floor(totalMonth/12);
      const targetMonth=((totalMonth%12)+12)%12;
      const lastDay=new Date(Date.UTC(targetYear,targetMonth+1,0)).getUTCDate();
      const targetDay=Math.min(day,lastDay);
      d.setUTCFullYear(targetYear,targetMonth,targetDay);
    }

    return String(d.getUTCFullYear()).padStart(4,'0')+'-'+
      String(d.getUTCMonth()+1).padStart(2,'0')+'-'+
      String(d.getUTCDate()).padStart(2,'0');
  }

  window.v685CalculatedEndDate=calculatedEndDate;

  function decorateEquipmentValidity(){
    const cards=document.querySelectorAll('#v117EquipmentBox .v118-eq-card');
    cards.forEach((card,i)=>{
      const eq=window.v117EditorEquipments?.[i]; if(!eq)return;
      const fields=Array.from(card.querySelectorAll('.field'));
      const field=fields.find(f=>f.querySelector('label')?.textContent.trim()==='Validade');
      if(!field)return;
      const currentPeriod=String(eq.periodicidade||'').trim();
      const currentDate=String(eq.validade||'').trim();
      // V110: um equipamento novo começa sem modo de validade selecionado.
      // Só mostra o campo de data quando a opção Data foi realmente escolhida
      // (ou quando existe uma data antiga guardada sem periodicidade).
      const mode=currentPeriod ? currentPeriod : (currentDate ? DATE_MODE : '');
      const periods=currentPeriods();
      field.innerHTML='<label>Validade</label>'+
        '<select id="v685_validity_mode_'+i+'" class="'+(mode?'v111-validity-selected':'v111-validity-placeholder')+'">'+
          '<option value="" '+(mode?'':'selected')+'>Selecionar validade</option>'+ 
          periods.map(v=>'<option value="'+esc(v)+'" '+(v===currentPeriod?'selected':'')+'>'+esc(v)+'</option>').join('')+
          '<option value="'+DATE_MODE+'" '+(mode===DATE_MODE?'selected':'')+'>📅 Data</option>'+ 
        '</select>'+ 
        '<div id="v685_validity_date_wrap_'+i+'" style="margin-top:6px;display:'+(mode?'block':'none')+'">'+
          '<input type="date" id="v685_validity_date_'+i+'" value="'+esc(currentDate)+'" '+(mode!==DATE_MODE?'readonly':'')+'>'+
        '</div>';
      const select=field.querySelector('select');
      const wrap=field.querySelector('#v685_validity_date_wrap_'+i);
      const date=field.querySelector('#v685_validity_date_'+i);
      select.onchange=function(){
        const item=window.v117EditorEquipments?.[i]; if(!item)return;
        this.classList.toggle('v111-validity-placeholder',!this.value);
        this.classList.toggle('v111-validity-selected',!!this.value);
        if(!this.value){
          item.periodicidade='';
          item.validade='';
          date.value='';
          date.readOnly=false;
          wrap.style.display='none';
          if(typeof window.v183RefreshEquipmentTotals==='function') window.v183RefreshEquipmentTotals(i);
          return;
        }
        if(this.value===DATE_MODE){
          wrap.style.display='block';
          date.readOnly=false;
          item.periodicidade='';
          date.value=item.validade||'';
          item.validade=date.value||'';
          date.focus();
        }else{
          item.periodicidade=this.value||'';
          item.validade=calculatedEndDate(item,item.periodicidade);
          date.value=item.validade||'';
          date.readOnly=true;
          wrap.style.display='block';
          if(typeof window.v183RefreshEquipmentTotals==='function') window.v183RefreshEquipmentTotals(i);
        }
      };
      date.onchange=function(){const item=window.v117EditorEquipments?.[i];if(item)item.validade=this.value||'';};
    });
  }
  window.v685RefreshEquipmentValidity=decorateEquipmentValidity;
  const previousRenderEquipments=window.v117RenderEquipments;
  if(typeof previousRenderEquipments==='function' && !previousRenderEquipments.__v685Wrapped){
    window.v117RenderEquipments=function(){
      const result=previousRenderEquipments.apply(this,arguments);
      decorateEquipmentValidity();
      return result;
    };
    window.v117RenderEquipments.__v685Wrapped=true;
  }

  /* Quando a app já está aberta e uma periodicidade é adicionada, a opção fica
     disponível na próxima abertura/renderização, sem obrigar a recarregar. */
  const previousAddConfig=window.addConfig;
  if(typeof previousAddConfig==='function' && !previousAddConfig.__v685Wrapped){
    window.addConfig=function(key){
      const result=previousAddConfig.apply(this,arguments);
      if(key==='periodicidades'){
        if(typeof window.v683RenderSubscriptionPeriods==='function') window.v683RenderSubscriptionPeriods('');
        if(typeof window.v685RefreshEquipmentValidity==='function') window.v685RefreshEquipmentValidity();
      }
      return result;
    };
    window.addConfig.__v685Wrapped=true;
  }
})();


(function(){
  function activeCompany(){
    return (typeof v586GetActiveCompany==='function' ? v586GetActiveCompany() : null)
      || {id:'company_1',name:'Empresa 1'};
  }
  function canonicalKey(){
    return typeof v618CatalogStorageKey==='function'
      ? v618CatalogStorageKey('servicos')
      : 'am_catalog_servicos';
  }
  function legacyServiceKey(){
    return 'am_v117_service_catalog__'+String(activeCompany().id||'company_1');
  }
  function clean(v){return String(v??'').trim();}
  function norm(v){return clean(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();}

  // Migração única: se o catálogo novo ainda não existir, aproveitar os serviços
  // já criados no catálogo antigo para não perder dados do utilizador.
  function ensureCanonicalCatalog(){
    try{
      const key=canonicalKey();
      if(localStorage.getItem(key)!==null)return;
      const legacyRaw=localStorage.getItem(legacyServiceKey());
      if(!legacyRaw)return;
      const legacy=JSON.parse(legacyRaw);
      if(!Array.isArray(legacy))return;
      const rows=legacy.map((s,i)=>({
        id:clean(s?.id)||('svc_'+Date.now().toString(36)+'_'+i),
        nome:clean(s?.name),
        tipo:clean(s?.tipo),
        unidade:clean(s?.unidade),
        venda:String(Number(s?.value||0)),
        campos:Array.isArray(s?.fields)?structuredClone(s.fields):[],
        subscriptionId:clean(s?.subscriptionId),
        subscriptionName:clean(s?.subscriptionName)
      })).filter(r=>r.nome);
      localStorage.setItem(key,JSON.stringify(rows));
    }catch(e){console.warn('V704 migração de serviços:',e)}
  }

  function loadCanonical(){
    if(typeof v676IsGlobalDatabaseEmpty==='function' && v676IsGlobalDatabaseEmpty()){
      v117ServiceCatalog=[];
      if(typeof CONFIG_LISTS==='object' && CONFIG_LISTS){
        CONFIG_LISTS.servicos=[];
        CONFIG_LISTS.valores=[];
      }
      return v117ServiceCatalog;
    }
    ensureCanonicalCatalog();
    let rows=[];
    try{rows=typeof getCatalog==='function' ? getCatalog('servicos') : [];}catch(e){rows=[];}
    if(!Array.isArray(rows))rows=[];
    v117ServiceCatalog=rows.map((r,i)=>({
      id:clean(r?.id)||('svc_cat_'+i),
      name:clean(r?.nome||r?.name),
      value:Number(String(r?.venda??r?.value??'0').replace(',','.'))||0,
      tipo:clean(r?.tipo),
      unidade:clean(r?.unidade),
      fields:Array.isArray(r?.campos)?structuredClone(r.campos):(Array.isArray(r?.fields)?structuredClone(r.fields):[]),
      subscriptionId:clean(r?.subscriptionId),
      subscriptionName:clean(r?.subscriptionName)
    })).filter(s=>s.name);
    // Compatibilidade: mantém as listas antigas sincronizadas, mas elas deixam
    // de ser uma fonte de dados independente.
    if(typeof CONFIG_LISTS==='object' && CONFIG_LISTS){
      CONFIG_LISTS.servicos=v117ServiceCatalog.map(s=>s.name);
      CONFIG_LISTS.valores=v117ServiceCatalog.map(s=>String(s.value));
    }
    return v117ServiceCatalog;
  }

  function persistCanonical(){
    const current=Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[];
    let existing=[];
    try{existing=typeof getCatalog==='function' ? getCatalog('servicos') : [];}catch(e){existing=[];}
    if(!Array.isArray(existing))existing=[];
    const byId=new Map(existing.map(r=>[clean(r?.id),r]));
    const byName=new Map(existing.map(r=>[norm(r?.nome||r?.name),r]));
    const rows=current.map((s,i)=>{
      const old=byId.get(clean(s.id))||byName.get(norm(s.name))||{};
      return {
        ...old,
        id:clean(s.id)||clean(old.id)||('svc_cat_'+Date.now().toString(36)+'_'+i),
        nome:clean(s.name),
        tipo:clean(s.tipo||old.tipo),
        unidade:clean(s.unidade||old.unidade),
        venda:String(Number(s.value||0)),
        campos:Array.isArray(s.fields)?structuredClone(s.fields):(Array.isArray(old.campos)?structuredClone(old.campos):[]),
        subscriptionId:clean(s.subscriptionId||old.subscriptionId),
        subscriptionName:clean(s.subscriptionName||old.subscriptionName)
      };
    }).filter(r=>r.nome);
    if(typeof setCatalog==='function')setCatalog('servicos',rows);
    try{localStorage.setItem(legacyServiceKey(),JSON.stringify(current));}catch(e){}
    if(typeof CONFIG_LISTS==='object' && CONFIG_LISTS){
      CONFIG_LISTS.servicos=current.map(s=>clean(s.name));
      CONFIG_LISTS.valores=current.map(s=>String(Number(s.value||0)));
      if(typeof saveConfigLists==='function')saveConfigLists();
    }
  }

  // A partir daqui, qualquer parte da aplicação que use o antigo v117ServiceCatalog
  // passa a ler/escrever o catálogo oficial de Serviços.
  window.v117LoadCatalog=loadCanonical;
  window.v117PersistCatalog=persistCanonical;
  window.v147SyncServicesFromCatalog=function(){loadCanonical();};

  // O serviço principal e os serviços extra do cliente continuam a funcionar,
  // mas passam a buscar os serviços ao módulo Serviços e subscrições.
  window.v117AddService=function(i){
    loadCanonical();
    const e=window.v117EditorEquipments?.[i];
    if(!e)return;
    const options=v117ServiceCatalog.map((s,n)=>
      `${n+1} — ${s.name} (${Number(s.value||0).toFixed(2).replace('.',',')} €)`
    ).join('\n');
    const choice=prompt('Escolhe o serviço pelo número:\n\n'+
      (options||'Ainda não existem serviços no catálogo.')+
      '\n\nOu escreve 0 para criar um serviço novo.');
    if(choice===null)return;
    const n=parseInt(choice,10);
    let service;
    if(n>=1 && n<=v117ServiceCatalog.length){
      service=v117ServiceCatalog[n-1];
    }else{
      const nome=prompt('Nome do serviço:');
      if(!nome)return;
      const valor=prompt('Valor do serviço (€):','0');
      service={
        id:'svc_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),
        name:clean(nome),value:Number(String(valor||'0').replace(',','.'))||0,tipo:'',unidade:''
      };
      if(!service.name)return;
      v117ServiceCatalog.push(service);
      persistCanonical();
    }
    e.servicos=e.servicos||[];
    e.servicos.push({
      id:'assign_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),
      serviceId:service.id,nome:service.name,valor:Number(service.value)||0
    });
    v117RenderEquipments();
    v117UpdatePaymentBalance();
  };

  // Criar/editar/apagar pelo antigo gestor, caso ainda seja chamado por algum
  // estado antigo da aplicação, também grava agora no catálogo oficial.
  window.v117AddCatalogService=function(){
    const nameEl=document.getElementById('v117ServiceName');
    const valueEl=document.getElementById('v117ServiceValue');
    const name=clean(nameEl?.value), value=Number(String(valueEl?.value||'0').replace(',','.'))||0;
    if(!name){alert('Indica o nome do serviço.');nameEl?.focus();return;}
    loadCanonical();
    if(v117ServiceCatalog.some(s=>norm(s.name)===norm(name))){alert('Já existe um serviço com esse nome.');return;}
    v117ServiceCatalog.push({id:'svc_'+Date.now().toString(36),name,value,tipo:'',unidade:''});
    persistCanonical();
    if(nameEl)nameEl.value=''; if(valueEl)valueEl.value='';
    if(typeof v117RenderCatalog==='function')v117RenderCatalog();
  };
  window.v117DeleteCatalogService=async function(i){
    loadCanonical();
    const service=v117ServiceCatalog[i]; if(!service)return;
    const confirmed=await showAppConfirm('Eliminar serviço?','Tem a certeza que pretende eliminar o serviço "'+service.name+'"?','Eliminar','Cancelar');
    if(!confirmed)return;
    v117ServiceCatalog.splice(i,1);
    persistCanonical();
    if(Array.isArray(DATA))DATA.forEach(c=>(c.equipamentos||[]).forEach(e=>{
      e.servicos=Array.isArray(e.servicos)?e.servicos.filter(x=>String(x?.serviceId||'')!==String(service.id||'')&&norm(x?.nome)!==norm(service.name)):[];
    }));
    try{saveDB();}catch(e){}
    if(typeof v117RenderCatalog==='function')v117RenderCatalog();
  };

  // VPN: a origem para identificar a subscrição do cliente já é a área
  // Subscrições. A lista de subscrições mantém-se independente dos serviços.
  const originalVPNTotal=window.v125VPNTotal;
  if(typeof originalVPNTotal==='function')window.v125VPNTotal=originalVPNTotal;

  // Carrega já o catálogo oficial para que o formulário de Cliente use a fonte certa.
  loadCanonical();
  try{if(typeof renderSettings==='function')renderSettings();}catch(e){}
})();


(function () {
  function saudacaoAtual() {
    const h = new Date().getHours();
    if (h >= 6 && h < 13) return "Bom dia,";
    if (h >= 13 && h < 20) return "Boa tarde,";
    return "Boa noite,";
  }

  function atualizarSaudacao(root) {
    const el = root || document;
    // [AGORA] é um marcador permanente no editor. Só deve ser convertido
    // quando a mensagem é mostrada/enviada, nunca dentro da caixa de edição.
    el.querySelectorAll('.message-preview, .mensagem-preview, [data-dynamic-greeting="true"], pre').forEach(function (node) {
      if (node.value && node.value.includes("[AGORA]")) {
        node.value = node.value.replaceAll("[AGORA]", saudacaoAtual());
      }
      if (node.textContent && node.textContent.includes("[AGORA]")) {
        node.textContent = node.textContent.replaceAll("[AGORA]", saudacaoAtual());
      }
    });
  }

  // Expose for the existing send/preview code.
  window.atualizarSaudacao = atualizarSaudacao;
  window.saudacaoAtual = saudacaoAtual;

  // Also update the visible preview shortly after navigation/template changes.
  const observer = new MutationObserver(function () {
    atualizarSaudacao(document);
  });
  observer.observe(document.body, {childList:true, subtree:true});
  setTimeout(function(){ atualizarSaudacao(document); }, 50);
})();


(function(){
  const META_KEY='amTemplateMeta';

  const baseMeta={
    renewal:{name:'Renovação',icon:'🔔'},
    expired:{name:'Expirado',icon:'⚠️'},
    payment:{name:'Pagamento',icon:'💶'},
    maintenance:{name:'Manutenção',icon:'🛠️'},
    custom:{name:'Personalizada',icon:'✏️'}
  };

  function loadMeta(){
    let m={};
    try{ m=JSON.parse(localStorage.getItem(META_KEY)||'{}')||{}; }catch(e){}
    Object.keys(baseMeta).forEach(k=>{ if(!m[k]) m[k]={...baseMeta[k]}; });
    Object.keys(templates||{}).forEach(k=>{
      if(!m[k]) m[k]={name:k==='custom'?'Personalizada':k,icon:'✉️'};
    });
    return m;
  }
  window.MESSAGE_META=loadMeta();

  function saveMeta(){ localStorage.setItem(META_KEY,JSON.stringify(window.MESSAGE_META)); }

  function migrateGreetings(){
    let changed=false;
    Object.keys(templates||{}).forEach(k=>{
      let t=String(templates[k]??'');
      let normalized=t
        .replace(/^\s*(?:Bom dia|Boa tarde|Boa noite),?\s*(?:\r?\n)?(?:\r?\n)?/i,'[AGORA]\n\n')
        .replaceAll('[SAUDACAO]','[AGORA]');
      if(normalized!==t){ templates[k]=normalized; changed=true; }
    });
    if(changed) localStorage.setItem('amTemplates',JSON.stringify(templates));
  }

  function greeting(){
    const h=new Date().getHours();
    if(h>=6 && h<13) return 'Bom dia,';
    if(h>=13 && h<20) return 'Boa tarde,';
    return 'Boa noite,';
  }

  function normalizeForStorage(t){
    let s=String(t??'');
    s=s.replace(/^\s*(?:Bom dia|Boa tarde|Boa noite),?\s*(?:\r?\n)?(?:\r?\n)?/i,'[AGORA]\n\n');
    s=s.replaceAll('[SAUDACAO]','[AGORA]');
    return s;
  }

  function displayTemplate(t){
    return String(t??'').replaceAll('[AGORA]',greeting());
  }

  // Corrige modelos antigos que ainda tenham "Bom dia" gravado.
  migrateGreetings();

  // O texto da mensagem passa a calcular a saudação no momento da utilização.
  window.fill=function(t,c){
    return displayTemplate(t)
      .replaceAll('[CLIENTE]',clientName(c))
      .replaceAll('[SERVIÇO]',c['Serviço']||'')
      .replaceAll('[DATA]',dateOf(c['Validade']).toLocaleDateString('pt-PT'))
      .replaceAll('[DIAS_RESTANTES]',days(c))
      .replaceAll('[VALOR]',c['Preço']||'0')
      .replaceAll('[SALDO]',c['Saldo']||'0');
  };

  window.label=function(k){
    const m=window.MESSAGE_META[k];
    return m ? `${m.icon||'✉️'} ${m.name||k}` : k;
  };

  window.setupTabs=function(){
    const tabs=document.getElementById('tabs');
    const template=document.getElementById('template');
    if(!tabs||!template)return;
    const keys=Object.keys(templates||{});
    if(!keys.length){
      tabs.innerHTML='';
      template.value='';
      return;
    }
    if(!templates[currentTemplate]) currentTemplate=keys[0];
    tabs.innerHTML=keys.map(k=>
      `<button class="${currentTemplate===k?'primary active':''}" onclick="chooseTemplate('${esc(k)}')">${esc(label(k))}</button>`
    ).join('');
    template.value=String(templates[currentTemplate]||'')
      .replace(/^\s*(?:Bom dia|Boa tarde|Boa noite),?\s*(?:\r?\n)?(?:\r?\n)?/i,'[AGORA]\n\n')
      .replaceAll('[SAUDACAO]','[AGORA]');
  };

  window.chooseTemplate=function(k){
    currentTemplate=k;
    setupTabs();
  };

  window.saveTemplate=function(){
    const before=snapshotState();
    const el=document.getElementById('template');
    if(!el)return;
    const value=normalizeForStorage(el.value);
    templates[currentTemplate]=value;
    localStorage.setItem('amTemplates',JSON.stringify(templates));
    recordAction('Mensagem alterada','Modelo de mensagem alterado: '+(MESSAGE_META[currentTemplate]?.name||currentTemplate),before,snapshotState());
    setupTabs();
    alert('Modelo guardado.');
  };

  window.previewTemplate=function(){
    const box=document.getElementById('templatePreview');
    const c=DATA[0];
    if(!box)return;
    const value=normalizeForStorage(document.getElementById('template')?.value||'');
    box.classList.remove('hidden');
    box.textContent=c?fill(value,c):displayTemplate(value);
  };

  window.renderMessageSettings=function(){
    const existing=Object.keys(templates||{});
    const list=existing.map((k,i)=>{
      const m=MESSAGE_META[k]||{name:k,icon:'✉️'};
      return `<div class="client v112-sort-item" data-id="${esc(k)}" data-message-key="${esc(k)}">
        <span class="v112-handle" title="Arrastar para ordenar">☷</span>
        <div style="min-width:0;flex:1"><strong>${esc(m.icon||'✉️')} ${esc(m.name||k)}</strong>
          <small>${esc(String(templates[k]||'').split('\n').find(x=>x.trim())||'Sem texto')}</small></div>
        <div class="actions"><button type="button" onclick="editMessageTemplate('${esc(k)}')">✏️</button>
          <button type="button" onclick="deleteMessageTemplate('${esc(k)}')">🗑️</button></div>
      </div>`;
    }).join('');

    return `<div class="card v577-collapsed v628-settings-card" data-v628-section="messages" style="margin-bottom:12px">
      <h3><span class="v628-settings-handle" title="Arrastar para ordenar" aria-label="Arrastar para ordenar">☷</span><span class="v628-settings-label">💬 Mensagens</span></h3>
      <div class="row">
        <div class="field"><label>Assunto</label><input id="newMessageName" placeholder="Ex.: Assunto da mensagem"></div>
        <div class="field"><label>Ícone</label><input id="newMessageIcon" placeholder="Ex.: 📘" maxlength="4"></div>
      </div>
      <div class="field" style="margin-top:8px">
        <label>Mensagem</label>
        <textarea id="newMessageText" class="message template" placeholder="Ex.: Escreve aqui a mensagem..."></textarea>
      </div>
      <div class="actions" style="margin-top:8px">
        <button class="primary" type="button" onclick="addMessageTemplate()">＋ Adicionar mensagem</button>
      </div>
      <div class="config-items message-config-list" style="margin-top:18px">${list}</div>
    </div>`;
  };

  window.addMessageTemplate=function(){
    const name=(document.getElementById('newMessageName')?.value||'').trim();
    const icon=(document.getElementById('newMessageIcon')?.value||'✉️').trim()||'✉️';
    const text=normalizeForStorage(document.getElementById('newMessageText')?.value||'');
    if(!name){alert('Indica o nome da mensagem.');return;}
    if(!text.trim()){alert('Escreve o texto da mensagem.');return;}
    const before=snapshotState();
    let key='msg_'+Date.now().toString(36);
    while(templates[key]) key+='x';
    templates[key]=text;
    MESSAGE_META[key]={name,icon};
    saveMeta();
    localStorage.setItem('amTemplates',JSON.stringify(templates));
    recordAction('Mensagem adicionada','Nova mensagem: '+name,before,snapshotState());
    renderSettings();
    setupTabs();
  };

  window.editMessageTemplate=function(k){
    if(!templates[k])return;
    const m=MESSAGE_META[k]||{name:k,icon:'✉️'};
    const name=prompt('Assunto:',m.name||k);
    if(name===null)return;
    const icon=prompt('Ícone:',m.icon||'✉️');
    if(icon===null)return;
    const text=prompt('Texto da mensagem:',String(templates[k]||'').replaceAll('[AGORA]',greeting()));
    if(text===null)return;
    const before=snapshotState();
    MESSAGE_META[k]={name:name.trim()||m.name||k,icon:icon.trim()||'✉️'};
    templates[k]=normalizeForStorage(text);
    saveMeta();
    localStorage.setItem('amTemplates',JSON.stringify(templates));
    recordAction('Mensagem alterada','Mensagem alterada: '+MESSAGE_META[k].name,before,snapshotState());
    renderSettings();
    setupTabs();
  };

  window.deleteMessageTemplate=async function(k){
    const m=MESSAGE_META[k]||{name:k};
    const confirmed=await showAppConfirm('Apagar mensagem?','Tem a certeza que pretende apagar a mensagem "'+(m.name||k)+'"?','Apagar','Cancelar');
    if(!confirmed)return;
    const before=snapshotState();
    delete templates[k];
    delete MESSAGE_META[k];
    if(currentTemplate===k) currentTemplate=Object.keys(templates)[0]||'';
    saveMeta();
    localStorage.setItem('amTemplates',JSON.stringify(templates));
    recordAction('Mensagem apagada','Mensagem apagada: '+(m.name||k),before,snapshotState());
    renderSettings();
    setupTabs();
  };

  // Acrescenta o gestor de mensagens no fim de Configurações.
  const originalRenderSettings=window.renderSettings;
  window.renderSettings=function(){
    const preservedSections=typeof v586CaptureSettingsSections==='function'
      ? v586CaptureSettingsSections() : {};
    const preservedScrollY=window.scrollY||document.documentElement.scrollTop||0;

    originalRenderSettings();

    const box=document.getElementById('settingsForm');
    if(box){
      const wrap=document.createElement('div');
      wrap.innerHTML=renderMessageSettings();
      const messageCard=wrap.firstElementChild;
      if(messageCard){
        messageCard.classList.add('v577-collapsed','v628-settings-card');
        messageCard.dataset.v628Section='messages';
        box.appendChild(messageCard);
        try{ v628ApplySettingsOrder(); }catch(_){}
      }
      if(typeof v586RestoreSettingsSections==='function'){
        v586RestoreSettingsSections(preservedSections);
      }
      requestAnimationFrame(()=>window.scrollTo({top:preservedScrollY,behavior:'auto'}));
    }
  };

  // Remove a descrição fixa e garante que os modelos aparecem sem ela.
  const desc=document.querySelector('#mensagens > p.muted');
  if(desc)desc.remove();

  // Atualiza a vista se a aplicação já estiver aberta.
  setTimeout(function(){
    if(typeof setupTabs==='function') setupTabs();
    if(typeof renderSettings==='function' && !document.getElementById('config')?.classList.contains('hidden')) renderSettings();
  },20);
})();


(function(){
  function manterPlaceholderNoEditor(){
    const el=document.getElementById('template');
    if(!el || document.activeElement===el) return;
    const v=String(el.value||'');
    if(/^Bom dia,|^Boa tarde,|^Boa noite,/.test(v)){
      el.value=v.replace(/^(?:Bom dia|Boa tarde|Boa noite),?\s*(?:\r?\n)?(?:\r?\n)?/,'[AGORA]\n\n');
    }
  }
  window.mostrarPlaceholderAgora=manterPlaceholderNoEditor;
  setTimeout(manterPlaceholderNoEditor,100);
})();


(function(){
  let drag=null;
  let pressTimer=null;
  let startX=0,startY=0;

  function itemOf(el){
    return el?.closest?.('.v112-sort-item,.v112-home-item,.v628-settings-card') || null;
  }
  function listOf(item){
    return item?.closest?.('.v112-sort-list,.v112-home-sort,.v628-settings-sort-list') || null;
  }
  function clearVisual(){
    document.querySelectorAll('.v113-dragging,.v113-over,.v628-settings-dragging,.v628-settings-over').forEach(el=>{
      el.classList.remove('v113-dragging','v113-over','v628-settings-dragging','v628-settings-over');
    });
  }
  function dragClassFor(item){
    return item.classList.contains('v628-settings-card')?'v628-settings-dragging':'v113-dragging';
  }
  function overClassFor(item){
    return item.classList.contains('v628-settings-card')?'v628-settings-over':'v113-over';
  }
  function getRows(list){
    return [...list.children].filter(el=>
      el.classList.contains('v112-sort-item') ||
      el.classList.contains('v112-home-item') ||
      el.classList.contains('v628-settings-card')
    );
  }
  function saveOrder(list){
    const rows=getRows(list);
    const type=list.dataset.v112Sort;

    if(list.dataset.v628Sort==='settings-sections'){
      const order=rows.map(r=>String(r.dataset.v628Section||'')).filter(Boolean);
      localStorage.setItem('amClientesSettingsMenuOrder',JSON.stringify(order));
      return;
    }

    if(type==='shortcuts' || type==='home-shortcuts'){
      const old=Array.isArray(APP_SETTINGS.shortcuts)?APP_SETTINGS.shortcuts:[];
      const byId=new Map(old.map(x=>[String(x.id||''),x]));
      const ordered=rows.map(r=>byId.get(String(r.dataset.id||''))).filter(Boolean);
      if(ordered.length===old.length){
        APP_SETTINGS.shortcuts=ordered;
        localStorage.setItem('amClientesAppSettings',JSON.stringify(APP_SETTINGS));
      }
      return;
    }

    if(type==='service-catalog'){
      const byId=new Map((Array.isArray(v117ServiceCatalog)?v117ServiceCatalog:[]).map(x=>[String(x.id||''),x]));
      const ordered=rows.map(r=>byId.get(String(r.dataset.id||''))).filter(Boolean);
      if(ordered.length===v117ServiceCatalog.length){
        v117ServiceCatalog=ordered;
        v117PersistCatalog();
      }
      return;
    }

    if(type==='config'){
      const key=list.dataset.v112Key;
      if(!CONFIG_LISTS[key]) return;
      CONFIG_LISTS[key]=rows.map(r=>String(r.dataset.id||''));
      localStorage.setItem('amClientesConfigLists',JSON.stringify(CONFIG_LISTS));
    }

    if(type==='catalog'){
      const catalogWork=document.getElementById('catalogWork');
      const catalogType=String(catalogWork?.dataset.type||'');
      if(!catalogType) return;
      const oldRows=getCatalog(catalogType);
      const ordered=rows
        .map(r=>Number(r.dataset.catIndex))
        .filter(i=>Number.isInteger(i) && i>=0 && i<oldRows.length)
        .map(i=>oldRows[i]);
      if(ordered.length===oldRows.length){
        setCatalog(catalogType,ordered);
        // Atualiza os índices para que um novo arrasto use a ordem atual.
        rows.forEach((r,i)=>{r.dataset.catIndex=String(i);});
      }
      return;
    }
    if(list.classList.contains('message-config-list') || list.dataset.v112Sort==='messages'){
      const keys=rows.map(r=>String(r.dataset.messageKey||r.dataset.id||'')).filter(Boolean);
      const oldT=templates||{}, oldM=MESSAGE_META||{};
      const nt={},nm={};
      keys.forEach(k=>{
        if(Object.prototype.hasOwnProperty.call(oldT,k)) nt[k]=oldT[k];
        if(oldM[k]) nm[k]=oldM[k];
      });
      templates=nt; MESSAGE_META=nm;
      localStorage.setItem('amTemplates',JSON.stringify(templates));
      localStorage.setItem('amMessageMeta',JSON.stringify(MESSAGE_META));
      return;
    }

  }

  function moveTo(list,item,x,y){
    const point=document.elementFromPoint(x,y);
    const target=itemOf(point);
    if(!target || target===item || listOf(target)!==list) return;

    const r=target.getBoundingClientRect();
    const before=y < r.top + r.height/2;

    if(before){
      if(target.previousElementSibling!==item){
        list.insertBefore(item,target);
      }
    }else{
      if(target.nextElementSibling!==item){
        list.insertBefore(item,target.nextSibling);
      }
    }

    clearVisual();
    item.classList.add(dragClassFor(item));
    target.classList.add(overClassFor(target));
  }

  function finish(cancel=false){
    if(!drag)return;
    const list=drag.list;
    if(!cancel) saveOrder(list);
    clearVisual();
    if(pressTimer){clearTimeout(pressTimer);pressTimer=null;}
    try{drag.handle.releasePointerCapture?.(drag.pointerId);}catch(_){}
    drag=null;
  }

  // Only the ☷ handle starts a drag. Nothing else in the application is
  // intercepted.
  document.addEventListener('pointerdown',e=>{
    const handle=e.target.closest?.('.v112-handle,.v628-settings-handle');
    if(!handle)return;

    const item=itemOf(handle);
    const list=listOf(item);
    if(!item || !list)return;

    e.preventDefault();
    e.stopPropagation();

    startX=e.clientX;
    startY=e.clientY;

    drag={
      handle,
      item,
      list,
      pointerId:e.pointerId,
      started:false
    };

    // Small delay prevents a normal tap from immediately becoming a drag.
    pressTimer=setTimeout(()=>{
      if(!drag)return;
      drag.started=true;
      item.classList.add(dragClassFor(item));
      try{handle.setPointerCapture(e.pointerId);}catch(_){}
    },160);
  },{passive:false});

  document.addEventListener('pointermove',e=>{
    if(!drag || e.pointerId!==drag.pointerId)return;

    const dx=Math.abs(e.clientX-startX);
    const dy=Math.abs(e.clientY-startY);

    // If the user moves enough before the delay, start immediately.
    if(!drag.started && (dx>6 || dy>6)){
      if(pressTimer){clearTimeout(pressTimer);pressTimer=null;}
      drag.started=true;
      drag.item.classList.add(dragClassFor(drag.item));
      try{drag.handle.setPointerCapture(e.pointerId);}catch(_){}
    }

    if(!drag.started)return;

    e.preventDefault();
    e.stopPropagation();

    moveTo(drag.list,drag.item,e.clientX,e.clientY);
  },{passive:false});

  document.addEventListener('pointerup',e=>{
    if(!drag || e.pointerId!==drag.pointerId)return;

    e.preventDefault();
    e.stopPropagation();

    // A tap without movement simply cancels the drag.
    if(drag.started) finish(false);
    else finish(true);
  },{passive:false});

  document.addEventListener('pointercancel',e=>{
    if(!drag || e.pointerId!==drag.pointerId)return;
    finish(true);
  },{passive:false});
})();


(function(){
  function bind(){ window.v112BindSorters?.(); }
  setTimeout(bind,80);
  const obs=new MutationObserver(()=>setTimeout(bind,0));
  const root=document.getElementById('settingsForm')||document.body;
  obs.observe(root,{childList:true,subtree:true});
})();


(function(){
  function markMessageList(){
    document.querySelectorAll('.message-config-list').forEach(list=>{
      list.classList.add('v112-sort-list');
      list.dataset.v112Sort='messages';
    });
  }
  markMessageList();
  const root=document.getElementById('settingsForm')||document.body;
  new MutationObserver(markMessageList).observe(root,{childList:true,subtree:true});
})();


(function(){
 function init(){
   if(typeof bindArchivedToggleControls==='function') bindArchivedToggleControls();
 }
 if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init);
 else init();
})();


window.openCatalog = openCatalog;
window.openCatalogos = openCatalogos;
window.saveCatalogItem = saveCatalogItem;
window.editCatalogItem = editCatalogItem;
window.deleteCatalogItem = deleteCatalogItem;


(function(){
  function applyFix(){
    if(typeof window.toggleHomeClientPanel!=='function') return;
    if(window.toggleHomeClientPanel.__v292Wrapped) return;

    const original=window.toggleHomeClientPanel;
    function fixedToggleHomeClientPanel(){
      const body=document.getElementById('homeClientsBody');
      const willOpen=!!(body && body.classList.contains('hidden'));

      original();

      // Ao fechar o painel Clientes do Início, eliminar também o estado
      // visual da ficha que estava aberta. Isto impede que o #detail vazio
      // reapareça como uma caixa entre o cabeçalho e a lista ao reabrir.
      if(!willOpen){
        if(typeof window.setHomeClientPreviewExpanded==='function'){
          window.setHomeClientPreviewExpanded(false);
        }
        const d=document.getElementById('detail');
        if(d){
          d.classList.add('hidden');
          d.innerHTML='';
          d.dataset.openClientId='';
          const b=document.getElementById('homeClientsBody');
          const l=document.getElementById('list');
          if(b && l && d.parentElement===b) b.appendChild(d);
        }
        window.selected=null;
      }
    }
    fixedToggleHomeClientPanel.__v292Wrapped=true;
    window.toggleHomeClientPanel=fixedToggleHomeClientPanel;
  }

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',applyFix,{once:true});
  }else{
    applyFix();
  }
})();


(function(){
  function syncFecharCliente(){
    const b=document.getElementById('listCloseBtn');
    if(!b)return;
    const txt=(b.textContent||'').trim();
    b.classList.toggle('v308-fechar-cliente', txt==='Fechar Cliente');
  }

  function init(){
    const b=document.getElementById('listCloseBtn');
    if(!b)return;
    syncFecharCliente();
    new MutationObserver(syncFecharCliente).observe(
      b,{childList:true,characterData:true,subtree:true}
    );
  }

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',init);
  }else{
    init();
  }
})();


(function(){
  function syncHomeButtonV309(){
    const body=document.getElementById('homeClientsBody');
    const detail=document.getElementById('detail');
    const btn=document.getElementById('homeClientsOpenCloseBtn');
    if(!body || !detail || !btn)return;

    const detailOpen=!detail.classList.contains('hidden');
    const bodyOpen=!body.classList.contains('hidden');

    btn.classList.toggle('v309-fechar-cliente', detailOpen);

    if(detailOpen){
      btn.textContent='Fechar Cliente';
    }else{
      btn.textContent=bodyOpen ? 'Fechar' : 'Abrir';
    }
  }

  window.handleHomeClientsButtonClickV309=function(){
    const detail=document.getElementById('detail');

    // Se há uma ficha aberta, o botão fecha APENAS a ficha,
    // exatamente como acontece no menu Clientes da V308.
    if(detail && !detail.classList.contains('hidden')){
      clearHomeClientDetail();
      setHomeClientPreviewExpanded(false);
      syncHomeButtonV309();
      return;
    }

    // Sem ficha aberta, mantém o comportamento normal Abrir/Fechar
    // do painel Clientes no Início.
    toggleHomeClientPanel();
    syncHomeButtonV309();
  };

  function initV309(){
    const body=document.getElementById('homeClientsBody');
    const detail=document.getElementById('detail');
    if(!body || !detail)return;

    syncHomeButtonV309();

    new MutationObserver(syncHomeButtonV309).observe(
      body,
      {attributes:true,attributeFilter:['class']}
    );

    new MutationObserver(syncHomeButtonV309).observe(
      detail,
      {attributes:true,attributeFilter:['class'],childList:true,subtree:true}
    );
  }

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',initV309,{once:true});
  }else{
    initV309();
  }
})();

function saveEditedSubscription(){
  const i=window.editingSubscriptionIndex;
  if(i===null || i===undefined)return;

  const s=SUBSCRIPTIONS[i];
  if(!s)return;

  const val=id=>{
    const el=document.getElementById(id);
    return el ? el.value : '';
  };

  const name=String(val('subName')||'').trim();
  const client=String(val('subClient')||'').trim();
  const limit=Math.max(1,parseInt(val('subLimit')||'10',10));

  if(!name){
    alert('Indica o nome da subscrição.');
    return;
  }

  if(limit<subscriptionLinkedCount(s)){
    alert('O novo limite não pode ser inferior aos equipamentos já associados ('+
      subscriptionLinkedCount(s)+').');
    return;
  }

  s.type=String(val('subType')||'').trim();
  s.name=name;
  s.client=client;
  s.limit=limit;
  s.validityType=val('subValidityType')||'purchase';
  s.licenseUsed=Math.max(0,Math.min(parseInt(val('subLicenseUsed')||'0',10),limit));
  s.purchaseDate=val('subPurchaseDate')||'';
  s.startDate=val('subStartDate')||'';
  s.validityMonths=Math.max(0,parseInt(val('subValidityMonths')||'0',10));
  s.endDate=val('subEndDate')||'';
  s.cost=Math.max(0,Number(val('subCost')||'0'));
  s.revenue=Math.max(0,Number(val('subRevenue')||'0'));

  saveSubscriptions();
  renderSubscriptions();

  window.editingSubscriptionIndex=null;

  const panel=document.getElementById('subscriptionCreatePanel');
  const title=document.querySelector('#subscricoes .subscricoes-title-close');
  const addBtn=panel ? panel.querySelector('.actions button') : null;

  if(title) title.innerHTML='🔐 Serviços e subscrições';

  if(addBtn){
    addBtn.textContent='+ Adicionar';
    addBtn.onclick=function(){ addSubscription(); };
  }
  const cancelBtn=document.getElementById('cancelSubscriptionEditBtn');
  if(cancelBtn) cancelBtn.style.display='none';
}


function cancelSubscriptionEdit(){
  window.editingSubscriptionIndex=null;

  const panel=document.getElementById('subscriptionCreatePanel');
  const title=document.querySelector('#subscricoes .subscricoes-title-close');
  const addBtn=panel ? panel.querySelector('.actions button') : null;
  const cancelBtn=document.getElementById('cancelSubscriptionEditBtn');

  if(title) title.innerHTML='🔐 Serviços e subscrições';

  if(addBtn){
    addBtn.textContent='+ Adicionar';
    addBtn.onclick=function(){ addSubscription(); };
  }

  if(cancelBtn) cancelBtn.style.display='none';

  // Clear the editing form so an accidental old value cannot be saved later.
  ['subType','subName','subClient','subLimit','subLicenseUsed','subPurchaseDate','subStartDate',
   'subValidityMonths','subEndDate','subCost','subRevenue'].forEach(id=>{
    const el=document.getElementById(id);
    if(el)el.value='';
  });

  const validity=document.getElementById('subValidityType');
  if(validity)validity.value='';
}



(function(){
  function syncFull(){
    const p=document.getElementById('todosClientes');
    const d=document.getElementById('fullClientDetail');
    const b=document.getElementById('listCloseBtn');
    if(!p||!d||!b)return;
    const detailOpen=!d.classList.contains('hidden');
    const collapsed=p.dataset.listCollapsed==='1';
    if(detailOpen) b.textContent='Fechar Cliente';
    else b.textContent=collapsed?'Abrir':'Fechar';
  }
  function init(){
    const p=document.getElementById('todosClientes');
    const d=document.getElementById('fullClientDetail');
    if(!p||!d)return;
    syncFull();
    new MutationObserver(syncFull).observe(p,{attributes:true,attributeFilter:['data-list-collapsed','class'],subtree:true});
    new MutationObserver(syncFull).observe(d,{attributes:true,attributeFilter:['class'],subtree:false});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});
  else init();
})();


(function(){
  const STATE = window.__AM_V536_CLIENT_CONTEXT = {
    context: 'home',
    home: { mode: 'all', collapsed: false },
    clients: { mode: 'all', collapsed: false }
  };

  function panel(){ return document.getElementById('todosClientes'); }
  function homeLayout(){ return document.querySelector('#clientes .layout'); }
  function shortcuts(){ return document.getElementById('homeShortcuts'); }
  function search(){ return document.getElementById('fullSearch'); }
  function list(){ return document.getElementById('fullClientList'); }
  function title(){ return document.getElementById('listTitle'); }
  function closeButton(){ return document.getElementById('listCloseBtn'); }
  function fullDetail(){ return document.getElementById('fullClientDetail'); }

  function statusTitle(mode){
    return {
      active:'🟢 Clientes ativos',
      warning:'🟠 Clientes a expirar',
      expired:'🔴 Clientes expirados'
    }[mode] || '📋 Clientes';
  }

  function setContext(context){
    STATE.context = context === 'clients' ? 'clients' : 'home';
    window.statusOpenedFromClientMenu = STATE.context === 'clients';
    if(typeof setActiveNav==='function') setActiveNav(STATE.context === 'clients' ? 'clientes' : 'inicio');
  }

  function syncFullMode(context){
    const p=panel();
    if(!p) return;
    const state=STATE[context];
    currentListMode=state.mode || 'all';
    p.classList.toggle('status-title-expired', currentListMode==='expired');
    const t=title();
    if(t) t.textContent=statusTitle(currentListMode);
  }

  function showFullPanel(context, mode){
    const p=panel();
    if(!p) return;
    setContext(context);
    STATE[context].mode=mode || 'all';
    STATE[context].collapsed=false;

    const home=homeLayout();
    const sh=shortcuts();
    if(home) home.classList.add('hidden');
    if(sh) sh.classList.add('hidden');
    clearHomeClientDetail();
    clearFullClientDetail();

    p.classList.remove('hidden');
    p.dataset.listCollapsed='0';
    const fs=search(), fl=list();
    if(fs){ fs.classList.remove('hidden'); fs.value=''; }
    if(fl) fl.classList.remove('hidden');
    syncFullMode(context);
    const cb=closeButton();
    if(cb) cb.textContent='Fechar';
    fullListWasClosedByUser=false;
    renderFullClients();
  }

  function restoreHomeFromStatus(){
    const p=panel();
    const home=homeLayout();
    const sh=shortcuts();
    if(p) p.classList.add('hidden');
    if(home) home.classList.remove('hidden');
    if(sh) sh.classList.remove('hidden');
    clearFullClientDetail();
    currentListMode='all';
    STATE.home.mode='all';
    STATE.home.collapsed=false;
    fullListWasClosedByUser=false;
    setContext('home');
    renderFullClients();
  }

  // Início: passa sempre a marcar explicitamente o seu próprio contexto.
  const originalGoHome=window.goHome;
  window.goHome=function(){
    setContext('home');
    STATE.home.mode='all';
    STATE.home.collapsed=false;
    const result=typeof originalGoHome==='function' ? originalGoHome.apply(this,arguments) : undefined;
    setContext('home');
    return result;
  };

  // Menu Clientes: entra sempre num contexto independente e abre a lista completa.
  window.openClientsNav=function(){
    setContext('clients');
    showFullPanel('clients','all');
  };

  // O título da lista tem exatamente a mesma função do botão azul Abrir/Fechar.
  // Nunca muda de contexto: apenas abre/fecha o painel atual.
  window.toggleFullClients=function(){
    window.closeCurrentListOrClient();
  };

  // Fechar/Abrir da lista completa respeita o contexto atual.
  window.closeCurrentListOrClient=function(){
    const p=panel(), d=fullDetail(), fs=search(), fl=list(), cb=closeButton();
    if(!p || p.classList.contains('hidden')) return;

    if(d && !d.classList.contains('hidden')){
      d.classList.add('hidden');
      d.innerHTML='';
      d.dataset.openClientId='';
      selected=null;
      if(cb) cb.textContent='Fechar';
      setContext(STATE.context);
      return;
    }

    if(p.dataset.listCollapsed==='1'){
      if(STATE.context==='clients'){
        showFullPanel('clients','all');
      }else{
        // Mantém exatamente o contexto Início e reabre apenas a lista que estava lá.
        p.dataset.listCollapsed='0';
        STATE.home.collapsed=false;
        if(fs) fs.classList.remove('hidden');
        if(fl) fl.classList.remove('hidden');
        syncFullMode('home');
        if(cb) cb.textContent='Fechar';
        setContext('home');
        renderFullClients();
      }
      return;
    }

    if(fs) fs.classList.add('hidden');
    if(fl) fl.classList.add('hidden');
    if(d){ d.classList.add('hidden'); d.innerHTML=''; d.dataset.openClientId=''; }
    selected=null;
    p.dataset.listCollapsed='1';
    STATE[STATE.context].collapsed=true;
    if(cb) cb.textContent='Abrir';
    setContext(STATE.context);
  };

  // Cartões verde/laranja/vermelho: cada menu guarda o seu próprio estado.
  window.toggleStatusList=function(mode){
    const p=panel();
    if(!p) return;
    const context=STATE.context==='clients' ? 'clients' : 'home';
    const state=STATE[context];
    const isOpen=!p.classList.contains('hidden');

    // Segundo toque no mesmo cartão: cada contexto regressa ao seu próprio sítio.
    if(isOpen && state.mode===mode && p.dataset.listCollapsed!=='1'){
      if(context==='clients'){
        showFullPanel('clients','all');
      }else{
        restoreHomeFromStatus();
      }
      return;
    }

    state.mode=mode;
    state.collapsed=false;
    showFullPanel(context,mode);
  };

  // Se o utilizador muda de estado sem sair da lista, continua sempre no mesmo contexto.
  // Também elimina qualquer resíduo da antiga variável global da V533/V535.
  setContext('home');
})();


(function(){
  const openClientsNavOriginal=window.openClientsNav;

  window.openClientsNav=function(){
    // Primeiro navegar efetivamente para o menu Clientes, escondendo qualquer
    // outro menu atualmente aberto. Só depois abrimos o contexto próprio de Clientes.
    if(typeof view==='function') view('clientes');

    if(typeof openClientsNavOriginal==='function') return openClientsNavOriginal.apply(this,arguments);
  };
})();


(function(){
  function isClientsContext(){
    const state=window.__AM_V536_CLIENT_CONTEXT;
    return !!(state && state.context==='clients');
  }
  function triggerSameAction(){
    const button=document.getElementById('listCloseBtn');
    if(button){ button.click(); return; }
    if(typeof window.closeCurrentListOrClient==='function') window.closeCurrentListOrClient();
  }
  function bind(){
    const title=document.getElementById('listTitle');
    if(!title || title.dataset.v538Bound==='1') return;
    title.dataset.v538Bound='1';
    title.addEventListener('click',function(ev){
      if(!isClientsContext()) return;
      ev.preventDefault();
      ev.stopImmediatePropagation();
      triggerSameAction();
    },true);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',bind,{once:true});
  else bind();
})();


(function(){
  const SEED_KEY='am_clientes_v657_default_shortcuts_seeded';
  const MIGRATION_KEY='am_clientes_v658_old_shortcuts_restored';
  const defaults=[
    {id:'shortcut_site_1',name:'Site 1',description:'Descrição do site 1',url:'https://example.com/link1'},
    {id:'shortcut_site_2',name:'Site 2',description:'Descrição do site 2',url:'https://example.com/link2'},
    {id:'shortcut_site_3',name:'Site 3',description:'Descrição do site 3',url:'https://example.com/link3'},
    {id:'shortcut_site_4',name:'Site 4',description:'Descrição do site 4',url:'https://example.com/link4'},
    {id:'shortcut_site_5',name:'Site 5',description:'Descrição do site 5',url:'https://example.com/link5'}
  ];

  function isPreviousGenericLinks(arr){
    if(!Array.isArray(arr) || arr.length!==5) return false;
    return arr.every((v,i)=>String(v?.name||'')==='Link '+(i+1));
  }

  function restoreDefaults(){
    if((typeof V167_FRESH_INSTALL!=='undefined' && V167_FRESH_INSTALL) ||
       (typeof v676IsGlobalDatabaseEmpty==='function' && v676IsGlobalDatabaseEmpty())) return false;
    if(!APP_SETTINGS || typeof APP_SETTINGS!=='object') return false;
    if(!Array.isArray(APP_SETTINGS.shortcuts)) APP_SETTINGS.shortcuts=[];

    let migrated=false;
    try{ migrated=localStorage.getItem(MIGRATION_KEY)==='1'; }catch(e){}

    // Recupera o aspeto antigo se os atalhos estiverem vazios ou se ainda forem
    // exatamente os cinco Link 1–5 criados pela versão anterior. Atalhos
    // personalizados não são alterados.
    if(!migrated && (APP_SETTINGS.shortcuts.length===0 || isPreviousGenericLinks(APP_SETTINGS.shortcuts))){
      APP_SETTINGS.shortcuts=defaults.map(v=>({...v}));
      if(typeof window.saveAppSettings==='function') window.saveAppSettings();
      try{
        localStorage.setItem(SEED_KEY,'1');
        localStorage.setItem(MIGRATION_KEY,'1');
      }catch(e){}
      return true;
    }
    return false;
  }

  function refreshShortcuts(){
    restoreDefaults();
    if(typeof window.renderHomeShortcuts==='function') window.renderHomeShortcuts();
  }

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',function(){
      setTimeout(refreshShortcuts,0);
      setTimeout(refreshShortcuts,120);
    },{once:true});
  }else{
    setTimeout(refreshShortcuts,0);
    setTimeout(refreshShortcuts,120);
  }
})();


(function(){
  const v665OriginalLoadConfigLists = loadConfigLists;

  const v665Labels = {
    saldos:'Saldo',
    valores:'Valor',
    empresas:'Empresa',
    servicos:'Serviço',
    pagamentos:'Método de pagamento',
    vpns:'VPN',
    nome_equipamentos:'Marcas dos Equipamentos',
    equipamentos:'Tipo de Equipamentos',
    periodicidades:'Periodicidade',
    metodos_contacto:'Canal de contacto',
    pacotes:'Pacote'
  };

  function v665ActiveCompany(){
    return (typeof v586GetActiveCompany==='function' ? v586GetActiveCompany() : null)
      || {id:'company_1',name:'Empresa 1'};
  }
  function v665CompanyNumber(){
    const active=v665ActiveCompany();
    const m=String(active.name||active.id||'').match(/(\d+)/);
    return m ? Number(m[1]) : 1;
  }
  function v665StorageKey(key){
    const active=v665ActiveCompany();
    return 'amClientesConfig_'+key+'__'+String(active.id||'company_1');
  }
  function v665DefaultList(key){
    const n=v665CompanyNumber();
    const label=v665Labels[key] || key;
    return [1,2,3,4,5].map(i=>label+' '+i+' da Empresa '+n);
  }
  function v665LoadList(key){
    try{
      const raw=localStorage.getItem(v665StorageKey(key));
      const arr=raw?JSON.parse(raw):null;
      if(Array.isArray(arr)) return arr.map(String);
    }catch(e){}
    if(typeof v675IsBaseEmpty==='function' && v675IsBaseEmpty()){
      const empty=[];
      localStorage.setItem(v665StorageKey(key),JSON.stringify(empty));
      return empty;
    }
    const seeded=v665DefaultList(key);
    localStorage.setItem(v665StorageKey(key),JSON.stringify(seeded));
    return seeded;
  }
  function v665SaveList(key,arr){
    localStorage.setItem(v665StorageKey(key),JSON.stringify(Array.isArray(arr)?arr.map(String):[]));
  }
  function v665Keys(){
    return Object.keys(DEFAULT_LISTS);
  }

  window.loadConfigLists=function(){
    v665OriginalLoadConfigLists();
    v665Keys().forEach(key=>{
      CONFIG_LISTS[key]=v665LoadList(key);
    });
  };

  window.saveConfigLists=function(){
    v665Keys().forEach(key=>v665SaveList(key,CONFIG_LISTS[key]));
    try{
      const raw=localStorage.getItem('amClientesConfigLists');
      const saved=raw?JSON.parse(raw):{};
      v665Keys().forEach(key=>delete saved[key]);
      localStorage.setItem('amClientesConfigLists',JSON.stringify(saved));
    }catch(e){}
  };

  function v665RefreshConfigAfterCompanySwitch(){
    try{
      loadConfigLists();
      if(typeof renderSettings==='function') renderSettings();
    }catch(e){
      console.warn('V665: não foi possível atualizar as Configurações',e);
    }
  }

  const v665OriginalSwitchCompany = v586SwitchCompany;
  window.v586SwitchCompany=function(id){
    v665OriginalSwitchCompany(id);
    v665RefreshConfigAfterCompanySwitch();
  };

  if(typeof v589SwitchCompanyFromMenu==='function'){
    const v665OriginalSwitchCompanyFromMenu=v589SwitchCompanyFromMenu;
    window.v589SwitchCompanyFromMenu=function(id){
      v665OriginalSwitchCompanyFromMenu(id);
      v665RefreshConfigAfterCompanySwitch();
    };
  }

  loadConfigLists();
})();


(function(){
  function activeCompanyNumber(){
    try{
      const a=(typeof v586GetActiveCompany==='function' ? v586GetActiveCompany() : null)
        || {id:'company_1',name:'Empresa 1'};
      const m=String(a.name||a.id||'').match(/(\d+)/);
      return m ? String(Number(m[1])) : '1';
    }catch(e){ return '1'; }
  }

  function baseMessageName(k){
    const m=(window.MESSAGE_META&&window.MESSAGE_META[k])||{};
    const fallback={
      renewal:'Renovação',
      expired:'Expirado',
      payment:'Pagamento',
      maintenance:'Manutenção',
      custom:'Personalizada'
    };
    return String(m.name||fallback[k]||k).replace(/\s+[1-5]\s*$/,'').trim();
  }

  function visibleMessageName(k){
    return baseMessageName(k)+' '+activeCompanyNumber();
  }

  // Os botões/modelos no menu de Mensagens passam a mostrar o número da empresa.
  const previousLabel=window.label;
  window.label=function(k){
    const m=(window.MESSAGE_META&&window.MESSAGE_META[k])||{};
    const icon=m.icon || ({renewal:'🔔',expired:'⚠️',payment:'💶',maintenance:'🛠️',custom:'✏️'}[k]||'✉️');
    return icon+' '+visibleMessageName(k);
  };

  // A lista de Configurações também passa a mostrar Renovação 1, Renovação 2, etc.
  const previousRenderMessageSettings=window.renderMessageSettings;
  window.renderMessageSettings=function(){
    const original=previousRenderMessageSettings();
    try{
      const wrap=document.createElement('div');
      wrap.innerHTML=original;
      wrap.querySelectorAll('[data-message-key]').forEach(item=>{
        const k=item.getAttribute('data-message-key');
        const strong=item.querySelector('strong');
        if(strong){
          const m=(window.MESSAGE_META&&window.MESSAGE_META[k])||{};
          const icon=m.icon||'✉️';
          strong.textContent=icon+' '+visibleMessageName(k);
        }
      });
      return wrap.innerHTML;
    }catch(e){
      return original;
    }
  };

  // Ao editar, a janela também mostra o número da empresa para permitir testar a base ativa.
  window.editMessageTemplate=function(k){
    if(!templates[k])return;
    const m=(window.MESSAGE_META&&window.MESSAGE_META[k])||{name:k,icon:'✉️'};
    const displayedName=visibleMessageName(k);
    const name=prompt('Assunto:',displayedName);
    if(name===null)return;
    const icon=prompt('Ícone:',m.icon||'✉️');
    if(icon===null)return;
    const text=prompt('Texto da mensagem:',String(templates[k]||'').replaceAll('[AGORA]',typeof greeting==='function'?greeting():'[AGORA]'));
    if(text===null)return;
    const before=typeof snapshotState==='function'?snapshotState():null;
    const suffix=new RegExp('\\s+'+activeCompanyNumber()+'\\s*$');
    const storedName=String(name).replace(suffix,'').trim() || baseMessageName(k);
    window.MESSAGE_META=window.MESSAGE_META||{};
    window.MESSAGE_META[k]={name:storedName,icon:String(icon).trim()||'✉️'};
    templates[k]=(typeof normalizeForStorage==='function'?normalizeForStorage(text):text);
    if(typeof saveMeta==='function') saveMeta();
    try{ localStorage.setItem('amTemplates',JSON.stringify(templates)); }catch(e){}
    if(typeof recordAction==='function') recordAction('Mensagem alterada','Mensagem alterada: '+visibleMessageName(k),before,typeof snapshotState==='function'?snapshotState():null);
    if(typeof renderSettings==='function') renderSettings();
    if(typeof setupTabs==='function') setupTabs();
  };

  // Reforço: redesenha agora e após a troca de empresa, depois de os scripts antigos terminarem.
  function refreshMessageLabels(){
    try{ if(typeof setupTabs==='function') setupTabs(); }catch(e){}
    try{ if(typeof renderSettings==='function') renderSettings(); }catch(e){}
  }
  setTimeout(refreshMessageLabels,0);
  setTimeout(refreshMessageLabels,150);

  const oldSwitch=window.v586SwitchCompany;
  if(typeof oldSwitch==='function'){
    window.v586SwitchCompany=function(id){
      const result=oldSwitch.apply(this,arguments);
      setTimeout(refreshMessageLabels,0);
      setTimeout(refreshMessageLabels,50);
      return result;
    };
  }
  const oldMenuSwitch=window.v589SwitchCompanyFromMenu;
  if(typeof oldMenuSwitch==='function'){
    window.v589SwitchCompanyFromMenu=function(id){
      const result=oldMenuSwitch.apply(this,arguments);
      setTimeout(refreshMessageLabels,0);
      setTimeout(refreshMessageLabels,50);
      return result;
    };
  }
})();


/* V674 — Renovação do cliente com consumo real de uma licença da subscrição. */
(function(){
  if(document.getElementById('v674RenewStyle')) return;
  const style=document.createElement('style');
  style.id='v674RenewStyle';
  style.textContent=`
    .v674-renew-btn{display:inline-flex;align-items:center;justify-content:center;gap:7px}
    .v674-modal{position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.66);display:grid;place-items:center;padding:16px}
    .v674-modal.hidden{display:none}
    .v674-box{width:min(520px,100%);background:#071127;border:1px solid var(--line);border-radius:18px;padding:18px;box-shadow:0 18px 50px #0008}
    .v674-box h3{margin:0 0 14px}
    .v674-box .field{margin-bottom:12px}
    .v674-box .actions{justify-content:flex-end;margin-top:16px}
  `;
  document.head.appendChild(style);

  function v674ISO(d){
    const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');
    return y+'-'+m+'-'+day;
  }
  function v674NormalizeISO(value){
    const raw=String(value||'').trim();
    if(!raw)return '';
    let m=raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if(m){
      const d=new Date(Number(m[1]),Number(m[2])-1,Number(m[3]));
      return d.getFullYear()===Number(m[1])&&d.getMonth()===Number(m[2])-1&&d.getDate()===Number(m[3])?raw:'';
    }
    m=raw.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if(m){
      const d=new Date(Number(m[3]),Number(m[2])-1,Number(m[1]));
      return d.getFullYear()===Number(m[3])&&d.getMonth()===Number(m[2])-1&&d.getDate()===Number(m[1])?v674ISO(d):'';
    }
    const d=new Date(raw);
    return Number.isNaN(d.getTime())?'':v674ISO(d);
  }
  function v674Months(period){
    const p=String(period||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    // Reconhece a palavra-base completa, mesmo com identificação adicional: "Mensal 1", "Bimensal Empresa 2", etc.
    if(/\bbimensal\b/.test(p)) return 2;
    if(/\btrimestral\b/.test(p)) return 3;
    if(/\bquadrimestral\b/.test(p)) return 4;
    if(/\bsemestral\b/.test(p)) return 6;
    if(/\banual\b/.test(p)||/\bano\b/.test(p)) return 12;
    if(/\bmensal\b/.test(p)) return 1;
    const n=parseInt(p.match(/\d+/)?.[0]||'',10);
    return Number.isFinite(n)&&n>0?n:1;
  }
  function v674AddMonths(start,months){
    const iso=v674NormalizeISO(start);
    if(!iso)return '';
    const [y,m,d]=iso.split('-').map(Number);
    const total=(m-1)+Math.max(1,Number(months)||1);
    const targetY=y+Math.floor(total/12);
    const targetM=(total%12)+1;
    const last=new Date(targetY,targetM,0).getDate();
    return v674ISO(new Date(targetY,targetM-1,Math.min(d,last)));
  }
  function v674ClientSubscriptionNames(c){
    const set=new Set();
    const add=v=>{v=String(v||'').trim();if(v)set.add(v)};
    add(c?.['Subscrição']);
    (Array.isArray(c?.equipamentos)?c.equipamentos:[]).forEach(e=>{
      add(e?.subscricao);
      (Array.isArray(e?.vpns)?e.vpns:[]).forEach(v=>add(v?.subscricao));
    });
    return [...set];
  }
  function v674GetTargetEquipment(c,subName){
    const eqs=Array.isArray(c?.equipamentos)?c.equipamentos:[];
    return eqs.find(e=>String(e?.subscricao||'').trim()===subName || (Array.isArray(e?.vpns)&&e.vpns.some(v=>String(v?.subscricao||'').trim()===subName))) || eqs[0] || null;
  }
  function v674RenewBaseDate(c,subName){
    const eq=v674GetTargetEquipment(c,subName);
    return v674NormalizeISO(eq?.validade||c?.['Validade']||'') || v674ISO(new Date());
  }
  function v674CloseModal(){document.getElementById('v674RenewModal')?.remove()}
  function v674OpenRenewModal(id){
    const c=DATA.find(x=>String(x['ID Cliente'])===String(id));
    if(!c)return;
    const names=v674ClientSubscriptionNames(c);
    if(!names.length){alert('Este cliente não tem nenhuma subscrição associada para renovar.');return;}
    const periodicities=(Array.isArray(CONFIG_LISTS?.periodicidades)?CONFIG_LISTS.periodicidades:[]).map(v=>String(v||'').trim()).filter(Boolean);
    const defaultEq=v674GetTargetEquipment(c,names[0]);
    const currentPeriod=String(defaultEq?.periodicidade||c['Periodicidade']||'').trim();
    const currentRenewBase=v674RenewBaseDate(c,names[0]);
    const options=[...new Set([currentPeriod,...periodicities].filter(Boolean))];
    const modal=document.createElement('div');
    modal.id='v674RenewModal';modal.className='v674-modal';
    modal.innerHTML=`<div class="v674-box" onclick="event.stopPropagation()">
      <h3>🔄 Renovar cliente</h3>
      <div class="muted" style="margin-bottom:14px">${String(c['Nome']||'Cliente')}</div>
      <div class="field"><label>Subscrição</label><select id="v674RenewSub" class="select">${names.map(n=>`<option value="${String(n).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;')}">${String(n).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</option>`).join('')}</select></div>
      <div class="field"><label>Periodicidade</label><select id="v674RenewPeriod" class="select">${options.map(p=>`<option value="${String(p).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;')}">${String(p).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</option>`).join('')}<option value="__custom__">✏️ Outra...</option></select></div>
      <div class="field" id="v674CustomPeriodWrap" style="display:none"><label>Escrever periodicidade</label><input id="v674CustomPeriod" type="text" placeholder="Ex.: Mensal"></div>
      <div class="field"><label>Meses de renovação</label><input id="v674RenewMonths" type="number" min="1" step="1" value="${v674Months(currentPeriod)}"></div>
      <div class="field"><label>Data da renovação</label><input id="v674RenewDate" type="date" value="${currentRenewBase}"></div>
      <div class="actions"><button type="button" id="v674CancelRenew">Cancelar</button><button type="button" class="primary" id="v674ConfirmRenew">🔄 Renovar</button></div>
    </div>`;
    modal.addEventListener('click',v674CloseModal);
    document.body.appendChild(modal);
    const subSelect=document.getElementById('v674RenewSub');
    const period=document.getElementById('v674RenewPeriod');
    const months=document.getElementById('v674RenewMonths');
    const renewDate=document.getElementById('v674RenewDate');
    subSelect.onchange=function(){
      const subName=String(this.value||'').trim();
      const eq=v674GetTargetEquipment(c,subName);
      renewDate.value=v674RenewBaseDate(c,subName);
      const p=String(eq?.periodicidade||c['Periodicidade']||'').trim();
      if(p && [...period.options].some(o=>o.value===p)){
        period.value=p;
        months.value=String(v674Months(p));
      }
    };
    period.onchange=function(){
      const custom=this.value==='__custom__';
      document.getElementById('v674CustomPeriodWrap').style.display=custom?'block':'none';
      if(!custom) months.value=String(v674Months(this.value));
    };
    document.getElementById('v674CustomPeriod').oninput=function(){months.value=String(v674Months(this.value));};
    document.getElementById('v674CancelRenew').onclick=v674CloseModal;
    document.getElementById('v674ConfirmRenew').onclick=function(){
      const subName=String(document.getElementById('v674RenewSub').value||'').trim();
      let periodicidade=String(period.value||'').trim();
      if(periodicidade==='__custom__') periodicidade=String(document.getElementById('v674CustomPeriod').value||'').trim();
      if(!periodicidade){alert('Seleciona ou escreve a periodicidade.');return;}
      const quantity=1;
      const date=v674NormalizeISO(document.getElementById('v674RenewDate').value)||v674RenewBaseDate(c,subName);
      const monthsValue=Math.max(1,parseInt(document.getElementById('v674RenewMonths').value||String(v674Months(periodicidade)),10)||1);
      const sub=SUBSCRIPTIONS.find(s=>String(s?.name||'').trim()===subName);
      if(!sub){alert('A subscrição selecionada já não existe.');return;}
      const summary=subMovementSummary(sub);
      if(summary.available<quantity){alert('Não tens licenças suficientes disponíveis. Disponíveis: '+summary.available+'.');return;}
      const before=typeof snapshotState==='function'?snapshotState():null;
      const endDate=v674AddMonths(date,monthsValue);
      if(!Array.isArray(sub.movements))sub.movements=[];
      sub.movements.push({type:'renewal',quantity,date,cost:0,client:String(c['Nome']||''),months:monthsValue,startDate:date,endDate});
      const eq=v674GetTargetEquipment(c,subName);
      if(eq){
        eq.periodicidade=periodicidade;
        eq.dataPagamento=v674ISO(new Date());
        eq.validade=endDate;
      }
      // Compatibilidade com os campos apresentados na ficha do cliente.
      const eqs=Array.isArray(c.equipamentos)?c.equipamentos:[];
      if(!eqs.length || eq===eqs[0]){
        c['Periodicidade']=periodicidade;
        c['Pagamento']=v674ISO(new Date());
        c['Validade']=endDate;
      }
      saveSubscriptions();
      if(typeof saveDB==='function') saveDB();
      if(typeof recordAction==='function') recordAction('Cliente renovado','Renovação de '+String(c['Nome']||'Cliente')+' · '+subName+' · 1 licença',before,typeof snapshotState==='function'?snapshotState():null);
      if(typeof renderSubscriptions==='function') renderSubscriptions();
      v674CloseModal();
      if(typeof selectClient==='function') selectClient(id);
      alert('Renovação registada com sucesso. Foi consumida 1 licença da subscrição "'+subName+'".');
    };
  }

  // Consumo correto: as ligações existentes contam como ativações iniciais e
  // cada renovação consome mais uma licença, sem deixar de somar compras futuras.
  const previousSummary=window.subMovementSummary;
  window.subMovementSummary=function(s){
    const movements=Array.isArray(s?.movements)?s.movements:[];
    if(!movements.length) return previousSummary(s);
    const purchased=movements.filter(m=>m.type==='purchase').reduce((n,m)=>n+Math.max(0,Number(m.quantity)||0),0);
    const activationMovements=movements.filter(m=>m.type==='activation').reduce((n,m)=>n+Math.max(0,Number(m.quantity)||0),0);
    const renewalConsumed=movements.filter(m=>m.type==='renewal').reduce((n,m)=>n+Math.max(0,Number(m.quantity)||0),0);
    const linked=typeof subscriptionLinkedCount==='function'?Math.max(0,Number(subscriptionLinkedCount(s))||0):0;
    const baseConsumed=Math.max(linked,activationMovements);
    const consumed=baseConsumed+renewalConsumed;
    const purchaseCost=movements.filter(m=>m.type==='purchase').reduce((n,m)=>n+Math.max(0,Number(m.cost)||0),0);
    return {purchased,consumed,available:Math.max(0,purchased-consumed),purchaseCost};
  };

  const previousSelectClient=window.selectClient;
  window.selectClient=function(id){
    const result=previousSelectClient.apply(this,arguments);
    try{
      const inFullList=!document.getElementById('todosClientes')?.classList.contains('hidden');
      const target=inFullList?document.getElementById('fullClientDetail'):document.getElementById('detail');
      const c=DATA.find(x=>String(x['ID Cliente'])===String(id));
      if(!target||!c)return result;
      const actions=target.querySelector('.client-vpn-actions');
      if(actions && !actions.querySelector('.v674-renew-btn')){
        const btn=document.createElement('button');
        btn.type='button';btn.className='primary v674-renew-btn';btn.innerHTML='🔄 Renovar';
        btn.onclick=function(ev){ev.stopPropagation();v674OpenRenewModal(id)};
        actions.insertBefore(btn,actions.querySelector('button:nth-child(2)')||null);
      }
    }catch(e){console.error('Erro ao preparar renovação:',e)}
    return result;
  };
  window.renewClientSubscription=v674OpenRenewModal;
})();


(function(){
  function cleanText(v){ return String(v??'').trim(); }
  function uniquePush(list, seen, value){
    const v=cleanText(value);
    if(!v) return;
    const key=v.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    if(seen.has(key)) return;
    seen.add(key); list.push(v);
  }

  /* SERVIÇOS — a V666 passou o catálogo a ser gravado por empresa. A função
     original de adicionar ainda gravava na chave global, por isso o serviço
     desaparecia logo a seguir ao renderizar. Agora usa sempre o persistidor
     ativo, que grava na empresa correta e sincroniza Configurações. */
  window.v117AddCatalogService=function(){
    const nameEl=document.getElementById('v117ServiceName');
    const valueEl=document.getElementById('v117ServiceValue');
    const name=cleanText(nameEl?.value);
    const value=Number(String(valueEl?.value||'').replace(',','.'))||0;

    if(!name){
      alert('Indica o nome do serviço.');
      nameEl?.focus();
      return;
    }

    if(typeof window.v117LoadCatalog==='function') window.v117LoadCatalog();
    if(!Array.isArray(window.v117ServiceCatalog)) window.v117ServiceCatalog=[];

    const duplicate=window.v117ServiceCatalog.some(s=>
      cleanText(s?.name).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()===
      name.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()
    );
    if(duplicate){
      alert('Já existe um serviço com esse nome. Podes alterar o valor diretamente na lista.');
      return;
    }

    window.v117ServiceCatalog.push({
      id:'svc_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),
      name:name,
      value:value
    });

    if(typeof window.v117PersistCatalog==='function') window.v117PersistCatalog();
    else {
      localStorage.setItem('am_v117_service_catalog',JSON.stringify(window.v117ServiceCatalog));
      if(!Array.isArray(window.CONFIG_LISTS?.servicos)) window.CONFIG_LISTS.servicos=[];
      window.CONFIG_LISTS.servicos=window.v117ServiceCatalog.map(s=>cleanText(s.name)).filter(Boolean);
      if(typeof window.saveConfigLists==='function') window.saveConfigLists();
    }

    if(nameEl) nameEl.value='';
    if(valueEl) valueEl.value='';
    if(typeof window.v117RenderCatalog==='function') window.v117RenderCatalog();
  };

  /* EQUIPAMENTOS — os menus do cliente devem mostrar tanto o que foi criado
     diretamente em Configurações como os equipamentos existentes no Catálogo. */
  window.v231EquipmentCatalogOptions=function(kind,current){
    const values=[];
    const seen=new Set();
    const configKey=kind==='tipo'?'equipamentos':null;

    const configured=(configKey && window.CONFIG_LISTS && Array.isArray(window.CONFIG_LISTS[configKey]))
      ? window.CONFIG_LISTS[configKey] : [];
    configured.forEach(v=>uniquePush(values,seen,v));

    let rows=[];
    try{ rows=typeof window.getCatalog==='function' ? window.getCatalog('equipamentos') : []; }catch(_){ rows=[]; }
    if(Array.isArray(rows)) rows.forEach(e=>{
      uniquePush(values,seen,kind==='tipo'?(e?.tipo||''):(e?.nome||''));
    });

    uniquePush(values,seen,current);
    return values;
  };

  /* Sempre que se adiciona uma opção nas Configurações, guarda primeiro e
     deixa os formulários lerem a mesma lista atualizada, sem obrigar a fechar
     ou recarregar a aplicação. */
  const previousAddConfig=window.addConfig;
  if(typeof previousAddConfig==='function' && !previousAddConfig.__v689Wrapped){
    window.addConfig=function(key){
      const result=previousAddConfig.apply(this,arguments);
      if(['empresas','equipamentos','nome_equipamentos','pagamentos','periodicidades','vpns','pacotes'].includes(String(key))){
        if(typeof window.saveConfigLists==='function') window.saveConfigLists();
      }
      return result;
    };
    window.addConfig.__v689Wrapped=true;
  }
})();


(function(){
  function clean(v){return String(v==null?'':v).trim();}
  function norm(v){return clean(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();}
  function unique(values,value){
    const text=clean(value);
    if(!text||values.some(v=>norm(v)===norm(text)))return;
    values.push(text);
  }
  function activeCompanyId(){
    try{if(typeof APP_SETTINGS!=='undefined'&&APP_SETTINGS?.activeCompanyId)return String(APP_SETTINGS.activeCompanyId);}catch(_){ }
    return 'company_1';
  }
  function companyList(key){
    const values=[];
    try{
      const raw=localStorage.getItem('amClientesConfig_'+key+'__'+activeCompanyId());
      const parsed=raw?JSON.parse(raw):null;
      if(Array.isArray(parsed))parsed.forEach(v=>unique(values,v));
    }catch(_){ }
    try{
      if(!values.length&&typeof CONFIG_LISTS!=='undefined'&&Array.isArray(CONFIG_LISTS[key]))CONFIG_LISTS[key].forEach(v=>unique(values,v));
    }catch(_){ }
    return values;
  }
  function replaceOptions(select,values,current){
    if(!select)return;
    const selected=clean(current);
    const custom=Array.from(select.options).find(o=>o.value==='__custom__');
    select.innerHTML='';
    const empty=document.createElement('option'); empty.value=''; empty.textContent='Selecionar'; select.appendChild(empty);
    values.forEach(value=>{
      const option=document.createElement('option'); option.value=value; option.textContent=value;
      if(norm(value)===norm(selected))option.selected=true;
      select.appendChild(option);
    });
    const other=document.createElement('option'); other.value='__custom__'; other.textContent=custom?.textContent||'✏️ Outro...'; select.appendChild(other);
    if(selected&&!values.some(v=>norm(v)===norm(selected))){
      const option=document.createElement('option'); option.value=selected; option.textContent=selected; option.selected=true; select.insertBefore(option,other);
    }
  }
  function refresh(){
    document.querySelectorAll('#v117EquipmentBox .v118-eq-card').forEach((card,index)=>{
      const eq=(Array.isArray(window.v117EditorEquipments)?window.v117EditorEquipments[index]:null)||{};
      card.querySelectorAll('.field').forEach(field=>{
        const label=clean(field.querySelector('label')?.textContent);
        const select=field.querySelector('select');
        if(label==='Tipo de Equipamento'){
          replaceOptions(select,companyList('equipamentos'),eq.tipo);
          if(select?.options?.[0]) select.options[0].textContent='Selecionar tipo de equipamento';
        }else if(label==='Marca do Equipamento'){
          replaceOptions(select,companyList('nome_equipamentos'),eq.marca);
          if(select?.options?.[0]) select.options[0].textContent='Selecionar marca do equipamento';
        }
      });
    });
  }
  const oldRender=window.v117RenderEquipments;
  if(typeof oldRender==='function'&&!oldRender.__v711BrandType){
    window.v117RenderEquipments=function(){const r=oldRender.apply(this,arguments);refresh();return r;};
    window.v117RenderEquipments.__v711BrandType=true;
  }
  const oldAddConfig=window.addConfig;
  if(typeof oldAddConfig==='function'&&!oldAddConfig.__v711BrandType){
    window.addConfig=function(key){const r=oldAddConfig.apply(this,arguments);if(key==='equipamentos'||key==='nome_equipamentos')refresh();return r;};
    window.addConfig.__v711BrandType=true;
  }
  window.v711RefreshEquipmentBrandType=refresh;
  setTimeout(refresh,0);
})();


/*
 V732 — Mensagens: edição inline, igual aos restantes menus de Configurações.
 O lápis coloca Nome, Ícone e Mensagem nos campos superiores.
 Não são usados prompts nem alertas nativos para editar/guardar.
*/
(function(){
  if(window.__v732MessageInlineEditInstalled) return;
  window.__v732MessageInlineEditInstalled=true;

  window.v732EditingMessageKey=null;

  function capture(){
    try{
      return typeof v586CaptureSettingsSections==='function'
        ? v586CaptureSettingsSections() : {};
    }catch(e){ return {}; }
  }

  function restore(state){
    try{
      if(typeof v586RestoreSettingsSections==='function') v586RestoreSettingsSections(state||{});
    }catch(e){}
  }

  function keepPosition(fn, key){
    const state=capture();
    state.messages=true;
    const y=window.scrollY||document.documentElement.scrollTop||0;
    fn();
    restore(state);
    requestAnimationFrame(()=>{
      window.scrollTo({top:y,behavior:'auto'});
      const first=document.getElementById('newMessageName');
      if(first){
        first.focus();
        if(key && window.v732EditingMessageKey) first.select();
      }
    });
  }

  function messageKeys(){
    return Object.keys(window.templates||templates||{});
  }

  function metaFor(k){
    const meta=(window.MESSAGE_META||{})[k];
    return meta||{name:k,icon:'✉️'};
  }

  function normalizeText(value){
    try{
      return typeof normalizeForStorage==='function'
        ? normalizeForStorage(value)
        : String(value??'');
    }catch(e){ return String(value??''); }
  }

  function saveMessages(){
    try{
      if(typeof window.v666SaveMessages==='function') window.v666SaveMessages();
      else localStorage.setItem('amTemplates',JSON.stringify(templates||{}));
    }catch(e){
      try{ localStorage.setItem('amTemplates',JSON.stringify(templates||{})); }catch(_){}
    }
  }

  function renderMessagesCard(){
    const existing=messageKeys();
    const editing=window.v732EditingMessageKey;
    const isEditing=editing!==null && editing!==undefined && Object.prototype.hasOwnProperty.call(templates||{},editing);
    const m=isEditing ? metaFor(editing) : {name:'',icon:'✉️'};
    const text=isEditing ? String(templates[editing]||'') : '';

    const list=existing.map(k=>{
      const mm=metaFor(k);
      return `<div class="client v112-sort-item" data-id="${esc(k)}" data-message-key="${esc(k)}">
        <span class="v112-handle" title="Arrastar para ordenar">☷</span>
        <div style="min-width:0;flex:1">
          <strong>${esc(mm.icon||'✉️')} ${esc(mm.name||k)}</strong>
          <small>${esc(String(templates[k]||'').split('\n').find(x=>x.trim())||'Sem texto')}</small>
        </div>
        <div class="actions">
          <button type="button" onclick="editMessageTemplate('${esc(k)}')">✏️</button>
          <button type="button" onclick="deleteMessageTemplate('${esc(k)}')">🗑️</button>
        </div>
      </div>`;
    }).join('');

    return `<div class="card v577-collapsed v628-settings-card" data-v628-section="messages" style="margin-bottom:12px">
      <h3><span class="v628-settings-handle" title="Arrastar para ordenar" aria-label="Arrastar para ordenar">☷</span><span class="v628-settings-label">💬 Mensagens</span></h3>
      <div class="row">
        <div class="field"><label>Nome da mensagem</label><input id="newMessageName" placeholder="Ex.: Assunto da mensagem" value="${esc(m.name||'')}"></div>
        <div class="field"><label>Ícone</label><input id="newMessageIcon" placeholder="Ex.: 📘" maxlength="4" value="${esc(m.icon||'')}"></div>
      </div>
      <div class="field" style="margin-top:8px">
        <label>Mensagem</label>
        <textarea id="newMessageText" class="message template" placeholder="Ex.: Escreve aqui a mensagem...">${esc(text)}</textarea>
      </div>
      <div class="actions" style="margin-top:8px">
        <button class="primary" type="button" onclick="${isEditing?`saveMessageEdit('${esc(editing)}')`:`addMessageTemplate()`}">${isEditing?'💾 Guardar alterações':'＋ Adicionar mensagem'}</button>
        ${isEditing?'<button type="button" onclick="cancelMessageEdit()">Cancelar</button>':''}
      </div>
      <div class="config-items message-config-list" style="margin-top:18px">${list}</div>
    </div>`;
  }

  window.renderMessageSettings=renderMessagesCard;

  window.editMessageTemplate=function(k){
    if(!templates || !Object.prototype.hasOwnProperty.call(templates,k)) return;
    window.v732EditingMessageKey=String(k);
    keepPosition(()=>{ if(typeof renderSettings==='function') renderSettings(); },k);
  };

  window.cancelMessageEdit=function(){
    window.v732EditingMessageKey=null;
    keepPosition(()=>{ if(typeof renderSettings==='function') renderSettings(); });
  };

  window.saveMessageEdit=function(k){
    if(!templates || !Object.prototype.hasOwnProperty.call(templates,k)) return;

    const name=(document.getElementById('newMessageName')?.value||'').trim();
    const icon=(document.getElementById('newMessageIcon')?.value||'✉️').trim()||'✉️';
    const text=document.getElementById('newMessageText')?.value||'';

    if(!name){
      showAppAlert('Aviso','Preenche o nome da mensagem antes de guardar.');
      document.getElementById('newMessageName')?.focus();
      return;
    }
    if(!text.trim()){
      showAppAlert('Aviso','Preenche a mensagem antes de guardar.');
      document.getElementById('newMessageText')?.focus();
      return;
    }

    const before=typeof snapshotState==='function'?snapshotState():null;
    MESSAGE_META=MESSAGE_META||{};
    MESSAGE_META[k]={name,icon};
    templates[k]=normalizeText(text);
    try{ if(typeof saveMeta==='function') saveMeta(); }catch(e){}
    saveMessages();

    if(typeof recordAction==='function'){
      recordAction('Mensagem alterada','Mensagem alterada: '+name,before,
        typeof snapshotState==='function'?snapshotState():null);
    }

    window.v732EditingMessageKey=null;
    keepPosition(()=>{
      if(typeof renderSettings==='function') renderSettings();
      if(typeof setupTabs==='function') setupTabs();
    });
  };

  // Também elimina os alerts nativos ao criar uma mensagem.
  const oldAdd=window.addMessageTemplate;
  window.addMessageTemplate=function(){
    const name=(document.getElementById('newMessageName')?.value||'').trim();
    const text=(document.getElementById('newMessageText')?.value||'').trim();

    if(!name){
      showAppAlert('Aviso','Preenche o nome da mensagem antes de adicionar.');
      document.getElementById('newMessageName')?.focus();
      return;
    }
    if(!text){
      showAppAlert('Aviso','Preenche a mensagem antes de adicionar.');
      document.getElementById('newMessageText')?.focus();
      return;
    }

    // Se por alguma razão a função original não estiver disponível, criar aqui.
    if(typeof oldAdd!=='function'){
      const icon=(document.getElementById('newMessageIcon')?.value||'✉️').trim()||'✉️';
      const before=typeof snapshotState==='function'?snapshotState():null;
      let key='msg_'+Date.now().toString(36);
      while(templates[key]) key+='x';
      templates[key]=normalizeText(document.getElementById('newMessageText')?.value||'');
      MESSAGE_META=MESSAGE_META||{};
      MESSAGE_META[key]={name,icon};
      try{ if(typeof saveMeta==='function') saveMeta(); }catch(e){}
      saveMessages();
      if(typeof recordAction==='function') recordAction('Mensagem adicionada','Nova mensagem: '+name,before,snapshotState());
      keepPosition(()=>{ if(typeof renderSettings==='function') renderSettings(); });
      return;
    }

    oldAdd();
  };
})();


/* V742 — Subscrições: adicionar usa o mesmo formulário visual da edição.
   O formulário abre vazio, Guardar fecha o painel e Cancelar fecha o painel
   sem deixar os dados da edição anterior. */
(function(){
  function el(id){return document.getElementById(id);}
  function clearForm(){
    ['subType','subName','subClient','subLimit','subLicenseUsed','subPurchaseDate','subStartDate','subEndDate','subCost','subRevenue'].forEach(id=>{
      const e=el(id); if(e)e.value='';
    });
    const validity=el('subValidityType'); if(validity)validity.value='';
    if(typeof window.v683RenderSubscriptionPeriods==='function') window.v683RenderSubscriptionPeriods('');
    else { const p=el('subValidityPeriod'); if(p)p.value=''; }
  }
  function setCreateMode(){
    window.editingSubscriptionIndex=null;
    clearForm();
    const panel=el('subscriptionCreatePanel');
    const title=document.querySelector('#subscricoes .subscricoes-title-close');
    const toggle=el('subscriptionCreateToggleBtn');
    const addBtn=panel ? panel.querySelector('.actions button') : null;
    const cancelBtn=el('cancelSubscriptionEditBtn');
    if(title) title.innerHTML='🔐 Serviços e subscrições';
    if(toggle) toggle.textContent='Fechar';
    if(panel) panel.classList.remove('v146-inner-collapsed');
    if(panel) panel.classList.remove('hidden');
    if(addBtn){
      addBtn.textContent='💾 Guardar';
      addBtn.onclick=function(){ window.saveNewSubscription(); };
    }
    if(cancelBtn) cancelBtn.style.display='inline-block';
  }
  function closeEditor(){
    const panel=el('subscriptionCreatePanel');
    const title=document.querySelector('#subscricoes .subscricoes-title-close');
    const toggle=el('subscriptionCreateToggleBtn');
    const addBtn=panel ? panel.querySelector('.actions button') : null;
    const cancelBtn=el('cancelSubscriptionEditBtn');
    window.editingSubscriptionIndex=null;
    clearForm();
    if(panel){
      panel.classList.remove('hidden');
      panel.classList.add('v146-inner-collapsed');
    }
    if(toggle) toggle.textContent='Fechar';
    if(title) title.innerHTML='🔐 Serviços e subscrições';
    if(addBtn){
      addBtn.textContent='+ Adicionar';
      addBtn.onclick=function(){ window.setSubscriptionCreateMode(); };
    }
    if(cancelBtn) cancelBtn.style.display='none';
  }

  window.setSubscriptionCreateMode=setCreateMode;
  window.cancelSubscriptionEdit=closeEditor;

  window.toggleSubscriptionCreatePanel=function(){
    const panel=el('subscriptionCreatePanel');
    if(!panel)return;
    const isOpen=!panel.classList.contains('hidden');
    if(isOpen){ closeEditor(); return; }
    setCreateMode();
    panel.classList.remove('hidden');
    requestAnimationFrame(()=>panel.scrollIntoView({behavior:'smooth',block:'start'}));
  };

  window.saveNewSubscription=function(){
    const type=(el('subType')?.value||'').trim();
    const name=(el('subName')?.value||'').trim();
    const client=(el('subClient')?.value||'').trim();
    const limit=Math.max(1,parseInt(el('subLimit')?.value||'1',10));
    const validityType=el('subValidityType')?.value||'purchase';
    const licenseUsed=Math.max(0,Math.min(parseInt(el('subLicenseUsed')?.value||'0',10),limit));
    const purchaseDate=el('subPurchaseDate')?.value||'';
    const startDate=el('subStartDate')?.value||'';
    const period=el('subValidityPeriod')?.value||'';
    const manual=period==='__date__';
    const validityMonths=manual?0:(typeof window.v683PeriodMonths==='function'?window.v683PeriodMonths(period):0);
    const manualEnd=manual?(el('subEndDate')?.value||''):'';
    const endDate=manualEnd||(typeof window.v683CalculatedEndDate==='function'?window.v683CalculatedEndDate(validityType,purchaseDate,startDate,validityMonths):'');
    const cost=Math.max(0,Number(el('subCost')?.value||'0'));
    const revenue=Math.max(0,Number(el('subRevenue')?.value||'0'));

    if(!name){
      if(typeof showAppAlert==='function') showAppAlert('Aviso','Preenche os campos antes de adicionar.');
      else alert('Preenche os campos antes de adicionar.');
      return;
    }
    if(!period){
      if(typeof showAppAlert==='function') showAppAlert('Aviso','Preenche os campos antes de adicionar.');
      else alert('Preenche os campos antes de adicionar.');
      return;
    }
    if(manual && !manualEnd){
      if(typeof showAppAlert==='function') showAppAlert('Aviso','Preenche os campos antes de adicionar.');
      else alert('Preenche os campos antes de adicionar.');
      return;
    }

    const initialMovementDate=String(purchaseDate||new Date().toISOString().slice(0,10));
    const initialMovement={type:'purchase',quantity:limit,date:initialMovementDate,cost,client:'',months:0,startDate:'',endDate:'',initial:true};
    SUBSCRIPTIONS.push({id:'SUB-'+Date.now(),type,name,client,limit,validityType,licenseUsed,purchaseDate,startDate,validityMonths,endDate,cost,revenue,movements:[initialMovement],initialPurchaseRecorded:true,devices:[],v683Period:period});
    saveSubscriptions();
    renderSubscriptions();
    closeEditor();
  };

  /* Depois de editar e guardar, regressa à lista tal como ao cancelar. */
  const originalSaveEdited=window.saveEditedSubscription;
  window.saveEditedSubscription=function(){
    if(typeof originalSaveEdited==='function') originalSaveEdited();
    if(window.editingSubscriptionIndex===null || window.editingSubscriptionIndex===undefined) closeEditor();
  };
})();


/* V88 — manter a criação de subscrições disponível e o título principal estável. */
(function(){
  const originalSetCreateMode=window.setSubscriptionCreateMode;
  window.toggleSubscriptionCreatePanel=function(){
    const panel=document.getElementById('subscriptionCreatePanel');
    const btn=document.getElementById('subscriptionCreateToggleBtn');
    const title=document.querySelector('#subscricoes .subscricoes-title-close');
    if(!panel)return;
    const opening=panel.classList.contains('hidden');
    if(opening){
      if(typeof originalSetCreateMode==='function') originalSetCreateMode();
      panel.classList.remove('hidden');
      if(btn) btn.textContent='Fechar';
      if(title) title.innerHTML='🔐 Serviços e subscrições';
    }else{
      panel.classList.add('hidden');
      if(btn) btn.textContent='Abrir';
      if(title) title.innerHTML='🔐 Serviços e subscrições';
    }
  };
})();


(function(){
  const originalSetCreateMode = window.setSubscriptionCreateMode;
  window.toggleSubscriptionCreatePanel = function(){
    const services = document.getElementById('servicesManagement');
    const panel = document.getElementById('subscriptionCreatePanel');
    const btn = document.getElementById('subscriptionCreateToggleBtn');
    const title = document.querySelector('#subscricoes .subscricoes-title-close');
    if(!services || !panel) return;

    const shouldOpen = services.classList.contains('hidden') || panel.classList.contains('hidden');
    if(shouldOpen){
      if(typeof originalSetCreateMode === 'function') originalSetCreateMode();
      services.classList.remove('hidden');
      panel.classList.remove('hidden');
      panel.classList.remove('v146-inner-collapsed');
      if(btn) btn.textContent='Fechar';
      if(title) title.innerHTML='🔐 Serviços e subscrições';
    }else{
      services.classList.add('hidden');
      panel.classList.add('hidden');
      if(btn) btn.textContent='Abrir';
      if(title) title.innerHTML='🔐 Serviços e subscrições';
    }
  };
})();


(function(){
  window.toggleServicesOnlyPanel=function(){
    const el=document.getElementById('servicesManagement');
    if(el) el.classList.toggle('v146-inner-collapsed');
  };
  window.toggleSubscriptionsOnlyPanel=function(){
    const el=document.getElementById('subscriptionCreatePanel');
    if(el) el.classList.toggle('v146-inner-collapsed');
  };
})();


(function(){
  const originalSetCreateMode = window.setSubscriptionCreateMode;

  window.toggleSubscriptionsOnlyPanel=function(){
    const el=document.getElementById('subscriptionCreatePanel');
    if(!el)return;
    const collapsed=el.classList.contains('v153-form-collapsed');
    if(collapsed){
      el.classList.remove('v153-form-collapsed');
      el.classList.remove('v146-inner-collapsed');
    }else{
      el.classList.remove('v146-inner-collapsed');
      el.classList.add('v153-form-collapsed');
    }
  };

  /* O botão/título principal continua a controlar Serviços + Subscrições em conjunto.
     Ao abrir, garante que o formulário de nova subscrição também fica disponível. */
  window.toggleSubscriptionCreatePanel=function(){
    const services=document.getElementById('servicesManagement');
    const panel=document.getElementById('subscriptionCreatePanel');
    const btn=document.getElementById('subscriptionCreateToggleBtn');
    const title=document.querySelector('#subscricoes .subscricoes-title-close');
    if(!services || !panel)return;

    const shouldOpen=services.classList.contains('hidden') || panel.classList.contains('hidden');
    if(shouldOpen){
      if(typeof originalSetCreateMode==='function') originalSetCreateMode();
      services.classList.remove('hidden');
      panel.classList.remove('hidden');
      panel.classList.remove('v146-inner-collapsed');
      panel.classList.remove('v153-form-collapsed');
      if(btn)btn.textContent='Fechar';
      if(title)title.innerHTML='🔐 Serviços e subscrições';
    }else{
      services.classList.add('hidden');
      panel.classList.add('hidden');
      if(btn)btn.textContent='Abrir';
      if(title)title.innerHTML='🔐 Serviços e subscrições';
    }
  };
})();


(function(){
  window.toggleSubscriptionCreatePanel=function(){
    const services=document.getElementById('servicesManagement');
    const panel=document.getElementById('subscriptionCreatePanel');
    const btn=document.getElementById('subscriptionCreateToggleBtn');
    const title=document.querySelector('#subscricoes .subscricoes-title-close');
    if(!services || !panel)return;

    const mainIsClosed=services.classList.contains('hidden') || panel.classList.contains('hidden');

    if(mainIsClosed){
      services.classList.remove('hidden');
      panel.classList.remove('hidden');

      /* Estado inicial pretendido: ambos os blocos internos fechados. */
      services.classList.add('v146-inner-collapsed');
      panel.classList.remove('v146-inner-collapsed');
      panel.classList.add('v153-form-collapsed');

      if(btn)btn.textContent='Fechar';
      if(title)title.innerHTML='🔐 Serviços e subscrições';
    }else{
      services.classList.add('hidden');
      panel.classList.add('hidden');
      if(btn)btn.textContent='Abrir';
      if(title)title.innerHTML='🔐 Serviços e subscrições';
    }
  };
})();


/* V176 — afinações visuais dos serviços do cliente e catálogo. */
(function(){
  const oldRender=window.v117RenderEquipments;
  if(typeof oldRender==='function' && !oldRender.__v176ServiceLayout){
    window.v117RenderEquipments=function(){
      const result=oldRender.apply(this,arguments);
      requestAnimationFrame(function(){
        document.querySelectorAll('#v117EquipmentBox .v118-eq-card').forEach(function(card,i){
          const eq=window.v117EditorEquipments?.[i];
          if(!eq)return;
          const extra=Array.isArray(eq.servicos)?eq.servicos:[];
          const mainLabel=card.querySelector('.field label');
          if(mainLabel && mainLabel.textContent.trim()==='Serviço') mainLabel.textContent=extra.length?'Serviço 1':'Serviço';
          card.querySelectorAll('.v174-service-row').forEach(function(row,j){
            const label=row.querySelector('.field label');
            if(label)label.textContent='Serviço '+(j+2);
            const select=row.querySelector('select');
            if(select){select.classList.add('am-placeholder-select');select.classList.toggle('has-value',!!select.value);}
          });
        });
      });
      return result;
    };
    window.v117RenderEquipments.__v176ServiceLayout=true;
  }
})();
