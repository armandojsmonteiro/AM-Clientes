# AM Clientes V330

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 330
- `versionName`: `1.0.330`

## Alterações da V324

- Ao tocar no título da área Equipamentos, Produtos / Consumíveis ou Marcas, recolhe-se apenas o formulário de adicionar/editar; a pesquisa e os registos existentes continuam visíveis. A seleção e os valores de edição ficam preservados ao recolher o formulário.
- O botão de edição apresenta apenas `Guardar`, com largura compatível com o botão `Cancelar`.
- O estado de stock usa a cor apenas no ponto indicador: vermelho para stock zero, laranja para 1–5 unidades inclusive e verde acima de 5. O texto `Stock N` mantém cor neutra.
- A expansão/recolha do formulário é restaurada após rotação do dispositivo.


- Contornos dos cartões unificados com o azul médio aprovado no menu Serviços e subscrições, incluindo o cabeçalho de navegação e as barras de pesquisa.
- Removido o ícone repetido dos cartões individuais de serviço; o ícone permanece no cabeçalho da secção.
- Tipo de subscrição corrigido para duas opções de lógica: `Subscrição simples` ou `Pack`. O nome do pack continua a ser definido no campo Nome.
- Ao escolher `Pack`, aparece o seletor múltiplo `Subscrições incluídas no pack`, com as subscrições simples já registadas, realce azul-claro e visto por cada opção selecionada.
- As subscrições incluídas são guardadas como componentes estruturados, preservando o custo e a regra de compra da subscrição associada, incluindo o campo usado pelo cálculo de licenças consumidas.
- O cartão exterior de Subscrições passa a conter o formulário e todos os cartões individuais, à semelhança da secção Serviços.
- Contornos da barra lateral ajustados para a mesma cor e espessura visual dos cartões principais.
- Texto dos botões Fechar/Abrir no ecrã Início ajustado ao tamanho padrão dos menus Clientes e Serviços e subscrições.
- Contornos azuis mais visíveis no módulo Serviços e subscrições, sem alterar o tema global da aplicação.
- Removida a secção Serviços do ecrã Catálogos; a sua gestão mantém-se em Serviços e subscrições.
- Retirado o texto introdutório redundante do ecrã Catálogos e reposta a estrutura com cartões interiores para Equipamentos, Produtos / Consumíveis e Marcas.
- Cabeçalho da barra lateral sem moldura exterior; mantida a linha horizontal separadora sob AM Clientes.
- Preservadas as correções anteriores do calendário, menus, aviso e edição de serviços.
- O ecrã Catálogos foi restaurado para gestão inline: Equipamentos, Produtos / Consumíveis e Marcas mantêm-se acessíveis enquanto o formulário escolhido aparece por baixo.
- Recuperados os campos específicos dos formulários, os valores calculados de stock, custo unitário e margem, a pesquisa dos registos e as ações de adicionar, editar e apagar.
- Os seletores de marca são alimentados pelas marcas registadas no próprio catálogo; a gestão de Serviços continua fora de Catálogos.

## Validação

A compilação Android/Gradle deve ser confirmada no workflow do GitHub Actions.


## V320 — ajustes do catálogo
- Animação de abertura do menu Catálogos ajustada para 260 ms.
- Tocar no título da área aberta recolhe apenas o formulário, mantendo os cartões de Catálogos visíveis.
- Campo Fotografia com seletor de imagem e URI persistente guardada no registo do equipamento.
- Lista de equipamentos/produtos com puxador de ordenação, ações Editar/Apagar empilhadas e indicador de stock por cor.
- Removidos os valores PVP/preço das linhas resumidas da lista.
- Removidos hífens decorativos dos textos de seleção.


## V321 — correções de renderização do catálogo
- Reposto o conteúdo interno de cada cartão de registo: puxador de ordenação, nome, marca/modelo, stock com indicação de cor e botões de editar/apagar.
- Removida a animação de opacidade/translação que era reiniciada em cada atualização do catálogo e provocava cintilação.
- Mantidos o formulário de fotografia, a validação do nome e os restantes campos e cálculos da V320.


## Alterações da V324
- Indicador de stock aumentado para ser mais legível.
- Stock 0 a vermelho; stock de 1 a 5 a laranja; stock superior a 5 a verde. A cor afeta apenas a bolinha, não o texto.
- Transição de abertura e regresso do formulário de catálogo usa a mesma animação suave de scroll utilizada no editor de clientes.


## Alterações da V325
- Corrigido o cálculo do destino de scroll ao abrir Equipamentos/Produtos/Consumíveis/Marcas para alinhar o cabeçalho do formulário no topo visível, sem parar a meio do percurso.
- Recolha/expansão do formulário agora anima a altura no próprio componente, sem reconstruir a secção; a lista de registos e a pesquisa ficam no lugar e deixam de piscar.
- Animação usa a mesma curva suave e uma duração consistente nos dois sentidos; toques durante a animação não deixam um listener anterior alterar o estado final.
- Indicador de stock redesenhado como círculo real de 14 dp, com alinhamento vertical centrado em relação ao texto. Vermelho para 0, laranja para 1–5 inclusive, verde acima de 5; o texto mantém cor neutra.


## Alterações da V327

- Abertura e recolha do formulário de Catálogos com a mesma duração de 700 ms.
- Ao reabrir pelo título inferior, a secção volta a ser posicionada através da mesma navegação suave usada no cartão superior.
- Mantida a bolinha de stock ampliada e centrada.


## Correções da V327

- A expansão/recolha do formulário de Catálogos e o reposicionamento do conteúdo começam em conjunto, com duração e interpolação iguais, evitando o segundo salto após a abertura.
- Ao recolher, a altura da página é preservada temporariamente para impedir que o ScrollView force um reposicionamento brusco; a altura original é reposta após a animação.


## Alterações da V329

- Fecho do módulo de Catálogos animado com a mesma duração do movimento de abertura.

## Alterações da V330

- O fecho de uma área de Catálogos anima simultaneamente a altura e o scroll até à posição anterior à abertura, eliminando o salto no último frame.
- Os formulários recolhíveis de Serviços e Subscrições usam a mesma transição de 700 ms, alinhando o cabeçalho da secção no topo durante a abertura e regressando suavemente ao ponto de origem ao fechar.
- A expansão/recolha usa um único animador para altura e scroll, sem reposicionamentos posteriores separados.
- Ao inverter uma animação a meio, a transição nova começa no frame atual para evitar saltos.
- Atualizado `versionCode`/`versionName` para 330 / `1.0.330`.
