AM Clientes V271 — projeto Android nativo.

Estado consolidado da nova aplicação independente.
- Package / Application ID: com.aminovacao.amclientes231
- Aplicação 100% Android nativa; sem HTML/WebView como solução de interface.
- V230 é apenas a referência funcional da aplicação original; esta aplicação é independente.
- Arranque em estado vazio, sem dados de demonstração.
- O backup JSON externo continua a ser a fonte de dados para testes/importação.
- Interface trabalhada progressivamente, menu a menu, sem patches ou implementações concorrentes para o mesmo elemento.

Alteração V271:
- Partindo diretamente da V268, mantém o botão Fechar Cliente no mesmo tamanho e posição do botão standard Fechar: 64 x 40 dp.
- Só muda o texto interno do botão entre Fechar e Fechar Cliente; as restantes dimensões e elementos ficam inalterados.
- Nenhuma outra alteração visual ou funcional foi feita nesta versão.
