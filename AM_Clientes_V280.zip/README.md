# AM Clientes V280

Projeto Android nativo independente.
- Package / Application ID: `com.aminovacao.amclientes231`
- Versão: V280

Nesta versão, os campos brancos do editor passam a usar a mesma altura compacta já usada nas linhas de Serviço e Subscrição. A numeração de Serviço/Subscrição é atualizada automaticamente: uma linha fica sem número; a partir de duas ficam `1`, `2`, etc. A posição dos botões do equipamento mantém-se: `＋ Novo equipamento` fica imediatamente abaixo de `Equipamentos do cliente` e `Adicionar serviço`/`Adicionar subscrição` permanecem dentro de cada equipamento.
