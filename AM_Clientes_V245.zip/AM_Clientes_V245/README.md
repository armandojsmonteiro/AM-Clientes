AM Clientes V245

Base: V245. Ajuste visual do menu lateral: largura, proporções, cores dos itens e alinhamento superior da aplicação. Sem alteração das funcionalidades.
