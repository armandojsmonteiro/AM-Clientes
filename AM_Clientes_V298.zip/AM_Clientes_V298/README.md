# AM Clientes V298

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 298
- `versionName`: `1.0.298`

## Alterações desta versão

- A lista de serviços permanece visível quando o formulário de criação de serviços está recolhido.
- Os formulários de Serviços e Subscrições continuam a abrir e fechar separadamente das respetivas listas.
- Os controlos de três traços iniciam o arrastamento dos cartões de serviços e subscrições.
- A nova ordem é guardada na base de dados da empresa ativa e reaparece ao voltar a abrir o menu.

O projeto ainda necessita de compilação Android para validação final da APK.
