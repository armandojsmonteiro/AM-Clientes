# AM Clientes V285

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 285
- `versionName`: `1.0.285`

Correção desta versão:
- Restaurada a abertura da pré-visualização do cliente ao tocar no cartão/nome no menu **Iniciar**. A navegação preserva o cliente selecionado em vez de o limpar antes de desenhar o ecrã.
- Voltar a tocar no nome dentro da pré-visualização continua a fechar a pré-visualização.
- Alteração limitada ao fluxo do menu Iniciar; o menu Clientes mantém o seu comportamento próprio.
