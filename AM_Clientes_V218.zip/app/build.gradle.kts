plugins { id("com.android.application") }

android {
    namespace = "com.aminovacao.amclientes"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aminovacao.amclientes"
        minSdk = 26
        targetSdk = 35
        versionCode = 218
        versionName = "1.0.218"
    }

    buildTypes {
        getByName("debug") {
            isMinifyEnabled = false
        }
        getByName("release") {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
