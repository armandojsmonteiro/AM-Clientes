package com.aminovacao.amclientes231;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.xml.parsers.DocumentBuilderFactory;

public class MainActivity extends Activity {
    // ---------------------------------------------------------------------
    // Ajustes visuais consolidados do ecrã Início.
    // ---------------------------------------------------------------------

    private static final int BLUE = Color.rgb(97, 165, 255);
    private static final int BG = Color.rgb(3, 11, 32);
    private static final int PANEL = Color.rgb(7, 17, 39);
    private static final int PANEL2 = Color.rgb(11, 25, 53);
    private static final int LINE = Color.rgb(49, 61, 87);
    private static final int HOME_LINE = Color.rgb(44, 73, 111);
    private static final int VALUE_LINE = Color.rgb(27, 49, 82);
    private static final int TEXT = Color.rgb(245, 247, 251);
    private static final int MUTED = Color.rgb(154, 170, 194);
    private static final int GREEN = Color.rgb(53, 208, 127);
    private static final int ORANGE = Color.rgb(255, 173, 69);
    private static final int RED = Color.rgb(255, 92, 104);

    private static final String PREF = "am_clientes_native";
    private static final String ACTION_TYPE = "application/vnd.ms-excel";
    private static final int REQ_OPEN_JSON = 4101;
    private static final int REQ_OPEN_EXCEL = 4102;
    private static final int REQ_SAVE_JSON = 4103;
    private static final int REQ_SAVE_EXCEL = 4104;
    private static final int REQ_LOGO = 4105;
    private static final int TAG_JSON = 0x6A4D233;

    private SharedData store;
    private String currentScreen = "inicio";
    private String selectedClientId = null;
    private String clientListMode = "all";
    private EditText topSearch;
    private TextView appTitleView;
    private TextView logoTextView;
    private ImageView logoImageView;
    private FrameLayout root;
    private FrameLayout drawerOverlay;
    private ScrollView drawerScroll;
    private LinearLayout drawer;
    private LinearLayout companyGroup;
    private LinearLayout companyList;
    private ScrollView contentScroll;
    private LinearLayout content;
    private LinearLayout topBar;
    private LinearLayout shell;
    private String pendingSaveFilename;
    private byte[] pendingSaveBytes;
    private String pendingSaveMime;
    private JSONObject pendingClientDraft;

    private static final Map<String, String> DEFAULTS = new LinkedHashMap<>();
    static {
        DEFAULTS.put("renewal", "[AGORA]\n\nA validade do serviço [SERVIÇO] em nome de [CLIENTE] termina em [DATA].\n\nEspero que tenha gostado do nosso serviço de manutenção e que queira continuar nosso cliente.\n\nCaso queira continuar, por favor contacte-nos.\n\nObrigado.");
        DEFAULTS.put("expired", "[AGORA]\n\nO serviço [SERVIÇO] em nome de [CLIENTE] encontra-se expirado desde [DATA].\n\nCaso pretenda renovar, por favor contacte-nos.\n\nObrigado.");
        DEFAULTS.put("payment", "[AGORA]\n\nRelativamente ao serviço [SERVIÇO] em nome de [CLIENTE], ficou registado um saldo de [SALDO]€.\n\nObrigado.");
        DEFAULTS.put("maintenance", "[AGORA]\n\nInformamos que a manutenção do serviço [SERVIÇO] em nome de [CLIENTE] está agendada.\n\nObrigado.");
        DEFAULTS.put("custom", "");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        w.setFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS,
                   WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );
        store = new SharedData(this);
        store.load();
        buildRoot();
        showScreen("inicio");
    }

    // ============================== UI BASE ==============================

    private void buildRoot() {
        root = new FrameLayout(this);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(16, 48, 94), Color.rgb(5, 19, 43), BG});
        root.setBackground(bg);

        shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(16), 0, dp(16), 0);
        root.addView(shell, new FrameLayout.LayoutParams(-1, -1));

        topBar = new LinearLayout(this);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(0, 0, 0, dp(10));
        shell.addView(topBar, new LinearLayout.LayoutParams(-1, dp(46)));

        Button menuBtn = button("☰", true);
        menuBtn.setContentDescription("Abrir menu");
        menuBtn.setTextSize(24);
        menuBtn.setPadding(0, 0, 0, 0);
        menuBtn.setGravity(Gravity.CENTER);
        menuBtn.setOnClickListener(v -> openDrawer());
        topBar.addView(menuBtn, new LinearLayout.LayoutParams(dp(40), dp(40)));

        FrameLayout logoBox = new FrameLayout(this);
        setRoundedBackground(logoBox, Color.rgb(7, 29, 62), LINE, 13);
        LinearLayout.LayoutParams lbp = new LinearLayout.LayoutParams(dp(42), dp(42));
        lbp.setMargins(dp(8), 0, dp(10), 0);
        topBar.addView(logoBox, lbp);
        logoTextView = tv("AM", 16, BLUE, true);
        logoTextView.setGravity(Gravity.CENTER);
        logoBox.addView(logoTextView, new FrameLayout.LayoutParams(-1, -1));

        logoImageView = new ImageView(this);
        logoImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logoImageView.setImageResource(com.aminovacao.amclientes231.R.drawable.ic_launcher);
        logoImageView.setVisibility(View.VISIBLE);
        // A imagem do logótipo deve respeitar o mesmo recorte arredondado do original.
        setRoundedBackground(logoImageView, Color.TRANSPARENT, 0, 10);
        logoImageView.setClipToOutline(true);
        logoBox.addView(logoImageView, new FrameLayout.LayoutParams(-1, -1));

        appTitleView = tv(store.title(), 20, TEXT, true);
        topBar.addView(appTitleView, new LinearLayout.LayoutParams(0, -2, 1f));

        topSearch = edit("Pesquisar nome, contacto, empresa, equipamento, MAC, nº série...", 15);
        topSearch.setSingleLine(true);
        topSearch.setInputType(InputType.TYPE_CLASS_TEXT);
        topSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int before, int count) {
                if ("inicio".equals(currentScreen) || "clientes".equals(currentScreen)) refreshCurrentScreen();
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        shell.addView(topSearch, new LinearLayout.LayoutParams(-1, dp(46)));

        contentScroll = new ScrollView(this);
        contentScroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(14), 0, dp(8));
        contentScroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        shell.addView(contentScroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        buildDrawer();
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0, bottom = 0;
            if (android.os.Build.VERSION.SDK_INT >= 20) {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            shell.setPadding(dp(16), top, dp(16), bottom);
            if (drawer != null) drawer.setPadding(dp(16), top + dp(10), dp(16), bottom + dp(16));
            return insets;
        });
        setContentView(root);
        root.post(() -> root.requestApplyInsets());
        applySettingsVisuals();
    }

    private void buildDrawer() {
        // Rebuild the drawer as a single instance. The previous implementation
        // could leave an old overlay/drawer attached to root when the company
        // selection rebuilt the drawer, making the side menu appear permanently
        // stuck above the application.
        if (drawerScroll != null) {
            root.removeView(drawerScroll);
            drawerScroll = null;
        }
        if (drawerOverlay != null) {
            root.removeView(drawerOverlay);
            drawerOverlay = null;
        }

        drawerOverlay = new FrameLayout(this);
        drawerOverlay.setBackgroundColor(Color.argb(130, 0, 0, 0));
        drawerOverlay.setVisibility(View.GONE);
        drawerOverlay.setOnClickListener(v -> closeDrawer());
        root.addView(drawerOverlay, new FrameLayout.LayoutParams(-1, -1));

        final int DRAWER_LINE = Color.rgb(44, 73, 111);
        final int DRAWER_ITEM_BG = Color.rgb(7, 29, 62);
        final int COMPANY_GROUP_BG = Color.rgb(4, 12, 29);

        drawerScroll = new ScrollView(this);
        drawerScroll.setFillViewport(true);
        drawerScroll.setClipToPadding(false);
        setRoundedBackground(drawerScroll, Color.rgb(7, 26, 54), DRAWER_LINE, 0);
        FrameLayout.LayoutParams drawerLp = new FrameLayout.LayoutParams(dp(202), -1);
        drawerLp.gravity = Gravity.START;
        drawerLp.leftMargin = -dp(202);
        root.addView(drawerScroll, drawerLp);

        drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setPadding(dp(16), dp(10), dp(16), dp(16));
        drawerScroll.addView(drawer, new ScrollView.LayoutParams(-1, -2));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = tv(store.title(), 18, TEXT, true);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        Button close = button("×", false);
        close.setTextSize(24);
        head.addView(close, new LinearLayout.LayoutParams(dp(42), dp(42)));
        close.setOnClickListener(v -> closeDrawer());
        drawer.addView(head, new LinearLayout.LayoutParams(-1, -2));
        addSpacer(drawer, 12);
        addDivider(drawer);
        addSpacer(drawer, 15);

        LinearLayout companyToggle = companyHeaderRow("🏢", "Empresa", true, DRAWER_ITEM_BG, DRAWER_LINE);
        drawer.addView(companyToggle, new LinearLayout.LayoutParams(-1, dp(46)));
        addSpacer(drawer, 7);

        companyGroup = new LinearLayout(this);
        companyGroup.setOrientation(LinearLayout.VERTICAL);
        companyGroup.setPadding(dp(7), dp(7), dp(7), dp(7));
        setRoundedBackground(companyGroup, COMPANY_GROUP_BG, DRAWER_LINE, 14);

        companyList = new LinearLayout(this);
        companyList.setOrientation(LinearLayout.VERTICAL);
        companyList.setPadding(0, 0, 0, 0);
        companyList.setVisibility(View.GONE);
        renderCompanyList(companyList);
        companyGroup.addView(companyList, new LinearLayout.LayoutParams(-1, -2));
        companyGroup.setVisibility(View.GONE);
        drawer.addView(companyGroup, new LinearLayout.LayoutParams(-1, -2));
        companyToggle.setOnClickListener(v -> {
            boolean open = companyGroup.getVisibility() != View.VISIBLE;
            companyGroup.setVisibility(open ? View.VISIBLE : View.GONE);
            companyList.setVisibility(open ? View.VISIBLE : View.GONE);
            if (open) drawerScroll.post(() -> drawerScroll.fullScroll(View.FOCUS_DOWN));
        });
        addSpacer(drawer, 8);

        String[][] nav = {
                {"Início", "🏠", "inicio"},
                {"Clientes", "📋", "clientes"},
                {"Serviços e subscrições", "🔐", "subscricoes"},
                {"Catálogos", "📦", "catalogos"},
                {"Arquivado", "📁", "historico"},
                {"Histórico", "🕘", "atividade"},
                {"Estatísticas", "📊", "estatisticas"},
                {"Configurações", "⚙️", "config"},
                {"Gestão", "🛠️", "gestao"}
        };
        for (String[] item : nav) {
            Button b = menuItem(item[1], item[0], item[2].equals(currentScreen));
            b.setTextSize(14);
            b.setTag(item[2]);
            b.setOnClickListener(v -> { showScreen((String) v.getTag()); closeDrawer(); });
            drawer.addView(b, new LinearLayout.LayoutParams(-1, dp(50)));
            addSpacer(drawer, 6);
        }
    }

    private void renderCompanyList(LinearLayout host) {
        host.removeAllViews();
        JSONArray companies = store.companies();
        final int DRAWER_LINE = Color.rgb(44, 73, 111);
        final int SUB_BG = Color.rgb(7, 29, 62);
        for (int i = 0; i < companies.length(); i++) {
            JSONObject c = companies.optJSONObject(i);
            if (c == null) continue;
            final String id = c.optString("id", "");
            final String name = c.optString("name", "Empresa");
            boolean selected = id.equals(store.activeCompanyId());

            LinearLayout row = companySubRow(selected, name, DRAWER_LINE, SUB_BG);
            row.setOnClickListener(v -> {
                store.selectCompany(id);
                rebuildDrawerCompanyLabel();
                refreshCurrentScreen();
                closeDrawer();
            });
            host.addView(row, new LinearLayout.LayoutParams(-1, dp(40)));
            if (i + 1 < companies.length()) addSpacer(host, 6);
        }

        LinearLayout manage = companySubRow(false, "Gerir empresas", DRAWER_LINE, SUB_BG);
        manage.setOnClickListener(v -> { closeDrawer(); openCompanyManagement(); });
        LinearLayout.LayoutParams manageLp = new LinearLayout.LayoutParams(-1, dp(40));
        manageLp.topMargin = dp(6);
        host.addView(manage, manageLp);
    }

    private LinearLayout companyHeaderRow(String icon, String label, boolean arrow, int bg, int line) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), 0, dp(12), 0);
        setRoundedBackground(row, bg, line, 12);

        TextView ic = tv(icon, 16, TEXT, false);
        ic.setGravity(Gravity.CENTER);
        row.addView(ic, new LinearLayout.LayoutParams(dp(26), dp(46)));

        TextView labelTv = tv(label, 14, TEXT, false);
        labelTv.setSingleLine(true);
        labelTv.setEllipsize(null);
        LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(0, -1, 1f);
        row.addView(labelTv, textLp);

        if (arrow) {
            TextView ar = tv("⌄", 16, TEXT, false);
            ar.setGravity(Gravity.CENTER);
            row.addView(ar, new LinearLayout.LayoutParams(dp(22), dp(46)));
        }
        return row;
    }

    private LinearLayout companySubRow(boolean selected, String label, int line, int subBg) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), 0, dp(8), 0);
        setRoundedBackground(row, selected ? BLUE : subBg, selected ? BLUE : line, 12);

        if (selected) {
            TextView check = tv("✓", 15, Color.rgb(3, 17, 39), true);
            check.setGravity(Gravity.CENTER);
            row.addView(check, new LinearLayout.LayoutParams(dp(18), dp(40)));
        }

        TextView ic = tv("🏢", 15, selected ? Color.rgb(3,17,39) : TEXT, false);
        ic.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(22), dp(40));
        if (selected) iconLp.setMargins(dp(4), 0, 0, 0);
        row.addView(ic, iconLp);
        TextView labelTv = tv(label, 14, selected ? Color.rgb(3,17,39) : TEXT, selected);
        labelTv.setSingleLine(true);
        labelTv.setEllipsize(null);
        labelTv.setIncludeFontPadding(false);
        row.addView(labelTv, new LinearLayout.LayoutParams(0, -1, 1f));
        return row;
    }

    private void rebuildDrawerCompanyLabel() {
        buildDrawer();
        openDrawer();
    }

    private void syncDrawerSelection() {
        if (drawer == null) return;
        for (int i = 0; i < drawer.getChildCount(); i++) {
            View child = drawer.getChildAt(i);
            if (!(child instanceof Button)) continue;
            Object tag = child.getTag();
            if (!(tag instanceof String)) continue;
            Button b = (Button) child;
            boolean selected = currentScreen.equals(tag);
            if (selected) {
                setRoundedBackground(b, BLUE, BLUE, 12);
                b.setTextColor(Color.rgb(3, 17, 39));
                b.setTypeface(Typeface.create("sans-serif", Typeface.BOLD), Typeface.BOLD);
            } else {
                setRoundedBackground(b, Color.rgb(7, 29, 62), Color.rgb(44, 73, 111), 12);
                b.setTextColor(TEXT);
                b.setTypeface(null, Typeface.NORMAL);
            }
        }
    }

    private void openDrawer() {
        if (drawer == null || drawerOverlay == null || drawerScroll == null) return;
        syncDrawerSelection();
        drawerOverlay.setVisibility(View.VISIBLE);
        drawerOverlay.bringToFront();
        drawerScroll.setVisibility(View.VISIBLE);
        drawerScroll.setTranslationX(dp(202));
        drawerScroll.bringToFront();
        root.invalidate();
    }

    private void closeDrawer() {
        // Fechar o menu lateral também fecha sempre o submenu Empresa.
        // Assim, ao voltar a abrir o menu, este começa recolhido e não
        // fica preso aberto depois de navegar para outra opção.
        if (companyList != null) companyList.setVisibility(View.GONE);
        if (companyGroup != null) companyGroup.setVisibility(View.GONE);
        if (drawerScroll != null) {
            drawerScroll.setTranslationX(0f);
            drawerScroll.setVisibility(View.GONE);
        }
        if (drawerOverlay != null) {
            drawerOverlay.setVisibility(View.GONE);
        }
    }

    private void clearContent() {
        content.removeAllViews();
        contentScroll.scrollTo(0, 0);
    }

    private void showScreen(String screen) {
        currentScreen = screen;
        syncDrawerSelection();
        if (topSearch != null) topSearch.setText("");
        if ("inicio".equals(screen)) selectedClientId = null;
        clearContent();
        if ("inicio".equals(screen)) renderHome();
        else if ("clientes".equals(screen)) renderClients();
        else if ("subscricoes".equals(screen)) renderSubscriptionsScreen();
        else if ("catalogos".equals(screen)) renderCatalogs();
        else if ("historico".equals(screen)) renderArchived();
        else if ("atividade".equals(screen)) renderActivity();
        else if ("estatisticas".equals(screen)) renderStatistics();
        else if ("config".equals(screen)) renderSettings();
        else if ("gestao".equals(screen)) renderManagement();
        else renderHome();
    }

    private void refreshCurrentScreen() {
        if (isFinishing()) return;
        if ("inicio".equals(currentScreen)) renderHome();
        else if ("clientes".equals(currentScreen)) renderClients();
    }

    // ============================== HOME ================================

    private void renderHome() {
        addSpacer(content, 1);
        content.addView(statRow(), new LinearLayout.LayoutParams(-1, -2));
        addSpacer(content, 14);

        Card home = card();
        setRoundedBackground(home, PANEL, HOME_LINE, 17);
        LinearLayout head = row();
        TextView h = tv("📋 Clientes", 21, TEXT, true);
        head.addView(h, new LinearLayout.LayoutParams(0, -2, 1f));

        Button toggle;
        if (selectedClientId != null) {
            toggle = primary("Fechar\nCliente");
            toggle.setSingleLine(false);
            toggle.setTextSize(13);
            toggle.setGravity(Gravity.CENTER);
            toggle.setPadding(0, 0, 0, 0);
            toggle.setLineSpacing(0f, 0.95f);
            toggle.setOnClickListener(v -> {
                selectedClientId = null;
                clearContent();
                renderHome();
            });
            head.addView(toggle, new LinearLayout.LayoutParams(dp(64), dp(40)));
            home.addView(head);
            addSpacer(home, 10);

            Card clientDetailPanel = new Card(this);
            clientDetailPanel.setPadding(dp(8), dp(8), dp(8), dp(8));
            setRoundedBackground(clientDetailPanel, PANEL, HOME_LINE, 17);
            JSONObject c = store.findClient(selectedClientId);
            if (c != null) {
                clientDetailPanel.addView(renderClientPreview(c));
                clientDetailPanel.addView(clientSummaryCard(c));
            } else {
                selectedClientId = null;
                clearContent();
                renderHome();
                return;
            }
            home.addView(clientDetailPanel);
        } else {
            toggle = primary("Fechar");
            toggle.setSingleLine(true);
            toggle.setMinWidth(0);
            toggle.setPadding(0, 0, 0, 0);
            toggle.setOnClickListener(v -> {
                View body = (View) v.getTag();
                if (body.getVisibility() == View.VISIBLE) { body.setVisibility(View.GONE); toggle.setText("Abrir"); }
                else { body.setVisibility(View.VISIBLE); toggle.setText("Fechar"); }
            });
            head.addView(toggle, new LinearLayout.LayoutParams(dp(64), dp(40)));
            home.addView(head);
            addSpacer(home, 10);

            Card clientListPanel = new Card(this);
            clientListPanel.setPadding(dp(8), dp(8), dp(8), dp(8));
            setRoundedBackground(clientListPanel, PANEL, HOME_LINE, 17);
            LinearLayout body = new LinearLayout(this);
            body.setOrientation(LinearLayout.VERTICAL);
            clientListPanel.addView(body, new LinearLayout.LayoutParams(-1, -2));
            home.addView(clientListPanel);
            toggle.setTag(body);

            String q = value(topSearch).trim().toLowerCase(Locale.ROOT);
            JSONArray clients = filteredClients(q);
            List<JSONObject> alerts = new ArrayList<>();
            for (int i = 0; i < clients.length(); i++) {
                JSONObject c = clients.optJSONObject(i); if (c == null) continue;
                String st = status(c);
                if ("expired".equals(st) || "warning".equals(st)) alerts.add(c);
            }
            Collections.sort(alerts, Comparator.comparingLong(this::daysUntilValidity));
            List<JSONObject> shown = new ArrayList<>();
            if (!q.isEmpty()) {
                for (int i = 0; i < clients.length(); i++) if (clients.optJSONObject(i) != null) shown.add(clients.optJSONObject(i));
            } else if (!alerts.isEmpty()) shown.addAll(alerts);
            else {
                for (int i = 0; i < clients.length(); i++) {
                    JSONObject c = clients.optJSONObject(i); if (c != null && "active".equals(status(c))) shown.add(c);
                    if (shown.size() >= 3) break;
                }
            }
            if (shown.isEmpty()) body.addView(muted("Nenhum cliente."));
            else for (JSONObject c : shown) body.addView(clientCard(c, true));
        }

        content.addView(home);
        addSpacer(content, 14);
        renderHomeShortcuts();
    }

    private void openHomeClientPreview(String id) {
        if (id == null || id.isEmpty()) return;
        selectedClientId = id;
        clearContent();
        renderHome();
    }

    private View statRow() {
        LinearLayout l = row();
        int active = 0, warning = 0, expired = 0;
        JSONArray a = store.clients();
        for (int i = 0; i < a.length(); i++) { JSONObject c = a.optJSONObject(i); if (c == null) continue; String s = status(c); if ("active".equals(s)) active++; else if ("warning".equals(s)) warning++; else expired++; }
        l.addView(statCard(String.valueOf(active), "Ativos", GREEN), homeStatParams(1, false, true));
        l.addView(statCard(String.valueOf(warning), "A expirar", ORANGE), homeStatParams(1, true, true));
        l.addView(statCard(String.valueOf(expired), "Expirados", RED), homeStatParams(1, true, false));
        return l;
    }

    private View statCard(String n, String label, int color) {
        Card c = new Card(this);
        c.setPadding(dp(8), dp(4), dp(8), dp(4));
        c.setGravity(Gravity.CENTER);
        // Proporção mais baixa e próxima do original: cartões praticamente quadrados,
        // mas sem a altura excessiva da implementação anterior.
        setRoundedBackground(c, PANEL, HOME_LINE, 17);
        TextView big = tv(n, 22, color, true);
        big.setGravity(Gravity.CENTER);
        c.addView(big, new LinearLayout.LayoutParams(-1, dp(31)));
        TextView small = tv(label, 13, TEXT, false);
        small.setGravity(Gravity.CENTER);
        c.addView(small, new LinearLayout.LayoutParams(-1, dp(27)));
        c.setMinimumHeight(dp(78));
        return c;
    }

    private void renderHomeShortcuts() {
        Card section = new Card(this);
        section.setPadding(dp(16), dp(14), dp(16), dp(14));
        // Painel próprio dos atalhos, sempre visível mesmo quando não existem atalhos.
        setRoundedBackground(section, PANEL, HOME_LINE, 17);

        TextView title = tv("🔗 Atalhos", 20, TEXT, true);
        section.addView(title);
        addSpacer(section, 8);

        JSONArray arr = store.appSettings().optJSONArray("shortcuts");
        if (arr == null || arr.length() == 0) {
            section.addView(muted("Ainda não existem atalhos. Pode adicioná-los em Configurações."));
            content.addView(section);
            return;
        }
        for (int i = 0; i < arr.length(); i++) {
            JSONObject s = arr.optJSONObject(i); if (s == null) continue;
            Card c = card();
            TextView n = tv(s.optString("name", "Atalho"), 16, TEXT, true);
            c.addView(n);
            c.addView(muted(s.optString("description", "")));
            Button open = primary("Abrir");
            open.setOnClickListener(v -> openExternal(s.optString("url", "")));
            c.addView(open, new LinearLayout.LayoutParams(-1, dp(40)));
            section.addView(c); addSpacer(section, 8);
        }
        content.addView(section);
    }

    // ============================== CLIENTES =============================

    private void renderClients() {
        Card panel = card();
        setRoundedBackground(panel, PANEL, HOME_LINE, 17);

        LinearLayout header = row();
        TextView t = tv("📋 Clientes", 20, TEXT, true);
        header.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));

        if (selectedClientId == null) {
            Button close = primary("Fechar");
            close.setOnClickListener(v -> showScreen("inicio"));
            header.addView(close, new LinearLayout.LayoutParams(dp(72), dp(40)));

            Button add = primary("Adicionar");
            add.setOnClickListener(v -> openClientEditor(null));
            header.addView(add, new LinearLayout.LayoutParams(dp(86), dp(40)));
            panel.addView(header);

            EditText search = edit("Pesquisar nome, contacto, empresa, equipamento, MAC...", 13);
            panel.addView(search, new LinearLayout.LayoutParams(-1, -2));

            LinearLayout listHost = new LinearLayout(this);
            listHost.setOrientation(LinearLayout.VERTICAL);
            search.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void onTextChanged(CharSequence s, int st, int before, int count) { renderClientsListInto(listHost); }
                @Override public void afterTextChanged(Editable s) {}
            });
            renderClientsListInto(listHost);
            panel.addView(listHost);
        } else {
            Button closeClient = primary("Fechar\nCliente");
            closeClient.setSingleLine(false);
            closeClient.setTextSize(13);
            closeClient.setGravity(Gravity.CENTER);
            closeClient.setPadding(0, 0, 0, 0);
            closeClient.setLineSpacing(0f, 0.95f);
            closeClient.setMinWidth(0);
            closeClient.setMinimumWidth(0);
            closeClient.setMaxWidth(dp(72));
            closeClient.setMinHeight(0);
            closeClient.setMinimumHeight(0);
            closeClient.setMaxHeight(dp(40));
            closeClient.setOnClickListener(v -> { selectedClientId = null; clearContent(); renderClients(); });
            header.addView(closeClient, new LinearLayout.LayoutParams(dp(72), dp(40)));
            panel.addView(header);

            JSONObject c = store.findClient(selectedClientId);
            if (c != null) {
                addSpacer(panel, 10);
                panel.addView(renderClientPreview(c));
                addSpacer(panel, 10);
                panel.addView(clientSummaryCard(c));
            } else {
                selectedClientId = null;
                clearContent();
                renderClients();
                return;
            }
        }

        content.addView(panel);
        addSpacer(content, 14);
        if (selectedClientId != null) renderHomeShortcuts();
    }

    private View clientSummaryCard(JSONObject c) {
        Card outer = card();
        outer.setPadding(dp(8), dp(8), dp(8), dp(8));
        setRoundedBackground(outer, PANEL, HOME_LINE, 17);
        LinearLayout line = row();
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(tv(clientName(c), 16, TEXT, true));
        left.addView(tv(orDash(c.optString("Serviço", "")), 14, MUTED, false));
        left.addView(tv(orDash(c.optString("Contacto", "")), 14, MUTED, false));
        line.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView badge = tv(statusLabel(c), 11, GREEN, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(10), dp(5), dp(10), dp(5));
        String st = status(c);
        int badgeBg = "active".equals(st) ? Color.rgb(10, 72, 45)
                : "warning".equals(st) ? Color.rgb(76, 52, 20)
                : Color.rgb(72, 28, 37);
        int badgeFg = "active".equals(st) ? GREEN
                : "warning".equals(st) ? ORANGE
                : RED;
        setRoundedBackground(badge, badgeBg, 0, 16);
        badge.setTextColor(badgeFg);
        line.addView(badge, new LinearLayout.LayoutParams(-2, -2));
        outer.addView(line);
        return outer;
    }

    private Card renderClientPreview(JSONObject c) {
        Card detail = card();
        detail.setPadding(dp(16), dp(14), dp(16), dp(14));
        setRoundedBackground(detail, PANEL, HOME_LINE, 17);

        LinearLayout head = row();
        TextView name = tv(clientName(c), 18, TEXT, true);
        head.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView badge = tv(statusLabel(c), 11, GREEN, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(10), dp(7), dp(10), dp(7));
        String st = status(c);
        int badgeBg = "active".equals(st) ? Color.rgb(10, 72, 45)
                : "warning".equals(st) ? Color.rgb(76, 52, 20)
                : Color.rgb(72, 28, 37);
        int badgeFg = "active".equals(st) ? GREEN
                : "warning".equals(st) ? ORANGE
                : RED;
        setRoundedBackground(badge, badgeBg, 0, 16);
        badge.setTextColor(badgeFg);
        head.addView(badge, new LinearLayout.LayoutParams(-2, -2));
        detail.addView(head);

        addCopyValue(detail, "Observações", c.optString("Observações", ""));
        addCopyValue(detail, "Contacto", c.optString("Contacto", ""));
        addSpacer(detail, 14);

        TextView eqTitle = tv("🛠️ Equipamento", 19, TEXT, true);
        detail.addView(eqTitle);
        addSpacer(detail, 5);

        JSONArray eqs = c.optJSONArray("equipamentos");
        JSONObject e = eqs != null && eqs.length() > 0 ? eqs.optJSONObject(0) : null;
        if (e == null) {
            addCopyValue(detail, "Nome do equipamento", "");
        } else {
            addCopyValue(detail, "Nome do equipamento", e.optString("nome", ""));
            addCopyValue(detail, "MAC", e.optString("mac", ""));
            addCopyValue(detail, "Utilizador", e.optString("utilizador", ""));
            addCopyValue(detail, "Senha", e.optString("senha", ""));
            addCopyValue(detail, "Link", e.optString("link", ""));

            TextView ssTitle = tv("🔐 Serviços e subscrições", 19, TEXT, true);
            addSpacer(detail, 12);
            detail.addView(ssTitle);
            addSpacer(detail, 5);

            List<String> serviceNames = equipmentNames(e, "servicos", "servico");
            for (int i = 0; i < serviceNames.size() && i < 4; i++) {
                addCopyValue(detail, "Serviço " + (i + 1), serviceNames.get(i));
            }
            List<String> subNames = equipmentNames(e, "subscricoes", "subscricao");
            if (subNames.isEmpty()) subNames = equipmentNames(e, "vpns", "subscricao");
            for (int i = 0; i < subNames.size() && i < 4; i++) {
                addCopyValue(detail, "Subscrição " + (i + 1), subNames.get(i));
            }
            addCopyValue(detail, "Validade", e.optString("validade", c.optString("Validade", "")));
            String periodicidade = e.optString("periodicidade", "");
            if (periodicidade.isEmpty()) periodicidade = inferPeriodicity(e.optString("validade", ""));
            addCopyValue(detail, "Periodicidade", periodicidade);
            String valor = e.optString("valorPago", "");
            if (!valor.isEmpty()) addCopyValue(detail, "Valor", valor.endsWith("€") ? valor : valor + " €");
            addCopyValue(detail, "Saldo", equipmentBalance(e) == 0 ? "—" : formatEuro(equipmentBalance(e)));
        }

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button edit = primary("✏️ Editar cliente");
        edit.setOnClickListener(v -> openClientEditor(c.optString("ID Cliente")));
        Button renew = primary("🔄 Renovar");
        renew.setOnClickListener(v -> Toast.makeText(this, "Renovação disponível para este cliente.", Toast.LENGTH_SHORT).show());
        actions.setGravity(Gravity.START);
        actions.addView(edit, new LinearLayout.LayoutParams(dp(132), dp(42)));
        LinearLayout.LayoutParams renewLp = new LinearLayout.LayoutParams(dp(98), dp(42));
        renewLp.leftMargin = dp(7);
        actions.addView(renew, renewLp);
        detail.addView(actions);
        addSpacer(detail, 8);
        Button archive = button("📦 Arquivar", false);
        archive.setOnClickListener(v -> confirm("Arquivar cliente?", "O cliente será movido para Arquivado.", () -> {
            store.archiveClient(c.optString("ID Cliente"));
            selectedClientId = null;
            showScreen("clientes");
        }));
        detail.addView(archive, new LinearLayout.LayoutParams(dp(100), dp(42)));
        addSpacer(detail, 8);

        TextView contactTitle = tv("📩 Contactar cliente", 19, TEXT, true);
        detail.addView(contactTitle);
        addSpacer(detail, 7);

        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        Button whatsapp = primary("WhatsApp");
        Button telegram = primary("Telegram");
        r1.addView(whatsapp, new LinearLayout.LayoutParams(dp(96), dp(42)));
        LinearLayout.LayoutParams telegramLp = new LinearLayout.LayoutParams(dp(90), dp(42));
        telegramLp.leftMargin = dp(7);
        r1.addView(telegram, telegramLp);
        detail.addView(r1);
        addSpacer(detail, 7);

        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        Button signal = primary("Signal");
        Button email = primary("E-mail");
        r2.addView(signal, new LinearLayout.LayoutParams(dp(72), dp(42)));
        LinearLayout.LayoutParams emailLp = new LinearLayout.LayoutParams(dp(72), dp(42));
        emailLp.leftMargin = dp(7);
        r2.addView(email, emailLp);
        detail.addView(r2);
        addSpacer(detail, 7);

        TextView modelLabel = tv("Modelo", 11, MUTED, false);
        detail.addView(modelLabel);
        addSpacer(detail, 4);
        Spinner model = spinner(asList("🔔 Renovação 1", "⚠️ Expirado", "💶 Pagamento", "🛠️ Manutenção", "✏️ Personalizada"), "🔔 Renovação 1");
        detail.addView(model, new LinearLayout.LayoutParams(-1, dp(42)));
        addSpacer(detail, 8);

        EditText message = edit("Mensagem", 14);
        message.setSingleLine(false);
        message.setMinHeight(dp(190));
        message.setGravity(Gravity.TOP | Gravity.START);
        message.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        model.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                message.setText(clientMessageFor(c, position));
            }
        });
        message.setText(clientMessageFor(c, 0));
        detail.addView(message);
        addSpacer(detail, 7);
        Button copy = button("Copiar mensagem", false);
        copy.setOnClickListener(v -> copyText(message.getText().toString(), "Mensagem copiada."));
        detail.addView(copy, new LinearLayout.LayoutParams(dp(145), dp(40)));

        whatsapp.setOnClickListener(v -> shareClientMessage(c, message.getText().toString(), "whatsapp"));
        telegram.setOnClickListener(v -> shareClientMessage(c, message.getText().toString(), "telegram"));
        signal.setOnClickListener(v -> shareClientMessage(c, message.getText().toString(), "signal"));
        email.setOnClickListener(v -> shareClientMessage(c, message.getText().toString(), "email"));
        return detail;
    }

    private void addCopyValue(ViewGroup host, String label, String value) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.addView(tv(label, 11, MUTED, false));
        addSpacer(block, 4);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        EditText field = edit("—", 14);
        field.setText(orDash(value));
        field.setFocusable(false);
        field.setClickable(false);
        field.setCursorVisible(false);
        row.addView(field, new LinearLayout.LayoutParams(0, dp(40), 1f));
        Button cp = button("📋", false);
        cp.setTextSize(17);
        cp.setGravity(Gravity.CENTER);
        cp.setPadding(0, 0, 0, 0);
        setRoundedBackground(cp, Color.rgb(10,27,55), LINE, 17);
        cp.setOnClickListener(v -> copyText(field.getText().toString(), "Copiado."));
        LinearLayout.LayoutParams cpLp = new LinearLayout.LayoutParams(dp(34), dp(34));
        cpLp.leftMargin = dp(8);
        row.addView(cp, cpLp);
        block.addView(row);
        host.addView(block);
        addSpacer(host, 7);
    }

    private List<String> equipmentNames(JSONObject e, String arrayKey, String singleKey) {
        List<String> out = new ArrayList<>();
        JSONArray a = e.optJSONArray(arrayKey);
        if (a != null) {
            for (int i = 0; i < a.length(); i++) {
                Object raw = a.opt(i);
                if (raw instanceof JSONObject) {
                    String n = ((JSONObject) raw).optString("name", ((JSONObject) raw).optString(singleKey, ""));
                    if (!n.isEmpty()) out.add(n);
                } else if (raw != null && !String.valueOf(raw).trim().isEmpty()) out.add(String.valueOf(raw));
            }
        }
        String single = e.optString(singleKey, "");
        if (out.isEmpty() && !single.isEmpty()) out.add(single);
        return out;
    }

    private String inferPeriodicity(String validity) {
        String s = String.valueOf(validity).toLowerCase(Locale.ROOT);
        if (s.contains("12")) return "Anual";
        if (s.contains("6")) return "Semestral";
        return "";
    }

    private String clientMessageFor(JSONObject c, int position) {
        String key = position == 1 ? "expired" : position == 2 ? "payment" : position == 3 ? "maintenance" : position == 4 ? "custom" : "renewal";
        String tpl = DEFAULTS.get(key);
        if (tpl == null) tpl = "";
        String service = c.optString("Serviço", "");
        String validity = c.optString("Validade", "");
        if (service.isEmpty()) {
            JSONArray eqs = c.optJSONArray("equipamentos");
            if (eqs != null && eqs.length() > 0) {
                JSONObject e = eqs.optJSONObject(0);
                if (e != null) service = e.optString("servico", "");
                if (validity.isEmpty() && e != null) validity = e.optString("validade", "");
            }
        }
        return tpl.replace("[AGORA]", "Boa tarde,")
                .replace("[CLIENTE]", clientName(c))
                .replace("[SERVIÇO]", service)
                .replace("[DATA]", validity)
                .replace("[DIAS_RESTANTES]", String.valueOf(daysUntilValidity(c)))
                .replace("[VALOR]", c.optString("Preço", "0"))
                .replace("[SALDO]", c.optString("Saldo", "0"));
    }

    private void copyText(String text, String toast) {
        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("AM Clientes", text));
        Toast.makeText(this, toast, Toast.LENGTH_SHORT).show();
    }

    private void shareClientMessage(JSONObject c, String message, String channel) {
        String phone = c.optString("Contacto", "").replaceAll("[^0-9]", "");
        String encoded = Uri.encode(message);
        try {
            if ("whatsapp".equals(channel) && !phone.isEmpty()) {
                openExternal("https://wa.me/" + phone + "?text=" + encoded);
            } else if ("telegram".equals(channel)) {
                // Abrir diretamente a aplicação oficial do Telegram, evitando
                // que o Android entregue o URL a clientes alternativos como o Nicegram.
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, message);
                i.setPackage("org.telegram.messenger");
                try {
                    startActivity(i);
                } catch (Exception e) {
                    // Fallback: abrir a aplicação oficial sem usar o cliente
                    // alternativo nem apresentar o menu de partilha.
                    Intent launch = getPackageManager().getLaunchIntentForPackage("org.telegram.messenger");
                    if (launch == null) throw e;
                    startActivity(launch);
                }
            } else if ("email".equals(channel)) {
                // Thunderbird é a aplicação de e-mail definida pelo utilizador.
                // Usamos SENDTO para manter o fluxo de e-mail do Android e,
                // quando instalado, encaminhamos diretamente para o Thunderbird.
                Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
                i.putExtra(Intent.EXTRA_SUBJECT, "AM Clientes");
                i.putExtra(Intent.EXTRA_TEXT, message);
                i.setPackage("org.mozilla.thunderbird");
                try {
                    startActivity(i);
                } catch (Exception e) {
                    // Se o Thunderbird não estiver disponível, deixa o Android
                    // usar a aplicação de e-mail predefinida do telefone.
                    Intent fallback = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
                    fallback.putExtra(Intent.EXTRA_SUBJECT, "AM Clientes");
                    fallback.putExtra(Intent.EXTRA_TEXT, message);
                    startActivity(fallback);
                }
            } else if ("signal".equals(channel)) {
                // Abrir diretamente o Signal e enviar o texto para a composição,
                // sem passar pelo menu geral de partilha do Android.
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, message);
                i.setPackage("org.thoughtcrime.securesms");
                try {
                    startActivity(i);
                } catch (Exception e) {
                    Intent launch = getPackageManager().getLaunchIntentForPackage("org.thoughtcrime.securesms");
                    if (launch == null) throw e;
                    startActivity(launch);
                }
            } else {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, message);
                startActivity(Intent.createChooser(i, "Enviar mensagem"));
            }
        } catch (Exception ignored) {
            copyText(message, "Mensagem copiada.");
        }
    }

    private void renderClientsListInto(LinearLayout host) {
        if (host == null) return;
        host.removeAllViews();
        String q = "";
        // host itself has no search ref; find latest search in parent.
        if (host.getParent() instanceof ViewGroup) {
            ViewGroup parent = (ViewGroup) host.getParent();
            for (int i = 0; i < parent.getChildCount(); i++) {
                View v = parent.getChildAt(i);
                if (v instanceof EditText) q = value((EditText) v).trim().toLowerCase(Locale.ROOT);
            }
        }
        List<JSONObject> list = new ArrayList<>();
        JSONArray a = store.clients();
        for (int i = 0; i < a.length(); i++) {
            JSONObject c = a.optJSONObject(i); if (c == null) continue;
            if (clientContains(c, q)) list.add(c);
        }
        if (list.isEmpty()) host.addView(muted("Nenhum cliente."));
        else for (JSONObject c : list) host.addView(clientCard(c, false));
    }

    private View clientCard(JSONObject c, boolean home) {
        Card row = card();
        setRoundedBackground(row, PANEL, HOME_LINE, 17);
        row.setPadding(dp(13), dp(12), dp(13), dp(12));
        LinearLayout line = new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL); line.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL);
        TextView name = tv(clientName(c), 16, TEXT, true); left.addView(name);
        left.addView(tv(orDash(c.optString("Serviço", "")), 14, MUTED, false));
        left.addView(tv(orDash(c.optString("Contacto", "")), 14, MUTED, false));
        line.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView badge = tv(statusLabel(c), 11, GREEN, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(10), dp(5), dp(10), dp(5));
        String st = status(c);
        int badgeBg = "active".equals(st) ? Color.rgb(10, 72, 45)
                : "warning".equals(st) ? Color.rgb(76, 52, 20)
                : Color.rgb(72, 28, 37);
        int badgeFg = "active".equals(st) ? GREEN
                : "warning".equals(st) ? ORANGE
                : RED;
        setRoundedBackground(badge, badgeBg, 0, 16);
        badge.setTextColor(badgeFg);
        line.addView(badge, new LinearLayout.LayoutParams(-2, -2));
        row.addView(line);
        row.setOnClickListener(v -> {
            String id = c.optString("ID Cliente", null);
            if (home) openHomeClientPreview(id); else { selectedClientId = id; refreshCurrentScreen(); }
        });
        return row;
    }

    private void openClientEditor(String id) {
        selectedClientId = id == null ? null : id;
        if (id == null) {
            try {
                JSONObject fresh = new JSONObject();
                fresh.put("ID Cliente", store.nextClientId());
                fresh.put("Nome", "");
                fresh.put("Nome Empresa", store.activeCompanyName());
                fresh.put("Data Criação", today());
                fresh.put("equipamentos", new JSONArray());
                showNewClientEditor(fresh);
            } catch (Exception e) { alert("Erro", e.getMessage()); }
        } else {
            JSONObject c = store.findClient(id);
            if (c != null) showNewClientEditor(c);
        }
    }

    private void showNewClientEditor(JSONObject original) {
        clearContent();
        content.addView(tv((original.optString("Nome", "").isEmpty() ? "Novo cliente" : "Editar cliente") + " · " + original.optString("ID Cliente", ""), 20, TEXT, true));
        addSpacer(content, 10);
        Card detail = (Card) renderClientEditorCard(original);
        content.addView(detail);
    }

    private View renderClientEditorCard(JSONObject c) {
        Card card = card();
        LinearLayout header = row();
        TextView title = tv("✎ " + clientName(c), 19, TEXT, true);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        Button cancel = button("Cancelar", false); cancel.setOnClickListener(v -> { selectedClientId = null; refreshCurrentScreen(); });
        header.addView(cancel, new LinearLayout.LayoutParams(dp(86), dp(40)));
        card.addView(header);

        final JSONObject work;
        try { work = new JSONObject(c.toString()); } catch (JSONException e) { throw new RuntimeException(e); }
        addEditorField(card, "Nome", "Nome", work);
        addEditorField(card, "Observações", "Observações", work);
        addEditorField(card, "Contacto", "Contacto", work);
        addEditorFieldSpinner(card, "Nome Empresa", "Nome Empresa", store.list("empresas"), work);
        addEditorField(card, "Email", "Email", work);
        addEditorField(card, "Morada", "Morada", work);
        addEditorDateField(card, "Data de criação", "Data Criação", work);

        TextView eqTitle = tv("📦 Equipamentos do cliente", 17, TEXT, true); card.addView(eqTitle); addSpacer(card, 6);
        JSONArray eqs = work.optJSONArray("equipamentos"); if (eqs == null) eqs = new JSONArray();
        LinearLayout eqHost = new LinearLayout(this); eqHost.setOrientation(LinearLayout.VERTICAL); card.addView(eqHost);
        renderEquipmentEditor(eqHost, eqs, work);

        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setGravity(Gravity.CENTER_VERTICAL);
        Button save = primary("💾 Guardar");
        Button archive = button("📁 Arquivar", false);
        Button del = button("🗑️ Apagar", false);
        archive.setOnClickListener(v -> confirm("Arquivar cliente?", "O cliente será movido para Arquivado.", () -> { store.archiveClient(c.optString("ID Cliente")); selectedClientId = null; showScreen("clientes"); }));
        save.setOnClickListener(v -> {
            try {
                JSONObject result = collectClientDraft(card, work);
                store.saveClient(result);
                selectedClientId = result.optString("ID Cliente", null);
                Toast.makeText(this, "Cliente guardado.", Toast.LENGTH_SHORT).show();
                showScreen("clientes");
            } catch (Exception e) { alert("Erro", "Não foi possível guardar o cliente: " + e.getMessage()); }
        });
        del.setOnClickListener(v -> confirm("Apagar cliente?", "Tem a certeza que pretende apagar este cliente?", () -> { store.deleteClient(c.optString("ID Cliente")); selectedClientId = null; showScreen("clientes"); }));
        LinearLayout.LayoutParams a1=new LinearLayout.LayoutParams(0,dp(42),1f);a1.rightMargin=dp(4);
        LinearLayout.LayoutParams a2=new LinearLayout.LayoutParams(0,dp(42),1f);a2.leftMargin=dp(4);a2.rightMargin=dp(4);
        LinearLayout.LayoutParams a3=new LinearLayout.LayoutParams(0,dp(42),1f);a3.leftMargin=dp(4);
        actions.addView(save,a1);actions.addView(archive,a2);actions.addView(del,a3);
        card.addView(actions);
        return card;
    }

    private JSONObject collectClientDraft(Card card, JSONObject work) throws JSONException {
        JSONObject out = new JSONObject(work.toString());
        String[] keys = {"Nome", "Observações", "Contacto", "Email", "Morada", "Data Criação"};
        for (String key : keys) {
            EditText e = (EditText) card.findViewWithTag("f:" + key);
            if (e != null) out.put(key, value(e));
        }
        Spinner company = (Spinner) card.findViewWithTag("s:Nome Empresa");
        if (company != null) out.put("Nome Empresa", String.valueOf(company.getSelectedItem()));
        View eqHost = card.findViewWithTag("equipmentHost");
        if (eqHost != null) out.put("equipamentos", collectEquipmentEditor((LinearLayout) eqHost));
        return out;
    }


    private JSONArray collectEquipmentEditor(LinearLayout host) throws JSONException {
        JSONArray out = new JSONArray();
        for (int i = 0; i < host.getChildCount(); i++) {
            View v = host.getChildAt(i); if (!(v instanceof Card)) continue;
            Card card = (Card) v;
            JSONObject e = new JSONObject();
            e.put("id", String.valueOf(card.getTag() == null ? uuid("eq") : card.getTag()));
            String[] fields = {"tipo","nome","mac","utilizador","senha","link","servico","subscricao","metodoPagamento","dataInstalacao","dataPagamento","validade","valorPago"};
            for (String f : fields) {
                EditText ed = (EditText) card.findViewWithTag("eq:" + f);
                if (ed != null) e.put(f, value(ed));
            }
            Spinner payment = (Spinner) card.findViewWithTag("eqs:metodoPagamento");
            if (payment != null) e.put("metodoPagamento", String.valueOf(payment.getSelectedItem()));
            syncAssignmentArraysFromEditor(card, e);
            Object nested = card.getTag(TAG_JSON);
            if (nested instanceof JSONObject) {
                JSONObject saved = (JSONObject) nested;
                if (saved.optJSONArray("vpns") != null && e.optJSONArray("subscricoes") != null && e.optJSONArray("subscricoes").length() == 0) {
                    e.put("vpns", new JSONArray(saved.optJSONArray("vpns").toString()));
                }
            }
            e.put("saldo", String.valueOf(Math.round(equipmentBalance(e))));
            out.put(e);
        }
        return out;
    }

    private JSONArray collectJsonListTag(ViewGroup card, String prefix) throws JSONException {
        JSONArray a = new JSONArray();
        ViewGroup host = card.findViewWithTag(prefix + "Host");
        if (host == null) return a;
        for (int i = 0; i < host.getChildCount(); i++) {
            View child = host.getChildAt(i); if (!(child instanceof Card)) continue;
            Card c = (Card) child;
            JSONObject o = new JSONObject();
            for (int j = 0; j < ((ViewGroup) c).getChildCount(); j++) {
                View vv = c.getChildAt(j);
                if (vv instanceof LinearLayout) {
                    o.put("nome", textFromTag((ViewGroup) vv, prefix + ":nome"));
                }
            }
            a.put(o);
        }
        return a;
    }

    private String textFromTag(ViewGroup host, String tag) {
        View v = host.findViewWithTag(tag);
        return v instanceof EditText ? value((EditText)v) : "";
    }

    private void addEditorField(ViewGroup host, String label, String key, JSONObject obj){LinearLayout block=fieldBlock(label);EditText e=editorEdit(orDash(obj.optString(key,"")));e.setTag("f:"+key);if(obj.has(key))e.setText(obj.optString(key,""));block.addView(e);host.addView(block);addSpacer(host,8);}
    private void addEditorFieldSpinner(ViewGroup host,String label,String key,JSONArray options,JSONObject obj){LinearLayout block=fieldBlock(label);Spinner sp=editorSpinner(optionsToList(options),obj.optString(key,""));sp.setTag("s:"+key);block.addView(sp);host.addView(block);addSpacer(host,8);}
    private void addEditorDateField(ViewGroup host,String label,String key,JSONObject obj){LinearLayout block=fieldBlock(label);EditText e=editorEdit("Selecionar data");e.setTag("f:"+key);e.setFocusable(false);e.setClickable(true);e.setText(obj.optString(key,""));e.setOnClickListener(v->pickDate(e));block.addView(e);host.addView(block);addSpacer(host,8);}
    private void addEditorEquipmentField(Card c,String label,String key,String value,boolean numeric){EditText e=editorEdit(label);e.setTag("eq:"+key);e.setText(value);if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);c.addView(fieldBlockWith(labelOnly(label),e));addSpacer(c,6);}
    private void addEditorEquipmentSpinner(Card c,String label,String key,List<String> values,String current){Spinner s=editorSpinner(values,current);s.setTag("eqs:"+key);c.addView(fieldBlockWith(labelOnly(label),s));addSpacer(c,6);}
    private void addEditorEquipmentDate(Card c,String label,String key,String value){EditText e=editorEdit("Selecionar data");e.setFocusable(false);e.setTag("eq:"+key);e.setText(value);e.setOnClickListener(v->pickDate(e));c.addView(fieldBlockWith(labelOnly(label),e));addSpacer(c,6);}

    private void addField(ViewGroup host, String label, String key, JSONObject obj) {
        LinearLayout block = fieldBlock(label);
        EditText e = edit(orDash(obj.optString(key, "")), 14);
        e.setHint(orDash(obj.optString(key, "")));
        e.setTag("f:" + key);
        if (obj.has(key)) e.setText(obj.optString(key, ""));
        block.addView(e);
        host.addView(block); addSpacer(host, 8);
    }

    private void addFieldSpinner(ViewGroup host, String label, String key, JSONArray options, JSONObject obj) {
        LinearLayout block = fieldBlock(label);
        Spinner s = spinner(optionsToList(options), obj.optString(key, ""));
        s.setTag("s:" + key);
        block.addView(s); host.addView(block); addSpacer(host, 8);
    }

    private void addDateField(ViewGroup host, String label, String key, JSONObject obj) {
        LinearLayout block = fieldBlock(label);
        EditText e = edit("Selecionar data", 14); e.setTag("f:" + key); e.setFocusable(false); e.setClickable(true);
        e.setText(obj.optString(key, ""));
        e.setOnClickListener(v -> pickDate(e));
        block.addView(e); host.addView(block); addSpacer(host, 8);
    }

    private LinearLayout fieldBlock(String label) {
        LinearLayout b = new LinearLayout(this); b.setOrientation(LinearLayout.VERTICAL);
        TextView l = tv(label, 11, MUTED, false); b.addView(l); addSpacer(b, 4); return b;
    }

    private void renderEquipmentEditor(LinearLayout host, JSONArray eqs, JSONObject client) {
        host.setTag("equipmentHost");
        host.removeAllViews();
        for (int i = 0; i < eqs.length(); i++) {
            JSONObject e = eqs.optJSONObject(i); if (e == null) continue;
            host.addView(equipmentCard(host, e, i)); addSpacer(host, 8);
        }
        Button add = primary("＋ Novo equipamento");
        add.setOnClickListener(v -> {
            try { JSONObject e = new JSONObject(); e.put("id", uuid("eq")); e.put("servicos", new JSONArray()); e.put("subscricoes", new JSONArray()); e.put("vpns", new JSONArray());
                host.removeView(add); host.addView(equipmentCard(host, e, host.getChildCount())); addSpacer(host,8); host.addView(add, new LinearLayout.LayoutParams(-1,dp(42))); }
            catch (Exception ex) { alert("Erro", ex.getMessage()); }
        });
        host.addView(add, new LinearLayout.LayoutParams(-1, dp(42)));
    }

    private Card equipmentCard(LinearLayout host, JSONObject e, int index) {
        Card c=card(); c.setTag(e.optString("id",uuid("eq")));
        try{c.setTag(TAG_JSON,new JSONObject(e.toString()));}catch(Exception ignored){c.setTag(TAG_JSON,new JSONObject());}
        LinearLayout head=row(); TextView title=tv("Equipamento "+(index+1),16,TEXT,true); head.addView(title,new LinearLayout.LayoutParams(0,-2,1f));
        Button remove=button("🗑️ Remover",false); remove.setOnClickListener(v->confirm("Remover equipamento?","Tem a certeza que pretende remover este equipamento?",()->host.removeView(c)));
        head.addView(remove,new LinearLayout.LayoutParams(dp(115),dp(40))); c.addView(head); addSpacer(c,8);

        addEditorEquipmentField(c,"Tipo de Equipamento","tipo",e.optString("tipo",""),false);
        addEditorEquipmentField(c,"Nome do Equipamento","nome",e.optString("nome",""),false);
        addEditorEquipmentField(c,"Identificação MAC","mac",e.optString("mac",""),false);
        addEditorEquipmentField(c,"Utilizador","utilizador",e.optString("utilizador",""),false);
        addEditorEquipmentField(c,"Senha","senha",e.optString("senha",""),false);
        addEditorEquipmentField(c,"Link","link",e.optString("link",""),false);

        LinearLayout serviceHost=new LinearLayout(this);serviceHost.setOrientation(LinearLayout.VERTICAL);serviceHost.setTag("serviceRowsHost");c.addView(serviceHost);
        JSONArray sr=mergedServiceRows(e);for(int i=0;i<sr.length();i++)addServiceRow(serviceHost,sr.optJSONObject(i),i);

        LinearLayout subHost=new LinearLayout(this);subHost.setOrientation(LinearLayout.VERTICAL);subHost.setTag("subscriptionRowsHost");c.addView(subHost);
        JSONArray subr=mergedSubscriptionRows(e);for(int i=0;i<subr.length();i++)addSubscriptionRow(subHost,subr.optJSONObject(i),i);

        addEditorEquipmentSpinner(c,"Tipo de pagamento","metodoPagamento",optionsToList(store.list("pagamentos")),e.optString("metodoPagamento",""));
        addEditorEquipmentDate(c,"Data de início de serviço","dataInstalacao",e.optString("dataInstalacao",""));
        addEditorEquipmentDate(c,"Data do pagamento","dataPagamento",e.optString("dataPagamento",""));
        addEditorEquipmentDate(c,"Validade","validade",e.optString("validade",""));
        addEditorEquipmentField(c,"Valor pago","valorPago",e.optString("valorPago",""),true);
        EditText saldo=editorEdit("Saldo");saldo.setTag("eq:saldo");saldo.setText(formatEuro(equipmentBalance(e)));saldo.setFocusable(false);c.addView(fieldBlockWith(labelOnly("Saldo"),saldo));addSpacer(c,8);

        LinearLayout actionRows=row();
        Button addService=primary("Adicionar serviço");Button addSub=primary("Adicionar subscrição");
        actionRows.addView(addService,new LinearLayout.LayoutParams(0,dp(42),1f));LinearLayout.LayoutParams subLp=new LinearLayout.LayoutParams(0,dp(42),1f);subLp.leftMargin=dp(4);actionRows.addView(addSub,subLp);c.addView(actionRows);addSpacer(c,8);
        addService.setOnClickListener(v->addServiceRow(serviceHost,null,serviceHost.getChildCount()));
        addSub.setOnClickListener(v->addSubscriptionRow(subHost,null,subHost.getChildCount()));

        TextView total=tv("Total deste equipamento: "+formatEuro(equipmentTotal(e)),14,TEXT,true);total.setGravity(Gravity.END);c.addView(total);
        return c;
    }

    private JSONArray mergedServiceRows(JSONObject e){JSONArray out=new JSONArray();try{JSONArray a=e.optJSONArray("servicos");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)out.put(new JSONObject(x.toString()));}if(out.length()==0){String n=e.optString("servico","");if(!n.isEmpty())out.put(new JSONObject().put("nome",n).put("valor",store.serviceValue(n)));}}catch(Exception ignored){}return out;}
    private JSONArray mergedSubscriptionRows(JSONObject e){JSONArray out=new JSONArray();try{JSONArray a=e.optJSONArray("subscricoes");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)out.put(new JSONObject(x.toString()));}if(out.length()==0){JSONArray v=e.optJSONArray("vpns");if(v!=null)for(int i=0;i<v.length();i++){JSONObject x=v.optJSONObject(i);if(x!=null)out.put(new JSONObject(x.toString()));}}if(out.length()==0){String n=e.optString("subscricao","");if(!n.isEmpty())out.put(new JSONObject().put("name",n).put("subscricao",n).put("valor",subscriptionSaleValue(n)));}}catch(Exception ignored){}return out;}

    private void addServiceRow(LinearLayout host,JSONObject existing,int index){
        LinearLayout block=new LinearLayout(this);block.setOrientation(LinearLayout.VERTICAL);block.setTag("serviceRow");
        block.addView(labelOnly("Serviço "+(rowCountByTag(host,"serviceRow")+1)));addSpacer(block,4);
        Spinner s=editorSpinner(store.serviceNames(),existing==null?"":existing.optString("nome",existing.optString("name","")));s.setTag("srvSpinner");
        block.addView(s,new LinearLayout.LayoutParams(-1,dp(42)));addSpacer(block,6);
        LinearLayout priceRow=row();EditText value=editorEdit("0 €");value.setTag("srvValue");String selected=existing==null?"":existing.optString("nome",existing.optString("name",""));if(existing!=null&&existing.has("valor"))value.setText(formatEuro(existing.optDouble("valor",0)));else if(!selected.isEmpty())value.setText(formatEuro(store.serviceValue(selected)));priceRow.addView(value,new LinearLayout.LayoutParams(0,dp(42),1f));
        Button del=button("🗑",false);del.setOnClickListener(v->{host.removeView(block);renumberRows(host,"serviceRow","Serviço ");});priceRow.addView(del,new LinearLayout.LayoutParams(dp(48),dp(42)));block.addView(priceRow);host.addView(block);addSpacer(host,6);
        s.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){@Override public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){String n=String.valueOf(p.getSelectedItem());if(!n.isEmpty())value.setText(formatEuro(store.serviceValue(n)));}@Override public void onNothingSelected(android.widget.AdapterView<?> p){}});
    }
    private void addSubscriptionRow(LinearLayout host,JSONObject existing,int index){
        LinearLayout block=new LinearLayout(this);block.setOrientation(LinearLayout.VERTICAL);block.setTag("subscriptionRow");
        block.addView(labelOnly("Subscrição "+(rowCountByTag(host,"subscriptionRow")+1)));addSpacer(block,4);
        Spinner s=editorSpinner(subscriptionNamesWithPacks(),existing==null?"":existing.optString("subscricao",existing.optString("name","")));s.setTag("subSpinner");
        block.addView(s,new LinearLayout.LayoutParams(-1,dp(42)));addSpacer(block,6);
        LinearLayout priceRow=row();EditText value=editorEdit("0 €");value.setTag("subValue");String selected=existing==null?"":existing.optString("subscricao",existing.optString("name",""));if(existing!=null&&existing.has("valor"))value.setText(formatEuro(existing.optDouble("valor",0)));else if(!selected.isEmpty())value.setText(formatEuro(subscriptionSaleValue(selected)));priceRow.addView(value,new LinearLayout.LayoutParams(0,dp(42),1f));
        Button del=button("🗑",false);del.setOnClickListener(v->{host.removeView(block);renumberRows(host,"subscriptionRow","Subscrição ");});priceRow.addView(del,new LinearLayout.LayoutParams(dp(48),dp(42)));block.addView(priceRow);host.addView(block);addSpacer(host,6);
    }
    private int rowCountByTag(ViewGroup host,String tag){int n=0;for(int i=0;i<host.getChildCount();i++)if(tag.equals(host.getChildAt(i).getTag()))n++;return n;}
    private void renumberRows(ViewGroup host,String tag,String prefix){int n=1;for(int i=0;i<host.getChildCount();i++){View v=host.getChildAt(i);if(!tag.equals(v.getTag())||!(v instanceof ViewGroup))continue;ViewGroup g=(ViewGroup)v;for(int j=0;j<g.getChildCount();j++){View x=g.getChildAt(j);if(x instanceof TextView){TextView t=(TextView)x;if(t.getText().toString().startsWith(prefix)){t.setText(prefix+n);n++;break;}}}}}

    private double equipmentTotal(JSONObject e){double total=0;JSONArray services=e.optJSONArray("servicos");if(services!=null&&services.length()>0){for(int i=0;i<services.length();i++){JSONObject x=services.optJSONObject(i);if(x!=null)total+=x.optDouble("valor",0);}}else total+=money(e.optString("servicoValor","0"));JSONArray subs=e.optJSONArray("subscricoes");if(subs!=null&&subs.length()>0){for(int i=0;i<subs.length();i++){JSONObject x=subs.optJSONObject(i);if(x!=null)total+=x.optDouble("valor",subscriptionSaleValue(x.optString("name",x.optString("subscricao",""))));}}else{JSONArray vpns=e.optJSONArray("vpns");if(vpns!=null&&vpns.length()>0){for(int i=0;i<vpns.length();i++){JSONObject x=vpns.optJSONObject(i);if(x!=null)total+=x.optDouble("valor",subscriptionSaleValue(x.optString("subscricao","")));}}else total+=money(e.optString("subscricaoValor","0"));}return total;}
    private double equipmentBalance(JSONObject e){return money(e.optString("valorPago","0"))-equipmentTotal(e);}
    private void syncAssignmentArraysFromEditor(Card card,JSONObject e)throws JSONException{JSONArray services=new JSONArray();ViewGroup sh=card.findViewWithTag("serviceRowsHost");if(sh!=null)for(int i=0;i<sh.getChildCount();i++){View rv=sh.getChildAt(i);if(!(rv instanceof LinearLayout)||!"serviceRow".equals(rv.getTag()))continue;Spinner s=(Spinner)rv.findViewWithTag("srvSpinner");EditText v=(EditText)rv.findViewWithTag("srvValue");String n=value(s);if(!n.isEmpty())services.put(new JSONObject().put("serviceId",n).put("nome",n).put("valor",money(value(v))));}e.put("servicos",services);e.put("servico",services.length()>0?services.optJSONObject(0).optString("nome",""):"");e.put("servicoValor",services.length()>0?services.optJSONObject(0).optDouble("valor",0):0);JSONArray subs=new JSONArray();ViewGroup uh=card.findViewWithTag("subscriptionRowsHost");if(uh!=null)for(int i=0;i<uh.getChildCount();i++){View rv=uh.getChildAt(i);if(!(rv instanceof LinearLayout)||!"subscriptionRow".equals(rv.getTag()))continue;Spinner sp=(Spinner)rv.findViewWithTag("subSpinner");EditText v=(EditText)rv.findViewWithTag("subValue");String n=value(sp);if(!n.isEmpty())subs.put(new JSONObject().put("name",n).put("subscricao",n).put("valor",money(value(v))));}e.put("subscricoes",subs);e.put("subscricao",subs.length()>0?subs.optJSONObject(0).optString("name",""):"");e.put("subscricaoValor",subs.length()>0?subs.optJSONObject(0).optDouble("valor",0):0);}

    private TextView labelOnly(String text){return tv(text,11,MUTED,false);}
    private LinearLayout fieldBlockWith(TextView label,View value){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.addView(label);addSpacer(b,4);b.addView(value);return b;}

    // ========================== SUBSCRIÇÕES =============================

    private void renderSubscriptionsScreen() {
        TextView title = tv("🔐 Serviços e subscrições", 20, TEXT, true); content.addView(title); addSpacer(content, 10);
        Card services = card(); LinearLayout sh = row(); sh.addView(tv("🛠️ Serviços",17,TEXT,true), new LinearLayout.LayoutParams(0,-2,1f)); Button add=primary("＋ Adicionar serviço"); sh.addView(add,new LinearLayout.LayoutParams(dp(155),dp(40))); services.addView(sh);
        add.setOnClickListener(v -> openServiceDialog(-1));
        JSONArray svc=store.serviceCatalog(); for(int i=0;i<svc.length();i++){JSONObject s=svc.optJSONObject(i);if(s==null)continue;final int idx=i;services.addView(catalogMiniRow(s.optString("name"),formatEuro(s.optDouble("value",0)),()->openServiceDialog(idx)));}
        content.addView(services); addSpacer(content,12);

        Card create=card(); LinearLayout ch=row(); ch.addView(tv("🔐 Subscrições",17,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f)); Button ca=primary("＋ Adicionar");ch.addView(ca,new LinearLayout.LayoutParams(dp(100),dp(40)));create.addView(ch);
        ca.setOnClickListener(v->openSubscriptionDialog(-1));
        content.addView(create); addSpacer(content,10);

        JSONArray subs=store.subscriptions(); if(subs.length()==0) content.addView(muted("Ainda não existem subscrições."));
        for(int i=0;i<subs.length();i++){JSONObject s=subs.optJSONObject(i);if(s==null)continue; content.addView(subscriptionCard(s,i));addSpacer(content,8);}
    }

    private View catalogMiniRow(String left,String right,Runnable edit){ Card c=card();LinearLayout r=row();TextView l=tv(left,14,TEXT,true);r.addView(l,new LinearLayout.LayoutParams(0,-2,1f));r.addView(tv(right,13,MUTED,false));Button b=button("✎",false);b.setOnClickListener(v->edit.run());r.addView(b,new LinearLayout.LayoutParams(dp(48),dp(40)));c.addView(r);return c; }

    private Card subscriptionCard(JSONObject s,int index){
        Card c=card();
        LinearLayout h=row();TextView l=tv("🔐 "+orDash(s.optString("name",s.optString("type","Subscrição"))),15,TEXT,true);h.addView(l,new LinearLayout.LayoutParams(0,-2,1f));
        SubSummary sm=subSummary(s);TextView counter=tv(sm.consumed+"/"+sm.purchased,13,TEXT,true);counter.setGravity(Gravity.CENTER);h.addView(counter,new LinearLayout.LayoutParams(dp(62),dp(36)));c.addView(h);
        if(!s.optString("client","").isEmpty()) c.addView(muted(s.optString("client")));
        c.addView(muted("Compradas: "+sm.purchased+" · Utilizadas: "+sm.consumed+" · Disponíveis: "+sm.available));
        if(!s.optString("endDate","").isEmpty()) c.addView(muted("Validade: "+formatDate(s.optString("endDate"))));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        Button equip=primary("+ Equipamento"), move=button("+ Movimento",false), edit=button("✎ Editar",false), del=button("🗑 Apagar",false);
        equip.setOnClickListener(v->openSubDeviceDialog(index)); move.setOnClickListener(v->openMovementDialog(index,-1)); edit.setOnClickListener(v->openSubscriptionDialog(index)); del.setOnClickListener(v->confirm("Apagar subscrição?","Tem a certeza?",()->{store.deleteSubscription(index);showScreen("subscricoes");}));
        actions.addView(equip,new LinearLayout.LayoutParams(0,dp(42),1f));actions.addView(move,new LinearLayout.LayoutParams(0,dp(42),1f));actions.addView(edit,new LinearLayout.LayoutParams(0,dp(42),1f));actions.addView(del,new LinearLayout.LayoutParams(dp(100),dp(42)));c.addView(actions);
        JSONArray dev=s.optJSONArray("devices");if(dev!=null){for(int i=0;i<dev.length();i++){JSONObject d=dev.optJSONObject(i);if(d!=null)c.addView(muted("• "+orDash(d.optString("name",""))+"  "+orDash(d.optString("person",""))+"  "+orDash(d.optString("location",""))));}}
        Button movements=button("Movimentos",false);movements.setOnClickListener(v->showSubscriptionMovementsDialog(s,index));c.addView(movements,new LinearLayout.LayoutParams(-1,dp(40)));
        return c;
    }

    private void openServiceDialog(int index){
        JSONObject existing=index>=0?store.serviceCatalog().optJSONObject(index):null;
        EditText name=edit("Nome do serviço",14), value=edit("Valor (€)",14);value.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        if(existing!=null){name.setText(existing.optString("name",""));value.setText(String.valueOf(existing.optDouble("value",0)));}
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(8),dp(8),dp(8),dp(8));form.addView(fieldBlockWith(labelOnly("Nome"),name));form.addView(fieldBlockWith(labelOnly("Valor"),value));
        AlertDialog d=new AlertDialog.Builder(this).setTitle(index>=0?"Editar serviço":"Adicionar serviço").setView(form).setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{JSONObject obj=new JSONObject();obj.put("id",existing==null?uuid("svc"):existing.optString("id",uuid("svc")));obj.put("name",value(name));obj.put("value",money(value(value)));store.saveService(index,obj);d.dismiss();showScreen("subscricoes");}catch(Exception e){alert("Erro",e.getMessage());}}));d.show();
    }

    private void openSubscriptionDialog(int index){
        JSONObject existing=index>=0?store.subscriptions().optJSONObject(index):null;
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(8),dp(8),dp(8),dp(8));
        EditText type=edit("Tipo de serviço",14), name=edit("Nome do serviço",14), client=edit("Nome do cliente",14), limit=edit("Quantidade de licenças",14);limit.setInputType(InputType.TYPE_CLASS_NUMBER);EditText used=edit("Licenças utilizadas",14);used.setInputType(InputType.TYPE_CLASS_NUMBER);EditText pDate=edit("Selecionar data",14);pDate.setFocusable(false);pDate.setOnClickListener(v->pickDate(pDate));EditText start=edit("Selecionar data",14);start.setFocusable(false);start.setOnClickListener(v->pickDate(start));EditText months=edit("Meses",14);months.setInputType(InputType.TYPE_CLASS_NUMBER);EditText end=edit("Selecionar data",14);end.setFocusable(false);end.setOnClickListener(v->pickDate(end));EditText cost=edit("Custo (€)",14);cost.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);EditText revenue=edit("Receita prevista (€)",14);revenue.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        Spinner validity=spinner(asList("purchase: Validade desde a compra","activation: Validade desde a ativação"),"purchase: Validade desde a compra"); Spinner rule=spinner(asList("normal: Normal — 1 por 1","6for5: Promoção — 6 por 5"),"normal: Normal — 1 por 1"); Spinner kind=spinner(asList("subscription: Subscrição normal","pack: Pack"),"subscription: Subscrição normal"); EditText components=edit("Nomes das subscrições incluídas, separados por vírgula",14);
        form.addView(fieldBlockWith(labelOnly("Tipo"),type));form.addView(fieldBlockWith(labelOnly("Nome"),name));form.addView(fieldBlockWith(labelOnly("Cliente"),client));form.addView(fieldBlockWith(labelOnly("Quantidade de licenças"),limit));form.addView(fieldBlockWith(labelOnly("Regra de compra"),rule));form.addView(fieldBlockWith(labelOnly("Tipo de validade"),validity));form.addView(fieldBlockWith(labelOnly("Licenças utilizadas"),used));form.addView(fieldBlockWith(labelOnly("Data de compra"),pDate));form.addView(fieldBlockWith(labelOnly("Data de início"),start));form.addView(fieldBlockWith(labelOnly("Validade em meses"),months));form.addView(fieldBlockWith(labelOnly("Data de fim"),end));form.addView(fieldBlockWith(labelOnly("Custo"),cost));form.addView(fieldBlockWith(labelOnly("Receita prevista"),revenue));form.addView(fieldBlockWith(labelOnly("Tipo de subscrição"),kind));
        if(existing!=null){type.setText(existing.optString("type",""));name.setText(existing.optString("name",""));client.setText(existing.optString("client",""));limit.setText(String.valueOf(existing.optInt("limit",10)));used.setText(String.valueOf(existing.optInt("licenseUsed",0)));pDate.setText(existing.optString("purchaseDate",""));start.setText(existing.optString("startDate",""));months.setText(String.valueOf(existing.optInt("validityMonths",0)));end.setText(existing.optString("endDate",""));cost.setText(String.valueOf(existing.optDouble("cost",0)));revenue.setText(String.valueOf(existing.optDouble("revenue",0)));}
        if(existing!=null){ JSONArray comps=existing.optJSONArray("components"); if(comps!=null){StringBuilder sb=new StringBuilder();for(int i=0;i<comps.length();i++){JSONObject co=comps.optJSONObject(i);String n=co!=null?co.optString("name",""):String.valueOf(comps.opt(i));if(!n.isEmpty()){if(sb.length()>0)sb.append(", ");sb.append(n);}}components.setText(sb.toString());}}
        AlertDialog d=new AlertDialog.Builder(this).setTitle(index>=0?"Editar subscrição":"Adicionar subscrição").setView(form).setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null).create();
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{JSONObject s=existing==null?new JSONObject():new JSONObject(existing.toString());s.put("id",s.optString("id",uuid("SUB")));s.put("type",value(type));s.put("name",value(name));s.put("client",value(client));s.put("limit",Math.max(1,(int)money(value(limit))));s.put("licenseUsed",Math.max(0,(int)money(value(used))));s.put("purchaseDate",value(pDate));s.put("startDate",value(start));s.put("validityMonths",Math.max(0,(int)money(value(months))));s.put("endDate",value(end));s.put("cost",money(value(cost)));s.put("revenue",money(value(revenue)));s.put("purchaseRule",splitBeforeColon(String.valueOf(rule.getSelectedItem())));s.put("kind",splitBeforeColon(String.valueOf(kind.getSelectedItem())));s.put("validityType",splitBeforeColon(String.valueOf(validity.getSelectedItem()))); JSONArray compArr=new JSONArray(); for(String cn : value(components).split(",")){String n=cn.trim();if(n.isEmpty())continue;JSONObject cs=findSubscription(n);JSONObject co=new JSONObject().put("name",n).put("costSnapshot",cs==null?0:cs.optDouble("cost",0)).put("purchaseRuleSnapshot",cs==null?"normal":cs.optString("purchaseRule","normal"));compArr.put(co);} if("pack".equals(splitBeforeColon(String.valueOf(kind.getSelectedItem()))))s.put("components",compArr);else s.remove("components"); if(!s.has("movements"))s.put("movements",new JSONArray());if(!s.has("devices"))s.put("devices",new JSONArray());if(!s.has("initialPurchaseRecorded")){JSONArray m=new JSONArray();m.put(new JSONObject().put("type","purchase").put("quantity",s.optInt("limit",1)).put("date",s.optString("purchaseDate",today())).put("cost",s.optDouble("cost",0)).put("initial",true));s.put("movements",m);s.put("initialPurchaseRecorded",true);}store.saveSubscription(index,s);d.dismiss();showScreen("subscricoes");}catch(Exception e){alert("Erro",e.getMessage());}}));d.show();
    }

    private void openMovementDialog(int si,int mi){
        JSONObject s=store.subscriptions().optJSONObject(si);if(s==null)return;
        JSONObject existing=null;JSONArray a=s.optJSONArray("movements");if(a!=null&&mi>=0)existing=a.optJSONObject(mi);
        Spinner type=spinner(asList("purchase: Compra","activation: Ativação","renewal: Renovação"),"purchase: Compra");EditText qty=edit("Quantidade",14);qty.setInputType(InputType.TYPE_CLASS_NUMBER);EditText date=edit("Selecionar data",14);date.setFocusable(false);date.setOnClickListener(v->pickDate(date));EditText cost=edit("Custo total (€)",14);cost.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);EditText client=edit("Cliente",14);EditText months=edit("Validade em meses",14);months.setInputType(InputType.TYPE_CLASS_NUMBER);EditText start=edit("Data de ativação",14);start.setFocusable(false);start.setOnClickListener(v->pickDate(start));EditText end=edit("Data de fim",14);end.setFocusable(false);end.setOnClickListener(v->pickDate(end));
        LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(8),dp(8),dp(8),dp(8));f.addView(fieldBlockWith(labelOnly("Tipo"),type));f.addView(fieldBlockWith(labelOnly("Quantidade"),qty));f.addView(fieldBlockWith(labelOnly("Data"),date));f.addView(fieldBlockWith(labelOnly("Custo"),cost));f.addView(fieldBlockWith(labelOnly("Cliente"),client));f.addView(fieldBlockWith(labelOnly("Meses"),months));f.addView(fieldBlockWith(labelOnly("Ativação"),start));f.addView(fieldBlockWith(labelOnly("Fim"),end));
        if(existing!=null){type.setSelection(findSpinner(asList("purchase: Compra","activation: Ativação","renewal: Renovação"),existing.optString("type","purchase")));qty.setText(String.valueOf(existing.optInt("quantity",0)));date.setText(existing.optString("date",today()));cost.setText(String.valueOf(existing.optDouble("cost",0)));client.setText(existing.optString("client",""));months.setText(String.valueOf(existing.optInt("months",0)));start.setText(existing.optString("startDate",""));end.setText(existing.optString("endDate",""));}
        final int movementIndex = mi;
        final int subscriptionIndex = si;
        final JSONObject subscription = s;
        final JSONObject existingMovement = existing;
        final AlertDialog d=new AlertDialog.Builder(this).setTitle(movementIndex>=0?"Editar movimento":"Adicionar movimento").setView(f).setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null).create();
        d.setOnShowListener(x->{
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                try{
                    String mt=splitBeforeColon(String.valueOf(type.getSelectedItem()));
                    int q=Math.max(1,(int)money(value(qty)));
                    SubSummary current=subSummary(subscription);
                    if(!"purchase".equals(mt)&&q>current.available){alert("Aviso","Não tens licenças suficientes disponíveis. Disponíveis: "+current.available);return;}
                    JSONObject m=existingMovement==null?new JSONObject():new JSONObject(existingMovement.toString());
                    m.put("type",mt);m.put("quantity",q);m.put("date",value(date).isEmpty()?today():value(date));m.put("cost",money(value(cost)));m.put("client",value(client));m.put("months",Math.max(0,(int)money(value(months))));m.put("startDate",value(start));m.put("endDate",value(end));
                    if(m.optInt("months",0)>0&&("activation".equals(mt)||"renewal".equals(mt))&&m.optString("startDate","").length()==10)m.put("endDate",plusMonths(m.optString("startDate"),m.optInt("months")));
                    JSONArray arr=subscription.optJSONArray("movements");if(arr==null)arr=new JSONArray();if(movementIndex>=0)arr.put(movementIndex,m);else arr.put(m);subscription.put("movements",arr);
                    store.saveSubscription(subscriptionIndex,subscription);d.dismiss();showScreen("subscricoes");
                }catch(Exception e){alert("Erro",e.getMessage());}
            });
        });
        d.show();
    }

    private void showSubscriptionMovementsDialog(JSONObject s,int si){JSONArray a=s.optJSONArray("movements");LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);if(a==null||a.length()==0)box.addView(muted("Sem movimentos."));else for(int i=0;i<a.length();i++){JSONObject m=a.optJSONObject(i);if(m==null)continue;LinearLayout r=row();r.addView(tv(splitBeforeColonLabel(m.optString("type","purchase"))+" · "+m.optInt("quantity",0),14,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));Button ed=button("✎",false),del=button("🗑",false);final int mi=i;ed.setOnClickListener(v->{showDialogDismiss();openMovementDialog(si,mi);});del.setOnClickListener(v->confirm("Apagar movimento?","Tem a certeza?",()->{store.deleteMovement(si,mi);showSubscriptionMovementsDialog(store.subscriptions().optJSONObject(si),si);}));r.addView(ed,new LinearLayout.LayoutParams(dp(48),dp(40)));r.addView(del,new LinearLayout.LayoutParams(dp(55),dp(40)));box.addView(r);addSpacer(box,5);}AlertDialog d=new AlertDialog.Builder(this).setTitle("Movimentos").setView(box).setPositiveButton("Fechar",null).create();activeDialog=d;d.show(); }
    private AlertDialog activeDialog;
    private void showDialogDismiss(){if(activeDialog!=null)activeDialog.dismiss();}

    private void openSubDeviceDialog(int si){
        EditText name=edit("Nome do equipamento",14), person=edit("Pessoa",14), location=edit("Local",14);LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(8),dp(8),dp(8),dp(8));f.addView(fieldBlockWith(labelOnly("Nome"),name));f.addView(fieldBlockWith(labelOnly("Pessoa"),person));f.addView(fieldBlockWith(labelOnly("Local"),location));AlertDialog d=new AlertDialog.Builder(this).setTitle("Associar equipamento").setView(f).setPositiveButton("Adicionar",null).setNegativeButton("Cancelar",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{JSONObject s=store.subscriptions().optJSONObject(si);JSONArray a=s.optJSONArray("devices");if(a==null)a=new JSONArray();a.put(new JSONObject().put("name",value(name)).put("person",value(person)).put("location",value(location)));s.put("devices",a);store.saveSubscription(si,s);d.dismiss();showScreen("subscricoes");}catch(Exception e){alert("Erro",e.getMessage());}}));d.show();
    }

    // ============================== CATÁLOGOS ============================

    private void renderCatalogs(){
        Card panel=card();
        LinearLayout head=row();
        head.addView(tv("📦 Catálogos",20,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));
        Button close=primary("Fechar");close.setOnClickListener(v->showScreen("inicio"));
        head.addView(close,new LinearLayout.LayoutParams(dp(72),dp(40)));
        panel.addView(head);
        addSpacer(panel,6);
        panel.addView(muted("Base de referência para equipamentos, produtos, serviços e marcas."));
        addSpacer(panel,10);
        String[] types={"equipamentos","produtos","servicos","marcas"};
        String[] titles={"📹 Equipamentos","📦 Produtos / Consumíveis","🛠️ Serviços","🏷️ Marcas"};
        String[] descs={"Para instalação em clientes","Material e consumíveis com stock","Serviços e mão de obra","De equipamentos e produtos"};
        for(int i=0;i<types.length;i++){
            final String type=types[i];
            Card c=card();
            c.setPadding(dp(16),dp(12),dp(16),dp(12));
            c.addView(tv(titles[i],16,TEXT,true));
            c.addView(muted(descs[i]));
            c.setOnClickListener(v->showCatalogList(type));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);
            cp.setMargins(dp(16),0,dp(16),dp(8));
            panel.addView(c,cp);
        }
        content.addView(panel);
    }

    private void showCatalogList(String type){
        clearContent();content.addView(tv(iconForCatalog(type)+" "+titleForCatalog(type),20,TEXT,true));addSpacer(content,8);Button back=button("← Voltar",false);back.setOnClickListener(v->showScreen("catalogos"));content.addView(back,new LinearLayout.LayoutParams(-1,dp(40)));addSpacer(content,8);Button add=primary("＋ Adicionar");add.setOnClickListener(v->openCatalogItemDialog(type,-1));content.addView(add,new LinearLayout.LayoutParams(-1,dp(42)));addSpacer(content,8);
        JSONArray a=store.catalog(type);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;Card c=card();LinearLayout r=row();r.addView(tv(o.optString("nome", "Sem nome"),15,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));Button e=button("✎",false),d=button("🗑",false);final int idx=i;e.setOnClickListener(v->openCatalogItemDialog(type,idx));d.setOnClickListener(v->confirm("Apagar item?","Tem a certeza?",()->{store.deleteCatalog(type,idx);showCatalogList(type);}));r.addView(e,new LinearLayout.LayoutParams(dp(48),dp(40)));r.addView(d,new LinearLayout.LayoutParams(dp(55),dp(40)));c.addView(r);if(!"marcas".equals(type)){c.addView(muted(summaryCatalogItem(type,o)));}content.addView(c);addSpacer(content,8);} }

    private void openCatalogItemDialog(String type,int index){
        JSONObject existing=index>=0?store.catalog(type).optJSONObject(index):null;LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(8),dp(8),dp(8),dp(8));
        List<EditText> edits=new ArrayList<>();Map<String,EditText> map=new LinkedHashMap<>();String[] fields;
        if("equipamentos".equals(type)) fields=new String[]{"nome","tipo","marca","modelo","referencia","categoria","custo","pvp","venda","quantidade_comprada","quantidade_utilizada","stock_minimo"};
        else if("produtos".equals(type)) fields=new String[]{"nome","marca","tipo","unidade","quantidade_comprada","quantidade_utilizada","custo","venda","stock_minimo"};
        else if("servicos".equals(type)) fields=new String[]{"nome","tipo","unidade","venda"};
        else fields=new String[]{"nome"};
        for(String key:fields){EditText e=edit(key,14);if(key.contains("quantidade")||key.equals("custo")||key.equals("pvp")||key.equals("venda")||key.equals("stock_minimo"))e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);if(existing!=null)e.setText(existing.optString(key,""));map.put(key,e);f.addView(fieldBlockWith(labelOnly(pretty(key)),e));}AlertDialog d=new AlertDialog.Builder(this).setTitle(index>=0?"Editar item":"Adicionar item").setView(f).setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{JSONObject o=existing==null?new JSONObject():new JSONObject(existing.toString());o.put("id",o.optString("id",uuid("CAT")));for(Map.Entry<String,EditText> en:map.entrySet())o.put(en.getKey(),value(en.getValue()));store.saveCatalog(type,index,o);d.dismiss();showCatalogList(type);}catch(Exception e){alert("Erro",e.getMessage());}}));d.show();
    }

    // ============================= ARQUIVADO =============================

    private void renderArchived(){
        Card p=card();LinearLayout h=row();h.addView(tv("📁 Arquivados",20,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));Button close=primary("Fechar");close.setOnClickListener(v->showScreen("inicio"));h.addView(close,new LinearLayout.LayoutParams(dp(72),dp(40)));p.addView(h);EditText s=edit("Pesquisar nome, contacto, empresa, equipamento...",13);p.addView(s);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);Runnable render=()->{list.removeAllViews();String q=value(s).trim().toLowerCase(Locale.ROOT);JSONArray a=store.archived();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null||!clientContains(c,q))continue;Card r=card();LinearLayout rr=row();rr.addView(tv(clientName(c),15,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));Button restore=button("Repor",false),del=button("🗑",false);final int idx=i;restore.setOnClickListener(v->{store.restoreArchived(idx);showScreen("historico");});del.setOnClickListener(v->confirm("Apagar arquivado?","Tem a certeza?",()->{store.deleteArchived(idx);showScreen("historico");}));rr.addView(restore,new LinearLayout.LayoutParams(dp(70),dp(40)));rr.addView(del,new LinearLayout.LayoutParams(dp(55),dp(40)));r.addView(rr);list.addView(r);addSpacer(list,8);}if(list.getChildCount()==0)list.addView(muted("Nenhum cliente arquivado."));};s.addTextChangedListener(simpleWatcher(render));render.run();p.addView(list);content.addView(p);
    }

    // ============================== HISTÓRICO ============================

    private void renderActivity(){
        Card p=card();LinearLayout h=row();h.addView(tv("🕘 Histórico de\nalterações",20,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));Button close=primary("Fechar");close.setOnClickListener(v->showScreen("inicio"));h.addView(close,new LinearLayout.LayoutParams(dp(72),dp(40)));p.addView(h);EditText s=edit("Pesquisar alteração...",13);p.addView(s);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);Runnable render=()->{list.removeAllViews();String q=value(s).toLowerCase(Locale.ROOT);JSONArray a=store.activity();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String txt=x.optString("action","")+" "+x.optString("details","");if(!txt.toLowerCase(Locale.ROOT).contains(q))continue;Card r=card();r.addView(tv(x.optString("type","Alteração")+" — "+x.optString("action","")+"",14,TEXT,true));r.addView(muted(x.optString("details","")));r.addView(muted(x.optString("date","") ));list.addView(r);addSpacer(list,8);}if(list.getChildCount()==0)list.addView(muted("Ainda não existem alterações."));};s.addTextChangedListener(simpleWatcher(render));render.run();p.addView(list);content.addView(p);
    }

    // ============================ ESTATÍSTICAS ===========================

    private void renderStatistics(){
        Card panel=card();
        LinearLayout head=row();
        head.addView(tv("📊 Estatísticas",20,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));
        Button close=primary("Fechar");close.setOnClickListener(v->showScreen("inicio"));
        head.addView(close,new LinearLayout.LayoutParams(dp(72),dp(40)));
        panel.addView(head);addSpacer(panel,10);
        LinearLayout r1=row();LinearLayout r2=row();
        int total=store.clients().length();int active=0;for(int i=0;i<store.clients().length();i++){JSONObject c=store.clients().optJSONObject(i);if(c!=null&&"active".equals(status(c)))active++;}
        r1.addView(statCard(String.valueOf(total),"Total de\nclientes",TEXT),weightParams(1));r1.addView(statCard(String.valueOf(active),"Clientes\nativos",TEXT),weightParams(1));
        r2.addView(statCard(String.valueOf(store.subscriptions().length()),"Subscrições",TEXT),weightParams(1));r2.addView(statCard(String.valueOf(stockAlerts()),"Alertas de\nstock",TEXT),weightParams(1));
        panel.addView(r1);addSpacer(panel,10);panel.addView(r2);addSpacer(panel,8);
        content.addView(panel);
        statsSection("👥 Clientes por estado",()->{LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);int a=0,w=0,e=0;for(int i=0;i<store.clients().length();i++){JSONObject c=store.clients().optJSONObject(i);if(c==null)continue;String st=status(c);if("active".equals(st))a++;else if("warning".equals(st))w++;else e++;}x.addView(statLine("🟢 Ativos",String.valueOf(a)));x.addView(statLine("🟠 A expirar",String.valueOf(w)));x.addView(statLine("🔴 Expirados",String.valueOf(e)));return x;});
        statsSection("🛠️ Clientes por serviço",()->{Map<String,Integer> m=new LinkedHashMap<>();for(int i=0;i<store.clients().length();i++){JSONObject c=store.clients().optJSONObject(i);String sv=c==null?"":c.optString("Serviço","");if(!sv.isEmpty())m.put(sv,m.getOrDefault(sv,0)+1);}LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);for(Map.Entry<String,Integer> e:m.entrySet())x.addView(statLine(e.getKey(),String.valueOf(e.getValue())));if(m.isEmpty())x.addView(muted("Ainda não existem serviços atribuídos."));return x;});
        statsSection("🔐 Subscrições",()->{LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);JSONArray a=store.subscriptions();for(int i=0;i<a.length();i++){JSONObject sub=a.optJSONObject(i);if(sub!=null){SubSummary sm=subSummary(sub);x.addView(statLine(sub.optString("name","Subscrição"),sm.consumed+"/"+sm.purchased+" · "+sm.available+" livres"));}}return x;});
        statsSection("🌐 VPNs",()->{LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);int n=0;JSONArray a=store.subscriptions();for(int i=0;i<a.length();i++){JSONObject sub=a.optJSONObject(i);if(sub!=null&&(sub.optString("type","")+" "+sub.optString("name","")).toLowerCase(Locale.ROOT).contains("vpn"))n++;}x.addView(statLine("VPNs registadas",String.valueOf(n)));return x;});
        statsSection("📦 Stock",()->{LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);JSONArray e=store.catalog("equipamentos"),p=store.catalog("produtos");int units=0,low=0,zero=0;for(int i=0;i<e.length();i++){StockResult rr=stock(e.optJSONObject(i));units+=rr.stock;if(rr.stock==0)zero++;else if(rr.low)low++;}for(int i=0;i<p.length();i++){StockResult rr=stock(p.optJSONObject(i));units+=rr.stock;if(rr.stock==0)zero++;else if(rr.low)low++;}x.addView(statLine("Equipamentos em catálogo",String.valueOf(e.length())));x.addView(statLine("Produtos / consumíveis",String.valueOf(p.length())));x.addView(statLine("Stock total",String.valueOf(units)));x.addView(statLine("🟠 Stock baixo",String.valueOf(low)));x.addView(statLine("🔴 Sem stock",String.valueOf(zero)));return x;});
        statsSection("📦 Packs",()->{LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);int packs=0;JSONArray a=store.subscriptions();for(int i=0;i<a.length();i++)if(isPack(a.optJSONObject(i)))packs++;x.addView(statLine("Packs registados",String.valueOf(packs)));return x;});
        statsSection("💶 Faturação mensal",()->renderRevenueStats());
    }

    private void statsSection(String title, SectionBody body){
        Card c=card();
        Button b=button(title,false);
        b.setGravity(Gravity.START);
        c.addView(b,new LinearLayout.LayoutParams(-1,dp(44)));
        LinearLayout host=new LinearLayout(this);
        host.setOrientation(LinearLayout.VERTICAL);
        host.setVisibility(View.GONE);
        c.addView(host);
        b.setOnClickListener(v->{
            if(host.getVisibility()==View.VISIBLE){
                host.setVisibility(View.GONE);
            }else{
                host.removeAllViews();
                host.addView(body.make());
                host.setVisibility(View.VISIBLE);
            }
        });
        content.addView(c);
        addSpacer(content,10);
    }
    interface SectionBody{View make();}
    private View statLine(String a,String b){LinearLayout r=row();r.setPadding(dp(4),dp(10),dp(4),dp(10));r.addView(tv(a,14,TEXT,false),new LinearLayout.LayoutParams(0,-2,1f));r.addView(tv(b,14,TEXT,true));return r;}
    private View renderRevenueStats(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);Calendar now=Calendar.getInstance();int year=now.get(Calendar.YEAR);double annual=0;double[] m=new double[12];JSONArray a=store.clients();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;String d=c.optString("Pagamento","");if(d.isEmpty())continue;Date dt=parseDate(d);if(dt==null)continue;Calendar z=Calendar.getInstance();z.setTime(dt);if(z.get(Calendar.YEAR)!=year)continue;double v=money(c.optString("Preço","0"));m[z.get(Calendar.MONTH)]+=v;annual+=v;}x.addView(statLine("Total "+year,formatEuro(annual)));x.addView(statLine("Média mensal",formatEuro(annual/12)));String[] mn={"Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"};for(int i=0;i<12;i++)x.addView(statLine(mn[i],formatEuro(m[i])));return x;}

    // ============================= CONFIG ================================

    private void renderSettings(){
        Card panel=card();
        LinearLayout head=row();
        head.addView(tv("⚙️ Configurações",20,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));
        Button close=primary("Fechar");close.setOnClickListener(v->showScreen("inicio"));
        head.addView(close,new LinearLayout.LayoutParams(dp(72),dp(40)));
        panel.addView(head);addSpacer(panel,10);

        Card app=card();app.addView(tv("Apresentação da aplicação",16,TEXT,true));EditText title=edit("Nome a apresentar",14);title.setText(store.title());app.addView(fieldBlockWith(labelOnly("Nome a apresentar na aplicação"),title));Button logo=primary("Escolher logotipo");logo.setOnClickListener(v->chooseLogo());app.addView(logo,new LinearLayout.LayoutParams(-1,dp(42)));Button save=primary("Guardar apresentação");save.setOnClickListener(v->{store.setTitle(value(title));appTitleView.setText(store.title());Toast.makeText(this,"Guardado.",Toast.LENGTH_SHORT).show();});app.addView(save,new LinearLayout.LayoutParams(-1,dp(42)));panel.addView(app);addSpacer(panel,10);
        Card company=card();company.addView(tv("Empresa ativa",16,TEXT,true));JSONObject ac=store.activeCompany();addField(company,"Designação legal","legalName",ac.optJSONObject("data"));addField(company,"Responsável","responsible",ac.optJSONObject("data"));addField(company,"Email","email",ac.optJSONObject("data"));addField(company,"Telefone","phone",ac.optJSONObject("data"));addField(company,"Morada","address",ac.optJSONObject("data"));addField(company,"Código postal","postalCode",ac.optJSONObject("data"));addField(company,"Localidade","locality",ac.optJSONObject("data"));addField(company,"NIF","nif",ac.optJSONObject("data"));addField(company,"Website","website",ac.optJSONObject("data"));Button saveCompany=primary("Guardar empresa");saveCompany.setOnClickListener(v->{try{JSONObject data=ac.optJSONObject("data");if(data==null)data=new JSONObject();String[] ks={"legalName","responsible","email","phone","address","postalCode","locality","nif","website"};for(String k:ks){EditText e=(EditText)company.findViewWithTag("f:"+k);if(e!=null)data.put(k,value(e));}store.updateActiveCompanyData(data);Toast.makeText(this,"Empresa guardada.",Toast.LENGTH_SHORT).show();}catch(Exception e){alert("Erro",e.getMessage());}});company.addView(saveCompany,new LinearLayout.LayoutParams(-1,dp(42)));Button manage=button("Gerir empresas",false);manage.setOnClickListener(v->openCompanyManagement());company.addView(manage,new LinearLayout.LayoutParams(-1,dp(42)));panel.addView(company);addSpacer(panel,10);
        content.addView(panel);
        renderSettingsLists();renderShortcutsSettings();
    }

    private void renderSettingsLists(){
        String[][] labels={{"empresas","Empresas dos clientes"},{"pagamentos","Métodos de pagamento"},{"nome_equipamentos","Marcas dos Equipamentos"},{"equipamentos","Tipo de Equipamentos"},{"periodicidades","Periodicidades"},{"metodos_contacto","Canais de contacto"},{"valores","Valores de pagamento"}};
        for(String[] p:labels){Card c=card();LinearLayout h=row();h.addView(tv(p[1],15,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));Button add=primary("＋");h.addView(add,new LinearLayout.LayoutParams(dp(54),dp(40)));c.addView(h);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);JSONArray a=store.list(p[0]);for(int i=0;i<a.length();i++){String val=a.optString(i,"");list.addView(settingListRow(p[0],i,val));}add.setOnClickListener(v->openListItemDialog(p[0],-1));c.addView(list);content.addView(c);addSpacer(content,8);}
    }

    private View settingListRow(String key,int idx,String val){Card c=card();LinearLayout r=row();r.addView(tv(val,14,TEXT,false),new LinearLayout.LayoutParams(0,-2,1f));Button ed=button("✎",false),del=button("🗑",false);ed.setOnClickListener(v->openListItemDialog(key,idx));del.setOnClickListener(v->confirm("Apagar opção?","Tem a certeza?",()->{store.deleteListItem(key,idx);showScreen("config");}));r.addView(ed,new LinearLayout.LayoutParams(dp(48),dp(40)));r.addView(del,new LinearLayout.LayoutParams(dp(55),dp(40)));c.addView(r);return c;}
    private void openListItemDialog(String key,int idx){JSONArray a=store.list(key);EditText e=edit("Valor",14);if(idx>=0)e.setText(a.optString(idx,""));AlertDialog d=new AlertDialog.Builder(this).setTitle(idx>=0?"Editar opção":"Adicionar opção").setView(wrapDialog(e)).setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(value(e).trim().isEmpty())return;store.saveListItem(key,idx,value(e).trim());d.dismiss();showScreen("config");}));d.show();}

    private void renderShortcutsSettings(){Card c=card();c.addView(tv("🔗 Atalhos",16,TEXT,true));Button add=primary("＋ Adicionar atalho");add.setOnClickListener(v->openShortcutDialog(-1));c.addView(add,new LinearLayout.LayoutParams(-1,dp(42)));JSONArray a=store.appSettings().optJSONArray("shortcuts");if(a!=null)for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s!=null)c.addView(shortcutRow(i,s));}content.addView(c);}
    private View shortcutRow(int idx,JSONObject s){Card c=card();LinearLayout r=row();r.addView(tv(s.optString("name","Atalho"),14,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));Button e=button("✎",false);e.setOnClickListener(v->openShortcutDialog(idx));r.addView(e,new LinearLayout.LayoutParams(dp(48),dp(40)));c.addView(r);c.addView(muted(s.optString("url","")));return c;}
    private void openShortcutDialog(int idx){JSONArray a=store.appSettings().optJSONArray("shortcuts");JSONObject ex=a!=null&&idx>=0?a.optJSONObject(idx):null;EditText name=edit("Nome",14),desc=edit("Descrição",14),url=edit("URL",14);if(ex!=null){name.setText(ex.optString("name",""));desc.setText(ex.optString("description",""));url.setText(ex.optString("url",""));}LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.addView(fieldBlockWith(labelOnly("Nome"),name));f.addView(fieldBlockWith(labelOnly("Descrição"),desc));f.addView(fieldBlockWith(labelOnly("URL"),url));AlertDialog d=new AlertDialog.Builder(this).setTitle(idx>=0?"Editar atalho":"Adicionar atalho").setView(f).setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{JSONObject o=ex==null?new JSONObject():new JSONObject(ex.toString());o.put("id",o.optString("id",uuid("shortcut")));o.put("name",value(name));o.put("description",value(desc));o.put("url",value(url));store.saveShortcut(idx,o);d.dismiss();showScreen("config");}catch(Exception e){alert("Erro",e.getMessage());}}));d.show();}

    private void openCompanyManagement(){
        LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);JSONArray a=store.companies();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;Button b=button("🏢 "+c.optString("name","Empresa"),false);final String id=c.optString("id");b.setOnClickListener(v->{store.selectCompany(id);showDialogDismiss();showScreen("inicio");});f.addView(b,new LinearLayout.LayoutParams(-1,dp(46)));addSpacer(f,5);}Button add=primary("＋ Nova empresa");add.setOnClickListener(v->{showDialogDismiss();openNewCompanyDialog();});f.addView(add,new LinearLayout.LayoutParams(-1,dp(42)));activeDialog=new AlertDialog.Builder(this).setTitle("Gerir empresas").setView(f).setPositiveButton("Fechar",null).create();activeDialog.show();}
    private void openNewCompanyDialog(){EditText name=edit("Nome da empresa",14);AlertDialog d=new AlertDialog.Builder(this).setTitle("Nova empresa").setView(wrapDialog(name)).setPositiveButton("Criar",null).setNegativeButton("Cancelar",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{store.addCompany(value(name));d.dismiss();showScreen("inicio");}));d.show();}

    private void chooseLogo(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");startActivityForResult(i,REQ_LOGO);}

    // =============================== GESTÃO ==============================

    private void renderManagement(){
        Card panel=card();
        LinearLayout head=row();
        head.addView(tv("🛠️ Gestão da\nbase de dados",20,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));
        Button close=primary("Fechar");close.setOnClickListener(v->showScreen("inicio"));
        head.addView(close,new LinearLayout.LayoutParams(dp(72),dp(40)));
        panel.addView(head);addSpacer(panel,10);
        Button json=button("☷   💾 Cópia de segurança JSON",false);json.setOnClickListener(v->exportBackupJson());panel.addView(json,new LinearLayout.LayoutParams(-1,dp(44)));addSpacer(panel,8);
        Button excel=button("☷   📊 Cópia de segurança Excel",false);excel.setOnClickListener(v->exportBackupExcel());panel.addView(excel,new LinearLayout.LayoutParams(-1,dp(44)));addSpacer(panel,8);
        Button impJson=button("☷   📂 Repor cópia JSON",false);impJson.setOnClickListener(v->openFile(REQ_OPEN_JSON,"application/json"));panel.addView(impJson,new LinearLayout.LayoutParams(-1,dp(44)));addSpacer(panel,8);
        Button impExcel=button("☷   📊 Repor cópia Excel",false);impExcel.setOnClickListener(v->openFile(REQ_OPEN_EXCEL,ACTION_TYPE));panel.addView(impExcel,new LinearLayout.LayoutParams(-1,dp(44)));addSpacer(panel,8);
        Button clear=button("☷   🗑️ Limpar base de dados",false);clear.setOnClickListener(v->confirm("Limpar base de dados?","Todos os clientes, histórico, subscrições e configurações desta base serão removidos.",()->{store.clearDatabase();showScreen("inicio");}));panel.addView(clear,new LinearLayout.LayoutParams(-1,dp(44)));
        content.addView(panel);
    }

    private void exportBackupJson(){try{String json=store.exportBackup().toString(2);pendingSaveFilename="AM_Clientes_V268_backup.json";pendingSaveBytes=json.getBytes(StandardCharsets.UTF_8);pendingSaveMime="application/json";Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,pendingSaveFilename);startActivityForResult(i,REQ_SAVE_JSON);}catch(Exception e){alert("Erro",e.getMessage());}}
    private void exportBackupExcel(){try{String xml=toSpreadsheetXml(store.exportBackup());pendingSaveFilename="AM_Clientes_V268_backup.xls";pendingSaveBytes=xml.getBytes(StandardCharsets.UTF_8);pendingSaveMime=ACTION_TYPE;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(ACTION_TYPE);i.putExtra(Intent.EXTRA_TITLE,pendingSaveFilename);startActivityForResult(i,REQ_SAVE_EXCEL);}catch(Exception e){alert("Erro",e.getMessage());}}
    private void openFile(int request,String type){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(type);startActivityForResult(i,request);}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;try{Uri u=data.getData();if(requestCode==REQ_SAVE_JSON||requestCode==REQ_SAVE_EXCEL){try(OutputStream out=getContentResolver().openOutputStream(u)){out.write(pendingSaveBytes);}Toast.makeText(this,"Cópia guardada.",Toast.LENGTH_SHORT).show();}else if(requestCode==REQ_OPEN_JSON){String text=readText(u);store.importBackup(new JSONObject(text));showScreen("inicio");Toast.makeText(this,"Backup importado.",Toast.LENGTH_SHORT).show();}else if(requestCode==REQ_OPEN_EXCEL){String text=readText(u);JSONObject backup=parseSpreadsheetXml(text);store.importBackup(backup);showScreen("inicio");Toast.makeText(this,"Excel importado.",Toast.LENGTH_SHORT).show();}else if(requestCode==REQ_LOGO){InputStream in=getContentResolver().openInputStream(u);Bitmap bmp=BitmapFactory.decodeStream(in);if(in!=null)in.close();ByteArrayOutputStream out=new ByteArrayOutputStream();bmp.compress(Bitmap.CompressFormat.PNG,90,out);store.setLogoBase64(android.util.Base64.encodeToString(out.toByteArray(),android.util.Base64.NO_WRAP));applySettingsVisuals();}}catch(Exception e){alert("Erro","Operação não concluída: "+e.getMessage());}}

    // ============================ DATA LAYER =============================

    private final class SharedData {
        private final android.content.SharedPreferences prefs;
        private JSONObject state = new JSONObject();
        private JSONArray companies = new JSONArray();
        private String activeCompany = "company_1";

        SharedData(Context c){prefs=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
        void load(){
            try{
                String raw=prefs.getString("state","");
                if(raw.isEmpty()){
                    initializeEmptyState();
                    return;
                }
                state=new JSONObject(raw);
                companies=state.optJSONArray("companies");
                if(companies==null)companies=new JSONArray();
                activeCompany=state.optString("activeCompany","company_1");
                if(companies.length()==0){
                    JSONObject c=companyTemplate("company_1","Empresa");
                    companies.put(c);
                    activeCompany="company_1";
                    ensureRootDefaults();
                    save();
                }else{
                    ensureRootDefaults();
                    if(activeCompany(activeCompany)==null){
                        activeCompany=companies.optJSONObject(0).optString("id","company_1");
                        save();
                    }
                }
            }catch(Exception e){
                initializeEmptyState();
            }
        }
        private JSONObject activeCompany(String id){
            for(int i=0;i<companies.length();i++){
                JSONObject c=companies.optJSONObject(i);
                if(c!=null&&id.equals(c.optString("id")))return c;
            }
            return null;
        }
        private void ensureRootDefaults(){
            try{
                if(!state.has("title"))state.put("title","AM Clientes");
                if(!state.has("logo"))state.put("logo","");
                if(!state.has("shortcuts"))state.put("shortcuts",new JSONArray());
                if(!state.has("messages"))state.put("messages",new JSONObject());
            }catch(Exception ignored){}
        }
        private void initializeEmptyState(){
            try{
                state=new JSONObject();
                state.put("title","AM Clientes");
                state.put("logo","");
                state.put("shortcuts",new JSONArray());
                state.put("messages",new JSONObject());
                companies=new JSONArray();
                companies.put(companyTemplate("company_1","Empresa"));
                activeCompany="company_1";
                save();
            }catch(Exception ignored){save();}
        }
        void save(){try{state.put("companies",companies);state.put("activeCompany",activeCompany);prefs.edit().putString("state",state.toString()).apply();}catch(Exception ignored){}}
        String title(){return state.optString("title","AM Clientes");}
        void setTitle(String s){try{state.put("title",s.isEmpty()?"AM Clientes":s);save();}catch(Exception ignored){}}
        void setLogoBase64(String b){try{state.put("logo",b);save();}catch(Exception ignored){}}
        String logo(){return state.optString("logo","");}
        JSONObject appSettings(){return state;}
        String activeCompanyId(){return activeCompany;}
        JSONObject activeCompany(){for(int i=0;i<companies.length();i++){JSONObject c=companies.optJSONObject(i);if(c!=null&&activeCompany.equals(c.optString("id")))return c;}return companies.optJSONObject(0);}
        String activeCompanyName(){JSONObject c=activeCompany();return c==null?"Empresa":c.optString("name","Empresa");}
        JSONArray companies(){return companies;}
        void selectCompany(String id){for(int i=0;i<companies.length();i++){JSONObject c=companies.optJSONObject(i);if(c!=null&&id.equals(c.optString("id"))){activeCompany=id;save();return;}}}
        JSONArray companyArray(String key){JSONObject c=activeCompany();if(c==null)return new JSONArray();JSONArray a=c.optJSONArray(key);return a==null?new JSONArray():a;}
        void setCompanyArray(String key,JSONArray a){try{JSONObject c=activeCompany();c.put(key,a);save();}catch(Exception ignored){}}
        JSONArray clients(){return companyArray("clients");} JSONArray archived(){return companyArray("archived");} JSONArray activity(){return companyArray("activity");} JSONArray subscriptions(){return companyArray("subscriptions");}
        JSONArray list(String key){JSONObject c=activeCompany();JSONArray a=c==null?null:c.optJSONObject("lists")!=null?c.optJSONObject("lists").optJSONArray(key):null;return a==null?new JSONArray():a;}
        void saveListItem(String key,int idx,String value){try{JSONObject c=activeCompany();JSONObject lists=c.optJSONObject("lists");if(lists==null){lists=new JSONObject();c.put("lists",lists);}JSONArray a=lists.optJSONArray(key);if(a==null)a=new JSONArray();if(idx>=0&&idx<a.length())a.put(idx,value);else a.put(value);lists.put(key,a);save();}catch(Exception ignored){}}
        void deleteListItem(String key,int idx){try{JSONObject c=activeCompany();JSONObject lists=c.optJSONObject("lists");if(lists==null)return;JSONArray a=lists.optJSONArray(key);if(a==null)return;JSONArray n=new JSONArray();for(int i=0;i<a.length();i++)if(i!=idx)n.put(a.opt(i));lists.put(key,n);save();}catch(Exception ignored){}}
        JSONArray serviceCatalog(){return companyArray("services");}
        double serviceValue(String name){JSONArray a=serviceCatalog();for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s!=null&&name.equals(s.optString("name")))return s.optDouble("value",0);}return 0;}
        List<String> serviceNames(){List<String> r=new ArrayList<>();JSONArray a=serviceCatalog();for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s!=null&&!s.optString("name","").isEmpty())r.add(s.optString("name"));}return r;}
        void saveService(int idx,JSONObject obj){try{JSONArray a=serviceCatalog();if(idx>=0&&idx<a.length())a.put(idx,obj);else a.put(obj);setCompanyArray("services",a);}catch(Exception ignored){}}
        JSONArray catalog(String type){return companyArray("catalog_"+type);}
        void saveCatalog(String type,int idx,JSONObject o){try{JSONArray a=catalog(type);if(idx>=0&&idx<a.length())a.put(idx,o);else a.put(o);setCompanyArray("catalog_"+type,a);}catch(Exception ignored){}}
        void deleteCatalog(String type,int idx){try{JSONArray a=catalog(type),n=new JSONArray();for(int i=0;i<a.length();i++)if(i!=idx)n.put(a.opt(i));setCompanyArray("catalog_"+type,n);}catch(Exception ignored){}}
        void saveClient(JSONObject c){try{JSONArray a=clients();String id=c.optString("ID Cliente","");if(id.isEmpty()){id=nextClientId();c.put("ID Cliente",id);}int idx=findIndex(a,id);if(idx>=0)a.put(idx,c);else a.put(c);setCompanyArray("clients",a);record("cliente",idx>=0?"Cliente alterado":"Cliente criado",c.optString("Nome",id));}catch(Exception ignored){}}
        void deleteClient(String id){JSONArray a=clients(),n=new JSONArray();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c!=null&&!id.equals(c.optString("ID Cliente")))n.put(c);}setCompanyArray("clients",n);}
        JSONObject findClient(String id){JSONArray a=clients();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c!=null&&id.equals(c.optString("ID Cliente")))return c;}return null;}
        void archiveClient(String id){JSONObject c=findClient(id);if(c==null)return;try{JSONArray ar=archived();ar.put(new JSONObject(c.toString()));setCompanyArray("archived",ar);deleteClient(id);}catch(Exception ignored){}}
        void restoreArchived(int idx){JSONArray a=archived();JSONObject c=a.optJSONObject(idx);if(c==null)return;try{JSONArray cl=clients();cl.put(new JSONObject(c.toString()));setCompanyArray("clients",cl);JSONArray n=new JSONArray();for(int i=0;i<a.length();i++)if(i!=idx)n.put(a.opt(i));setCompanyArray("archived",n);}catch(Exception ignored){}}
        void deleteArchived(int idx){JSONArray a=archived(),n=new JSONArray();for(int i=0;i<a.length();i++)if(i!=idx)n.put(a.opt(i));setCompanyArray("archived",n);}
        void record(String type,String action,String details){try{JSONArray a=activity();a.put(new JSONObject().put("type",type).put("action",action).put("details",details).put("date",new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date())));if(a.length()>500){JSONArray n=new JSONArray();for(int i=Math.max(0,a.length()-500);i<a.length();i++)n.put(a.opt(i));a=n;}setCompanyArray("activity",a);}catch(Exception ignored){}}
        void saveSubscription(int idx,JSONObject s){try{JSONArray a=subscriptions();if(idx>=0&&idx<a.length())a.put(idx,s);else a.put(s);setCompanyArray("subscriptions",a);}catch(Exception ignored){}}
        void deleteSubscription(int idx){JSONArray a=subscriptions(),n=new JSONArray();for(int i=0;i<a.length();i++)if(i!=idx)n.put(a.opt(i));setCompanyArray("subscriptions",n);}
        void deleteMovement(int si,int mi){try{JSONArray a=subscriptions();JSONObject s=a.optJSONObject(si);JSONArray m=s.optJSONArray("movements"),n=new JSONArray();if(m!=null)for(int i=0;i<m.length();i++)if(i!=mi)n.put(m.opt(i));s.put("movements",n);a.put(si,s);setCompanyArray("subscriptions",a);}catch(Exception ignored){}}
        void saveShortcut(int idx,JSONObject o){try{JSONArray a=state.optJSONArray("shortcuts");if(a==null)a=new JSONArray();if(idx>=0&&idx<a.length())a.put(idx,o);else a.put(o);state.put("shortcuts",a);save();}catch(Exception ignored){}}
        void addCompany(String name){try{JSONObject c=companyTemplate(uuid("company"),name.isEmpty()?"Empresa":name);companies.put(c);activeCompany=c.optString("id");save();}catch(Exception ignored){}}
        void updateActiveCompanyData(JSONObject data){try{JSONObject c=activeCompany();c.put("data",data);save();}catch(Exception ignored){}}
        JSONObject companyTemplate(String id,String name){try{return new JSONObject().put("id",id).put("name",name).put("data",new JSONObject()).put("clients",new JSONArray()).put("archived",new JSONArray()).put("activity",new JSONArray()).put("subscriptions",new JSONArray()).put("services",new JSONArray()).put("lists",new JSONObject()).put("catalog_equipamentos",new JSONArray()).put("catalog_produtos",new JSONArray()).put("catalog_servicos",new JSONArray()).put("catalog_marcas",new JSONArray());}catch(Exception e){return new JSONObject();}}
        void clearDatabase(){try{JSONObject c=activeCompany();c.put("clients",new JSONArray());c.put("archived",new JSONArray());c.put("activity",new JSONArray());c.put("subscriptions",new JSONArray());c.put("services",new JSONArray());c.put("lists",emptyLists());for(String t:new String[]{"equipamentos","produtos","servicos","marcas"})c.put("catalog_"+t,new JSONArray());state.put("shortcuts",new JSONArray());save();}catch(Exception ignored){}}
        JSONObject exportBackup(){try{JSONObject b=new JSONObject();b.put("clientes",clients());b.put("arquivados",archived());b.put("atividade",activity());b.put("subscricoes",subscriptions());b.put("listas",activeCompany().optJSONObject("lists"));b.put("mensagens",state.optJSONObject("messages"));b.put("appSettings",state);JSONObject cats=new JSONObject();for(String t:new String[]{"equipamentos","produtos","servicos","marcas"})cats.put(t,catalog(t));b.put("catalogos",cats);return b;}catch(Exception e){return new JSONObject();}}
        void importBackup(JSONObject b){try{JSONArray cl=b.optJSONArray("clientes");JSONArray ar=b.optJSONArray("arquivados");JSONArray ac=b.optJSONArray("atividade");JSONArray su=b.optJSONArray("subscricoes");if(cl!=null)setCompanyArray("clients",new JSONArray(cl.toString()));if(ar!=null)setCompanyArray("archived",new JSONArray(ar.toString()));if(ac!=null)setCompanyArray("activity",new JSONArray(ac.toString()));if(su!=null)setCompanyArray("subscriptions",new JSONArray(su.toString()));JSONObject li=b.optJSONObject("listas");if(li!=null){activeCompany().put("lists",new JSONObject(li.toString()));}JSONObject msg=b.optJSONObject("mensagens");if(msg!=null)state.put("messages",new JSONObject(msg.toString()));JSONObject cats=b.optJSONObject("catalogos");if(cats!=null)for(String t:new String[]{"equipamentos","produtos","servicos","marcas"}){JSONArray x=cats.optJSONArray(t);if(x!=null)setCompanyArray("catalog_"+t,new JSONArray(x.toString()));}save();}catch(Exception ignored){}}
        String nextClientId(){int max=0;JSONArray a=clients();for(int i=0;i<a.length();i++){String id=a.optJSONObject(i).optString("ID Cliente","");if(id.startsWith("CLI")){try{max=Math.max(max,Integer.parseInt(id.substring(3)));}catch(Exception ignored){}}}return String.format(Locale.US,"CLI%03d",max+1);}
        int findIndex(JSONArray a,String id){for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c!=null&&id.equals(c.optString("ID Cliente")))return i;}return -1;}
        JSONObject emptyLists(){try{return new JSONObject().put("empresas",new JSONArray()).put("servicos",new JSONArray()).put("pagamentos",new JSONArray()).put("vpns",new JSONArray()).put("nome_equipamentos",new JSONArray()).put("equipamentos",new JSONArray()).put("periodicidades",new JSONArray()).put("metodos_contacto",new JSONArray()).put("valores",new JSONArray()).put("pacotes",new JSONArray());}catch(Exception e){return new JSONObject();}}
    }

    // =========================== ACCOUNTING =============================

    private static final class SubSummary { int purchased, consumed, available; }
    private SubSummary subSummary(JSONObject s){SubSummary out=new SubSummary();JSONArray m=s.optJSONArray("movements");if(m==null||m.length()==0){out.purchased=Math.max(0,s.optInt("limit",0));}else{for(int i=0;i<m.length();i++){JSONObject x=m.optJSONObject(i);if(x==null)continue;if("purchase".equals(x.optString("type")))out.purchased+=Math.max(0,x.optInt("quantity",0));else out.consumed+=Math.max(0,x.optInt("quantity",0));}}int linked=subscriptionLinkedUsage(s);out.consumed=Math.max(out.consumed,linked);out.consumed=Math.max(out.consumed,s.optInt("licenseUsed",0));out.available=Math.max(0,out.purchased-out.consumed);return out;}
    private int subscriptionLinkedUsage(JSONObject target){String targetName=target.optString("name",target.optString("type",""));if(targetName.isEmpty())return 0;if(isPack(target))return 0;int total=0;JSONArray clients=store.clients();for(int i=0;i<clients.length();i++){JSONObject c=clients.optJSONObject(i);if(c==null)continue;JSONArray eqs=c.optJSONArray("equipamentos");if(eqs==null)continue;for(int j=0;j<eqs.length();j++){JSONObject e=eqs.optJSONObject(j);if(e==null)continue;for(JSONObject assignment:assignments(e)){String n=assignment.optString("name","");if(targetName.equals(n))total+=promoUnits(monthsFor(e),purchaseRule(target));else{JSONObject pack=findSubscription(n);if(pack!=null&&isPack(pack)){JSONArray comps=pack.optJSONArray("components");if(comps!=null)for(int k=0;k<comps.length();k++){JSONObject comp=comps.optJSONObject(k);String cn=comp==null?String.valueOf(comps.opt(k)):comp.optString("name",comp.optString("subscriptionName",""));if(targetName.equals(cn))total+=promoUnits(monthsFor(e),purchaseRule(comp));}}}}}}JSONArray d=target.optJSONArray("devices");if(d!=null)total+=d.length();return total;}
    private List<JSONObject> assignments(JSONObject e){List<JSONObject> out=new ArrayList<>();JSONArray a=e.optJSONArray("subscricoes");if(a!=null&&a.length()>0){for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&!x.optString("name",x.optString("subscricao","")).isEmpty())out.add(x);}return out;}String s=e.optString("subscricao","");if(!s.isEmpty()){JSONObject y=new JSONObject();try{y.put("name",s);}catch(Exception ignored){}out.add(y);}JSONArray v=e.optJSONArray("vpns");if(v!=null)for(int i=0;i<v.length();i++){JSONObject x=v.optJSONObject(i);if(x!=null&&!x.optString("subscricao","").isEmpty()){JSONObject y=new JSONObject();try{y.put("name",x.optString("subscricao",""));}catch(Exception ignored){}out.add(y);}}return out;}
    private int monthsFor(JSONObject e){String t=(e.optString("validade","")+" "+e.optString("periodicidade","")).toLowerCase(Locale.ROOT);String[] keys={"mensal","bimestral","bimensal","trimestral","quadrimestral","semestral","anual","bienal","trienal"};int[] vals={1,2,2,3,4,6,12,24,36};for(int i=0;i<keys.length;i++)if(t.contains(keys[i]))return vals[i];for(String n:t.split(" ")){try{return Math.max(1,Integer.parseInt(n.replaceAll("[^0-9]", "")));}catch(Exception ignored){}}return 1;}
    private int promoUnits(int months,String rule){if("6for5".equals(rule))return (months/6)*5 + (months%6);return Math.max(1,months);}
    private String purchaseRule(JSONObject s){return "6for5".equals(s.optString("purchaseRule","normal"))?"6for5":"normal";}
    private JSONObject findSubscription(String name){JSONArray a=store.subscriptions();for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s!=null&&name.equals(s.optString("name",s.optString("type",""))))return s;}return null;}
    private boolean isPack(JSONObject s){return s!=null&&("pack".equals(s.optString("kind","") ) || s.optJSONArray("components")!=null&&s.optJSONArray("components").length()>0);}

    // ========================== HELPERS / VISUAL =========================

    private static class Card extends LinearLayout { Card(Context c){super(c);setOrientation(VERTICAL);} }
    private Card card(){Card c=new Card(this);c.setPadding(dp(16),dp(14),dp(16),dp(14));setRoundedBackground(c,PANEL,LINE,17);return c;}
    private TextView tv(String text,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(text);t.setTextColor(color);t.setTextSize(size);t.setGravity(Gravity.CENTER_VERTICAL);t.setTypeface(null,bold?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL);return t;}
    private TextView muted(String text){return tv(text==null?"":text,13,MUTED,false);}
    private Button button(String text,boolean icon){Button b=new Button(this);b.setText(text);b.setTextColor(TEXT);b.setTextSize(icon?18:14);b.setAllCaps(false);b.setPadding(dp(8),0,dp(8),0);setRoundedBackground(b,Color.rgb(10,27,55),LINE,11);return b;}
    private Button primary(String text){Button b=button(text,false);setRoundedBackground(b,BLUE,BLUE,11);b.setTextColor(Color.rgb(3,17,39));b.setTypeface(null,android.graphics.Typeface.BOLD);return b;}
    private Button menuItem(String text){return menuItem("",text,false);}
    private Button menuItem(String text, boolean selected){return menuItem("",text,selected);}
    private Button menuItem(String icon, String label, boolean selected){
        Button b=button(label,false);
        b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        b.setTextSize(16);
        b.setPadding(dp(14),0,dp(14),0);
        b.setCompoundDrawablePadding(dp(20));
        if(icon!=null && !icon.isEmpty()){
            b.setCompoundDrawablesWithIntrinsicBounds(new EmojiDrawable(icon, dp(18)), null, null, null);
        }
        if(selected){
            setRoundedBackground(b,BLUE,BLUE,12);
            b.setTextColor(Color.rgb(3,17,39));
            b.setTypeface(null,Typeface.BOLD);
        }else{
            setRoundedBackground(b,Color.rgb(7,29,62),LINE,12);
            b.setTextColor(TEXT);
            b.setTypeface(null,Typeface.NORMAL);
        }
        return b;
    }


    private class EmojiDrawable extends Drawable {
        private final String value;
        private final int size;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        EmojiDrawable(String value,int size){this.value=value;this.size=size;paint.setTypeface(Typeface.DEFAULT);paint.setTextSize(size);}
        @Override public void draw(Canvas canvas){
            android.graphics.Rect bounds=getBounds();
            paint.setTextSize(size);
            float w=paint.measureText(value);
            Paint.FontMetrics fm=paint.getFontMetrics();
            float x=bounds.left+(bounds.width()-w)/2f;
            float y=bounds.top+(bounds.height()-fm.bottom-fm.top)/2f;
            canvas.drawText(value,x,y,paint);
        }
        @Override public void setAlpha(int alpha){paint.setAlpha(alpha);}
        @Override public void setColorFilter(android.graphics.ColorFilter filter){paint.setColorFilter(filter);}
        @Override public int getOpacity(){return android.graphics.PixelFormat.TRANSLUCENT;}
        @Override public int getIntrinsicWidth(){
            paint.setTextSize(size);
            return Math.max(size, (int)Math.ceil(paint.measureText(value)));
        }
        @Override public int getIntrinsicHeight(){return size;}
    }
    private EditText editorEdit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(145,153,166));e.setTextColor(Color.rgb(22,25,30));e.setTextSize(14);e.setSingleLine(true);e.setPadding(dp(12),0,dp(12),0);setRoundedBackground(e,Color.WHITE,Color.rgb(125,133,145),10);return e;}
    private Spinner editorSpinner(List<String> values,String selected){Spinner s=new Spinner(this);ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values){@Override public View getView(int position,View convertView,android.view.ViewGroup parent){TextView t=(TextView)super.getView(position,convertView,parent);t.setTextColor(Color.rgb(28,31,36));t.setTextSize(14);t.setPadding(dp(10),0,dp(10),0);return t;}@Override public View getDropDownView(int p,View c,android.view.ViewGroup parent){TextView t=(TextView)super.getDropDownView(p,c,parent);t.setTextColor(Color.BLACK);return t;}};ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(ad);int idx=findSpinner(values,selected);if(idx>=0)s.setSelection(idx);setRoundedBackground(s,Color.WHITE,Color.rgb(125,133,145),10);return s;}
    private EditText edit(String hint,float size){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(MUTED);e.setTextColor(TEXT);e.setTextSize(size);e.setSingleLine(false);e.setPadding(dp(12),dp(8),dp(12),dp(8));setRoundedBackground(e,Color.rgb(4,12,29),VALUE_LINE,10);return e;}
    private Spinner spinner(List<String> values,String selected){Spinner s=new Spinner(this);ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values){@Override public View getView(int position,View convertView,android.view.ViewGroup parent){TextView t=(TextView)super.getView(position,convertView,parent);t.setTextColor(TEXT);t.setTextSize(14);t.setPadding(dp(10),dp(8),dp(10),dp(8));return t;}@Override public View getDropDownView(int p,View c,android.view.ViewGroup parent){TextView t=(TextView)super.getDropDownView(p,c,parent);t.setTextColor(Color.BLACK);return t;}};ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(ad);int idx=findSpinner(values,selected);if(idx>=0)s.setSelection(idx);setRoundedBackground(s,Color.rgb(4,12,29),LINE,9);return s;}
    private Spinner spinner(List<String> values,String selectedOrKey,boolean ignored){return spinner(values,selectedOrKey);}
    private ArrayList<String> asList(String... v){ArrayList<String> r=new ArrayList<>();Collections.addAll(r,v);return r;}
    private List<String> optionsToList(JSONArray a){List<String> r=new ArrayList<>();for(int i=0;i<a.length();i++)r.add(a.optString(i,""));return r;}
    private List<String> subscriptionNamesWithPacks(){List<String> r=new ArrayList<>();JSONArray a=store.subscriptions();for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s!=null)r.add(s.optString("name",s.optString("type","")));}return r;}
    private int findSpinner(List<String> a,String value){for(int i=0;i<a.size();i++)if(a.get(i).equals(value)||a.get(i).startsWith(value+":"))return i;return a.isEmpty()?-1:0;}
    private int findSpinner(List<String> a,Object v){return findSpinner(a,String.valueOf(v));}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout lp(int w,int h){return new LinearLayout(this);}
    private LinearLayout.LayoutParams lp0(){return new LinearLayout.LayoutParams(-1,-2);}
    private LinearLayout.LayoutParams homeStatParams(float weight, boolean leftGap, boolean rightGap){
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, weight);
        if (leftGap) p.leftMargin = dp(6);
        if (rightGap) p.rightMargin = dp(6);
        return p;
    }

    private LinearLayout.LayoutParams weightParams(float w){return new LinearLayout.LayoutParams(0,-2,w);}

    private void addSpacer(ViewGroup p,int h){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));p.addView(v);}
    private void addDivider(ViewGroup p){View v=new View(this);v.setBackgroundColor(LINE);p.addView(v,new LinearLayout.LayoutParams(-1,1));}
    private LinearLayout wrapDialog(View v){LinearLayout l=new LinearLayout(this);l.setPadding(dp(8),dp(8),dp(8),dp(8));l.addView(v,new LinearLayout.LayoutParams(-1,-2));return l;}

    private void setRoundedBackground(View v,int bg,int stroke,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(bg);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(1,stroke);v.setBackground(d);}
    private static int dp(int value){return (int)(value*ResourcesHolder.density);}private static class ResourcesHolder{static float density=1f;}

    private String value(EditText e){return e==null?"":e.getText().toString();}
    private String value(Spinner s){return s==null?"":String.valueOf(s.getSelectedItem());}
    private void applySettingsVisuals(){appTitleView.setText(store.title());String b64=store.logo();if(!b64.isEmpty()){try{byte[] bytes=android.util.Base64.decode(b64,android.util.Base64.DEFAULT);Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);logoTextView.setVisibility(View.GONE);logoImageView.setVisibility(View.VISIBLE);logoImageView.setImageBitmap(bmp);}catch(Exception ignored){logoTextView.setVisibility(View.GONE);logoImageView.setVisibility(View.VISIBLE);logoImageView.setImageResource(com.aminovacao.amclientes231.R.drawable.ic_launcher);}}else{logoTextView.setVisibility(View.GONE);logoImageView.setVisibility(View.VISIBLE);logoImageView.setImageResource(com.aminovacao.amclientes231.R.drawable.ic_launcher);}}
    private String clientName(JSONObject c){String n=c.optString("Nome","");return n.isEmpty()?orDash(c.optString("Nome Empresa","")):n;}
    private String orDash(String s){return s==null||s.trim().isEmpty()?"—":s;}
    private boolean clientContains(JSONObject c,String q){if(q.isEmpty())return true;Iterator<String> it=c.keys();while(it.hasNext()){String k=it.next();String v=c.optString(k,"");if(v.toLowerCase(Locale.ROOT).contains(q))return true;}return false;}
    private JSONArray filteredClients(String q){JSONArray out=new JSONArray();JSONArray a=store.clients();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c!=null&&clientContains(c,q))out.put(c);}return out;}
    private String status(JSONObject c){String raw=c.optString("Validade","");if(raw.isEmpty())return "active";Date d=parseDate(raw);if(d==null)return "active";long days=(d.getTime()-startOfDay(new Date()).getTime())/86400000L;return days<0?"expired":days<=30?"warning":"active";}
    private long daysUntilValidity(JSONObject c){Date d=parseDate(c.optString("Validade",""));return d==null?Long.MAX_VALUE:(d.getTime()-startOfDay(new Date()).getTime())/86400000L;}
    private String statusLabel(JSONObject c){String s=status(c);if("expired".equals(s))return "EXPIRADO";long d=daysUntilValidity(c);return d==Long.MAX_VALUE?"—":d+" dias";}
    private Date startOfDay(Date d){Calendar c=Calendar.getInstance();c.setTime(d);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTime();}
    private Date parseDate(String s){try{if(s==null||s.length()<8)return null;return new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(s.substring(0,10));}catch(Exception e){return null;}}
    private String formatDate(String s){Date d=parseDate(s);return d==null?s:new SimpleDateFormat("dd/MM/yyyy",new Locale("pt","PT")).format(d);}
    private String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    private String plusMonths(String s,int m){Date d=parseDate(s);if(d==null)return s;Calendar c=Calendar.getInstance();c.setTime(d);c.add(Calendar.MONTH,m);return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
    private double money(String s){try{return Double.parseDouble(String.valueOf(s).replace("€","").replace(" ","").replace(".","").replace(",","."));}catch(Exception e){try{return Double.parseDouble(s);}catch(Exception ignored){return 0;}}}
    private String formatEuro(double v){return NumberFormat.getCurrencyInstance(new Locale("pt","PT")).format(v);}
    private String splitBeforeColon(String s){int i=s.indexOf(':');return i>=0?s.substring(0,i):s;}
    private String splitBeforeColonLabel(String s){return "purchase".equals(s)?"Compra":"activation".equals(s)?"Ativação":"renewal".equals(s)?"Renovação":s;}
    private String titleForCatalog(String t){return "equipamentos".equals(t)?"Equipamentos":"produtos".equals(t)?"Produtos / Consumíveis":"servicos".equals(t)?"Serviços":"Marcas";}
    private String iconForCatalog(String t){return "equipamentos".equals(t)?"📹":"produtos".equals(t)?"📦":"servicos".equals(t)?"🛠️":"🏷️";}
    private String summaryCatalogItem(String type,JSONObject o){if("equipamentos".equals(type))return orDash(o.optString("marca",""))+" · "+orDash(o.optString("modelo",""))+" · PVP "+formatEuro(o.optDouble("pvp",0));if("produtos".equals(type))return orDash(o.optString("marca",""))+" · stock "+stock(o).stock;return orDash(o.optString("tipo",""))+" · "+orDash(o.optString("unidade",""))+" · "+formatEuro(o.optDouble("venda",0));}
    private String pretty(String key){String s=key.replace('_',' ');return s.substring(0,1).toUpperCase()+s.substring(1);}
    private String uuid(String p){return p+"-"+UUID.randomUUID().toString().substring(0,8);}
    private double subscriptionSaleValue(String name){JSONObject s=findSubscription(name);return s==null?0:s.optDouble("revenue",s.optDouble("cost",0));}
    private void pickDate(EditText e){Calendar c=Calendar.getInstance();Date cur=parseDate(value(e));if(cur!=null)c.setTime(cur);new DatePickerDialog(this,(v,y,m,d)->{String s=String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d);e.setText(s);},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    private void openExternal(String url){if(url==null||url.isEmpty())return;try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}}
    private void confirm(String title,String message,Runnable yes){new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("Confirmar",(d,w)->yes.run()).setNegativeButton("Cancelar",null).show();}
    private void alert(String title,String msg){new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK",null).show();}
    private TextWatcher simpleWatcher(Runnable r){return new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){r.run();}public void afterTextChanged(Editable e){}};}
    private String readText(Uri u)throws Exception{try(InputStream in=getContentResolver().openInputStream(u)){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);return out.toString(StandardCharsets.UTF_8.name());}}
    private void startActivityForResultSafe(Intent i,int req){try{startActivityForResult(i,req);}catch(Exception e){alert("Erro",e.getMessage());}}

    // ========================== XLS SpreadsheetML ========================
    private String toSpreadsheetXml(JSONObject backup)throws Exception{
        StringBuilder b=new StringBuilder();b.append("<?xml version=\"1.0\"?><?mso-application progid=\"Excel.Sheet\"?>");b.append("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\"><Worksheet ss:Name=\"Clientes\"><Table>");writeSheetRows(b,backup.optJSONArray("clientes"));b.append("</Table></Worksheet><Worksheet ss:Name=\"Arquivados\"><Table>");writeSheetRows(b,backup.optJSONArray("arquivados"));b.append("</Table></Worksheet><Worksheet ss:Name=\"Subscricoes\"><Table>");writeSheetRows(b,backup.optJSONArray("subscricoes"));b.append("</Table></Worksheet></Workbook>");return b.toString();}
    private void writeSheetRows(StringBuilder b,JSONArray a){if(a==null||a.length()==0)return;LinkedHashSet<String> keys=new LinkedHashSet<>();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null){Iterator<String> it=o.keys();while(it.hasNext())keys.add(it.next());}}b.append("<Row>");for(String k:keys)b.append("<Cell><Data ss:Type=\"String\">").append(xml(k)).append("</Data></Cell>");b.append("</Row>");for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;b.append("<Row>");for(String k:keys)b.append("<Cell><Data ss:Type=\"String\">").append(xml(o.optString(k,"")).replace("<", "&lt;").replace(">","&gt;")).append("</Data></Cell>");b.append("</Row>");}}
    private String xml(String s){return s==null?"":s.replace("&","&amp;").replace("\"","&quot;").replace("'","&apos;");}
    private JSONObject parseSpreadsheetXml(String text)throws Exception{Document d=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new java.io.ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)));JSONObject out=new JSONObject();parseWorksheet(d,"Clientes","clientes",out);parseWorksheet(d,"Arquivados","arquivados",out);parseWorksheet(d,"Subscricoes","subscricoes",out);return out;}
    private void parseWorksheet(Document d,String sheetName,String outKey,JSONObject out)throws Exception{NodeList sheets=d.getElementsByTagName("Worksheet");for(int i=0;i<sheets.getLength();i++){Element e=(Element)sheets.item(i);if(!sheetName.equals(e.getAttributeNS("urn:schemas-microsoft-com:office:spreadsheet","Name"))&&!sheetName.equals(e.getAttribute("ss:Name")))continue;NodeList rows=e.getElementsByTagName("Row");if(rows.getLength()==0)continue;List<String> headers=new ArrayList<>();JSONArray arr=new JSONArray();for(int r=0;r<rows.getLength();r++){Element row=(Element)rows.item(r);NodeList cells=row.getElementsByTagName("Cell");List<String> vals=new ArrayList<>();for(int c=0;c<cells.getLength();c++){NodeList data=((Element)cells.item(c)).getElementsByTagName("Data");vals.add(data.getLength()>0?data.item(0).getTextContent():"");}if(r==0)headers.addAll(vals);else{JSONObject o=new JSONObject();for(int c=0;c<Math.min(headers.size(),vals.size());c++)o.put(headers.get(c),vals.get(c));arr.put(o);}}out.put(outKey,arr);return;}}

    private int stockAlerts(){int n=0;for(String t:new String[]{"equipamentos","produtos"}){JSONArray a=store.catalog(t);for(int i=0;i<a.length();i++){StockResult r=stock(a.optJSONObject(i));if(r.low||r.stock==0)n++;}}return n;}
    private static class StockResult{int stock;boolean low;}
    private StockResult stock(JSONObject o){StockResult r=new StockResult();if(o==null)return r;r.stock=Math.max(0,(int)o.optDouble("quantidade_comprada",o.optDouble("quantidade",0))- (int)o.optDouble("quantidade_utilizada",0));double min=o.optDouble("stock_minimo",0);r.low=r.stock>0&&min>0&&r.stock<=min;return r;}


    @Override public void onBackPressed(){if(drawerOverlay!=null&&drawerOverlay.getVisibility()==View.VISIBLE){closeDrawer();return;}if(!"inicio".equals(currentScreen)){showScreen("inicio");return;}super.onBackPressed();}

    static { ResourcesHolder.density=android.content.res.Resources.getSystem().getDisplayMetrics().density; }

}
