AM Clientes V275 — projeto Android nativo.

Estado consolidado da nova aplicação independente.
- Package / Application ID: com.aminovacao.amclientes231
- Aplicação 100% Android nativa; sem HTML/WebView como solução de interface.
- V230 é apenas a referência funcional da aplicação original; esta aplicação é independente.
- Arranque em estado vazio, sem dados de demonstração.
- O backup JSON externo continua a ser a fonte de dados para testes/importação.
- Interface trabalhada progressivamente, menu a menu, sem patches ou implementações concorrentes para o mesmo elemento.

Alteração V275:
- Baseada diretamente na V272 (a V273 não é utilizada).
- No ecrã de edição do cliente, os campos passam a usar o aspeto claro/branco da referência original.
- Serviços e subscrições são adicionados diretamente no ecrã, em linhas numeradas com seleção a partir dos catálogos, sem pop-ups.
- Os dados existentes em formato antigo são mantidos compatíveis.
- As restantes funcionalidades e o package da aplicação são preservados.
