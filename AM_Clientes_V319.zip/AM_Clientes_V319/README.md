# AM Clientes V319

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 319
- `versionName`: `1.0.319`

## Alterações desta versão

- Contornos dos cartões unificados com o azul médio aprovado no menu Serviços e subscrições, incluindo o cabeçalho de navegação e as barras de pesquisa.
- Removido o ícone repetido dos cartões individuais de serviço; o ícone permanece no cabeçalho da secção.
- Tipo de subscrição corrigido para duas opções de lógica: `Subscrição simples` ou `Pack`. O nome do pack continua a ser definido no campo Nome.
- Ao escolher `Pack`, aparece o seletor múltiplo `Subscrições incluídas no pack`, com as subscrições simples já registadas, realce azul-claro e visto por cada opção selecionada.
- As subscrições incluídas são guardadas como componentes estruturados, preservando o custo e a regra de compra da subscrição associada, incluindo o campo usado pelo cálculo de licenças consumidas.
- O cartão exterior de Subscrições passa a conter o formulário e todos os cartões individuais, à semelhança da secção Serviços.
- Contornos da barra lateral ajustados para a mesma cor e espessura visual dos cartões principais.
- Texto dos botões Fechar/Abrir no ecrã Início ajustado ao tamanho padrão dos menus Clientes e Serviços e subscrições.
- Contornos azuis mais visíveis no módulo Serviços e subscrições, sem alterar o tema global da aplicação.
- Removida a secção Serviços do ecrã Catálogos; a sua gestão mantém-se em Serviços e subscrições.
- Retirado o texto introdutório redundante do ecrã Catálogos e reposta a estrutura com cartões interiores para Equipamentos, Produtos / Consumíveis e Marcas.
- Cabeçalho da barra lateral sem moldura exterior; mantida a linha horizontal separadora sob AM Clientes.
- Preservadas as correções anteriores do calendário, menus, aviso e edição de serviços.
- O ecrã Catálogos foi restaurado para gestão inline: Equipamentos, Produtos / Consumíveis e Marcas mantêm-se acessíveis enquanto o formulário escolhido aparece por baixo.
- Recuperados os campos específicos dos formulários, os valores calculados de stock, custo unitário e margem, a pesquisa dos registos e as ações de adicionar, editar e apagar.
- Os seletores de marca são alimentados pelas marcas registadas no próprio catálogo; a gestão de Serviços continua fora de Catálogos.

## Validação

A compilação Android/Gradle deve ser confirmada no workflow do GitHub Actions.
