AM Clientes V265 — projeto Android nativo.

Estado consolidado da nova aplicação independente.
- Package / Application ID: com.aminovacao.amclientes231
- Aplicação 100% Android nativa; sem HTML/WebView como solução de interface.
- V230 é apenas a referência funcional da aplicação original; esta aplicação é independente.
- Arranque em estado vazio, sem dados de demonstração.
- O backup JSON externo continua a ser a fonte de dados para testes/importação.
- Interface trabalhada progressivamente, menu a menu, sem patches ou implementações concorrentes para o mesmo elemento.
