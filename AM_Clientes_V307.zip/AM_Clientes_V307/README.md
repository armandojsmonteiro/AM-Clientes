# AM Clientes V307

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 307
- `versionName`: `1.0.307`

## Alterações desta versão

- Calendário: os botões DEFINIR, CANCELAR e OK ficam dentro do cartão branco, alinhados no rodapé, evitando que apareçam duplicados ou fora do calendário.
- Calendário: o cabeçalho azul tem os cantos superiores arredondados; o corpo mantém o fundo branco e os dias selecionados em azul.
- Seleção do ano: substituído o seletor numérico invisível por uma grelha de anos, com o ano selecionado destacado a azul e navegação por décadas.
- Seleção de mês e ano: a data só é aplicada depois da confirmação do ano; a seleção do mês abre a grelha de anos.
- Mantidos os menus de seleção personalizados já aprovados e as restantes correções da V306.

## Validação

A compilação Android/Gradle deve ser confirmada no workflow do GitHub Actions.
