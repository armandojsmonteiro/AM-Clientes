# AM Clientes V60

V60 marks the return to the original complete HTML as the application source.

The Android shell uses a WebView and loads the complete AM Clientes HTML locally from app assets. This avoids recreating the menus one by one in Compose and preserves the menu structure and JavaScript logic already present in the HTML.

Source: AM_Clientes_744.html
Android version: 1.0.60 / versionCode 60


V66: persistência da base de dados transferida para armazenamento nativo Android (SharedPreferences) através de JavascriptInterface. A interface HTML permanece apenas como camada visual/funcional.
