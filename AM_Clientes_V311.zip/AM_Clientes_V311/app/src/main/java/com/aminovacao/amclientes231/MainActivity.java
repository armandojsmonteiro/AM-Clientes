package com.aminovacao.amclientes231;

import android.app.Activity;
import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.xml.parsers.DocumentBuilderFactory;

public class MainActivity extends Activity {
    // ---------------------------------------------------------------------
    // Ajustes visuais consolidados do ecrã Início.
    // ---------------------------------------------------------------------

    private static final int BLUE = Color.rgb(97, 165, 255);
    private static final int BG = Color.rgb(3, 11, 32);
    private static final int PANEL = Color.rgb(7, 17, 39);
    private static final int PANEL2 = Color.rgb(11, 25, 53);
    // Contorno azul uniforme para cartões e painéis em toda a aplicação.
    private static final int CARD_OUTLINE = Color.rgb(52, 82, 126);
    private static final int LINE = CARD_OUTLINE;
    private static final int HOME_LINE = CARD_OUTLINE;
    private static final int VALUE_LINE = Color.rgb(27, 49, 82);
    private static final int TEXT = Color.rgb(245, 247, 251);
    private static final int MUTED = Color.rgb(154, 170, 194);
    private static final int GREEN = Color.rgb(53, 208, 127);
    private static final int ORANGE = Color.rgb(255, 173, 69);
    private static final int RED = Color.rgb(255, 92, 104);

    private static final String PREF = "am_clientes_native";
    private static final String ACTION_TYPE = "application/vnd.ms-excel";
    private static final int REQ_OPEN_JSON = 4101;
    private static final int REQ_OPEN_EXCEL = 4102;
    private static final int REQ_SAVE_JSON = 4103;
    private static final int REQ_SAVE_EXCEL = 4104;
    private static final int REQ_LOGO = 4105;
    private static final int TAG_JSON = 0x6A4D233;

    private SharedData store;
    private String currentScreen = "inicio";
    private String selectedClientId = null;
    private String editorReturnScreen = "inicio";
    private String editorReturnClientId = null;
    // Posição exata da página de pré-visualização antes de entrar no editor.
    private int editorReturnScrollY = 0;
    // Altura do conteúdo anterior usada temporariamente para permitir que a
    // animação regresse do editor sem o ScrollView limitar o scroll ao novo ecrã.
    private int editorReturnContentHeight = 0;
    private boolean pendingEditorScrollRestore = false;
    private boolean finishTemporaryContentHeightAfterScroll = false;
    private boolean suppressSearchRefresh = false;
    private String clientListMode = "all";
    private EditText topSearch;
    private TextView appTitleView;
    private TextView logoTextView;
    private ImageView logoImageView;
    private FrameLayout root;
    private FrameLayout drawerOverlay;
    private ScrollView drawerScroll;
    private LinearLayout drawer;
    private LinearLayout companyGroup;
    private LinearLayout companyList;
    private ScrollView contentScroll;
    private ValueAnimator contentScrollAnimator;
    private LinearLayout pageColumn;
    private LinearLayout content;
    private LinearLayout topBar;
    private LinearLayout shell;
    private String pendingSaveFilename;
    private byte[] pendingSaveBytes;
    private String pendingSaveMime;
    private JSONObject pendingClientDraft;
    // Estado dos formulários inline do menu Serviços e subscrições.
    private int subscriptionEditIndex = -1;
    private String subscriptionEditReturnTag = null;
    // Estado dos blocos recolhíveis do menu Serviços e subscrições.
    private boolean subscriptionsMenuExpanded = true;
    private boolean servicesSectionExpanded = false;
    private boolean subscriptionsSectionExpanded = false;
    private final Set<String> expandedServiceCardIds = new HashSet<>();

    private static final Map<String, String> DEFAULTS = new LinkedHashMap<>();
    static {
        DEFAULTS.put("renewal", "[AGORA]\n\nA validade do serviço [SERVIÇO] em nome de [CLIENTE] termina em [DATA].\n\nEspero que tenha gostado do nosso serviço de manutenção e que queira continuar nosso cliente.\n\nCaso queira continuar, por favor contacte-nos.\n\nObrigado.");
        DEFAULTS.put("expired", "[AGORA]\n\nO serviço [SERVIÇO] em nome de [CLIENTE] encontra-se expirado desde [DATA].\n\nCaso pretenda renovar, por favor contacte-nos.\n\nObrigado.");
        DEFAULTS.put("payment", "[AGORA]\n\nRelativamente ao serviço [SERVIÇO] em nome de [CLIENTE], ficou registado um saldo de [SALDO]€.\n\nObrigado.");
        DEFAULTS.put("maintenance", "[AGORA]\n\nInformamos que a manutenção do serviço [SERVIÇO] em nome de [CLIENTE] está agendada.\n\nObrigado.");
        DEFAULTS.put("custom", "");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        w.setFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS,
                   WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );
        store = new SharedData(this);
        store.load();
        buildRoot();
        showScreen("inicio");
    }

    // ============================== UI BASE ==============================

    private void buildRoot() {
        root = new FrameLayout(this);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(16, 48, 94), Color.rgb(5, 19, 43), BG});
        root.setBackground(bg);

        shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(16), 0, dp(16), 0);
        root.addView(shell, new FrameLayout.LayoutParams(-1, -1));

        // A página inteira (barra superior, pesquisa global e conteúdo) partilha
        // o mesmo scroll. Assim, ao abrir uma pré-visualização longa, o cabeçalho
        // desloca-se para cima como na aplicação de referência, em vez de ficar preso.
        contentScroll = new ScrollView(this);
        contentScroll.setFillViewport(true);
        contentScroll.setClipToPadding(false);
        contentScroll.setVerticalScrollBarEnabled(false);
        pageColumn = new LinearLayout(this);
        pageColumn.setOrientation(LinearLayout.VERTICAL);
        contentScroll.addView(pageColumn, new ScrollView.LayoutParams(-1, -2));
        shell.addView(contentScroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        topBar = new LinearLayout(this);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(0, 0, 0, dp(10));
        pageColumn.addView(topBar, new LinearLayout.LayoutParams(-1, dp(46)));

        Button menuBtn = button("☰", true);
        menuBtn.setContentDescription("Abrir menu");
        menuBtn.setTextSize(24);
        menuBtn.setPadding(0, 0, 0, 0);
        menuBtn.setGravity(Gravity.CENTER);
        // O botão do menu usa o mesmo contorno azul dos cartões.
        setRoundedBackground(menuBtn, Color.rgb(10, 27, 55), CARD_OUTLINE, 11);
        menuBtn.setOnClickListener(v -> openDrawer());
        topBar.addView(menuBtn, new LinearLayout.LayoutParams(dp(40), dp(40)));

        FrameLayout logoBox = new FrameLayout(this);
        setRoundedBackground(logoBox, Color.rgb(7, 29, 62), LINE, 13);
        LinearLayout.LayoutParams lbp = new LinearLayout.LayoutParams(dp(42), dp(42));
        lbp.setMargins(dp(8), 0, dp(10), 0);
        topBar.addView(logoBox, lbp);
        logoTextView = tv("AM", 16, BLUE, true);
        logoTextView.setGravity(Gravity.CENTER);
        logoBox.addView(logoTextView, new FrameLayout.LayoutParams(-1, -1));

        logoImageView = new ImageView(this);
        logoImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logoImageView.setImageResource(com.aminovacao.amclientes231.R.drawable.ic_launcher);
        logoImageView.setVisibility(View.VISIBLE);
        // A imagem do logótipo deve respeitar o mesmo recorte arredondado do original.
        setRoundedBackground(logoImageView, Color.TRANSPARENT, 0, 10);
        logoImageView.setClipToOutline(true);
        logoBox.addView(logoImageView, new FrameLayout.LayoutParams(-1, -1));

        appTitleView = tv(store.title(), 20, TEXT, true);
        topBar.addView(appTitleView, new LinearLayout.LayoutParams(0, -2, 1f));

        topSearch = edit("Pesquisar nome, contacto, empresa, equipamento, MAC, nº série...", 15);
        topSearch.setSingleLine(true);
        topSearch.setInputType(InputType.TYPE_CLASS_TEXT);
        // A barra de pesquisa acompanha o contorno azul dos restantes painéis.
        setRoundedBackground(topSearch, Color.rgb(4, 12, 29), CARD_OUTLINE, 10);
        topSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int before, int count) {
                if (!suppressSearchRefresh && ("inicio".equals(currentScreen) || "clientes".equals(currentScreen))) refreshCurrentScreen();
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        pageColumn.addView(topSearch, new LinearLayout.LayoutParams(-1, dp(46)));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(14), 0, dp(8));
        pageColumn.addView(content, new LinearLayout.LayoutParams(-1, -2));

        buildDrawer();
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0, bottom = 0;
            if (android.os.Build.VERSION.SDK_INT >= 20) {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            shell.setPadding(dp(16), top, dp(16), bottom);
            if (drawer != null) drawer.setPadding(dp(16), top + dp(10), dp(16), bottom + dp(16));
            return insets;
        });
        setContentView(root);
        root.post(() -> root.requestApplyInsets());
        applySettingsVisuals();
    }

    private void buildDrawer() {
        // Rebuild the drawer as a single instance. The previous implementation
        // could leave an old overlay/drawer attached to root when the company
        // selection rebuilt the drawer, making the side menu appear permanently
        // stuck above the application.
        if (drawerScroll != null) {
            root.removeView(drawerScroll);
            drawerScroll = null;
        }
        if (drawerOverlay != null) {
            root.removeView(drawerOverlay);
            drawerOverlay = null;
        }

        drawerOverlay = new FrameLayout(this);
        drawerOverlay.setBackgroundColor(Color.argb(130, 0, 0, 0));
        drawerOverlay.setVisibility(View.GONE);
        drawerOverlay.setOnClickListener(v -> closeDrawer());
        root.addView(drawerOverlay, new FrameLayout.LayoutParams(-1, -1));

        final int DRAWER_LINE = Color.rgb(44, 73, 111);
        final int DRAWER_ITEM_BG = Color.rgb(7, 29, 62);
        final int COMPANY_GROUP_BG = Color.rgb(4, 12, 29);

        drawerScroll = new ScrollView(this);
        drawerScroll.setFillViewport(true);
        drawerScroll.setClipToPadding(false);
        setRoundedBackground(drawerScroll, Color.rgb(7, 26, 54), DRAWER_LINE, 0);
        FrameLayout.LayoutParams drawerLp = new FrameLayout.LayoutParams(dp(202), -1);
        drawerLp.gravity = Gravity.START;
        drawerLp.leftMargin = -dp(202);
        root.addView(drawerScroll, drawerLp);

        drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setPadding(dp(16), dp(10), dp(16), dp(16));
        drawerScroll.addView(drawer, new ScrollView.LayoutParams(-1, -2));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = tv(store.title(), 18, TEXT, true);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        Button close = button("×", false);
        close.setTextSize(24);
        head.addView(close, new LinearLayout.LayoutParams(dp(42), dp(42)));
        close.setOnClickListener(v -> closeDrawer());
        drawer.addView(head, new LinearLayout.LayoutParams(-1, -2));
        addSpacer(drawer, 12);
        addDivider(drawer);
        addSpacer(drawer, 15);

        LinearLayout companyToggle = companyHeaderRow("🏢", "Empresa", true, DRAWER_ITEM_BG, DRAWER_LINE);
        drawer.addView(companyToggle, new LinearLayout.LayoutParams(-1, dp(46)));
        addSpacer(drawer, 7);

        companyGroup = new LinearLayout(this);
        companyGroup.setOrientation(LinearLayout.VERTICAL);
        companyGroup.setPadding(dp(7), dp(7), dp(7), dp(7));
        setRoundedBackground(companyGroup, COMPANY_GROUP_BG, DRAWER_LINE, 14);

        companyList = new LinearLayout(this);
        companyList.setOrientation(LinearLayout.VERTICAL);
        companyList.setPadding(0, 0, 0, 0);
        companyList.setVisibility(View.GONE);
        renderCompanyList(companyList);
        companyGroup.addView(companyList, new LinearLayout.LayoutParams(-1, -2));
        companyGroup.setVisibility(View.GONE);
        drawer.addView(companyGroup, new LinearLayout.LayoutParams(-1, -2));
        companyToggle.setOnClickListener(v -> {
            boolean open = companyGroup.getVisibility() != View.VISIBLE;
            companyGroup.setVisibility(open ? View.VISIBLE : View.GONE);
            companyList.setVisibility(open ? View.VISIBLE : View.GONE);
            if (open) drawerScroll.post(() -> drawerScroll.fullScroll(View.FOCUS_DOWN));
        });
        addSpacer(drawer, 8);

        String[][] nav = {
                {"Início", "🏠", "inicio"},
                {"Clientes", "📋", "clientes"},
                {"Serviços e subscrições", "🔐", "subscricoes"},
                {"Catálogos", "📦", "catalogos"},
                {"Arquivado", "📁", "historico"},
                {"Histórico", "🕘", "atividade"},
                {"Estatísticas", "📊", "estatisticas"},
                {"Configurações", "⚙️", "config"},
                {"Gestão", "🛠️", "gestao"}
        };
        for (String[] item : nav) {
            Button b = menuItem(item[1], item[0], item[2].equals(currentScreen));
            b.setTextSize(14);
            b.setTag(item[2]);
            b.setOnClickListener(v -> { showScreen((String) v.getTag()); closeDrawer(); });
            drawer.addView(b, new LinearLayout.LayoutParams(-1, dp(50)));
            addSpacer(drawer, 6);
        }
    }

    private void renderCompanyList(LinearLayout host) {
        host.removeAllViews();
        JSONArray companies = store.companies();
        final int DRAWER_LINE = Color.rgb(44, 73, 111);
        final int SUB_BG = Color.rgb(7, 29, 62);
        for (int i = 0; i < companies.length(); i++) {
            JSONObject c = companies.optJSONObject(i);
            if (c == null) continue;
            final String id = c.optString("id", "");
            final String name = c.optString("name", "Empresa");
            boolean selected = id.equals(store.activeCompanyId());

            LinearLayout row = companySubRow(selected, name, DRAWER_LINE, SUB_BG);
            row.setOnClickListener(v -> {
                store.selectCompany(id);
                rebuildDrawerCompanyLabel();
                refreshCurrentScreen();
                closeDrawer();
            });
            host.addView(row, new LinearLayout.LayoutParams(-1, dp(40)));
            if (i + 1 < companies.length()) addSpacer(host, 6);
        }

        LinearLayout manage = companySubRow(false, "Gerir empresas", DRAWER_LINE, SUB_BG);
        manage.setOnClickListener(v -> { closeDrawer(); openCompanyManagement(); });
        LinearLayout.LayoutParams manageLp = new LinearLayout.LayoutParams(-1, dp(40));
        manageLp.topMargin = dp(6);
        host.addView(manage, manageLp);
    }

    private LinearLayout companyHeaderRow(String icon, String label, boolean arrow, int bg, int line) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), 0, dp(12), 0);
        setRoundedBackground(row, bg, line, 12);

        TextView ic = tv(icon, 16, TEXT, false);
        ic.setGravity(Gravity.CENTER);
        row.addView(ic, new LinearLayout.LayoutParams(dp(26), dp(46)));

        TextView labelTv = tv(label, 14, TEXT, false);
        labelTv.setSingleLine(true);
        labelTv.setEllipsize(null);
        LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(0, -1, 1f);
        row.addView(labelTv, textLp);

        if (arrow) {
            TextView ar = tv("⌄", 16, TEXT, false);
            ar.setGravity(Gravity.CENTER);
            row.addView(ar, new LinearLayout.LayoutParams(dp(22), dp(46)));
        }
        return row;
    }

    private LinearLayout companySubRow(boolean selected, String label, int line, int subBg) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), 0, dp(8), 0);
        setRoundedBackground(row, selected ? BLUE : subBg, selected ? BLUE : line, 12);

        if (selected) {
            TextView check = tv("✓", 15, Color.rgb(3, 17, 39), true);
            check.setGravity(Gravity.CENTER);
            row.addView(check, new LinearLayout.LayoutParams(dp(18), dp(40)));
        }

        TextView ic = tv("🏢", 15, selected ? Color.rgb(3,17,39) : TEXT, false);
        ic.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(22), dp(40));
        if (selected) iconLp.setMargins(dp(4), 0, 0, 0);
        row.addView(ic, iconLp);
        TextView labelTv = tv(label, 14, selected ? Color.rgb(3,17,39) : TEXT, selected);
        labelTv.setSingleLine(true);
        labelTv.setEllipsize(null);
        labelTv.setIncludeFontPadding(false);
        row.addView(labelTv, new LinearLayout.LayoutParams(0, -1, 1f));
        return row;
    }

    private void rebuildDrawerCompanyLabel() {
        buildDrawer();
        openDrawer();
    }

    private void syncDrawerSelection() {
        if (drawer == null) return;
        for (int i = 0; i < drawer.getChildCount(); i++) {
            View child = drawer.getChildAt(i);
            if (!(child instanceof Button)) continue;
            Object tag = child.getTag();
            if (!(tag instanceof String)) continue;
            Button b = (Button) child;
            boolean selected = currentScreen.equals(tag);
            if (selected) {
                setRoundedBackground(b, BLUE, BLUE, 12);
                b.setTextColor(Color.rgb(3, 17, 39));
                b.setTypeface(Typeface.create("sans-serif", Typeface.BOLD), Typeface.BOLD);
            } else {
                setRoundedBackground(b, Color.rgb(7, 29, 62), Color.rgb(44, 73, 111), 12);
                b.setTextColor(TEXT);
                b.setTypeface(null, Typeface.NORMAL);
            }
        }
    }

    private void openDrawer() {
        if (drawer == null || drawerOverlay == null || drawerScroll == null) return;
        syncDrawerSelection();
        drawerOverlay.setVisibility(View.VISIBLE);
        drawerOverlay.bringToFront();
        drawerScroll.setVisibility(View.VISIBLE);
        drawerScroll.setTranslationX(dp(202));
        drawerScroll.bringToFront();
        root.invalidate();
    }

    private void closeDrawer() {
        // Fechar o menu lateral também fecha sempre o submenu Empresa.
        // Assim, ao voltar a abrir o menu, este começa recolhido e não
        // fica preso aberto depois de navegar para outra opção.
        if (companyList != null) companyList.setVisibility(View.GONE);
        if (companyGroup != null) companyGroup.setVisibility(View.GONE);
        if (drawerScroll != null) {
            drawerScroll.setTranslationX(0f);
            drawerScroll.setVisibility(View.GONE);
        }
        if (drawerOverlay != null) {
            drawerOverlay.setVisibility(View.GONE);
        }
    }

    private void clearContent() {
        clearContent(true);
    }

    // Permite trocar o conteúdo sem forçar o scroll para o topo quando regressamos
    // de um formulário a uma pré-visualização que estava aberta mais abaixo na página.
    private void clearContent(boolean resetScrollPosition) {
        if (contentScrollAnimator != null) {
            contentScrollAnimator.cancel();
            contentScrollAnimator = null;
        }
        content.removeAllViews();
        if (resetScrollPosition) {
            finishTemporaryContentHeightAfterScroll = false;
            if (content != null) content.setMinimumHeight(0);
            if (contentScroll != null) contentScroll.scrollTo(0, 0);
        }
    }

    private void showScreen(String screen) {
        currentScreen = screen;
        if ("subscricoes".equals(screen)) subscriptionsMenuExpanded = true;
        syncDrawerSelection();
        if (topSearch != null) topSearch.setText("");
        if ("inicio".equals(screen)) selectedClientId = null;
        clearContent();
        if ("inicio".equals(screen)) renderHome();
        else if ("clientes".equals(screen)) renderClients();
        else if ("subscricoes".equals(screen)) renderSubscriptionsScreen();
        else if ("catalogos".equals(screen)) renderCatalogs();
        else if ("historico".equals(screen)) renderArchived();
        else if ("atividade".equals(screen)) renderActivity();
        else if ("estatisticas".equals(screen)) renderStatistics();
        else if ("config".equals(screen)) renderSettings();
        else if ("gestao".equals(screen)) renderManagement();
        else renderHome();
    }

    private void refreshCurrentScreen() {
        if (isFinishing()) return;
        if ("inicio".equals(currentScreen)) renderHome();
        else if ("clientes".equals(currentScreen)) renderClients();
    }

    // ============================== HOME ================================

    private void renderHome() {
        addSpacer(content, 1);
        content.addView(statRow(), new LinearLayout.LayoutParams(-1, -2));
        addSpacer(content, 14);

        Card home = card();
        setRoundedBackground(home, PANEL, HOME_LINE, 17);
        LinearLayout head = row();
        TextView h = tv("📋 Clientes", 21, TEXT, true);
        head.addView(h, new LinearLayout.LayoutParams(0, -2, 1f));

        Button toggle;
        if (selectedClientId != null) {
            h.setOnClickListener(v -> { selectedClientId = null; showScreen("inicio"); });
            h.setClickable(true);
            toggle = primary("Fechar\nCliente");
            toggle.setSingleLine(false);
            toggle.setTextSize(12);
            toggle.setIncludeFontPadding(false);
            toggle.setGravity(Gravity.CENTER);
            toggle.setPadding(0, 0, 0, 0);
            toggle.setLineSpacing(0f, 0.95f);
            toggle.setOnClickListener(v -> {
                selectedClientId = null;
                clearContent();
                renderHome();
            });
            head.addView(toggle, new LinearLayout.LayoutParams(dp(64), dp(40)));
            home.addView(head);
            addSpacer(home, 10);

            Card clientDetailPanel = new Card(this);
            clientDetailPanel.setTag("homeClientPreviewPanel");
            clientDetailPanel.setPadding(dp(8), dp(8), dp(8), dp(8));
            setRoundedBackground(clientDetailPanel, PANEL, HOME_LINE, 17);
            JSONObject c = store.findClient(selectedClientId);
            if (c != null) {
                clientDetailPanel.addView(renderClientPreview(c));
                clientDetailPanel.addView(clientSummaryCard(c));
            } else {
                selectedClientId = null;
                clearContent();
                renderHome();
                return;
            }
            home.addView(clientDetailPanel);
        } else {
            toggle = primary("Fechar");
            toggle.setSingleLine(true);
            toggle.setMinWidth(0);
            toggle.setPadding(0, 0, 0, 0);
            toggle.setOnClickListener(v -> {
                View body = (View) v.getTag();
                if (body.getVisibility() == View.VISIBLE) { body.setVisibility(View.GONE); toggle.setText("Abrir"); }
                else { body.setVisibility(View.VISIBLE); toggle.setText("Fechar"); }
            });
            head.addView(toggle, new LinearLayout.LayoutParams(dp(64), dp(40)));
            home.addView(head);
            addSpacer(home, 10);

            Card clientListPanel = new Card(this);
            clientListPanel.setPadding(dp(8), dp(8), dp(8), dp(8));
            setRoundedBackground(clientListPanel, PANEL, HOME_LINE, 17);
            LinearLayout body = new LinearLayout(this);
            body.setOrientation(LinearLayout.VERTICAL);
            clientListPanel.addView(body, new LinearLayout.LayoutParams(-1, -2));
            home.addView(clientListPanel);
            toggle.setTag(body);
            final Button homeToggle = toggle;
            h.setClickable(true);
            h.setOnClickListener(v -> {
                boolean isVisible = body.getVisibility() == View.VISIBLE;
                body.setVisibility(isVisible ? View.GONE : View.VISIBLE);
                homeToggle.setText(isVisible ? "Abrir" : "Fechar");
            });

            String q = value(topSearch).trim().toLowerCase(Locale.ROOT);
            JSONArray clients = filteredClients(q);
            List<JSONObject> alerts = new ArrayList<>();
            for (int i = 0; i < clients.length(); i++) {
                JSONObject c = clients.optJSONObject(i); if (c == null) continue;
                String st = status(c);
                if ("expired".equals(st) || "warning".equals(st)) alerts.add(c);
            }
            Collections.sort(alerts, Comparator.comparingLong(this::daysUntilValidity));
            List<JSONObject> shown = new ArrayList<>();
            if (!q.isEmpty()) {
                for (int i = 0; i < clients.length(); i++) if (clients.optJSONObject(i) != null) shown.add(clients.optJSONObject(i));
            } else if (!alerts.isEmpty()) shown.addAll(alerts);
            else {
                for (int i = 0; i < clients.length(); i++) {
                    JSONObject c = clients.optJSONObject(i); if (c != null && "active".equals(status(c))) shown.add(c);
                    if (shown.size() >= 3) break;
                }
            }
            if (shown.isEmpty()) body.addView(muted("Nenhum cliente."));
            else for (JSONObject c : shown) body.addView(clientCard(c, true));
        }

        content.addView(home);
        addSpacer(content, 14);
        renderHomeShortcuts();
    }

    private void openHomeClientPreview(String id) {
        if (id == null || id.isEmpty()) return;
        // showScreen("inicio") limpa selectedClientId; renderizar diretamente
        // preserva a seleção e abre a pré-visualização apenas no menu Iniciar.
        selectedClientId = id.equals(selectedClientId) ? null : id;
        currentScreen = "inicio";
        syncDrawerSelection();
        if (topSearch != null) topSearch.setText("");
        clearContent();
        renderHome();
        if (selectedClientId != null) {
            scrollContentTo(content.findViewWithTag("clientPreviewBody"));
        }
    }

    private View statRow() {
        LinearLayout l = row();
        int active = 0, warning = 0, expired = 0;
        JSONArray a = store.clients();
        for (int i = 0; i < a.length(); i++) { JSONObject c = a.optJSONObject(i); if (c == null) continue; String s = status(c); if ("active".equals(s)) active++; else if ("warning".equals(s)) warning++; else expired++; }
        l.addView(statCard(String.valueOf(active), "Ativos", GREEN), homeStatParams(1, false, true));
        l.addView(statCard(String.valueOf(warning), "A expirar", ORANGE), homeStatParams(1, true, true));
        l.addView(statCard(String.valueOf(expired), "Expirados", RED), homeStatParams(1, true, false));
        return l;
    }

    private View clientsStatRow() {
        LinearLayout l = row();
        int active = 0, warning = 0, expired = 0;
        JSONArray a = store.clients();
        for (int i = 0; i < a.length(); i++) {
            JSONObject c = a.optJSONObject(i);
            if (c == null) continue;
            String state = status(c);
            if ("active".equals(state)) active++;
            else if ("warning".equals(state)) warning++;
            else expired++;
        }
        l.addView(statCard(String.valueOf(active), "Ativos", GREEN, 24, 13), homeStatParams(1, false, true));
        l.addView(statCard(String.valueOf(warning), "A expirar", ORANGE, 24, 13), homeStatParams(1, true, true));
        l.addView(statCard(String.valueOf(expired), "Expirados", RED, 24, 13), homeStatParams(1, true, false));
        return l;
    }

    private View statCard(String n, String label, int color) {
        return statCard(n, label, color, 22, 13);
    }

    private View statCard(String n, String label, int color, float numberSize, float labelSize) {
        Card c = new Card(this);
        c.setPadding(dp(8), dp(4), dp(8), dp(4));
        c.setGravity(Gravity.CENTER);
        // Proporção mais baixa e próxima do original: cartões praticamente quadrados,
        // mas sem a altura excessiva da implementação anterior.
        setRoundedBackground(c, PANEL, HOME_LINE, 17);
        TextView big = tv(n, numberSize, color, true);
        big.setGravity(Gravity.CENTER);
        c.addView(big, new LinearLayout.LayoutParams(-1, dp(31)));
        TextView small = tv(label, labelSize, TEXT, false);
        small.setGravity(Gravity.CENTER);
        c.addView(small, new LinearLayout.LayoutParams(-1, dp(27)));
        c.setMinimumHeight(dp(78));
        return c;
    }

    private void renderHomeShortcuts() {
        Card section = new Card(this);
        section.setPadding(dp(16), dp(14), dp(16), dp(14));
        // Painel próprio dos atalhos, sempre visível mesmo quando não existem atalhos.
        setRoundedBackground(section, PANEL, HOME_LINE, 17);

        TextView title = tv("🔗 Atalhos", 20, TEXT, true);
        section.addView(title);
        addSpacer(section, 8);

        JSONArray arr = store.appSettings().optJSONArray("shortcuts");
        if (arr == null || arr.length() == 0) {
            section.addView(muted("Ainda não existem atalhos. Pode adicioná-los em Configurações."));
            content.addView(section);
            return;
        }
        for (int i = 0; i < arr.length(); i++) {
            JSONObject s = arr.optJSONObject(i); if (s == null) continue;
            Card c = card();
            TextView n = tv(s.optString("name", "Atalho"), 16, TEXT, true);
            c.addView(n);
            c.addView(muted(s.optString("description", "")));
            Button open = primary("Abrir");
            open.setOnClickListener(v -> openExternal(s.optString("url", "")));
            c.addView(open, new LinearLayout.LayoutParams(-1, dp(40)));
            section.addView(c); addSpacer(section, 8);
        }
        content.addView(section);
    }

    // ============================== CLIENTES =============================

    private void renderClients() {
        // O menu Clientes mantém os mesmos indicadores do ecrã Iniciar.
        // A correção é limitada ao espaçamento e estrutura deste menu.
        addSpacer(content, 1);
        content.addView(clientsStatRow(), new LinearLayout.LayoutParams(-1, -2));
        addSpacer(content, 14);

        Card panel = card();
        setRoundedBackground(panel, PANEL, HOME_LINE, 17);

        LinearLayout header = row();
        TextView t = tv("📋 Clientes", 20, TEXT, true);
        header.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));

        if (selectedClientId == null) {
            Button close = primary("Fechar");
            // Botões compactos e de dimensão fixa: o texto nunca deve quebrar em duas linhas.
            close.setSingleLine(true);
            close.setTextSize(12);
            close.setIncludeFontPadding(false);
            close.setPadding(0, 0, 0, 0);
            close.setMinWidth(0);
            close.setMinimumWidth(0);
            header.addView(close, new LinearLayout.LayoutParams(dp(64), dp(40)));

            Button add = primary("Adicionar");
            add.setSingleLine(true);
            add.setTextSize(12);
            add.setIncludeFontPadding(false);
            add.setPadding(0, 0, 0, 0);
            add.setMinWidth(0);
            add.setMinimumWidth(0);
            add.setOnClickListener(v -> openClientEditor(null));
            LinearLayout.LayoutParams addParams = new LinearLayout.LayoutParams(dp(64), dp(40));
            addParams.leftMargin = dp(8);
            header.addView(add, addParams);
            panel.addView(header);
            addSpacer(panel, 12);

            EditText search = edit("Pesquisar nome, contacto, empresa, equipamento, MAC...", 13);
            // Na barra de pesquisa do menu Clientes, o texto fica numa única linha,
            // com a mesma altura compacta do controlo original.
            search.setSingleLine(true);
            search.setMaxLines(1);
            search.setEllipsize(android.text.TextUtils.TruncateAt.END);
            search.setPadding(dp(12), 0, dp(12), 0);
            // Pesquisa interna do menu Clientes com o mesmo contorno azul.
            setRoundedBackground(search, Color.rgb(4, 12, 29), CARD_OUTLINE, 10);
            panel.addView(search, new LinearLayout.LayoutParams(-1, dp(48)));
            addSpacer(panel, 12);

            LinearLayout listHost = new LinearLayout(this);
            listHost.setOrientation(LinearLayout.VERTICAL);
            search.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void onTextChanged(CharSequence s, int st, int before, int count) { renderClientsListInto(listHost); }
                @Override public void afterTextChanged(Editable s) {}
            });
            renderClientsListInto(listHost);
            panel.addView(listHost);
            close.setOnClickListener(v -> {
                boolean currentlyVisible = listHost.getVisibility() == View.VISIBLE;
                listHost.setVisibility(currentlyVisible ? View.GONE : View.VISIBLE);
                close.setText(currentlyVisible ? "Abrir" : "Fechar");
            });
        } else {
            Button closeClient = primary("Fechar\nCliente");
            closeClient.setSingleLine(false);
            closeClient.setTextSize(12);
            closeClient.setIncludeFontPadding(false);
            closeClient.setGravity(Gravity.CENTER);
            closeClient.setPadding(0, 0, 0, 0);
            closeClient.setLineSpacing(0f, 0.95f);
            closeClient.setMinWidth(0);
            closeClient.setMinimumWidth(0);
            closeClient.setMaxWidth(dp(64));
            closeClient.setMinHeight(0);
            closeClient.setMinimumHeight(0);
            closeClient.setMaxHeight(dp(40));
            closeClient.setOnClickListener(v -> { selectedClientId = null; showScreen("clientes"); });
            t.setClickable(true);
            t.setOnClickListener(v -> { selectedClientId = null; showScreen("clientes"); });
            header.addView(closeClient, new LinearLayout.LayoutParams(dp(64), dp(40)));
            panel.addView(header);

            JSONObject c = store.findClient(selectedClientId);
            if (c != null) {
                addSpacer(panel, 10);
                panel.addView(renderClientPreview(c));
                addSpacer(panel, 10);
                panel.addView(clientSummaryCard(c));
            } else {
                selectedClientId = null;
                clearContent();
                renderClients();
                return;
            }
        }

        content.addView(panel);
        addSpacer(content, 14);
        if (selectedClientId != null) {
            scrollContentTo(content.findViewWithTag("clientPreviewBody"));
        }
    }

    private View clientSummaryCard(JSONObject c) {
        Card outer = card();
        outer.setPadding(dp(8), dp(8), dp(8), dp(8));
        setRoundedBackground(outer, PANEL, HOME_LINE, 17);
        LinearLayout line = row();
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(tv(clientName(c), 16, TEXT, true));
        left.addView(tv(orDash(c.optString("Serviço", "")), 14, MUTED, false));
        left.addView(tv(orDash(c.optString("Contacto", "")), 14, MUTED, false));
        line.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView badge = tv(statusLabel(c), 11, GREEN, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(10), dp(5), dp(10), dp(5));
        String st = status(c);
        int badgeBg = "active".equals(st) ? Color.rgb(10, 72, 45)
                : "warning".equals(st) ? Color.rgb(76, 52, 20)
                : Color.rgb(72, 28, 37);
        int badgeFg = "active".equals(st) ? GREEN
                : "warning".equals(st) ? ORANGE
                : RED;
        setRoundedBackground(badge, badgeBg, 0, 16);
        badge.setTextColor(badgeFg);
        line.addView(badge, new LinearLayout.LayoutParams(-2, -2));
        outer.addView(line);
        return outer;
    }

    private Card renderClientPreview(JSONObject c) {
        Card detail = card();
        detail.setTag("clientPreviewBody");
        detail.setPadding(dp(16), dp(14), dp(16), dp(14));
        setRoundedBackground(detail, PANEL, HOME_LINE, 17);

        LinearLayout head = row();
        TextView name = tv(clientName(c), 18, TEXT, true);
        name.setClickable(true);
        name.setOnClickListener(v -> {
            selectedClientId = null;
            showScreen(currentScreen);
        });
        head.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView badge = tv(statusLabel(c), 11, GREEN, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(10), dp(7), dp(10), dp(7));
        String st = status(c);
        int badgeBg = "active".equals(st) ? Color.rgb(10, 72, 45)
                : "warning".equals(st) ? Color.rgb(76, 52, 20)
                : Color.rgb(72, 28, 37);
        int badgeFg = "active".equals(st) ? GREEN
                : "warning".equals(st) ? ORANGE
                : RED;
        setRoundedBackground(badge, badgeBg, 0, 16);
        badge.setTextColor(badgeFg);
        head.addView(badge, new LinearLayout.LayoutParams(-2, -2));
        detail.addView(head);

        addCopyValue(detail, "Observações", c.optString("Observações", ""));
        addCopyValue(detail, "Contacto", c.optString("Contacto", ""));
        addSpacer(detail, 14);

        TextView eqTitle = tv("🛠️ Equipamento", 19, TEXT, true);
        detail.addView(eqTitle);
        addSpacer(detail, 5);

        JSONArray eqs = c.optJSONArray("equipamentos");
        JSONObject e = eqs != null && eqs.length() > 0 ? eqs.optJSONObject(0) : null;
        if (e == null) {
            addCopyValue(detail, "Nome do equipamento", "");
        } else {
            addCopyValue(detail, "Nome do equipamento", e.optString("nome", ""));
            addCopyValue(detail, "MAC", e.optString("mac", ""));
            addCopyValue(detail, "Utilizador", e.optString("utilizador", ""));
            addCopyValue(detail, "Senha", e.optString("senha", ""));
            addCopyValue(detail, "Link", e.optString("link", ""));

            TextView ssTitle = tv("🔐 Serviços e subscrições", 19, TEXT, true);
            addSpacer(detail, 12);
            detail.addView(ssTitle);
            addSpacer(detail, 5);

            List<String> serviceNames = equipmentNames(e, "servicos", "servico");
            for (int i = 0; i < serviceNames.size() && i < 4; i++) {
                addCopyValue(detail, "Serviço " + (i + 1), serviceNames.get(i));
            }
            List<String> subNames = equipmentNames(e, "subscricoes", "subscricao");
            if (subNames.isEmpty()) subNames = equipmentNames(e, "vpns", "subscricao");
            for (int i = 0; i < subNames.size() && i < 4; i++) {
                addCopyValue(detail, "Subscrição " + (i + 1), subNames.get(i));
            }
            addCopyValue(detail, "Validade", e.optString("validade", c.optString("Validade", "")));
            String periodicidade = e.optString("periodicidade", "");
            if (periodicidade.isEmpty()) periodicidade = inferPeriodicity(e.optString("validade", ""));
            addCopyValue(detail, "Periodicidade", periodicidade);
            String valor = e.optString("valorPago", "");
            if (!valor.isEmpty()) addCopyValue(detail, "Valor", valor.endsWith("€") ? valor : valor + " €");
            addCopyValue(detail, "Saldo", equipmentBalance(e) == 0 ? "—" : formatEuro(equipmentBalance(e)));
        }

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button edit = primary("✏️ Editar cliente");
        edit.setOnClickListener(v -> openClientEditor(c.optString("ID Cliente")));
        Button renew = primary("🔄 Renovar");
        renew.setOnClickListener(v -> Toast.makeText(this, "Renovação disponível para este cliente.", Toast.LENGTH_SHORT).show());
        actions.setGravity(Gravity.START);
        actions.addView(edit, new LinearLayout.LayoutParams(dp(132), dp(42)));
        LinearLayout.LayoutParams renewLp = new LinearLayout.LayoutParams(dp(98), dp(42));
        renewLp.leftMargin = dp(7);
        actions.addView(renew, renewLp);
        detail.addView(actions);
        addSpacer(detail, 8);
        Button archive = button("📦 Arquivar", false);
        archive.setOnClickListener(v -> confirm("Arquivar cliente?", "O cliente será movido para Arquivado.", () -> {
            store.archiveClient(c.optString("ID Cliente"));
            selectedClientId = null;
            showScreen("clientes");
        }));
        detail.addView(archive, new LinearLayout.LayoutParams(dp(100), dp(42)));
        addSpacer(detail, 8);

        TextView contactTitle = tv("📩 Contactar cliente", 19, TEXT, true);
        detail.addView(contactTitle);
        addSpacer(detail, 7);

        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        Button whatsapp = primary("WhatsApp");
        Button telegram = primary("Telegram");
        r1.addView(whatsapp, new LinearLayout.LayoutParams(dp(96), dp(42)));
        LinearLayout.LayoutParams telegramLp = new LinearLayout.LayoutParams(dp(90), dp(42));
        telegramLp.leftMargin = dp(7);
        r1.addView(telegram, telegramLp);
        detail.addView(r1);
        addSpacer(detail, 7);

        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        Button signal = primary("Signal");
        Button email = primary("E-mail");
        r2.addView(signal, new LinearLayout.LayoutParams(dp(72), dp(42)));
        LinearLayout.LayoutParams emailLp = new LinearLayout.LayoutParams(dp(72), dp(42));
        emailLp.leftMargin = dp(7);
        r2.addView(email, emailLp);
        detail.addView(r2);
        addSpacer(detail, 7);

        TextView modelLabel = tv("Modelo", 11, MUTED, false);
        detail.addView(modelLabel);
        addSpacer(detail, 4);
        Spinner model = spinner(asList("🔔 Renovação 1", "⚠️ Expirado", "💶 Pagamento", "🛠️ Manutenção", "✏️ Personalizada"), "🔔 Renovação 1");
        detail.addView(model, new LinearLayout.LayoutParams(-1, dp(42)));
        addSpacer(detail, 8);

        EditText message = edit("Mensagem", 14);
        message.setSingleLine(false);
        message.setMinHeight(dp(190));
        message.setGravity(Gravity.TOP | Gravity.START);
        message.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        model.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                message.setText(clientMessageFor(c, position));
            }
        });
        message.setText(clientMessageFor(c, 0));
        detail.addView(message);
        addSpacer(detail, 7);
        Button copy = button("Copiar mensagem", false);
        copy.setOnClickListener(v -> copyText(message.getText().toString(), "Mensagem copiada."));
        detail.addView(copy, new LinearLayout.LayoutParams(dp(145), dp(40)));

        whatsapp.setOnClickListener(v -> shareClientMessage(c, message.getText().toString(), "whatsapp"));
        telegram.setOnClickListener(v -> shareClientMessage(c, message.getText().toString(), "telegram"));
        signal.setOnClickListener(v -> shareClientMessage(c, message.getText().toString(), "signal"));
        email.setOnClickListener(v -> shareClientMessage(c, message.getText().toString(), "email"));
        return detail;
    }

    private void addCopyValue(ViewGroup host, String label, String value) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.addView(tv(label, 11, MUTED, false));
        addSpacer(block, 4);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        EditText field = edit("—", 14);
        field.setText(orDash(value));
        field.setFocusable(false);
        field.setClickable(false);
        field.setCursorVisible(false);
        row.addView(field, new LinearLayout.LayoutParams(0, dp(40), 1f));
        Button cp = button("📋", false);
        cp.setTextSize(17);
        cp.setGravity(Gravity.CENTER);
        cp.setPadding(0, 0, 0, 0);
        setRoundedBackground(cp, Color.rgb(10,27,55), LINE, 17);
        cp.setOnClickListener(v -> copyText(field.getText().toString(), "Copiado."));
        LinearLayout.LayoutParams cpLp = new LinearLayout.LayoutParams(dp(34), dp(34));
        cpLp.leftMargin = dp(8);
        row.addView(cp, cpLp);
        block.addView(row);
        host.addView(block);
        addSpacer(host, 7);
    }

    private List<String> equipmentNames(JSONObject e, String arrayKey, String singleKey) {
        List<String> out = new ArrayList<>();
        JSONArray a = e.optJSONArray(arrayKey);
        if (a != null) {
            for (int i = 0; i < a.length(); i++) {
                Object raw = a.opt(i);
                if (raw instanceof JSONObject) {
                    String n = ((JSONObject) raw).optString("name", ((JSONObject) raw).optString(singleKey, ""));
                    if (!n.isEmpty()) out.add(n);
                } else if (raw != null && !String.valueOf(raw).trim().isEmpty()) out.add(String.valueOf(raw));
            }
        }
        String single = e.optString(singleKey, "");
        if (out.isEmpty() && !single.isEmpty()) out.add(single);
        return out;
    }

    private String inferPeriodicity(String validity) {
        String s = String.valueOf(validity).toLowerCase(Locale.ROOT);
        if (s.contains("12")) return "Anual";
        if (s.contains("6")) return "Semestral";
        return "";
    }

    private String clientMessageFor(JSONObject c, int position) {
        String key = position == 1 ? "expired" : position == 2 ? "payment" : position == 3 ? "maintenance" : position == 4 ? "custom" : "renewal";
        String tpl = DEFAULTS.get(key);
        if (tpl == null) tpl = "";
        String service = c.optString("Serviço", "");
        String validity = c.optString("Validade", "");
        if (service.isEmpty()) {
            JSONArray eqs = c.optJSONArray("equipamentos");
            if (eqs != null && eqs.length() > 0) {
                JSONObject e = eqs.optJSONObject(0);
                if (e != null) service = e.optString("servico", "");
                if (validity.isEmpty() && e != null) validity = e.optString("validade", "");
            }
        }
        return tpl.replace("[AGORA]", "Boa tarde,")
                .replace("[CLIENTE]", clientName(c))
                .replace("[SERVIÇO]", service)
                .replace("[DATA]", validity)
                .replace("[DIAS_RESTANTES]", String.valueOf(daysUntilValidity(c)))
                .replace("[VALOR]", c.optString("Preço", "0"))
                .replace("[SALDO]", c.optString("Saldo", "0"));
    }

    private void copyText(String text, String toast) {
        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("AM Clientes", text));
        Toast.makeText(this, toast, Toast.LENGTH_SHORT).show();
    }

    private void shareClientMessage(JSONObject c, String message, String channel) {
        String phone = c.optString("Contacto", "").replaceAll("[^0-9]", "");
        String encoded = Uri.encode(message);
        try {
            if ("whatsapp".equals(channel) && !phone.isEmpty()) {
                openExternal("https://wa.me/" + phone + "?text=" + encoded);
            } else if ("telegram".equals(channel)) {
                // Abrir diretamente a aplicação oficial do Telegram, evitando
                // que o Android entregue o URL a clientes alternativos como o Nicegram.
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, message);
                i.setPackage("org.telegram.messenger");
                try {
                    startActivity(i);
                } catch (Exception e) {
                    // Fallback: abrir a aplicação oficial sem usar o cliente
                    // alternativo nem apresentar o menu de partilha.
                    Intent launch = getPackageManager().getLaunchIntentForPackage("org.telegram.messenger");
                    if (launch == null) throw e;
                    startActivity(launch);
                }
            } else if ("email".equals(channel)) {
                // Thunderbird é a aplicação de e-mail definida pelo utilizador.
                // Usamos SENDTO para manter o fluxo de e-mail do Android e,
                // quando instalado, encaminhamos diretamente para o Thunderbird.
                Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
                i.putExtra(Intent.EXTRA_SUBJECT, "AM Clientes");
                i.putExtra(Intent.EXTRA_TEXT, message);
                i.setPackage("org.mozilla.thunderbird");
                try {
                    startActivity(i);
                } catch (Exception e) {
                    // Se o Thunderbird não estiver disponível, deixa o Android
                    // usar a aplicação de e-mail predefinida do telefone.
                    Intent fallback = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
                    fallback.putExtra(Intent.EXTRA_SUBJECT, "AM Clientes");
                    fallback.putExtra(Intent.EXTRA_TEXT, message);
                    startActivity(fallback);
                }
            } else if ("signal".equals(channel)) {
                // Abrir diretamente o Signal e enviar o texto para a composição,
                // sem passar pelo menu geral de partilha do Android.
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, message);
                i.setPackage("org.thoughtcrime.securesms");
                try {
                    startActivity(i);
                } catch (Exception e) {
                    Intent launch = getPackageManager().getLaunchIntentForPackage("org.thoughtcrime.securesms");
                    if (launch == null) throw e;
                    startActivity(launch);
                }
            } else {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, message);
                startActivity(Intent.createChooser(i, "Enviar mensagem"));
            }
        } catch (Exception ignored) {
            copyText(message, "Mensagem copiada.");
        }
    }

    private void renderClientsListInto(LinearLayout host) {
        if (host == null) return;
        host.removeAllViews();
        String q = "";
        // host itself has no search ref; find latest search in parent.
        if (host.getParent() instanceof ViewGroup) {
            ViewGroup parent = (ViewGroup) host.getParent();
            for (int i = 0; i < parent.getChildCount(); i++) {
                View v = parent.getChildAt(i);
                if (v instanceof EditText) q = value((EditText) v).trim().toLowerCase(Locale.ROOT);
            }
        }
        List<JSONObject> list = new ArrayList<>();
        JSONArray a = store.clients();
        for (int i = 0; i < a.length(); i++) {
            JSONObject c = a.optJSONObject(i); if (c == null) continue;
            if (clientContains(c, q)) list.add(c);
        }
        if (list.isEmpty()) host.addView(muted("Nenhum cliente."));
        else for (JSONObject c : list) host.addView(clientCard(c, false));
    }

    private View clientCard(JSONObject c, boolean home) {
        Card row = card();
        setRoundedBackground(row, PANEL, HOME_LINE, 17);
        row.setPadding(dp(13), dp(12), dp(13), dp(12));
        LinearLayout line = new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL); line.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL);
        TextView name = tv(clientName(c), 16, TEXT, true); left.addView(name);
        left.addView(tv(orDash(c.optString("Serviço", "")), 14, MUTED, false));
        left.addView(tv(orDash(c.optString("Contacto", "")), 14, MUTED, false));
        line.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView badge = tv(statusLabel(c), 11, GREEN, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(10), dp(5), dp(10), dp(5));
        String st = status(c);
        int badgeBg = "active".equals(st) ? Color.rgb(10, 72, 45)
                : "warning".equals(st) ? Color.rgb(76, 52, 20)
                : Color.rgb(72, 28, 37);
        int badgeFg = "active".equals(st) ? GREEN
                : "warning".equals(st) ? ORANGE
                : RED;
        setRoundedBackground(badge, badgeBg, 0, 16);
        badge.setTextColor(badgeFg);
        line.addView(badge, new LinearLayout.LayoutParams(-2, -2));
        row.addView(line);
        row.setOnClickListener(v -> {
            String id = c.optString("ID Cliente", null);
            if (home) {
                openHomeClientPreview(id);
            } else {
                selectedClientId = id != null && id.equals(selectedClientId) ? null : id;
                showScreen("clientes");
            }
        });
        return row;
    }

    private void openClientEditor(String id) {
        // Guardar o contexto, a posição e a altura do ecrã anterior antes de
        // substituir a pré-visualização pelo editor. A altura temporária evita
        // que o ScrollView limite o ponto inicial antes da animação começar.
        editorReturnScreen = "clientes".equals(currentScreen) ? "clientes" : "inicio";
        editorReturnClientId = (id != null && !id.isEmpty()) ? id : selectedClientId;
        editorReturnScrollY = contentScroll == null ? 0 : contentScroll.getScrollY();
        editorReturnContentHeight = content == null ? 0 : Math.max(content.getHeight(), content.getMeasuredHeight());
        pendingEditorScrollRestore = false;
        selectedClientId = id == null ? null : id;
        if (id == null) {
            try {
                JSONObject fresh = new JSONObject();
                fresh.put("ID Cliente", store.nextClientId());
                fresh.put("Nome", "");
                fresh.put("Nome Empresa", "");
                fresh.put("Data Criação", "");
                fresh.put("equipamentos", new JSONArray());
                showNewClientEditor(fresh, true);
            } catch (Exception e) { alert("Erro", e.getMessage()); }
        } else {
            JSONObject c = store.findClient(id);
            if (c != null) showNewClientEditor(c, false);
        }
    }

    private void returnFromClientEditor() {
        // Restaurar sempre a pré-visualização de onde o editor foi aberto.
        // Mantemos temporariamente a altura do editor para que o scroll possa
        // animar desde a posição real no fim do formulário até à posição anterior.
        int editorContentHeight = content == null ? 0 : Math.max(content.getHeight(), content.getMeasuredHeight());
        int transitionHeight = Math.max(editorContentHeight, editorReturnContentHeight);

        selectedClientId = editorReturnClientId;
        currentScreen = editorReturnScreen;
        syncDrawerSelection();
        if (topSearch != null && topSearch.length() > 0) {
            suppressSearchRefresh = true;
            topSearch.setText("");
            suppressSearchRefresh = false;
        }

        // Ao cancelar a edição de um cliente existente, o destino é o INÍCIO
        // da pré-visualização, tal como quando se abre o cliente pela primeira
        // vez. Não usar editorReturnScrollY neste caso: essa posição pode ser
        // o fundo da lista e deixa a pré-visualização parcialmente escondida.
        // Para um cliente novo, que ainda não tem pré-visualização, mantemos o
        // regresso à posição anterior guardada.
        boolean hasExistingClientPreview = editorReturnClientId != null
                && !editorReturnClientId.isEmpty();
        pendingEditorScrollRestore = !hasExistingClientPreview;
        clearContent(false);
        if (content != null) content.setMinimumHeight(transitionHeight);
        finishTemporaryContentHeightAfterScroll = true;
        if ("clientes".equals(currentScreen)) {
            renderClients(); // renderClients agenda scroll para o topo da pré-visualização.
        } else {
            renderHome();
            if (hasExistingClientPreview && selectedClientId != null) {
                // O ecrã Início não agenda o scroll automaticamente ao renderizar;
                // usar o mesmo alvo e a mesma animação usados ao abrir o cliente.
                scrollContentTo(content.findViewWithTag("clientPreviewBody"));
            }
        }

        // Ao cancelar a criação de um cliente novo não existe pré-visualização.
        // Nesse caso, regressar à posição anterior que foi guardada.
        if (pendingEditorScrollRestore) {
            pendingEditorScrollRestore = false;
            animateContentScrollToY(editorReturnScrollY);
        }
    }

    private void showNewClientEditor(JSONObject original, boolean isNewClient) {
        // Não repor scrollY a zero ao reconstruir o formulário. Preservamos o
        // ponto de partida e animamos até ao título do editor, independentemente
        // de o utilizador ter carregado em Editar no topo ou no fundo da página.
        clearContent(false);
        if (content != null) content.setMinimumHeight(editorReturnContentHeight);
        TextView title = tv((isNewClient ? "Novo cliente" : "Editar cliente") + " · " + original.optString("ID Cliente", ""), 20, TEXT, true);
        title.setTag("clientEditorTitle");
        content.addView(title);
        addSpacer(content, 10);
        Card detail = (Card) renderClientEditorCard(original, isNewClient);
        content.addView(detail);
        finishTemporaryContentHeightAfterScroll = true;
        if (contentScroll != null) {
            contentScroll.setFocusableInTouchMode(true);
            contentScroll.requestFocus();
            // Ao entrar na edição, começar no topo do formulário e percorrer a página
            // para baixo até aos campos mais usados do equipamento. Isto substitui
            // o alinhamento antigo ao título, que fazia a animação terminar no topo.
            contentScroll.scrollTo(0, 0);
        }
        pendingEditorScrollRestore = false;
        View editorScrollTarget = content.findViewWithTag("editorEquipmentTypeTarget");
        if (editorScrollTarget == null) {
            // Clientes sem equipamento ainda não têm campos de tipo/nome; mostrar
            // a secção onde se pode adicionar o primeiro equipamento.
            editorScrollTarget = content.findViewWithTag("editorEquipmentStartTarget");
        }
        scrollContentTo(editorScrollTarget != null ? editorScrollTarget : title);
    }

    private View renderClientEditorCard(JSONObject c, boolean isNewClient) {
        Card card = card();
        final JSONObject work;
        try { work = new JSONObject(c.toString()); } catch (JSONException e) { throw new RuntimeException(e); }
        addEditorField(card, "Nome", "Nome", work, "Ex.: Nome do cliente");
        addEditorField(card, "Observações", "Observações", work, "Ex.: Observações sobre o cliente");
        addEditorField(card, "Contacto", "Contacto", work, "Ex.: Número de contacto");
        addEditorFieldSpinner(card, "Nome Empresa", "Nome Empresa", store.list("empresas"), work, "Selecionar empresa");
        addEditorField(card, "Email", "Email", work, "Ex.: email@cliente.pt");
        addEditorField(card, "Morada", "Morada", work, "Ex.: Morada do cliente");
        addEditorDateField(card, "Data de criação", "Data Criação", work);

        addSpacer(card, 10);
        TextView eqTitle = tv("📦 Equipamentos do cliente", 18, TEXT, true); card.addView(eqTitle); addSpacer(card, 12);
        JSONArray eqs = work.optJSONArray("equipamentos"); if (eqs == null) eqs = new JSONArray();
        LinearLayout eqHost = new LinearLayout(this); eqHost.setOrientation(LinearLayout.VERTICAL); card.addView(eqHost);
        renderEquipmentEditor(eqHost, eqs, work);

        addSpacer(card, 12);
        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setGravity(Gravity.CENTER_VERTICAL);
        Button save = primary("💾 Guardar");
        Button cancel = button("Cancelar", false);
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        saveLp.rightMargin = dp(4);
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        cancelLp.leftMargin = dp(4);
        if (!isNewClient) {
            Button del = button("🗑️ Apagar", false);
            LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
            delLp.leftMargin = dp(4);
            actions.addView(save, saveLp);
            actions.addView(cancel, cancelLp);
            actions.addView(del, delLp);
            del.setOnClickListener(v -> confirm("Apagar cliente?", "Tem a certeza que pretende apagar este cliente?", () -> {
                store.deleteClient(c.optString("ID Cliente"));
                selectedClientId = null;
                showScreen("clientes");
            }));
        } else {
            actions.addView(save, saveLp);
            actions.addView(cancel, cancelLp);
        }
        save.setOnClickListener(v -> { try { JSONObject result = collectClientDraft(card, work); store.saveClient(result); selectedClientId = result.optString("ID Cliente", null); Toast.makeText(this, "Cliente guardado.", Toast.LENGTH_SHORT).show(); showScreen("clientes"); } catch (Exception e) { alert("Erro", "Não foi possível guardar o cliente: " + e.getMessage()); } });
        cancel.setOnClickListener(v -> returnFromClientEditor());
        card.addView(actions);
        return card;
    }

    private JSONObject collectClientDraft(Card card, JSONObject work) throws JSONException {
        JSONObject out = new JSONObject(work.toString());
        String[] keys = {"Nome", "Observações", "Contacto", "Email", "Morada", "Data Criação"};
        for (String key : keys) { EditText e=(EditText)card.findViewWithTag("f:"+key); if(e!=null)out.put(key,value(e)); }
        Spinner company=(Spinner)card.findViewWithTag("s:Nome Empresa"); if(company!=null)out.put("Nome Empresa",selectedEditorSpinnerValue(company));
        View eqHost=card.findViewWithTag("equipmentHost"); if(eqHost!=null)out.put("equipamentos",collectEquipmentEditor((LinearLayout)eqHost));
        return out;
    }

    private JSONArray collectEquipmentEditor(LinearLayout host) throws JSONException {
        JSONArray out=new JSONArray();
        for(int i=0;i<host.getChildCount();i++){
            View v=host.getChildAt(i); if(!(v instanceof Card))continue;
            Card card=(Card)v; JSONObject e=new JSONObject(); e.put("id",String.valueOf(card.getTag()==null?uuid("eq"):card.getTag()));
            String[] fields={"mac","utilizador","senha","link","dataInstalacao","dataPagamento","validade","valorPago"};
            for(String f:fields){EditText ed=(EditText)card.findViewWithTag("eq:"+f);if(ed!=null)e.put(f,value(ed));}
            Spinner equipmentType=(Spinner)card.findViewWithTag("eqs:tipo");if(equipmentType!=null)e.put("tipo",selectedEditorSpinnerValue(equipmentType));
            Spinner equipmentName=(Spinner)card.findViewWithTag("eqs:nome");if(equipmentName!=null)e.put("nome",selectedEditorSpinnerValue(equipmentName));
            Spinner payment=(Spinner)card.findViewWithTag("eqs:metodoPagamento");if(payment!=null)e.put("metodoPagamento",selectedEditorSpinnerValue(payment));
            syncAssignmentArraysFromEditor(card,e); e.put("saldo",String.valueOf(Math.round(equipmentBalance(e)))); out.put(e);
        }
        return out;
    }

    private String textFromTag(ViewGroup host,String tag){View v=host.findViewWithTag(tag);return v instanceof EditText?value((EditText)v):"";}

    private void addEditorField(ViewGroup host,String label,String key,JSONObject obj,String hint){LinearLayout block=fieldBlock(label);EditText e=editorFormEdit(hint);e.setTag("f:"+key);String current=obj.optString(key,"");if(!current.isEmpty())e.setText(current);block.addView(e);host.addView(block);addSpacer(host,10);}
    private void addField(ViewGroup host, String label, String key, JSONObject obj) {
        LinearLayout block = fieldBlock(label);
        EditText e = edit(orDash(obj.optString(key, "")), 14);
        e.setHint(orDash(obj.optString(key, "")));
        e.setTag("f:" + key);
        if (obj.has(key)) e.setText(obj.optString(key, ""));
        block.addView(e);
        host.addView(block); addSpacer(host, 8);
    }

    private void addFieldSpinner(ViewGroup host, String label, String key, JSONArray options, JSONObject obj) {
        LinearLayout block = fieldBlock(label);
        Spinner s = spinner(optionsToList(options), obj.optString(key, ""));
        s.setTag("s:" + key);
        block.addView(s); host.addView(block); addSpacer(host, 8);
    }

    private void addDateField(ViewGroup host, String label, String key, JSONObject obj) {
        LinearLayout block = fieldBlock(label);
        EditText e = edit("Selecionar data", 14); e.setTag("f:" + key); e.setFocusable(false); e.setClickable(true);
        e.setText(obj.optString(key, ""));
        e.setOnClickListener(v -> pickDate(e));
        block.addView(e); host.addView(block); addSpacer(host, 8);
    }

    private void addEditorFieldSpinner(ViewGroup host,String label,String key,JSONArray options,JSONObject obj,String hint){LinearLayout block=fieldBlock(label);Spinner s=editorFormSpinner(optionsToList(options),obj.optString(key,""),hint);s.setTag("s:"+key);block.addView(s,new LinearLayout.LayoutParams(-1,dp(28)));host.addView(block);addSpacer(host,10);}
    private void addEditorDateField(ViewGroup host,String label,String key,JSONObject obj){LinearLayout block=fieldBlock(label);EditText e=editorFormEdit("Selecionar data");e.setTag("f:"+key);e.setFocusable(false);e.setClickable(true);e.setCompoundDrawablePadding(dp(6));e.setCompoundDrawablesRelative(null,null,new DownChevronDrawable(),null);e.setPadding(dp(12),0,dp(8),0);String current=obj.optString(key,"");if(!current.isEmpty())e.setText(current);e.setOnClickListener(v->pickDate(e));block.addView(e);host.addView(block);addSpacer(host,10);}
    private void addEditorEquipmentField(Card c,String label,String key,String val,boolean numeric){String hint=label; if("mac".equals(key))hint="Ex.: 00:11:22:33:44:55";else if("utilizador".equals(key))hint="Ex.: Nome de utilizador";else if("senha".equals(key))hint="Ex.: Senha do equipamento";else if("link".equals(key))hint="Ex.: https://exemplo.pt";else if("valorPago".equals(key))hint="Valor pago";EditText e=editorFormEdit(hint);e.setTag("eq:"+key);if(!val.isEmpty())e.setText(val);if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);c.addView(fieldBlockWith(labelOnly(label),e));addSpacer(c,10);}
    private void addEditorEquipmentSpinner(Card c,String label,String key,List<String> values,String current,String hint){Spinner s=editorFormSpinner(values,current,hint);s.setTag("eqs:"+key);LinearLayout block=fieldBlockWith(labelOnly(label),s);if("tipo".equals(key))block.setTag("editorEquipmentTypeTarget");c.addView(block);addSpacer(c,10);}
    private void addEditorEquipmentDate(Card c,String label,String key,String val){EditText e=editorFormEdit("Selecionar data");e.setFocusable(false);e.setClickable(true);e.setTag("eq:"+key);e.setCompoundDrawablePadding(dp(6));e.setCompoundDrawablesRelative(null,null,new DownChevronDrawable(),null);e.setPadding(dp(12),0,dp(8),0);if(!val.isEmpty())e.setText(val);e.setOnClickListener(v->pickDate(e));c.addView(fieldBlockWith(labelOnly(label),e));addSpacer(c,10);}

    private LinearLayout fieldBlock(String label){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);TextView l=tv(label,11,MUTED,false);b.addView(l);addSpacer(b,4);return b;}
    private TextView labelOnly(String text){return tv(text,11,MUTED,false);}
    private LinearLayout fieldBlockWith(TextView label,View value){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.addView(label);addSpacer(b,4);b.addView(value);return b;}

    private void renderEquipmentEditor(LinearLayout host,JSONArray eqs,JSONObject client){
        host.setTag("equipmentHost");host.removeAllViews();
        Button add=primary("＋ Novo equipamento");
        add.setTag("editorEquipmentStartTarget");
        host.addView(add,new LinearLayout.LayoutParams(-1,dp(42)));
        addSpacer(host,12);
        add.setOnClickListener(v->{try{
            JSONObject e=new JSONObject();
            e.put("id",uuid("eq"));e.put("servicos",new JSONArray());e.put("subscricoes",new JSONArray());e.put("vpns",new JSONArray());
            TextView overall=(TextView)host.findViewWithTag("overallServiceTotal");
            int insertAt=overall==null?host.getChildCount():host.indexOfChild(overall);
            Card newEquipment=equipmentCard(host,e,countEquipmentCards(host));
            host.addView(newEquipment,insertAt);
            View gap=new View(this);gap.setLayoutParams(new LinearLayout.LayoutParams(1,dp(8)));host.addView(gap,insertAt+1);
            refreshEquipmentCardLabels(host);refreshEditorTotals(host);
            scrollContentTo(newEquipment);
        }catch(Exception ex){alert("Erro",ex.getMessage());}});
        for(int i=0;i<eqs.length();i++){JSONObject e=eqs.optJSONObject(i);if(e==null)continue;host.addView(equipmentCard(host,e,i));addSpacer(host,8);}
        TextView overall=tv("Total de serviço: 0 €",15,TEXT,true);overall.setTag("overallServiceTotal");overall.setGravity(Gravity.END);LinearLayout.LayoutParams totalLp=new LinearLayout.LayoutParams(-1,-2);totalLp.topMargin=dp(8);totalLp.bottomMargin=dp(2);host.addView(overall,totalLp);
        refreshEquipmentCardLabels(host);refreshEditorTotals(host);
    }

    private int countEquipmentCards(ViewGroup host){int n=0;for(int i=0;i<host.getChildCount();i++)if(host.getChildAt(i) instanceof Card)n++;return n;}

    private Card equipmentCard(LinearLayout host,JSONObject e,int index){
        Card c=card();c.setTag(e.optString("id",uuid("eq")));try{c.setTag(TAG_JSON,new JSONObject(e.toString()));}catch(Exception ignored){c.setTag(TAG_JSON,new JSONObject());}
        c.setPadding(dp(14),dp(14),dp(14),dp(14));
        LinearLayout head=row();TextView title=tv("Equipamento "+(index+1),16,TEXT,true);title.setTag("equipmentTitle");head.addView(title,new LinearLayout.LayoutParams(0,-2,1f));Button remove=button("🗑️ Remover",false);remove.setOnClickListener(v->confirm("Remover equipamento?","Tem a certeza que pretende remover este equipamento?",()->{int idx=host.indexOfChild(c);host.removeView(c);if(idx>=0&&idx<host.getChildCount()&&!(host.getChildAt(idx) instanceof Card)&&!(host.getChildAt(idx) instanceof Button)&&host.getChildAt(idx).getTag()==null)host.removeViewAt(idx);refreshEquipmentCardLabels(host);refreshEditorTotals(host);}));head.addView(remove,new LinearLayout.LayoutParams(dp(115),dp(40)));c.addView(head);addSpacer(c,10);
        addEditorEquipmentSpinner(c,"Tipo de Equipamento","tipo",optionsToList(store.list("equipamentos")),e.optString("tipo",""),"Selecionar tipo de equipamento");
        addEditorEquipmentSpinner(c,"Nome do Equipamento","nome",optionsToList(store.list("nome_equipamentos")),e.optString("nome",""),"Selecionar nome do equipamento");
        addEditorEquipmentField(c,"Identificação MAC","mac",e.optString("mac",""),false);addEditorEquipmentField(c,"Utilizador","utilizador",e.optString("utilizador",""),false);addEditorEquipmentField(c,"Senha","senha",e.optString("senha",""),false);addEditorEquipmentField(c,"Link","link",e.optString("link",""),false);
        LinearLayout serviceHost=new LinearLayout(this);serviceHost.setOrientation(LinearLayout.VERTICAL);serviceHost.setTag("serviceRowsHost");c.addView(serviceHost);JSONArray sr=mergedServiceRows(e);if(sr.length()==0)addServiceRow(serviceHost,null);else for(int i=0;i<sr.length();i++)addServiceRow(serviceHost,sr.optJSONObject(i));refreshRowLabels(serviceHost,"serviceRow","Serviço");
        LinearLayout subHost=new LinearLayout(this);subHost.setOrientation(LinearLayout.VERTICAL);subHost.setTag("subscriptionRowsHost");c.addView(subHost);JSONArray subr=mergedSubscriptionRows(e);if(subr.length()==0)addSubscriptionRow(subHost,null);else for(int i=0;i<subr.length();i++)addSubscriptionRow(subHost,subr.optJSONObject(i));refreshRowLabels(subHost,"subscriptionRow","Subscrição");
        addEditorEquipmentSpinner(c,"Tipo de pagamento","metodoPagamento",optionsToList(store.list("pagamentos")),e.optString("metodoPagamento",""),"Selecionar método de pagamento");addEditorEquipmentDate(c,"Data de início de serviço","dataInstalacao",e.optString("dataInstalacao",""));addEditorEquipmentDate(c,"Data do pagamento","dataPagamento",e.optString("dataPagamento",""));addEditorEquipmentDate(c,"Validade","validade",e.optString("validade",""));addEditorEquipmentField(c,"Valor pago","valorPago",e.optString("valorPago",""),true);
        EditText saldo=editorFormEdit("Saldo");saldo.setTag("eq:saldo");saldo.setText(formatEuro(equipmentBalance(e)));saldo.setFocusable(false);c.addView(fieldBlockWith(labelOnly("Saldo"),saldo));addSpacer(c,10);
        LinearLayout actionRows=row();Button addService=primary("Adicionar\nserviço");Button addSub=primary("Adicionar\nsubscrição");actionRows.addView(addService,new LinearLayout.LayoutParams(0,dp(42),1f));LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(0,dp(42),1f);slp.leftMargin=dp(6);actionRows.addView(addSub,slp);c.addView(actionRows);addSpacer(c,10);
        addService.setOnClickListener(v->{addServiceRow(serviceHost,null);refreshRowLabels(serviceHost,"serviceRow","Serviço");refreshEditorTotals(serviceHost);scrollContentTo(lastRowByTag(serviceHost,"serviceRow"));});
        addSub.setOnClickListener(v->{addSubscriptionRow(subHost,null);refreshRowLabels(subHost,"subscriptionRow","Subscrição");refreshEditorTotals(subHost);scrollContentTo(lastRowByTag(subHost,"subscriptionRow"));});
        TextView total=tv("Total deste equipamento: "+formatEuro(equipmentTotal(e)),14,TEXT,true);total.setTag("equipmentTotalLabel");total.setGravity(Gravity.END);c.addView(total);return c;
    }

    private void promoteToNumbered(ViewGroup host,String tag,String prefix){if(rowCountByTag(host,tag)==1){View v=firstRowByTag(host,tag);if(v instanceof ViewGroup){View l=((ViewGroup)v).getChildAt(0);if(l instanceof TextView)((TextView)l).setText(prefix+" 1");}}else refreshRowLabels(host,tag,prefix);}
    private View firstRowByTag(ViewGroup host,String tag){for(int i=0;i<host.getChildCount();i++)if(tag.equals(host.getChildAt(i).getTag()))return host.getChildAt(i);return null;}

    private void addServiceRow(LinearLayout host,JSONObject existing){
        int index=rowCountByTag(host,"serviceRow");
        LinearLayout block=new LinearLayout(this);block.setOrientation(LinearLayout.VERTICAL);block.setTag("serviceRow");
        TextView label=labelOnly(index==0?"Serviço":"Serviço "+(index+1));block.addView(label);addSpacer(block,4);
        String selected=existing==null?"":existing.optString("nome",existing.optString("name",""));
        Spinner sp=editorFormSpinner(store.serviceNames(),selected,"Selecionar serviço");sp.setTag("srvSpinner");block.addView(sp,new LinearLayout.LayoutParams(-1,dp(28)));addSpacer(block,6);
        LinearLayout priceRow=row();priceRow.setTag("servicePriceRow");
        EditText val=editorFormEdit("");val.setTag("srvValue");
        val.setVisibility(selected.isEmpty()?(index>0?View.INVISIBLE:View.GONE):View.VISIBLE);
        if(existing!=null&&existing.has("valor"))val.setText(formatEuro(existing.optDouble("valor",0)));else if(!selected.isEmpty())val.setText(formatEuro(store.serviceValue(selected)));
        priceRow.addView(val,new LinearLayout.LayoutParams(0,dp(28),1f));
        if(index>0){
            Button del=button("🗑",false);del.setContentDescription("Remover serviço");
            LinearLayout.LayoutParams delLp=new LinearLayout.LayoutParams(dp(48),dp(34));delLp.leftMargin=dp(6);
            del.setOnClickListener(v->{host.removeView(block);refreshRowLabels(host,"serviceRow","Serviço");refreshEditorTotals(host);});
            priceRow.addView(del,delLp);
        }
        if(selected.isEmpty()&&index==0)priceRow.setVisibility(View.GONE);
        block.addView(priceRow);host.addView(block);addSpacer(host,8);
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){
                String n=selectedEditorSpinnerValue(sp);boolean chosen=!n.isEmpty();
                priceRow.setVisibility(chosen||index>0?View.VISIBLE:View.GONE);
                val.setVisibility(chosen?View.VISIBLE:(index>0?View.INVISIBLE:View.GONE));
                if(!chosen)val.setText("");else val.setText(formatEuro(store.serviceValue(n)));
                refreshEditorTotals(host);
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent){priceRow.setVisibility(index>0?View.VISIBLE:View.GONE);val.setVisibility(index>0?View.INVISIBLE:View.GONE);val.setText("");refreshEditorTotals(host);}
        });
    }

    private void addSubscriptionRow(LinearLayout host,JSONObject existing){
        int index=rowCountByTag(host,"subscriptionRow");
        LinearLayout block=new LinearLayout(this);block.setOrientation(LinearLayout.VERTICAL);block.setTag("subscriptionRow");
        TextView label=labelOnly(index==0?"Subscrição":"Subscrição "+(index+1));block.addView(label);addSpacer(block,4);
        String selected=existing==null?"":existing.optString("subscricao",existing.optString("name",""));
        Spinner sp=editorFormSpinner(subscriptionNamesWithPacks(),selected,"Selecionar subscrição");sp.setTag("subSpinner");block.addView(sp,new LinearLayout.LayoutParams(-1,dp(28)));addSpacer(block,6);
        LinearLayout priceRow=row();priceRow.setTag("subscriptionPriceRow");
        EditText val=editorFormEdit("");val.setTag("subValue");
        val.setVisibility(selected.isEmpty()?(index>0?View.INVISIBLE:View.GONE):View.VISIBLE);
        if(existing!=null&&existing.has("valor"))val.setText(formatEuro(existing.optDouble("valor",0)));else if(!selected.isEmpty())val.setText(formatEuro(subscriptionSaleValue(selected)));
        priceRow.addView(val,new LinearLayout.LayoutParams(0,dp(28),1f));
        if(index>0){
            Button del=button("🗑",false);del.setContentDescription("Remover subscrição");
            LinearLayout.LayoutParams delLp=new LinearLayout.LayoutParams(dp(48),dp(34));delLp.leftMargin=dp(6);
            del.setOnClickListener(v->{host.removeView(block);refreshRowLabels(host,"subscriptionRow","Subscrição");refreshEditorTotals(host);});
            priceRow.addView(del,delLp);
        }
        if(selected.isEmpty()&&index==0)priceRow.setVisibility(View.GONE);
        block.addView(priceRow);host.addView(block);addSpacer(host,8);
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){
                String n=selectedEditorSpinnerValue(sp);boolean chosen=!n.isEmpty();
                priceRow.setVisibility(chosen||index>0?View.VISIBLE:View.GONE);
                val.setVisibility(chosen?View.VISIBLE:(index>0?View.INVISIBLE:View.GONE));
                if(!chosen)val.setText("");else val.setText(formatEuro(subscriptionSaleValue(n)));
                refreshEditorTotals(host);
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent){priceRow.setVisibility(index>0?View.VISIBLE:View.GONE);val.setVisibility(index>0?View.INVISIBLE:View.GONE);val.setText("");refreshEditorTotals(host);}
        });
    }

    private View lastRowByTag(ViewGroup host,String tag){
        for(int i=host.getChildCount()-1;i>=0;i--){View v=host.getChildAt(i);if(tag.equals(v.getTag()))return v;}
        return null;
    }

    private void scrollContentTo(View target){
        if(target==null||contentScroll==null)return;
        // No regresso do editor, a posição guardada tem prioridade sobre o
        // alinhamento normal do alvo. A animação parte do scroll atual e pode
        // subir ou descer conforme a distância até ao ponto anterior.
        if (pendingEditorScrollRestore) {
            pendingEditorScrollRestore = false;
            animateContentScrollToY(editorReturnScrollY);
            return;
        }
        contentScroll.post(()->contentScroll.postOnAnimation(()->{
            if(target.getParent()==null||contentScroll.getHeight()<=0)return;
            int[] targetLocation=new int[2];int[] scrollLocation=new int[2];
            target.getLocationOnScreen(targetLocation);contentScroll.getLocationOnScreen(scrollLocation);
            int current=contentScroll.getScrollY();
            int targetTop=current+targetLocation[1]-scrollLocation[1];
            int maxScroll=Math.max(0,pageColumn.getHeight()-contentScroll.getHeight());
            int destination=Math.min(maxScroll,Math.max(0,targetTop-dp(12)));
            animateContentScroll(current,destination);
        }));
    }

    private void animateContentScrollToY(int requestedY) {
        if (contentScroll == null) { finishTemporaryContentHeightIfNeeded(); return; }
        contentScroll.post(() -> contentScroll.postOnAnimation(() -> {
            if (contentScroll == null || pageColumn == null || contentScroll.getHeight() <= 0) {
                finishTemporaryContentHeightIfNeeded();
                return;
            }
            int maxScroll = Math.max(0, pageColumn.getHeight() - contentScroll.getHeight());
            int current = contentScroll.getScrollY();
            int destination = Math.max(0, Math.min(maxScroll, requestedY));
            animateContentScroll(current, destination);
        }));
    }

    private void animateContentScroll(int current, int destination) {
        if (contentScroll == null || Math.abs(destination - current) < 3) {
            finishTemporaryContentHeightIfNeeded();
            return;
        }
        if (contentScrollAnimator != null) {
            contentScrollAnimator.cancel();
            contentScrollAnimator = null;
        }
        ValueAnimator animator = ValueAnimator.ofInt(current, destination);
        // Curva simétrica e natural: acelera suavemente, percorre a distância e
        // desacelera no fim, tanto ao abrir o editor como ao cancelar a edição.
        long duration = Math.max(520L, Math.min(1050L, 420L + Math.round(Math.abs(destination - current) * 0.32f)));
        animator.setDuration(duration);
        animator.setInterpolator(new AccelerateDecelerateInterpolator());
        animator.addUpdateListener(a -> {
            if (contentScroll != null) contentScroll.scrollTo(0, (Integer) a.getAnimatedValue());
        });
        animator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                if (contentScrollAnimator == animator) contentScrollAnimator = null;
                finishTemporaryContentHeightIfNeeded();
            }
            @Override public void onAnimationCancel(android.animation.Animator animation) {
                if (contentScrollAnimator == animator) contentScrollAnimator = null;
            }
        });
        contentScrollAnimator = animator;
        animator.start();
    }

    private void finishTemporaryContentHeightIfNeeded() {
        if (!finishTemporaryContentHeightAfterScroll) return;
        finishTemporaryContentHeightAfterScroll = false;
        if (content != null) {
            content.setMinimumHeight(0);
            content.requestLayout();
        }
    }

    private int rowCountByTag(ViewGroup host,String tag){int n=0;for(int i=0;i<host.getChildCount();i++)if(tag.equals(host.getChildAt(i).getTag()))n++;return n;}
    private void refreshRowLabels(ViewGroup host,String tag,String prefix){int count=rowCountByTag(host,tag),n=0;for(int i=0;i<host.getChildCount();i++){View v=host.getChildAt(i);if(!tag.equals(v.getTag())||!(v instanceof ViewGroup))continue;View l=((ViewGroup)v).getChildAt(0);if(l instanceof TextView)((TextView)l).setText(count==1?prefix:prefix+" "+(++n));}}

    private void refreshEquipmentCardLabels(LinearLayout equipmentHost){
        int n=0;
        for(int i=0;i<equipmentHost.getChildCount();i++){
            View v=equipmentHost.getChildAt(i);
            if(!(v instanceof Card))continue;
            TextView title=((Card)v).findViewWithTag("equipmentTitle");
            if(title!=null)title.setText("Equipamento "+(++n));
        }
    }

    private LinearLayout findEquipmentHost(View source){
        View current=source;
        while(current!=null){
            if(current instanceof LinearLayout && "equipmentHost".equals(current.getTag()))return (LinearLayout)current;
            android.view.ViewParent parent=current.getParent();
            current=parent instanceof View?(View)parent:null;
        }
        return null;
    }

    private double editorRowsTotal(ViewGroup equipmentCard,String hostTag,String rowTag,String valueTag){
        double total=0;
        ViewGroup rows=equipmentCard.findViewWithTag(hostTag);
        if(rows==null)return total;
        for(int i=0;i<rows.getChildCount();i++){
            View row=rows.getChildAt(i);
            if(!(row instanceof ViewGroup)||!rowTag.equals(row.getTag()))continue;
            EditText amount=((ViewGroup)row).findViewWithTag(valueTag);
            if(amount!=null)total+=money(value(amount));
        }
        return total;
    }

    private double editorEquipmentCardTotal(ViewGroup equipmentCard){
        return editorRowsTotal(equipmentCard,"serviceRowsHost","serviceRow","srvValue")
                + editorRowsTotal(equipmentCard,"subscriptionRowsHost","subscriptionRow","subValue");
    }

    private void refreshEditorTotals(View source){
        LinearLayout equipmentHost=findEquipmentHost(source);
        if(equipmentHost==null)return;
        double grandTotal=0;
        for(int i=0;i<equipmentHost.getChildCount();i++){
            View v=equipmentHost.getChildAt(i);
            if(!(v instanceof Card))continue;
            double total=editorEquipmentCardTotal((ViewGroup)v);
            grandTotal+=total;
            Card equipment=(Card)v;
            TextView label=equipment.findViewWithTag("equipmentTotalLabel");
            if(label!=null)label.setText("Total deste equipamento: "+formatEuro(total));
            EditText paid=equipment.findViewWithTag("eq:valorPago");
            EditText balance=equipment.findViewWithTag("eq:saldo");
            if(balance!=null)balance.setText(formatEuro((paid==null?0:money(value(paid)))-total));
        }
        TextView overall=equipmentHost.findViewWithTag("overallServiceTotal");
        if(overall!=null)overall.setText("Total de serviço: "+formatEuro(grandTotal));
    }

    private JSONArray mergedServiceRows(JSONObject e){JSONArray out=new JSONArray();try{String main=e.optString("servico","");if(!main.isEmpty())out.put(new JSONObject().put("nome",main).put("valor",e.has("servicoValor")?money(e.optString("servicoValor","0")):store.serviceValue(main)));JSONArray a=e.optJSONArray("servicos");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String n=x.optString("nome",x.optString("name",""));if(n.isEmpty())continue;if(!main.equals(n)||out.length()==0)out.put(new JSONObject(x.toString()));}}catch(Exception ignored){}return out;}
    private JSONArray mergedSubscriptionRows(JSONObject e){JSONArray out=new JSONArray();try{String main=e.optString("subscricao","");if(!main.isEmpty())out.put(new JSONObject().put("name",main).put("subscricao",main).put("valor",e.has("subscricaoValor")?money(e.optString("subscricaoValor","0")):subscriptionSaleValue(main)));JSONArray a=e.optJSONArray("subscricoes");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String n=x.optString("subscricao",x.optString("name",""));if(n.isEmpty())continue;if(!main.equals(n)||out.length()==0)out.put(new JSONObject(x.toString()));}if(out.length()==0){JSONArray v=e.optJSONArray("vpns");if(v!=null)for(int i=0;i<v.length();i++){JSONObject x=v.optJSONObject(i);if(x!=null)out.put(new JSONObject(x.toString()));}}}catch(Exception ignored){}return out;}

    private void syncAssignmentArraysFromEditor(Card card,JSONObject e)throws JSONException{JSONArray services=new JSONArray();ViewGroup sh=card.findViewWithTag("serviceRowsHost");if(sh!=null)for(int i=0;i<sh.getChildCount();i++){View rv=sh.getChildAt(i);if(!(rv instanceof LinearLayout)||!"serviceRow".equals(rv.getTag()))continue;Spinner sp=(Spinner)rv.findViewWithTag("srvSpinner");EditText v=(EditText)rv.findViewWithTag("srvValue");String n=selectedEditorSpinnerValue(sp);if(!n.isEmpty())services.put(new JSONObject().put("serviceId",n).put("nome",n).put("valor",money(value(v))));}e.put("servicos",services);e.put("servico",services.length()>0?services.optJSONObject(0).optString("nome",""):"");e.put("servicoValor",services.length()>0?services.optJSONObject(0).optDouble("valor",0):0);JSONArray subs=new JSONArray();ViewGroup uh=card.findViewWithTag("subscriptionRowsHost");if(uh!=null)for(int i=0;i<uh.getChildCount();i++){View rv=uh.getChildAt(i);if(!(rv instanceof LinearLayout)||!"subscriptionRow".equals(rv.getTag()))continue;Spinner sp=(Spinner)rv.findViewWithTag("subSpinner");EditText v=(EditText)rv.findViewWithTag("subValue");String n=selectedEditorSpinnerValue(sp);if(!n.isEmpty())subs.put(new JSONObject().put("name",n).put("subscricao",n).put("valor",money(value(v))));}e.put("subscricoes",subs);e.put("subscricao",subs.length()>0?subs.optJSONObject(0).optString("name",""):"");e.put("subscricaoValor",subs.length()>0?subs.optJSONObject(0).optDouble("valor",0):0);}

    private double equipmentTotal(JSONObject e){double total=0;JSONArray s=e.optJSONArray("servicos");if(s!=null&&s.length()>0)for(int i=0;i<s.length();i++){JSONObject x=s.optJSONObject(i);if(x!=null)total+=x.optDouble("valor",0);}else if(!e.optString("servico","").isEmpty())total+=money(e.optString("servicoValor","0"));JSONArray u=e.optJSONArray("subscricoes");if(u!=null&&u.length()>0)for(int i=0;i<u.length();i++){JSONObject x=u.optJSONObject(i);if(x!=null)total+=x.optDouble("valor",subscriptionSaleValue(x.optString("name",x.optString("subscricao",""))));}else if(!e.optString("subscricao","").isEmpty())total+=money(e.optString("subscricaoValor","0"));else{JSONArray v=e.optJSONArray("vpns");if(v!=null)for(int i=0;i<v.length();i++){JSONObject x=v.optJSONObject(i);if(x!=null)total+=x.optDouble("valor",subscriptionSaleValue(x.optString("subscricao","")));}}return total;}
    private double equipmentBalance(JSONObject e){return money(e.optString("valorPago","0"))-equipmentTotal(e);}

    // ========================== SERVIÇOS E SUBSCRIÇÕES ===================

    private static final class ReorderDragInfo {
        final String type;
        final int fromIndex;
        ReorderDragInfo(String type, int fromIndex) { this.type = type; this.fromIndex = fromIndex; }
    }

    /** Inicia o arrastamento a partir apenas dos três tracinhos e recebe largadas nos cartões. */
    private void installReorderDrag(View handle, View targetCard, String type, int targetIndex) {
        handle.setLongClickable(true);
        handle.setOnLongClickListener(v -> {
            // A sombra deve acompanhar apenas o puxador. Usar o cartão inteiro
            // deslocava visualmente a sombra para fora do ecrã em ecrãs estreitos.
            ClipData data = ClipData.newPlainText(type, type);
            View.DragShadowBuilder shadow = new View.DragShadowBuilder(handle);
            return handle.startDragAndDrop(data, shadow, new ReorderDragInfo(type, targetIndex), 0);
        });
        targetCard.setOnDragListener((view, event) -> {
            Object local = event.getLocalState();
            if (!(local instanceof ReorderDragInfo)) return false;
            ReorderDragInfo info = (ReorderDragInfo) local;
            if (!type.equals(info.type)) return false;
            switch (event.getAction()) {
                case android.view.DragEvent.ACTION_DRAG_STARTED:
                    return true;
                case android.view.DragEvent.ACTION_DRAG_ENTERED:
                    view.setAlpha(0.72f);
                    return true;
                case android.view.DragEvent.ACTION_DRAG_EXITED:
                case android.view.DragEvent.ACTION_DRAG_ENDED:
                    view.setAlpha(1f);
                    return true;
                case android.view.DragEvent.ACTION_DROP:
                    view.setAlpha(1f);
                    boolean after = event.getY() >= view.getHeight() / 2f;
                    reorderItems(type, info.fromIndex, targetIndex, after);
                    return true;
                default:
                    return true;
            }
        });
    }

    private void reorderItems(String type, int fromIndex, int targetIndex, boolean after) {
        try {
            JSONArray source = "services".equals(type) ? store.serviceCatalog() : store.subscriptions();
            if (fromIndex < 0 || fromIndex >= source.length() || targetIndex < 0 || targetIndex >= source.length()) return;
            if (fromIndex == targetIndex) return;
            ArrayList<Object> items = new ArrayList<>();
            for (int i = 0; i < source.length(); i++) items.add(source.opt(i));
            Object moving = items.remove(fromIndex);
            int insertion = targetIndex + (after ? 1 : 0);
            if (fromIndex < insertion) insertion--;
            insertion = Math.max(0, Math.min(insertion, items.size()));
            items.add(insertion, moving);
            JSONArray reordered = new JSONArray();
            for (Object item : items) reordered.put(item);
            store.setCompanyArray(type, reordered);
            renderSubscriptionsPreservingScroll(null);
        } catch (Exception e) {
            alert("Erro", "Não foi possível alterar a ordem: " + e.getMessage());
        }
    }

    private void renderSubscriptionsScreen() {
        Card pagePanel = card();
        styleSubscriptionsMenuCard(pagePanel);
        LinearLayout pageHeader = row();
        // Ícone e título são elementos separados para que, quando o título
        // ocupa duas linhas, a segunda linha fique alinhada com o texto e não
        // comece por baixo do cadeado.
        LinearLayout pageTitleGroup = row();
        TextView titleIcon = tv("🔐", 19, TEXT, false);
        titleIcon.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        pageTitleGroup.addView(titleIcon, new LinearLayout.LayoutParams(dp(28), -2));
        TextView title = tv("Serviços e subscrições", 19, TEXT, true);
        title.setClickable(true);
        pageTitleGroup.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        pageHeader.addView(pageTitleGroup, new LinearLayout.LayoutParams(0, -2, 1f));
        Button closeMenu = primary(subscriptionsMenuExpanded ? "Fechar" : "Abrir");
        closeMenu.setSingleLine(true);
        closeMenu.setTextSize(12);
        closeMenu.setPadding(0, 0, 0, 0);
        closeMenu.setIncludeFontPadding(false);
        closeMenu.setMinWidth(0);
        closeMenu.setMinimumWidth(0);
        pageHeader.addView(closeMenu, new LinearLayout.LayoutParams(dp(64), dp(40)));
        pagePanel.addView(pageHeader);

        // O cabeçalho principal abre/fecha este módulo internamente; não navega
        // para Início. Assim, tocar numa subscrição nunca encerra o menu.
        LinearLayout pageBody = new LinearLayout(this);
        pageBody.setOrientation(LinearLayout.VERTICAL);
        pageBody.setTag("subscriptionMenuBody");
        pageBody.setVisibility(subscriptionsMenuExpanded ? View.VISIBLE : View.GONE);
        addSpacer(pageBody, 10);
        Runnable toggleMainBody = () -> {
            subscriptionsMenuExpanded = pageBody.getVisibility() != View.VISIBLE;
            pageBody.setVisibility(subscriptionsMenuExpanded ? View.VISIBLE : View.GONE);
            closeMenu.setText(subscriptionsMenuExpanded ? "Fechar" : "Abrir");
        };
        closeMenu.setOnClickListener(v -> toggleMainBody.run());
        title.setOnClickListener(v -> toggleMainBody.run());
        titleIcon.setClickable(true);
        titleIcon.setOnClickListener(v -> toggleMainBody.run());
        pageTitleGroup.setClickable(true);
        pageTitleGroup.setOnClickListener(v -> toggleMainBody.run());
        pagePanel.addView(pageBody);

        // ---------------------------- Serviços ----------------------------
        Card services = card();
        styleSubscriptionsMenuCard(services);
        TextView servicesTitle = tv("🛠️ Serviços", 17, TEXT, true);
        servicesTitle.setClickable(true);
        services.addView(servicesTitle);
        LinearLayout servicesBody = new LinearLayout(this);
        servicesBody.setOrientation(LinearLayout.VERTICAL);
        servicesBody.setVisibility(servicesSectionExpanded ? View.VISIBLE : View.GONE);
        servicesTitle.setOnClickListener(v -> {
            servicesSectionExpanded = servicesBody.getVisibility() != View.VISIBLE;
            servicesBody.setVisibility(servicesSectionExpanded ? View.VISIBLE : View.GONE);
        });
        services.addView(servicesBody);
        addSpacer(servicesBody, 8);

        EditText serviceName = editorFormEdit("Ex.: Nome do serviço");
        EditText serviceValue = editorFormEdit("Ex.: Valor (€)");
        serviceValue.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        setSubscriptionControlSize(serviceName, 28);
        setSubscriptionControlSize(serviceValue, 28);
        // No modelo original os dois campos de criação de serviço usam apenas
        // placeholders; não acrescentamos os rótulos Nome/Valor por cima.
        servicesBody.addView(serviceName);
        addSpacer(servicesBody, 6);
        servicesBody.addView(serviceValue);
        addSpacer(servicesBody, 8);
        LinearLayout serviceFormActions = row();
        Button saveService = primary("＋ Adicionar serviço");
        saveService.setTextSize(14);
        saveService.setPadding(dp(12), 0, dp(12), 0);
        serviceFormActions.addView(saveService, new LinearLayout.LayoutParams(-2, dp(40)));
        servicesBody.addView(serviceFormActions);
        saveService.setOnClickListener(v -> {
            String name = value(serviceName).trim();
            if (name.isEmpty()) { alert("Aviso", "Indica o nome do serviço."); return; }
            JSONArray knownServices = store.serviceCatalog();
            for (int i = 0; i < knownServices.length(); i++) {
                JSONObject existing = knownServices.optJSONObject(i);
                if (existing != null && name.equalsIgnoreCase(existing.optString("name", "").trim())) {
                    alert("Aviso", "Esse serviço já existe."); return;
                }
            }
            try {
                JSONObject obj = new JSONObject();
                obj.put("id", uuid("svc"));
                obj.put("name", name);
                obj.put("value", money(value(serviceValue)));
                store.saveService(-1, obj);
                renderSubscriptionsPreservingScroll(null);
            } catch (Exception e) { alert("Erro", e.getMessage()); }
        });

        // A lista de serviços permanece visível mesmo quando o formulário de criação está recolhido.
        LinearLayout servicesListHost = new LinearLayout(this);
        servicesListHost.setOrientation(LinearLayout.VERTICAL);
        servicesListHost.setTag("servicesListHost");
        addSpacer(servicesListHost, 10);
        JSONArray svc = store.serviceCatalog();
        if (svc.length() == 0) servicesListHost.addView(muted("Ainda não existem serviços."));
        for (int i = 0; i < svc.length(); i++) {
            JSONObject item = svc.optJSONObject(i);
            if (item == null) continue;
            final int idx = i;
            final String serviceId = item.optString("id", "index_" + i);
            Card itemCard = card();
            styleSubscriptionsMenuCard(itemCard);
            itemCard.setPadding(dp(12), dp(12), dp(12), dp(12));
            LinearLayout itemRow = row();
            itemRow.setClickable(true);
            LinearLayout leading = new LinearLayout(this);
            leading.setOrientation(LinearLayout.VERTICAL);
            leading.setGravity(Gravity.CENTER);
            // O ícone de serviço já está no cabeçalho da secção; aqui fica apenas
            // a pega de ordenação, evitando repetir o mesmo símbolo em cada cartão.
            TextView serviceDragHandle = tv("☷", 16, MUTED, false);
            serviceDragHandle.setContentDescription("Arrastar para reordenar serviço");
            serviceDragHandle.setTag("serviceDragHandle");
            leading.addView(serviceDragHandle);
            itemRow.addView(leading, new LinearLayout.LayoutParams(dp(30), dp(54)));
            TextView itemName = tv(orDash(item.optString("name", "")), 16, TEXT, true);
            itemName.setClickable(true);
            itemRow.addView(itemName, new LinearLayout.LayoutParams(0, -2, 1f));
            Button edit = button("✏️", false);
            edit.setContentDescription("Editar serviço");
            edit.setTextSize(16);
            Button delete = button("🗑️", false);
            delete.setContentDescription("Apagar serviço");
            delete.setTextSize(16);
            LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(dp(42), dp(40));
            ep.leftMargin = dp(4);
            itemRow.addView(edit, ep);
            LinearLayout.LayoutParams delp = new LinearLayout.LayoutParams(dp(42), dp(40));
            delp.leftMargin = dp(4);
            itemRow.addView(delete, delp);
            itemCard.addView(itemRow);

            // Tal como no original, cada serviço expande o seu próprio cartão.
            // O botão do lápis abre estes campos e coloca o cursor no nome; não
            // navega para outro ecrã nem cria uma janela de edição.
            LinearLayout inlineBody = new LinearLayout(this);
            inlineBody.setOrientation(LinearLayout.VERTICAL);
            inlineBody.setVisibility(expandedServiceCardIds.contains(serviceId) ? View.VISIBLE : View.GONE);
            EditText inlineName = editorFormEdit("Nome do serviço");
            inlineName.setText(item.optString("name", ""));
            EditText inlineValue = editorFormEdit("Valor (€)");
            inlineValue.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            inlineValue.setText(String.valueOf(item.optDouble("value", 0)));
            setSubscriptionControlSize(inlineName, 28);
            setSubscriptionControlSize(inlineValue, 28);
            inlineBody.addView(fieldBlockWith(labelOnly("Nome do serviço"), inlineName));
            addSpacer(inlineBody, 5);
            inlineBody.addView(fieldBlockWith(labelOnly("Valor (€)"), inlineValue));
            addSpacer(inlineBody, 7);
            LinearLayout inlineActions = row();
            Button saveInline = primary("💾 Guardar serviço");
            saveInline.setTextSize(13);
            LinearLayout.LayoutParams saveInlineLp = new LinearLayout.LayoutParams(-2, dp(40));
            saveInlineLp.rightMargin = dp(8);
            inlineActions.addView(saveInline, saveInlineLp);
            Button cancelInline = button("Cancelar", false);
            cancelInline.setTextSize(13);
            inlineActions.addView(cancelInline, new LinearLayout.LayoutParams(-2, dp(40)));
            inlineBody.addView(inlineActions);
            itemCard.addView(inlineBody);
            servicesListHost.addView(itemCard);
            addSpacer(servicesListHost, 10);
            Runnable toggleInline = () -> {
                boolean opening = inlineBody.getVisibility() != View.VISIBLE;
                inlineBody.setVisibility(opening ? View.VISIBLE : View.GONE);
                if (opening) expandedServiceCardIds.add(serviceId); else expandedServiceCardIds.remove(serviceId);
            };
            itemRow.setOnClickListener(v -> toggleInline.run());
            itemName.setOnClickListener(v -> toggleInline.run());
            installReorderDrag(serviceDragHandle, itemCard, "services", idx);
            edit.setOnClickListener(v -> {
                // Abrir a edição no próprio cartão sem roubar o foco nem deslocar
                // a página. O utilizador escolhe o campo que quer editar; só aí
                // o teclado é aberto pelo Android.
                expandedServiceCardIds.add(serviceId);
                inlineBody.setVisibility(View.VISIBLE);
                inlineBody.setAlpha(1f);
            });
            cancelInline.setOnClickListener(v -> {
                // Descarta o rascunho e fecha a edição sem alterar o serviço guardado.
                inlineName.setText(item.optString("name", ""));
                inlineValue.setText(String.valueOf(item.optDouble("value", 0)));
                inlineBody.animate().alpha(0f).setDuration(130).withEndAction(() -> {
                    inlineBody.setVisibility(View.GONE);
                    inlineBody.setAlpha(1f);
                    expandedServiceCardIds.remove(serviceId);
                }).start();
            });
            saveInline.setOnClickListener(v -> {
                String newName = value(inlineName).trim();
                if (newName.isEmpty()) { alert("Aviso", "Indica o nome do serviço."); return; }
                try {
                    JSONArray knownServices = store.serviceCatalog();
                    for (int k = 0; k < knownServices.length(); k++) {
                        JSONObject existing = knownServices.optJSONObject(k);
                        if (k != idx && existing != null && newName.equalsIgnoreCase(existing.optString("name", "").trim())) {
                            alert("Aviso", "Já existe outro serviço com esse nome."); return;
                        }
                    }
                    JSONObject updated = new JSONObject(item.toString());
                    updated.put("name", newName);
                    updated.put("value", money(value(inlineValue)));
                    store.saveService(idx, updated);
                    expandedServiceCardIds.remove(serviceId);
                    renderSubscriptionsPreservingScroll(null);
                    alertCompact("Serviço guardado", "As alterações ao serviço\nforam guardadas.");
                } catch (Exception e) { alert("Erro", e.getMessage()); }
            });
            delete.setOnClickListener(v -> confirm("Apagar serviço?", "Tens a certeza de que queres apagar este serviço?", () -> {
                store.deleteService(idx);
                expandedServiceCardIds.remove(serviceId);
                renderSubscriptionsPreservingScroll(null);
            }));
        }
        services.addView(servicesListHost);
        pageBody.addView(services);
        addSpacer(pageBody, 12);

        // --------------------------- Subscrições --------------------------
        Card subForm = card();
        styleSubscriptionsMenuCard(subForm);
        subForm.setTag("subscriptionsEditorTarget");
        TextView subTitle = tv("🔐 Subscrições", 17, TEXT, true);
        subTitle.setClickable(true);
        subForm.addView(subTitle);
        LinearLayout subFormBody = new LinearLayout(this);
        subFormBody.setOrientation(LinearLayout.VERTICAL);
        subFormBody.setTag("subscriptionFormFields");
        subFormBody.setVisibility(subscriptionsSectionExpanded ? View.VISIBLE : View.GONE);
        subForm.addView(subFormBody);
        addSpacer(subFormBody, 8);

        JSONObject editingSub = subscriptionEditIndex >= 0
                ? store.subscriptions().optJSONObject(subscriptionEditIndex) : null;
        EditText type = editorFormEdit("Ex.: Tipo de serviço");
        EditText name = editorFormEdit("Ex.: Nome do serviço");
        EditText client = editorFormEdit("Ex.: Nome do cliente");
        EditText limit = editorFormEdit("Ex.: Número de licenças");
        EditText used = editorFormEdit("Ex.: Número de licenças utilizadas");
        limit.setInputType(InputType.TYPE_CLASS_NUMBER);
        used.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText purchaseDate = subscriptionDateField("Selecionar data");
        EditText startDate = subscriptionDateField("Selecionar data");
        EditText cost = editorFormEdit("Ex.: Custo da subscrição (€)");
        EditText revenue = editorFormEdit("Ex.: Receita prevista (€)");
        cost.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        revenue.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        String oldRule = editingSub == null ? "" : editingSub.optString("purchaseRule", "normal");
        String oldKind = editingSub == null ? "" : editingSub.optString("kind", "subscription");
        String oldValidity = editingSub == null ? "" : editingSub.optString("validityType", "purchase");
        int oldMonths = editingSub == null ? 0 : editingSub.optInt("validityMonths", 0);
        Spinner rule = editorFormSpinner(asList("Normal — 1 por 1", "Promoção — 6 por 5"),
                "6for5".equals(oldRule) ? "Promoção — 6 por 5" : "Normal — 1 por 1", "Selecionar regra de compra");
        // O tipo é uma regra estrutural: simples ou Pack. O nome próprio do pack
        // (por exemplo, "Pack Segurança") continua a ser introduzido no campo Nome.
        boolean existingIsPack = "pack".equals(oldKind) || (editingSub != null && isPack(editingSub));
        Spinner kind = editorFormSpinner(asList("Subscrição simples", "Pack"),
                existingIsPack ? "Pack" : "Subscrição simples", "Selecionar tipo de subscrição");
        Spinner validity = editorFormSpinner(asList("Validade desde a compra", "Validade desde a ativação"),
                "activation".equals(oldValidity) ? "Validade desde a ativação" : (editingSub == null ? "" : "Validade desde a compra"), "Selecionar tipo de validade");
        List<String> periods = asList("Mensal", "Bimestral", "Trimestral", "Quadrimestral", "Semestral", "Anual", "Bienal", "Trienal");
        Spinner periodicity = editorFormSpinner(periods, periodLabel(oldMonths), "Selecionar periodicidade");

        LinkedHashSet<String> selectedComponentNames = new LinkedHashSet<>();
        TextView components = new TextView(this);
        components.setText("Selecionar subscrição");
        components.setTextColor(Color.rgb(145, 153, 166));
        components.setTextSize(14);
        components.setSingleLine(true);
        components.setEllipsize(android.text.TextUtils.TruncateAt.END);
        components.setGravity(Gravity.CENTER_VERTICAL);
        components.setPadding(dp(12), 0, dp(10), 0);
        components.setCompoundDrawablePadding(dp(6));
        components.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, new DownChevronDrawable(), null);
        components.setClickable(true);
        setRoundedBackground(components, Color.WHITE, Color.rgb(125, 133, 145), 10);
        LinearLayout componentsBlock = fieldBlockWith(labelOnly("Subscrições incluídas no pack"), components);
        componentsBlock.setVisibility(existingIsPack ? View.VISIBLE : View.GONE);
        kind.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                Object selected = kind.getSelectedItem();
                componentsBlock.setVisibility(selected != null && "Pack".equals(String.valueOf(selected)) ? View.VISIBLE : View.GONE);
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { componentsBlock.setVisibility(View.GONE); }
        });
        components.setOnClickListener(v -> showPackComponentsPopup(components, selectedComponentNames, subscriptionEditIndex));

        setSubscriptionControlSize(type, 28); setSubscriptionControlSize(name, 28);
        setSubscriptionControlSize(client, 28); setSubscriptionControlSize(limit, 28);
        setSubscriptionControlSize(used, 28); setSubscriptionControlSize(purchaseDate, 28);
        setSubscriptionControlSize(startDate, 28); setSubscriptionControlSize(cost, 28);
        setSubscriptionControlSize(revenue, 28); setSubscriptionControlSize(components, 28);
        setSubscriptionControlSize(rule, 28); setSubscriptionControlSize(kind, 28);
        setSubscriptionControlSize(validity, 28); setSubscriptionControlSize(periodicity, 28);
        styleLightSubscriptionDropdown(rule); styleLightSubscriptionDropdown(kind);
        styleLightSubscriptionDropdown(validity); styleLightSubscriptionDropdown(periodicity);

        if (editingSub != null) {
            type.setText(editingSub.optString("type", ""));
            name.setText(editingSub.optString("name", ""));
            client.setText(editingSub.optString("client", ""));
            limit.setText(String.valueOf(editingSub.optInt("limit", 10)));
            used.setText(String.valueOf(editingSub.optInt("licenseUsed", 0)));
            purchaseDate.setText(editingSub.optString("purchaseDate", ""));
            startDate.setText(editingSub.optString("startDate", ""));
            cost.setText(String.valueOf(editingSub.optDouble("cost", 0)));
            revenue.setText(String.valueOf(editingSub.optDouble("revenue", 0)));
            JSONArray comps = editingSub.optJSONArray("components");
            if (comps != null) {
                for (int i = 0; i < comps.length(); i++) {
                    JSONObject co = comps.optJSONObject(i);
                    String componentName = co == null ? String.valueOf(comps.opt(i)) : co.optString("name", co.optString("subscriptionName", ""));
                    if (!componentName.trim().isEmpty()) selectedComponentNames.add(componentName.trim());
                }
            }
        }
        updatePackComponentsField(components, selectedComponentNames);

        addSubscriptionField(subFormBody, "Tipo", type);
        addSubscriptionField(subFormBody, "Nome", name);
        addSubscriptionField(subFormBody, "Cliente", client);
        addSubscriptionField(subFormBody, "Quantidade de licenças", limit);
        addSubscriptionField(subFormBody, "Regra de compra", rule);
        addSubscriptionField(subFormBody, "Tipo de subscrição", kind);
        subFormBody.addView(componentsBlock);
        addSpacer(subFormBody, 6);
        addSubscriptionField(subFormBody, "Tipo de validade", validity);
        addSubscriptionField(subFormBody, "Licenças utilizadas", used);
        addSubscriptionField(subFormBody, "Data de compra", purchaseDate);
        addSubscriptionField(subFormBody, "Data de início", startDate);
        addSubscriptionField(subFormBody, "Periodicidade", periodicity);
        addSubscriptionField(subFormBody, "Custo da subscrição (€)", cost);
        addSubscriptionField(subFormBody, "Receita prevista (€)", revenue);

        LinearLayout subActions = row();
        Button saveSub = primary(editingSub == null ? "＋ Adicionar" : "💾 Guardar");
        saveSub.setTextSize(14);
        saveSub.setPadding(dp(12), 0, dp(12), 0);
        subActions.addView(saveSub, new LinearLayout.LayoutParams(-2, dp(40)));
        if (editingSub != null) {
            Button cancelSub = button("Cancelar", false); cancelSub.setTextSize(13);
            cancelSub.setMinWidth(dp(96));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, dp(40)); cp.leftMargin = dp(8);
            subActions.addView(cancelSub, cp);
            cancelSub.setOnClickListener(v -> {
                // Abandona a edição sem guardar e recolhe novamente o formulário.
                // A navegação animada regressa ao cartão de subscrição que abriu o editor.
                String returnTag = subscriptionEditReturnTag;
                subscriptionEditIndex = -1;
                subscriptionEditReturnTag = null;
                subscriptionsSectionExpanded = false;
                renderSubscriptionsPreservingScroll(returnTag);
            });
        }
        subFormBody.addView(subActions);
        saveSub.setOnClickListener(v -> {
            String subName = value(name).trim();
            if (subName.isEmpty()) { alert("Aviso", "Indica o nome da subscrição."); return; }
            try {
                JSONObject sub = editingSub == null ? new JSONObject() : new JSONObject(editingSub.toString());
                sub.put("id", sub.optString("id", uuid("SUB")));
                sub.put("type", value(type).trim());
                sub.put("name", subName);
                sub.put("client", value(client).trim());
                sub.put("limit", Math.max(1, (int) money(value(limit))));
                sub.put("licenseUsed", Math.max(0, (int) money(value(used))));
                String purchase = value(purchaseDate).trim();
                sub.put("purchaseDate", purchase.isEmpty() ? today() : purchase);
                sub.put("startDate", value(startDate).trim());
                int months = periodMonths(value(periodicity));
                sub.put("validityMonths", months);
                String endDate = editingSub == null ? "" : editingSub.optString("endDate", "");
                if (!value(startDate).trim().isEmpty() && months > 0) endDate = plusMonths(value(startDate).trim(), months);
                sub.put("endDate", endDate);
                sub.put("cost", money(value(cost)));
                sub.put("revenue", money(value(revenue)));
                String ruleChoice = value(rule);
                sub.put("purchaseRule", ruleChoice.startsWith("Promoção") ? "6for5" : "normal");
                String kindChoice = value(kind);
                String kindCode = kindChoice.startsWith("Pack") ? "pack" : "subscription";
                sub.put("kind", kindCode);
                String validityChoice = value(validity);
                sub.put("validityType", validityChoice.startsWith("Validade desde a ativação") ? "activation" : "purchase");
                JSONArray componentArray = new JSONArray();
                for (String componentName : selectedComponentNames) {
                    JSONObject linked = findSubscription(componentName);
                    String componentPurchaseRule = linked == null ? "normal" : linked.optString("purchaseRule", "normal");
                    componentArray.put(new JSONObject().put("name", componentName)
                            .put("costSnapshot", linked == null ? 0 : linked.optDouble("cost", 0))
                            .put("purchaseRule", componentPurchaseRule)
                            .put("purchaseRuleSnapshot", componentPurchaseRule));
                }
                if ("pack".equals(kindCode)) sub.put("components", componentArray); else sub.remove("components");
                if (!sub.has("movements")) sub.put("movements", new JSONArray());
                if (!sub.has("devices")) sub.put("devices", new JSONArray());
                if (!sub.has("initialPurchaseRecorded")) {
                    JSONArray movements = new JSONArray();
                    movements.put(new JSONObject().put("type", "purchase").put("quantity", sub.optInt("limit", 1))
                            .put("date", sub.optString("purchaseDate", today())).put("cost", sub.optDouble("cost", 0)).put("initial", true));
                    sub.put("movements", movements);
                    sub.put("initialPurchaseRecorded", true);
                }
                store.saveSubscription(subscriptionEditIndex, sub);
                subscriptionEditIndex = -1;
                subscriptionEditReturnTag = null;
                renderSubscriptionsPreservingScroll(null);
            } catch (Exception e) { alert("Erro", e.getMessage()); }
        });
        subTitle.setOnClickListener(v -> {
            subscriptionsSectionExpanded = subFormBody.getVisibility() != View.VISIBLE;
            subFormBody.setVisibility(subscriptionsSectionExpanded ? View.VISIBLE : View.GONE);
            // Só recolhe/expande o formulário. A lista de subscrições fica sempre visível.
        });
        LinearLayout subscriptionCardsHost = new LinearLayout(this);
        subscriptionCardsHost.setOrientation(LinearLayout.VERTICAL);
        subscriptionCardsHost.setTag("subscriptionCardsHost");
        subscriptionCardsHost.setVisibility(View.VISIBLE);
        addSpacer(subscriptionCardsHost, 10);
        JSONArray subs = store.subscriptions();
        if (subs.length() == 0) subscriptionCardsHost.addView(muted("Ainda não existem subscrições."));
        for (int i = 0; i < subs.length(); i++) {
            JSONObject sub = subs.optJSONObject(i);
            if (sub == null) continue;
            Card subCard = subscriptionCard(sub, i);
            subCard.setTag("subscriptionCard_" + i);
            subscriptionCardsHost.addView(subCard);
            addSpacer(subscriptionCardsHost, 8);
        }
        // A lista de subscrições fica dentro do mesmo cartão exterior do título,
        // tal como a lista de serviços fica dentro do cartão Serviços.
        subForm.addView(subscriptionCardsHost);
        pageBody.addView(subForm);
        content.addView(pagePanel);
    }

    private void openSubscriptionEditorAt(int subscriptionIndex, String targetTag) {
        subscriptionEditIndex = subscriptionIndex;
        subscriptionEditReturnTag = "subscriptionCard_" + subscriptionIndex;
        subscriptionsMenuExpanded = true;
        subscriptionsSectionExpanded = true;
        renderSubscriptionsPreservingScroll(targetTag);
    }

    private void renderSubscriptionsPreservingScroll(String targetTag) {
        int previousY = contentScroll == null ? 0 : contentScroll.getScrollY();
        int oldHeight = content == null ? 0 : Math.max(content.getHeight(), content.getMeasuredHeight());
        if (content != null && contentScroll != null) {
            content.setMinimumHeight(Math.max(oldHeight, previousY + contentScroll.getHeight()));
            finishTemporaryContentHeightAfterScroll = true;
        }
        currentScreen = "subscricoes";
        syncDrawerSelection();
        pendingEditorScrollRestore = false;
        if (topSearch != null && topSearch.length() > 0) {
            suppressSearchRefresh = true;
            topSearch.setText("");
            suppressSearchRefresh = false;
        }
        clearContent(false);
        renderSubscriptionsScreen();
        if (contentScroll == null) return;
        contentScroll.post(() -> contentScroll.postOnAnimation(() -> {
            if (contentScroll == null || pageColumn == null) return;
            int max = Math.max(0, pageColumn.getHeight() - contentScroll.getHeight());
            contentScroll.scrollTo(0, Math.min(previousY, max));
            if (targetTag != null) {
                View target = content.findViewWithTag(targetTag);
                if (target != null) scrollContentTo(target);
                else finishTemporaryContentHeightIfNeeded();
            } else {
                finishTemporaryContentHeightIfNeeded();
            }
        }));
    }

    private void styleLightSubscriptionDropdown(Spinner spinner) {
        if (spinner == null) return;
        spinner.setPopupBackgroundDrawable(new ColorDrawable(Color.WHITE));
        spinner.setDropDownVerticalOffset(dp(2));
    }

    private void addSubscriptionField(ViewGroup host, String label, View field) {
        host.addView(fieldBlockWith(labelOnly(label), field));
        addSpacer(host, 5);
    }

    private EditText subscriptionDateField(String hint) {
        EditText date = editorFormEdit(hint);
        date.setFocusable(false); date.setClickable(true);
        date.setCompoundDrawablePadding(dp(6));
        date.setCompoundDrawablesRelative(null, null, new DownChevronDrawable(), null);
        date.setPadding(dp(12), 0, dp(8), 0);
        date.setOnClickListener(v -> pickSubscriptionDate(date));
        return date;
    }

    private void pickSubscriptionDate(EditText target) {
        Calendar initial = Calendar.getInstance();
        Date current = parseDate(value(target));
        if (current != null) initial.setTime(current);
        showSequentialDateDialog(target, initial);
    }

    private void setSubscriptionControlSize(View view, int heightDp) {
        view.setMinimumHeight(dp(heightDp));
        if (view instanceof EditText) ((EditText) view).setMinHeight(dp(heightDp));
        view.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(heightDp)));
    }

    private int periodMonths(String label) {
        if (label == null) return 0;
        switch (label) {
            case "Mensal": return 1;
            case "Bimestral": return 2;
            case "Trimestral": return 3;
            case "Quadrimestral": return 4;
            case "Semestral": return 6;
            case "Anual": return 12;
            case "Bienal": return 24;
            case "Trienal": return 36;
            default: return 0;
        }
    }

    private String periodLabel(int months) {
        switch (months) {
            case 1: return "Mensal";
            case 2: return "Bimestral";
            case 3: return "Trimestral";
            case 4: return "Quadrimestral";
            case 6: return "Semestral";
            case 12: return "Anual";
            case 24: return "Bienal";
            case 36: return "Trienal";
            default: return "";
        }
    }

    private static final class LinkedSubscriptionEntry {
        String clientId = "";
        String clientName = "";
        String equipmentName = "Equipamento";
        int equipmentIndex = -1;
        int used = 1;
    }

    private List<LinkedSubscriptionEntry> subscriptionLinkedEntries(JSONObject targetSub) {
        List<LinkedSubscriptionEntry> rows = new ArrayList<>();
        if (targetSub == null) return rows;
        String targetName = targetSub.optString("name", targetSub.optString("type", "")).trim();
        if (targetName.isEmpty()) return rows;
        JSONArray clients = store.clients();
        for (int ci = 0; ci < clients.length(); ci++) {
            JSONObject client = clients.optJSONObject(ci);
            if (client == null) continue;
            String clientId = client.optString("ID Cliente", "");
            String clientName = client.optString("Nome", "").trim();
            JSONArray equipmentArray = client.optJSONArray("equipamentos");
            boolean matched = false;
            if (equipmentArray != null) {
                for (int ei = 0; ei < equipmentArray.length(); ei++) {
                    JSONObject equipment = equipmentArray.optJSONObject(ei);
                    if (equipment == null) continue;
                    int count = 0;
                    JSONArray assigned = equipment.optJSONArray("subscricoes");
                    if (assigned != null && assigned.length() > 0) {
                        for (int ai = 0; ai < assigned.length(); ai++) {
                            JSONObject a = assigned.optJSONObject(ai);
                            String n = a == null ? String.valueOf(assigned.opt(ai))
                                    : a.optString("name", a.optString("subscricao", ""));
                            if (targetName.equals(n.trim())) count++;
                        }
                    } else if (targetName.equals(equipment.optString("subscricao", "").trim())) {
                        count++;
                    }
                    JSONArray legacyVpns = equipment.optJSONArray("vpns");
                    if (legacyVpns != null) {
                        for (int vi = 0; vi < legacyVpns.length(); vi++) {
                            JSONObject vpn = legacyVpns.optJSONObject(vi);
                            if (vpn != null && targetName.equals(vpn.optString("subscricao", "").trim())) count++;
                        }
                    }
                    if (count <= 0) continue;
                    matched = true;
                    LinkedSubscriptionEntry entry = new LinkedSubscriptionEntry();
                    entry.clientId = clientId;
                    entry.clientName = clientName;
                    entry.equipmentName = orDash(equipment.optString("nome", client.optString("Equipamento", "Equipamento")));
                    entry.equipmentIndex = ei;
                    entry.used = Math.max(1, monthsFor(equipment)) * count;
                    rows.add(entry);
                }
            }
            if (!matched && targetName.equals(client.optString("Subscrição", "").trim())) {
                LinkedSubscriptionEntry entry = new LinkedSubscriptionEntry();
                entry.clientId = clientId;
                entry.clientName = clientName;
                entry.equipmentName = orDash(client.optString("Equipamento", "Equipamento"));
                entry.equipmentIndex = -1;
                entry.used = 1;
                rows.add(entry);
            }
        }
        return rows;
    }

    private void removeLinkedSubscriptionAssociation(int subscriptionIndex, LinkedSubscriptionEntry entry) {
        if (entry == null || entry.clientId.isEmpty()) return;
        JSONObject client = store.findClient(entry.clientId);
        JSONObject subscription = store.subscriptions().optJSONObject(subscriptionIndex);
        if (client == null || subscription == null) return;
        String targetName = subscription.optString("name", subscription.optString("type", "")).trim();
        confirm("Remover associação?", "Remover " + targetName + " deste cliente?", () -> {
            try {
                JSONArray equipmentArray = client.optJSONArray("equipamentos");
                if (equipmentArray != null) {
                    for (int ei = 0; ei < equipmentArray.length(); ei++) {
                        JSONObject e = equipmentArray.optJSONObject(ei);
                        if (e == null) continue;
                        if (entry.equipmentIndex >= 0 && ei != entry.equipmentIndex) continue;
                        if (targetName.equals(e.optString("subscricao", "").trim())) e.put("subscricao", "");
                        JSONArray assigned = e.optJSONArray("subscricoes");
                        if (assigned != null) {
                            JSONArray kept = new JSONArray();
                            for (int ai = 0; ai < assigned.length(); ai++) {
                                Object raw = assigned.opt(ai);
                                JSONObject a = assigned.optJSONObject(ai);
                                String n = a == null ? String.valueOf(raw) : a.optString("name", a.optString("subscricao", ""));
                                if (!targetName.equals(n.trim())) kept.put(raw);
                            }
                            e.put("subscricoes", kept);
                        }
                        JSONArray vpns = e.optJSONArray("vpns");
                        if (vpns != null) {
                            JSONArray kept = new JSONArray();
                            for (int vi = 0; vi < vpns.length(); vi++) {
                                Object raw = vpns.opt(vi);
                                JSONObject vpn = vpns.optJSONObject(vi);
                                if (vpn == null || !targetName.equals(vpn.optString("subscricao", "").trim())) kept.put(raw);
                            }
                            e.put("vpns", kept);
                        }
                    }
                }
                if (targetName.equals(client.optString("Subscrição", "").trim())) client.put("Subscrição", "");
                store.saveClient(client);
                renderSubscriptionsPreservingScroll(null);
            } catch (Exception e) { alert("Erro", e.getMessage()); }
        });
    }

    private void openLinkedClientEditor(String clientId) {
        JSONObject client = store.findClient(clientId);
        if (client == null) return;
        editorReturnScreen = "clientes";
        editorReturnClientId = null; // ao sair do editor, voltar à lista completa de Clientes.
        editorReturnScrollY = contentScroll == null ? 0 : contentScroll.getScrollY();
        editorReturnContentHeight = content == null ? 0 : Math.max(content.getHeight(), content.getMeasuredHeight());
        pendingEditorScrollRestore = false;
        selectedClientId = clientId;
        showNewClientEditor(client, false);
    }

    private Card subscriptionCard(JSONObject s, int index) {
        Card c = card();
        styleSubscriptionsMenuCard(c);
        c.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout header = row();
        TextView handle = tv("☷", 16, MUTED, true);
        handle.setContentDescription("Arrastar para reordenar subscrição");
        handle.setLongClickable(true);
        header.addView(handle, new LinearLayout.LayoutParams(dp(22), dp(36)));
        installReorderDrag(handle, c, "subscriptions", index);
        LinearLayout headingText = new LinearLayout(this);
        headingText.setOrientation(LinearLayout.VERTICAL);
        TextView name = tv(orDash(s.optString("name", s.optString("type", "Subscrição"))), 16, TEXT, true);
        name.setClickable(true);
        name.setContentDescription("Mostrar ou ocultar equipamentos associados a " + s.optString("name", "Subscrição"));
        headingText.addView(name);
        if (!s.optString("client", "").isEmpty()) headingText.addView(muted(s.optString("client")));
        header.addView(headingText, new LinearLayout.LayoutParams(0, -2, 1f));
        SubSummary summary = subSummary(s);
        TextView counter = tv(summary.consumed + "/" + summary.purchased, 18, GREEN, true);
        counter.setGravity(Gravity.CENTER);
        setRoundedBackground(counter, Color.rgb(9, 59, 42), Color.rgb(9, 59, 42), 12);
        header.addView(counter, new LinearLayout.LayoutParams(dp(64), dp(36)));
        c.addView(header);
        c.addView(muted("Compradas: " + summary.purchased + " · Utilizadas: " + summary.consumed + " · Disponíveis: " + summary.available));
        if (!s.optString("endDate", "").isEmpty()) c.addView(muted("Validade: " + formatDate(s.optString("endDate"))));
        addSpacer(c, 8);

        LinearLayout actionsTop = row();
        Button equip = primary("＋ Equipamento");
        Button move = button("＋ Movimento", false);
        equip.setTextSize(12); move.setTextSize(12);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0, dp(40), 1f);
        actionsTop.addView(equip, ep);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, dp(40), 1f); mp.leftMargin = dp(6);
        actionsTop.addView(move, mp);
        c.addView(actionsTop);
        addSpacer(c, 6);
        LinearLayout actionsBottom = row();
        Button edit = button("✎ Editar", false);
        Button del = button("🗑 Apagar", false);
        edit.setTextSize(12); del.setTextSize(12);
        actionsBottom.addView(edit, new LinearLayout.LayoutParams(dp(90), dp(40)));
        LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(dp(100), dp(40)); dp2.leftMargin = dp(6);
        actionsBottom.addView(del, dp2);
        c.addView(actionsBottom);

        equip.setOnClickListener(v -> openSubDeviceDialog(index));
        move.setOnClickListener(v -> openMovementDialog(index, -1));
        edit.setOnClickListener(v -> openSubscriptionEditorAt(index, "subscriptionsEditorTarget"));
        del.setOnClickListener(v -> confirm("Apagar subscrição?", "Tens a certeza de que queres apagar esta subscrição?", () -> {
            store.deleteSubscription(index);
            subscriptionEditIndex = -1;
            renderSubscriptionsPreservingScroll(null);
        }));

        LinearLayout associatedHost = new LinearLayout(this);
        associatedHost.setOrientation(LinearLayout.VERTICAL);
        associatedHost.setTag("subscriptionAssociatedEquipment");
        associatedHost.setVisibility(View.GONE);
        List<LinkedSubscriptionEntry> linkedEntries = subscriptionLinkedEntries(s);
        JSONArray devices = s.optJSONArray("devices");
        if (linkedEntries.isEmpty() && (devices == null || devices.length() == 0)) {
            associatedHost.addView(muted("Nenhum equipamento associado."));
        }
        for (LinkedSubscriptionEntry linked : linkedEntries) {
            Card deviceCard = card();
            styleSubscriptionsMenuCard(deviceCard);
            deviceCard.setPadding(dp(10), dp(8), dp(10), dp(8));
            LinearLayout deviceRow = row();
            LinearLayout info = new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            info.addView(tv(linked.equipmentName, 14, TEXT, true));
            if (!linked.clientName.isEmpty()) info.addView(tv(linked.clientName, 13, TEXT, false));
            info.addView(muted("Utilizadas neste cliente: " + linked.used));
            deviceRow.addView(info, new LinearLayout.LayoutParams(0, -2, 1f));
            Button editClient = button("✎", false); editClient.setContentDescription("Editar cliente associado");
            Button removeClient = button("🗑", false); removeClient.setContentDescription("Remover associação");
            LinearLayout.LayoutParams lEdit = new LinearLayout.LayoutParams(dp(38), dp(36)); lEdit.leftMargin = dp(4);
            LinearLayout.LayoutParams lRemove = new LinearLayout.LayoutParams(dp(38), dp(36)); lRemove.leftMargin = dp(4);
            deviceRow.addView(editClient, lEdit); deviceRow.addView(removeClient, lRemove);
            deviceCard.addView(deviceRow);
            associatedHost.addView(deviceCard); addSpacer(associatedHost, 6);
            editClient.setOnClickListener(v -> openLinkedClientEditor(linked.clientId));
            removeClient.setOnClickListener(v -> removeLinkedSubscriptionAssociation(index, linked));
        }
        if (devices != null) {
            for (int i = 0; i < devices.length(); i++) {
                JSONObject d = devices.optJSONObject(i); if (d == null) continue;
                final int di = i;
                Card deviceCard = card();
                deviceCard.setPadding(dp(10), dp(8), dp(10), dp(8));
                LinearLayout deviceRow = row();
                LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
                info.addView(tv(orDash(d.optString("name", "Equipamento")), 14, TEXT, true));
                info.addView(tv(orDash(d.optString("person", "")) + (d.optString("location", "").isEmpty() ? "" : " · " + d.optString("location")), 13, MUTED, false));
                deviceRow.addView(info, new LinearLayout.LayoutParams(0, -2, 1f));
                Button editDevice = button("✎", false); editDevice.setContentDescription("Editar equipamento associado");
                Button removeDevice = button("🗑", false); removeDevice.setContentDescription("Remover equipamento associado");
                LinearLayout.LayoutParams edp = new LinearLayout.LayoutParams(dp(38), dp(36)); edp.leftMargin = dp(4);
                LinearLayout.LayoutParams rdp = new LinearLayout.LayoutParams(dp(38), dp(36)); rdp.leftMargin = dp(4);
                deviceRow.addView(editDevice, edp); deviceRow.addView(removeDevice, rdp);
                deviceCard.addView(deviceRow);
                associatedHost.addView(deviceCard); addSpacer(associatedHost, 6);
                editDevice.setOnClickListener(v -> openSubDeviceDialog(index, di));
                removeDevice.setOnClickListener(v -> confirm("Remover equipamento?", "Remover este equipamento da subscrição?", () -> {
                    try {
                        JSONObject sub = store.subscriptions().optJSONObject(index);
                        JSONArray items = sub == null ? null : sub.optJSONArray("devices");
                        if (items != null && di >= 0 && di < items.length()) {
                            JSONArray kept = new JSONArray();
                            for (int k = 0; k < items.length(); k++) if (k != di) kept.put(items.opt(k));
                            sub.put("devices", kept); store.saveSubscription(index, sub);
                        }
                        renderSubscriptionsPreservingScroll(null);
                    } catch (Exception e) { alert("Erro", e.getMessage()); }
                }));
            }
        }
        addSpacer(c, 8); addSubscriptionsDivider(c); addSpacer(c, 6);
        LinearLayout movementsSection = new LinearLayout(this);
        movementsSection.setOrientation(LinearLayout.VERTICAL);
        addSpacer(c, 8); addSubscriptionsDivider(c); addSpacer(c, 6);
        TextView movementsTitle = tv("Movimentos", 14, TEXT, true);
        movementsTitle.setClickable(true);
        movementsSection.addView(movementsTitle);
        LinearLayout movementRowsHost = new LinearLayout(this);
        movementRowsHost.setOrientation(LinearLayout.VERTICAL);
        movementRowsHost.setVisibility(View.GONE);
        JSONArray movements = s.optJSONArray("movements");
        if (movements == null || movements.length() == 0) movementRowsHost.addView(muted("Nenhum movimento registado."));
        if (movements != null) {
            for (int i = 0; i < movements.length(); i++) {
                JSONObject m = movements.optJSONObject(i); if (m == null) continue;
                final int mi = i;
                LinearLayout movementRow = row();
                String movementLabel = splitBeforeColonLabel(m.optString("type", "purchase")) + " · " + m.optInt("quantity", 0)
                        + (m.optString("date", "").isEmpty() ? "" : " · " + formatDate(m.optString("date")));
                TextView movementText = tv(movementLabel, 12, MUTED, false);
                movementRow.addView(movementText, new LinearLayout.LayoutParams(0, -2, 1f));
                Button editMovement = button("✎", false); Button deleteMovement = button("🗑", false);
                LinearLayout.LayoutParams emp = new LinearLayout.LayoutParams(dp(38), dp(36)); emp.leftMargin = dp(4);
                movementRow.addView(editMovement, emp);
                LinearLayout.LayoutParams dmp = new LinearLayout.LayoutParams(dp(38), dp(36)); dmp.leftMargin = dp(4);
                movementRow.addView(deleteMovement, dmp);
                movementRowsHost.addView(movementRow); addSpacer(movementRowsHost, 4);
                editMovement.setOnClickListener(v -> openMovementDialog(index, mi));
                deleteMovement.setOnClickListener(v -> confirm("Apagar movimento?", "Tens a certeza?", () -> {
                    store.deleteMovement(index, mi); renderSubscriptionsPreservingScroll(null);
                }));
            }
        }
        movementsSection.addView(movementRowsHost);
        c.addView(movementsSection);
        movementsTitle.setOnClickListener(v -> movementRowsHost.setVisibility(
                movementRowsHost.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));

        // A lista de equipamentos associados surge logo abaixo de Movimentos,
        // e é aberta/fechada ao tocar no nome da subscrição.
        c.addView(associatedHost);
        name.setOnClickListener(v -> {
            boolean opening = associatedHost.getVisibility() != View.VISIBLE;
            associatedHost.setVisibility(opening ? View.VISIBLE : View.GONE);
            name.setContentDescription((opening ? "Ocultar" : "Mostrar") + " equipamentos associados a " + s.optString("name", "Subscrição"));
        });
        return c;
    }

    private void openMovementDialog(int si, int mi) {
        JSONObject s = store.subscriptions().optJSONObject(si);
        if (s == null) return;
        JSONObject existing = null;
        JSONArray a = s.optJSONArray("movements");
        if (a != null && mi >= 0) existing = a.optJSONObject(mi);

        Spinner type = editorFormSpinner(asList("Compra", "Ativação", "Renovação"), "Compra", "Selecionar tipo");
        EditText qty = editorFormEdit("Quantidade");
        qty.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText date = subscriptionDateField("Selecionar data");
        EditText cost = editorFormEdit("Custo total (€)");
        cost.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText client = editorFormEdit("Cliente");
        EditText months = editorFormEdit("Validade em meses");
        months.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText activation = subscriptionDateField("Data de ativação");
        EditText finish = subscriptionDateField("Data de fim");
        for (View field : new View[]{type, qty, date, cost, client, months, activation, finish}) {
            setSubscriptionControlSize(field, 28);
        }
        styleLightSubscriptionDropdown(type);

        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        fields.setPadding(dp(4), dp(4), dp(4), dp(4));
        fields.addView(fieldBlockWith(labelOnly("Tipo"), type));
        fields.addView(fieldBlockWith(labelOnly("Quantidade"), qty));
        fields.addView(fieldBlockWith(labelOnly("Data"), date));
        fields.addView(fieldBlockWith(labelOnly("Custo"), cost));
        fields.addView(fieldBlockWith(labelOnly("Cliente"), client));
        fields.addView(fieldBlockWith(labelOnly("Meses"), months));
        fields.addView(fieldBlockWith(labelOnly("Ativação"), activation));
        fields.addView(fieldBlockWith(labelOnly("Fim"), finish));

        if (existing != null) {
            String mt = existing.optString("type", "purchase");
            type.setSelection("activation".equals(mt) ? 2 : "renewal".equals(mt) ? 3 : 1);
            qty.setText(String.valueOf(existing.optInt("quantity", 0)));
            date.setText(existing.optString("date", today()));
            cost.setText(String.valueOf(existing.optDouble("cost", 0)));
            client.setText(existing.optString("client", ""));
            months.setText(String.valueOf(existing.optInt("months", 0)));
            activation.setText(existing.optString("startDate", ""));
            finish.setText(existing.optString("endDate", ""));
        }

        final int movementIndex = mi;
        final int subscriptionIndex = si;
        final JSONObject subscription = s;
        final JSONObject existingMovement = existing;
        showDarkFormDialog(movementIndex >= 0 ? "Editar movimento" : "Adicionar movimento", fields, "Guardar", d -> {
            try {
                String selectedType = String.valueOf(type.getSelectedItem());
                String mt = selectedType.startsWith("Ativação") ? "activation"
                        : selectedType.startsWith("Renovação") ? "renewal" : "purchase";
                int q = Math.max(1, (int) money(value(qty)));
                SubSummary current = subSummary(subscription);
                if (!"purchase".equals(mt) && q > current.available) {
                    alert("Aviso", "Não tens licenças suficientes disponíveis. Disponíveis: " + current.available);
                    return;
                }
                JSONObject m = existingMovement == null ? new JSONObject() : new JSONObject(existingMovement.toString());
                m.put("type", mt);
                m.put("quantity", q);
                m.put("date", value(date).isEmpty() ? today() : value(date));
                m.put("cost", money(value(cost)));
                m.put("client", value(client));
                m.put("months", Math.max(0, (int) money(value(months))));
                m.put("startDate", value(activation));
                m.put("endDate", value(finish));
                if (m.optInt("months", 0) > 0 && ("activation".equals(mt) || "renewal".equals(mt))
                        && m.optString("startDate", "").length() == 10) {
                    m.put("endDate", plusMonths(m.optString("startDate"), m.optInt("months")));
                }
                JSONArray arr = subscription.optJSONArray("movements");
                if (arr == null) arr = new JSONArray();
                if (movementIndex >= 0 && movementIndex < arr.length()) arr.put(movementIndex, m);
                else arr.put(m);
                subscription.put("movements", arr);
                store.saveSubscription(subscriptionIndex, subscription);
                d.dismiss();
                renderSubscriptionsPreservingScroll(null);
            } catch (Exception e) {
                alert("Erro", e.getMessage());
            }
        });
    }

    private AlertDialog activeDialog;
    private void showDialogDismiss(){if(activeDialog!=null)activeDialog.dismiss();}

    private void openSubDeviceDialog(int si) { openSubDeviceDialog(si, -1); }

    private void openSubDeviceDialog(int si, int di) {
        JSONObject sub = store.subscriptions().optJSONObject(si);
        if (sub == null) return;
        JSONArray currentDevices = sub.optJSONArray("devices");
        JSONObject existing = currentDevices != null && di >= 0 ? currentDevices.optJSONObject(di) : null;
        EditText name = editorFormEdit("Nome do equipamento");
        EditText person = editorFormEdit("Pessoa");
        EditText location = editorFormEdit("Local");
        setSubscriptionControlSize(name, 28);
        setSubscriptionControlSize(person, 28);
        setSubscriptionControlSize(location, 28);
        if (existing != null) {
            name.setText(existing.optString("name", ""));
            person.setText(existing.optString("person", ""));
            location.setText(existing.optString("location", ""));
        }
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        fields.setPadding(dp(4), dp(4), dp(4), dp(4));
        fields.addView(fieldBlockWith(labelOnly("Nome"), name));
        fields.addView(fieldBlockWith(labelOnly("Pessoa"), person));
        fields.addView(fieldBlockWith(labelOnly("Local"), location));

        showDarkFormDialog(existing == null ? "Associar equipamento" : "Editar equipamento associado",
                fields, existing == null ? "Adicionar" : "Guardar", d -> {
            try {
                JSONObject live = store.subscriptions().optJSONObject(si);
                if (live == null) return;
                JSONArray items = live.optJSONArray("devices");
                if (items == null) items = new JSONArray();
                JSONObject entry = existing == null ? new JSONObject() : new JSONObject(existing.toString());
                entry.put("name", value(name).trim());
                entry.put("person", value(person).trim());
                entry.put("location", value(location).trim());
                if (di >= 0 && di < items.length()) items.put(di, entry);
                else items.put(entry);
                live.put("devices", items);
                store.saveSubscription(si, live);
                d.dismiss();
                renderSubscriptionsPreservingScroll(null);
            } catch (Exception e) {
                alert("Erro", e.getMessage());
            }
        });
    }

    // ============================== CATÁLOGOS ============================

    private void renderCatalogs(){
        Card panel=card();
        LinearLayout head=row();
        head.addView(tv("📦 Catálogos",20,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));
        Button close=primary("Fechar");close.setOnClickListener(v->showScreen("inicio"));
        head.addView(close,new LinearLayout.LayoutParams(dp(72),dp(40)));
        panel.addView(head);
        addSpacer(panel,6);
        panel.addView(muted("Base de referência para equipamentos, produtos, serviços e marcas."));
        addSpacer(panel,10);
        String[] types={"equipamentos","produtos","servicos","marcas"};
        String[] titles={"📹 Equipamentos","📦 Produtos / Consumíveis","🛠️ Serviços","🏷️ Marcas"};
        String[] descs={"Para instalação em clientes","Material e consumíveis com stock","Serviços e mão de obra","De equipamentos e produtos"};
        for(int i=0;i<types.length;i++){
            final String type=types[i];
            Card c=card();
            c.setPadding(dp(16),dp(12),dp(16),dp(12));
            c.addView(tv(titles[i],16,TEXT,true));
            c.addView(muted(descs[i]));
            c.setOnClickListener(v->showCatalogList(type));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);
            cp.setMargins(dp(16),0,dp(16),dp(8));
            panel.addView(c,cp);
        }
        content.addView(panel);
    }

    private void showCatalogList(String type){
        clearContent();content.addView(tv(iconForCatalog(type)+" "+titleForCatalog(type),20,TEXT,true));addSpacer(content,8);Button back=button("← Voltar",false);back.setOnClickListener(v->showScreen("catalogos"));content.addView(back,new LinearLayout.LayoutParams(-1,dp(40)));addSpacer(content,8);Button add=primary("＋ Adicionar");add.setOnClickListener(v->openCatalogItemDialog(type,-1));content.addView(add,new LinearLayout.LayoutParams(-1,dp(42)));addSpacer(content,8);
        JSONArray a=store.catalog(type);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;Card c=card();LinearLayout r=row();r.addView(tv(o.optString("nome", "Sem nome"),15,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));Button e=button("✎",false),d=button("🗑",false);final int idx=i;e.setOnClickListener(v->openCatalogItemDialog(type,idx));d.setOnClickListener(v->confirm("Apagar item?","Tem a certeza?",()->{store.deleteCatalog(type,idx);showCatalogList(type);}));r.addView(e,new LinearLayout.LayoutParams(dp(48),dp(40)));r.addView(d,new LinearLayout.LayoutParams(dp(55),dp(40)));c.addView(r);if(!"marcas".equals(type)){c.addView(muted(summaryCatalogItem(type,o)));}content.addView(c);addSpacer(content,8);} }

    private void openCatalogItemDialog(String type,int index){
        JSONObject existing=index>=0?store.catalog(type).optJSONObject(index):null;LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(8),dp(8),dp(8),dp(8));
        List<EditText> edits=new ArrayList<>();Map<String,EditText> map=new LinkedHashMap<>();String[] fields;
        if("equipamentos".equals(type)) fields=new String[]{"nome","tipo","marca","modelo","referencia","categoria","custo","pvp","venda","quantidade_comprada","quantidade_utilizada","stock_minimo"};
        else if("produtos".equals(type)) fields=new String[]{"nome","marca","tipo","unidade","quantidade_comprada","quantidade_utilizada","custo","venda","stock_minimo"};
        else if("servicos".equals(type)) fields=new String[]{"nome","tipo","unidade","venda"};
        else fields=new String[]{"nome"};
        for(String key:fields){EditText e=edit(key,14);if(key.contains("quantidade")||key.equals("custo")||key.equals("pvp")||key.equals("venda")||key.equals("stock_minimo"))e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);if(existing!=null)e.setText(existing.optString(key,""));map.put(key,e);f.addView(fieldBlockWith(labelOnly(pretty(key)),e));}AlertDialog d=new AlertDialog.Builder(this).setTitle(index>=0?"Editar item":"Adicionar item").setView(f).setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{JSONObject o=existing==null?new JSONObject():new JSONObject(existing.toString());o.put("id",o.optString("id",uuid("CAT")));for(Map.Entry<String,EditText> en:map.entrySet())o.put(en.getKey(),value(en.getValue()));store.saveCatalog(type,index,o);d.dismiss();showCatalogList(type);}catch(Exception e){alert("Erro",e.getMessage());}}));d.show();
    }

    // ============================= ARQUIVADO =============================

    private void renderArchived(){
        Card p=card();LinearLayout h=row();h.addView(tv("📁 Arquivados",20,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));Button close=primary("Fechar");close.setOnClickListener(v->showScreen("inicio"));h.addView(close,new LinearLayout.LayoutParams(dp(72),dp(40)));p.addView(h);EditText s=edit("Pesquisar nome, contacto, empresa, equipamento...",13);p.addView(s);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);Runnable render=()->{list.removeAllViews();String q=value(s).trim().toLowerCase(Locale.ROOT);JSONArray a=store.archived();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null||!clientContains(c,q))continue;Card r=card();LinearLayout rr=row();rr.addView(tv(clientName(c),15,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));Button restore=button("Repor",false),del=button("🗑",false);final int idx=i;restore.setOnClickListener(v->{store.restoreArchived(idx);showScreen("historico");});del.setOnClickListener(v->confirm("Apagar arquivado?","Tem a certeza?",()->{store.deleteArchived(idx);showScreen("historico");}));rr.addView(restore,new LinearLayout.LayoutParams(dp(70),dp(40)));rr.addView(del,new LinearLayout.LayoutParams(dp(55),dp(40)));r.addView(rr);list.addView(r);addSpacer(list,8);}if(list.getChildCount()==0)list.addView(muted("Nenhum cliente arquivado."));};s.addTextChangedListener(simpleWatcher(render));render.run();p.addView(list);content.addView(p);
    }

    // ============================== HISTÓRICO ============================

    private void renderActivity(){
        Card p=card();LinearLayout h=row();h.addView(tv("🕘 Histórico de\nalterações",20,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));Button close=primary("Fechar");close.setOnClickListener(v->showScreen("inicio"));h.addView(close,new LinearLayout.LayoutParams(dp(72),dp(40)));p.addView(h);EditText s=edit("Pesquisar alteração...",13);p.addView(s);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);Runnable render=()->{list.removeAllViews();String q=value(s).toLowerCase(Locale.ROOT);JSONArray a=store.activity();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String txt=x.optString("action","")+" "+x.optString("details","");if(!txt.toLowerCase(Locale.ROOT).contains(q))continue;Card r=card();r.addView(tv(x.optString("type","Alteração")+" — "+x.optString("action","")+"",14,TEXT,true));r.addView(muted(x.optString("details","")));r.addView(muted(x.optString("date","") ));list.addView(r);addSpacer(list,8);}if(list.getChildCount()==0)list.addView(muted("Ainda não existem alterações."));};s.addTextChangedListener(simpleWatcher(render));render.run();p.addView(list);content.addView(p);
    }

    // ============================ ESTATÍSTICAS ===========================

    private void renderStatistics(){
        Card panel=card();
        LinearLayout head=row();
        head.addView(tv("📊 Estatísticas",20,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));
        Button close=primary("Fechar");close.setOnClickListener(v->showScreen("inicio"));
        head.addView(close,new LinearLayout.LayoutParams(dp(72),dp(40)));
        panel.addView(head);addSpacer(panel,10);
        LinearLayout r1=row();LinearLayout r2=row();
        int total=store.clients().length();int active=0;for(int i=0;i<store.clients().length();i++){JSONObject c=store.clients().optJSONObject(i);if(c!=null&&"active".equals(status(c)))active++;}
        r1.addView(statCard(String.valueOf(total),"Total de\nclientes",TEXT),weightParams(1));r1.addView(statCard(String.valueOf(active),"Clientes\nativos",TEXT),weightParams(1));
        r2.addView(statCard(String.valueOf(store.subscriptions().length()),"Subscrições",TEXT),weightParams(1));r2.addView(statCard(String.valueOf(stockAlerts()),"Alertas de\nstock",TEXT),weightParams(1));
        panel.addView(r1);addSpacer(panel,10);panel.addView(r2);addSpacer(panel,8);
        content.addView(panel);
        statsSection("👥 Clientes por estado",()->{LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);int a=0,w=0,e=0;for(int i=0;i<store.clients().length();i++){JSONObject c=store.clients().optJSONObject(i);if(c==null)continue;String st=status(c);if("active".equals(st))a++;else if("warning".equals(st))w++;else e++;}x.addView(statLine("🟢 Ativos",String.valueOf(a)));x.addView(statLine("🟠 A expirar",String.valueOf(w)));x.addView(statLine("🔴 Expirados",String.valueOf(e)));return x;});
        statsSection("🛠️ Clientes por serviço",()->{Map<String,Integer> m=new LinkedHashMap<>();for(int i=0;i<store.clients().length();i++){JSONObject c=store.clients().optJSONObject(i);String sv=c==null?"":c.optString("Serviço","");if(!sv.isEmpty())m.put(sv,m.getOrDefault(sv,0)+1);}LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);for(Map.Entry<String,Integer> e:m.entrySet())x.addView(statLine(e.getKey(),String.valueOf(e.getValue())));if(m.isEmpty())x.addView(muted("Ainda não existem serviços atribuídos."));return x;});
        statsSection("🔐 Subscrições",()->{LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);JSONArray a=store.subscriptions();for(int i=0;i<a.length();i++){JSONObject sub=a.optJSONObject(i);if(sub!=null){SubSummary sm=subSummary(sub);x.addView(statLine(sub.optString("name","Subscrição"),sm.consumed+"/"+sm.purchased+" · "+sm.available+" livres"));}}return x;});
        statsSection("🌐 VPNs",()->{LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);int n=0;JSONArray a=store.subscriptions();for(int i=0;i<a.length();i++){JSONObject sub=a.optJSONObject(i);if(sub!=null&&(sub.optString("type","")+" "+sub.optString("name","")).toLowerCase(Locale.ROOT).contains("vpn"))n++;}x.addView(statLine("VPNs registadas",String.valueOf(n)));return x;});
        statsSection("📦 Stock",()->{LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);JSONArray e=store.catalog("equipamentos"),p=store.catalog("produtos");int units=0,low=0,zero=0;for(int i=0;i<e.length();i++){StockResult rr=stock(e.optJSONObject(i));units+=rr.stock;if(rr.stock==0)zero++;else if(rr.low)low++;}for(int i=0;i<p.length();i++){StockResult rr=stock(p.optJSONObject(i));units+=rr.stock;if(rr.stock==0)zero++;else if(rr.low)low++;}x.addView(statLine("Equipamentos em catálogo",String.valueOf(e.length())));x.addView(statLine("Produtos / consumíveis",String.valueOf(p.length())));x.addView(statLine("Stock total",String.valueOf(units)));x.addView(statLine("🟠 Stock baixo",String.valueOf(low)));x.addView(statLine("🔴 Sem stock",String.valueOf(zero)));return x;});
        statsSection("📦 Packs",()->{LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);int packs=0;JSONArray a=store.subscriptions();for(int i=0;i<a.length();i++)if(isPack(a.optJSONObject(i)))packs++;x.addView(statLine("Packs registados",String.valueOf(packs)));return x;});
        statsSection("💶 Faturação mensal",()->renderRevenueStats());
    }

    private void statsSection(String title, SectionBody body){
        Card c=card();
        Button b=button(title,false);
        b.setGravity(Gravity.START);
        c.addView(b,new LinearLayout.LayoutParams(-1,dp(44)));
        LinearLayout host=new LinearLayout(this);
        host.setOrientation(LinearLayout.VERTICAL);
        host.setVisibility(View.GONE);
        c.addView(host);
        b.setOnClickListener(v->{
            if(host.getVisibility()==View.VISIBLE){
                host.setVisibility(View.GONE);
            }else{
                host.removeAllViews();
                host.addView(body.make());
                host.setVisibility(View.VISIBLE);
            }
        });
        content.addView(c);
        addSpacer(content,10);
    }
    interface SectionBody{View make();}
    private View statLine(String a,String b){LinearLayout r=row();r.setPadding(dp(4),dp(10),dp(4),dp(10));r.addView(tv(a,14,TEXT,false),new LinearLayout.LayoutParams(0,-2,1f));r.addView(tv(b,14,TEXT,true));return r;}
    private View renderRevenueStats(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);Calendar now=Calendar.getInstance();int year=now.get(Calendar.YEAR);double annual=0;double[] m=new double[12];JSONArray a=store.clients();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;String d=c.optString("Pagamento","");if(d.isEmpty())continue;Date dt=parseDate(d);if(dt==null)continue;Calendar z=Calendar.getInstance();z.setTime(dt);if(z.get(Calendar.YEAR)!=year)continue;double v=money(c.optString("Preço","0"));m[z.get(Calendar.MONTH)]+=v;annual+=v;}x.addView(statLine("Total "+year,formatEuro(annual)));x.addView(statLine("Média mensal",formatEuro(annual/12)));String[] mn={"Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"};for(int i=0;i<12;i++)x.addView(statLine(mn[i],formatEuro(m[i])));return x;}

    // ============================= CONFIG ================================

    private void renderSettings(){
        Card panel=card();
        LinearLayout head=row();
        head.addView(tv("⚙️ Configurações",20,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));
        Button close=primary("Fechar");close.setOnClickListener(v->showScreen("inicio"));
        head.addView(close,new LinearLayout.LayoutParams(dp(72),dp(40)));
        panel.addView(head);addSpacer(panel,10);

        Card app=card();app.addView(tv("Apresentação da aplicação",16,TEXT,true));EditText title=edit("Nome a apresentar",14);title.setText(store.title());app.addView(fieldBlockWith(labelOnly("Nome a apresentar na aplicação"),title));Button logo=primary("Escolher logotipo");logo.setOnClickListener(v->chooseLogo());app.addView(logo,new LinearLayout.LayoutParams(-1,dp(42)));Button save=primary("Guardar apresentação");save.setOnClickListener(v->{store.setTitle(value(title));appTitleView.setText(store.title());Toast.makeText(this,"Guardado.",Toast.LENGTH_SHORT).show();});app.addView(save,new LinearLayout.LayoutParams(-1,dp(42)));panel.addView(app);addSpacer(panel,10);
        Card company=card();company.addView(tv("Empresa ativa",16,TEXT,true));JSONObject ac=store.activeCompany();addField(company,"Designação legal","legalName",ac.optJSONObject("data"));addField(company,"Responsável","responsible",ac.optJSONObject("data"));addField(company,"Email","email",ac.optJSONObject("data"));addField(company,"Telefone","phone",ac.optJSONObject("data"));addField(company,"Morada","address",ac.optJSONObject("data"));addField(company,"Código postal","postalCode",ac.optJSONObject("data"));addField(company,"Localidade","locality",ac.optJSONObject("data"));addField(company,"NIF","nif",ac.optJSONObject("data"));addField(company,"Website","website",ac.optJSONObject("data"));Button saveCompany=primary("Guardar empresa");saveCompany.setOnClickListener(v->{try{JSONObject data=ac.optJSONObject("data");if(data==null)data=new JSONObject();String[] ks={"legalName","responsible","email","phone","address","postalCode","locality","nif","website"};for(String k:ks){EditText e=(EditText)company.findViewWithTag("f:"+k);if(e!=null)data.put(k,value(e));}store.updateActiveCompanyData(data);Toast.makeText(this,"Empresa guardada.",Toast.LENGTH_SHORT).show();}catch(Exception e){alert("Erro",e.getMessage());}});company.addView(saveCompany,new LinearLayout.LayoutParams(-1,dp(42)));Button manage=button("Gerir empresas",false);manage.setOnClickListener(v->openCompanyManagement());company.addView(manage,new LinearLayout.LayoutParams(-1,dp(42)));panel.addView(company);addSpacer(panel,10);
        content.addView(panel);
        renderSettingsLists();renderShortcutsSettings();
    }

    private void renderSettingsLists(){
        String[][] labels={{"empresas","Empresas dos clientes"},{"pagamentos","Métodos de pagamento"},{"nome_equipamentos","Marcas dos Equipamentos"},{"equipamentos","Tipo de Equipamentos"},{"periodicidades","Periodicidades"},{"metodos_contacto","Canais de contacto"},{"valores","Valores de pagamento"}};
        for(String[] p:labels){Card c=card();LinearLayout h=row();h.addView(tv(p[1],15,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));Button add=primary("＋");h.addView(add,new LinearLayout.LayoutParams(dp(54),dp(40)));c.addView(h);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);JSONArray a=store.list(p[0]);for(int i=0;i<a.length();i++){String val=a.optString(i,"");list.addView(settingListRow(p[0],i,val));}add.setOnClickListener(v->openListItemDialog(p[0],-1));c.addView(list);content.addView(c);addSpacer(content,8);}
    }

    private View settingListRow(String key,int idx,String val){Card c=card();LinearLayout r=row();r.addView(tv(val,14,TEXT,false),new LinearLayout.LayoutParams(0,-2,1f));Button ed=button("✎",false),del=button("🗑",false);ed.setOnClickListener(v->openListItemDialog(key,idx));del.setOnClickListener(v->confirm("Apagar opção?","Tem a certeza?",()->{store.deleteListItem(key,idx);showScreen("config");}));r.addView(ed,new LinearLayout.LayoutParams(dp(48),dp(40)));r.addView(del,new LinearLayout.LayoutParams(dp(55),dp(40)));c.addView(r);return c;}
    private void openListItemDialog(String key,int idx){JSONArray a=store.list(key);EditText e=edit("Valor",14);if(idx>=0)e.setText(a.optString(idx,""));AlertDialog d=new AlertDialog.Builder(this).setTitle(idx>=0?"Editar opção":"Adicionar opção").setView(wrapDialog(e)).setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(value(e).trim().isEmpty())return;store.saveListItem(key,idx,value(e).trim());d.dismiss();showScreen("config");}));d.show();}

    private void renderShortcutsSettings(){Card c=card();c.addView(tv("🔗 Atalhos",16,TEXT,true));Button add=primary("＋ Adicionar atalho");add.setOnClickListener(v->openShortcutDialog(-1));c.addView(add,new LinearLayout.LayoutParams(-1,dp(42)));JSONArray a=store.appSettings().optJSONArray("shortcuts");if(a!=null)for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s!=null)c.addView(shortcutRow(i,s));}content.addView(c);}
    private View shortcutRow(int idx,JSONObject s){Card c=card();LinearLayout r=row();r.addView(tv(s.optString("name","Atalho"),14,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));Button e=button("✎",false);e.setOnClickListener(v->openShortcutDialog(idx));r.addView(e,new LinearLayout.LayoutParams(dp(48),dp(40)));c.addView(r);c.addView(muted(s.optString("url","")));return c;}
    private void openShortcutDialog(int idx){JSONArray a=store.appSettings().optJSONArray("shortcuts");JSONObject ex=a!=null&&idx>=0?a.optJSONObject(idx):null;EditText name=edit("Nome",14),desc=edit("Descrição",14),url=edit("URL",14);if(ex!=null){name.setText(ex.optString("name",""));desc.setText(ex.optString("description",""));url.setText(ex.optString("url",""));}LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.addView(fieldBlockWith(labelOnly("Nome"),name));f.addView(fieldBlockWith(labelOnly("Descrição"),desc));f.addView(fieldBlockWith(labelOnly("URL"),url));AlertDialog d=new AlertDialog.Builder(this).setTitle(idx>=0?"Editar atalho":"Adicionar atalho").setView(f).setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{JSONObject o=ex==null?new JSONObject():new JSONObject(ex.toString());o.put("id",o.optString("id",uuid("shortcut")));o.put("name",value(name));o.put("description",value(desc));o.put("url",value(url));store.saveShortcut(idx,o);d.dismiss();showScreen("config");}catch(Exception e){alert("Erro",e.getMessage());}}));d.show();}

    private void openCompanyManagement(){
        LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);JSONArray a=store.companies();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;Button b=button("🏢 "+c.optString("name","Empresa"),false);final String id=c.optString("id");b.setOnClickListener(v->{store.selectCompany(id);showDialogDismiss();showScreen("inicio");});f.addView(b,new LinearLayout.LayoutParams(-1,dp(46)));addSpacer(f,5);}Button add=primary("＋ Nova empresa");add.setOnClickListener(v->{showDialogDismiss();openNewCompanyDialog();});f.addView(add,new LinearLayout.LayoutParams(-1,dp(42)));activeDialog=new AlertDialog.Builder(this).setTitle("Gerir empresas").setView(f).setPositiveButton("Fechar",null).create();activeDialog.show();}
    private void openNewCompanyDialog(){EditText name=edit("Nome da empresa",14);AlertDialog d=new AlertDialog.Builder(this).setTitle("Nova empresa").setView(wrapDialog(name)).setPositiveButton("Criar",null).setNegativeButton("Cancelar",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{store.addCompany(value(name));d.dismiss();showScreen("inicio");}));d.show();}

    private void chooseLogo(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");startActivityForResult(i,REQ_LOGO);}

    // =============================== GESTÃO ==============================

    private void renderManagement(){
        Card panel=card();
        LinearLayout head=row();
        head.addView(tv("🛠️ Gestão da\nbase de dados",20,TEXT,true),new LinearLayout.LayoutParams(0,-2,1f));
        Button close=primary("Fechar");close.setOnClickListener(v->showScreen("inicio"));
        head.addView(close,new LinearLayout.LayoutParams(dp(72),dp(40)));
        panel.addView(head);addSpacer(panel,10);
        Button json=button("☷   💾 Cópia de segurança JSON",false);json.setOnClickListener(v->exportBackupJson());panel.addView(json,new LinearLayout.LayoutParams(-1,dp(44)));addSpacer(panel,8);
        Button excel=button("☷   📊 Cópia de segurança Excel",false);excel.setOnClickListener(v->exportBackupExcel());panel.addView(excel,new LinearLayout.LayoutParams(-1,dp(44)));addSpacer(panel,8);
        Button impJson=button("☷   📂 Repor cópia JSON",false);impJson.setOnClickListener(v->openFile(REQ_OPEN_JSON,"application/json"));panel.addView(impJson,new LinearLayout.LayoutParams(-1,dp(44)));addSpacer(panel,8);
        Button impExcel=button("☷   📊 Repor cópia Excel",false);impExcel.setOnClickListener(v->openFile(REQ_OPEN_EXCEL,ACTION_TYPE));panel.addView(impExcel,new LinearLayout.LayoutParams(-1,dp(44)));addSpacer(panel,8);
        Button clear=button("☷   🗑️ Limpar base de dados",false);clear.setOnClickListener(v->confirm("Limpar base de dados?","Todos os clientes, histórico, subscrições e configurações desta base serão removidos.",()->{store.clearDatabase();showScreen("inicio");}));panel.addView(clear,new LinearLayout.LayoutParams(-1,dp(44)));
        content.addView(panel);
    }

    private void exportBackupJson(){try{String json=store.exportBackup().toString(2);pendingSaveFilename="AM_Clientes_V296_backup.json";pendingSaveBytes=json.getBytes(StandardCharsets.UTF_8);pendingSaveMime="application/json";Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,pendingSaveFilename);startActivityForResult(i,REQ_SAVE_JSON);}catch(Exception e){alert("Erro",e.getMessage());}}
    private void exportBackupExcel(){try{String xml=toSpreadsheetXml(store.exportBackup());pendingSaveFilename="AM_Clientes_V296_backup.xls";pendingSaveBytes=xml.getBytes(StandardCharsets.UTF_8);pendingSaveMime=ACTION_TYPE;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(ACTION_TYPE);i.putExtra(Intent.EXTRA_TITLE,pendingSaveFilename);startActivityForResult(i,REQ_SAVE_EXCEL);}catch(Exception e){alert("Erro",e.getMessage());}}
    private void openFile(int request,String type){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(type);startActivityForResult(i,request);}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;try{Uri u=data.getData();if(requestCode==REQ_SAVE_JSON||requestCode==REQ_SAVE_EXCEL){try(OutputStream out=getContentResolver().openOutputStream(u)){out.write(pendingSaveBytes);}Toast.makeText(this,"Cópia guardada.",Toast.LENGTH_SHORT).show();}else if(requestCode==REQ_OPEN_JSON){String text=readText(u);store.importBackup(new JSONObject(text));showScreen("inicio");Toast.makeText(this,"Backup importado.",Toast.LENGTH_SHORT).show();}else if(requestCode==REQ_OPEN_EXCEL){String text=readText(u);JSONObject backup=parseSpreadsheetXml(text);store.importBackup(backup);showScreen("inicio");Toast.makeText(this,"Excel importado.",Toast.LENGTH_SHORT).show();}else if(requestCode==REQ_LOGO){InputStream in=getContentResolver().openInputStream(u);Bitmap bmp=BitmapFactory.decodeStream(in);if(in!=null)in.close();ByteArrayOutputStream out=new ByteArrayOutputStream();bmp.compress(Bitmap.CompressFormat.PNG,90,out);store.setLogoBase64(android.util.Base64.encodeToString(out.toByteArray(),android.util.Base64.NO_WRAP));applySettingsVisuals();}}catch(Exception e){alert("Erro","Operação não concluída: "+e.getMessage());}}

    // ============================ DATA LAYER =============================

    private final class SharedData {
        private final android.content.SharedPreferences prefs;
        private JSONObject state = new JSONObject();
        private JSONArray companies = new JSONArray();
        private String activeCompany = "company_1";

        SharedData(Context c){prefs=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
        void load(){
            try{
                String raw=prefs.getString("state","");
                if(raw.isEmpty()){
                    initializeEmptyState();
                    return;
                }
                state=new JSONObject(raw);
                companies=state.optJSONArray("companies");
                if(companies==null)companies=new JSONArray();
                activeCompany=state.optString("activeCompany","company_1");
                if(companies.length()==0){
                    JSONObject c=companyTemplate("company_1","Empresa");
                    companies.put(c);
                    activeCompany="company_1";
                    ensureRootDefaults();
                    save();
                }else{
                    ensureRootDefaults();
                    if(activeCompany(activeCompany)==null){
                        activeCompany=companies.optJSONObject(0).optString("id","company_1");
                        save();
                    }
                }
            }catch(Exception e){
                initializeEmptyState();
            }
        }
        private JSONObject activeCompany(String id){
            for(int i=0;i<companies.length();i++){
                JSONObject c=companies.optJSONObject(i);
                if(c!=null&&id.equals(c.optString("id")))return c;
            }
            return null;
        }
        private void ensureRootDefaults(){
            try{
                if(!state.has("title"))state.put("title","AM Clientes");
                if(!state.has("logo"))state.put("logo","");
                if(!state.has("shortcuts"))state.put("shortcuts",new JSONArray());
                if(!state.has("messages"))state.put("messages",new JSONObject());
            }catch(Exception ignored){}
        }
        private void initializeEmptyState(){
            try{
                state=new JSONObject();
                state.put("title","AM Clientes");
                state.put("logo","");
                state.put("shortcuts",new JSONArray());
                state.put("messages",new JSONObject());
                companies=new JSONArray();
                companies.put(companyTemplate("company_1","Empresa"));
                activeCompany="company_1";
                save();
            }catch(Exception ignored){save();}
        }
        void save(){try{state.put("companies",companies);state.put("activeCompany",activeCompany);prefs.edit().putString("state",state.toString()).apply();}catch(Exception ignored){}}
        String title(){return state.optString("title","AM Clientes");}
        void setTitle(String s){try{state.put("title",s.isEmpty()?"AM Clientes":s);save();}catch(Exception ignored){}}
        void setLogoBase64(String b){try{state.put("logo",b);save();}catch(Exception ignored){}}
        String logo(){return state.optString("logo","");}
        JSONObject appSettings(){return state;}
        String activeCompanyId(){return activeCompany;}
        JSONObject activeCompany(){for(int i=0;i<companies.length();i++){JSONObject c=companies.optJSONObject(i);if(c!=null&&activeCompany.equals(c.optString("id")))return c;}return companies.optJSONObject(0);}
        String activeCompanyName(){JSONObject c=activeCompany();return c==null?"Empresa":c.optString("name","Empresa");}
        JSONArray companies(){return companies;}
        void selectCompany(String id){for(int i=0;i<companies.length();i++){JSONObject c=companies.optJSONObject(i);if(c!=null&&id.equals(c.optString("id"))){activeCompany=id;save();return;}}}
        JSONArray companyArray(String key){JSONObject c=activeCompany();if(c==null)return new JSONArray();JSONArray a=c.optJSONArray(key);return a==null?new JSONArray():a;}
        void setCompanyArray(String key,JSONArray a){try{JSONObject c=activeCompany();c.put(key,a);save();}catch(Exception ignored){}}
        JSONArray clients(){return companyArray("clients");} JSONArray archived(){return companyArray("archived");} JSONArray activity(){return companyArray("activity");} JSONArray subscriptions(){return companyArray("subscriptions");}
        JSONArray list(String key){JSONObject c=activeCompany();JSONArray a=c==null?null:c.optJSONObject("lists")!=null?c.optJSONObject("lists").optJSONArray(key):null;return a==null?new JSONArray():a;}
        void saveListItem(String key,int idx,String value){try{JSONObject c=activeCompany();JSONObject lists=c.optJSONObject("lists");if(lists==null){lists=new JSONObject();c.put("lists",lists);}JSONArray a=lists.optJSONArray(key);if(a==null)a=new JSONArray();if(idx>=0&&idx<a.length())a.put(idx,value);else a.put(value);lists.put(key,a);save();}catch(Exception ignored){}}
        void deleteListItem(String key,int idx){try{JSONObject c=activeCompany();JSONObject lists=c.optJSONObject("lists");if(lists==null)return;JSONArray a=lists.optJSONArray(key);if(a==null)return;JSONArray n=new JSONArray();for(int i=0;i<a.length();i++)if(i!=idx)n.put(a.opt(i));lists.put(key,n);save();}catch(Exception ignored){}}
        JSONArray serviceCatalog(){return companyArray("services");}
        double serviceValue(String name){JSONArray a=serviceCatalog();for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s!=null&&name.equals(s.optString("name")))return s.optDouble("value",0);}return 0;}
        List<String> serviceNames(){List<String> r=new ArrayList<>();JSONArray a=serviceCatalog();for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s!=null&&!s.optString("name","").isEmpty())r.add(s.optString("name"));}return r;}
        void saveService(int idx,JSONObject obj){try{JSONArray a=serviceCatalog();if(idx>=0&&idx<a.length())a.put(idx,obj);else a.put(obj);setCompanyArray("services",a);}catch(Exception ignored){}}
        void deleteService(int idx){try{JSONArray a=serviceCatalog(),n=new JSONArray();for(int i=0;i<a.length();i++)if(i!=idx)n.put(a.opt(i));setCompanyArray("services",n);}catch(Exception ignored){}}
        JSONArray catalog(String type){return companyArray("catalog_"+type);}
        void saveCatalog(String type,int idx,JSONObject o){try{JSONArray a=catalog(type);if(idx>=0&&idx<a.length())a.put(idx,o);else a.put(o);setCompanyArray("catalog_"+type,a);}catch(Exception ignored){}}
        void deleteCatalog(String type,int idx){try{JSONArray a=catalog(type),n=new JSONArray();for(int i=0;i<a.length();i++)if(i!=idx)n.put(a.opt(i));setCompanyArray("catalog_"+type,n);}catch(Exception ignored){}}
        void saveClient(JSONObject c){try{JSONArray a=clients();String id=c.optString("ID Cliente","");if(id.isEmpty()){id=nextClientId();c.put("ID Cliente",id);}int idx=findIndex(a,id);if(idx>=0)a.put(idx,c);else a.put(c);setCompanyArray("clients",a);record("cliente",idx>=0?"Cliente alterado":"Cliente criado",c.optString("Nome",id));}catch(Exception ignored){}}
        void deleteClient(String id){JSONArray a=clients(),n=new JSONArray();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c!=null&&!id.equals(c.optString("ID Cliente")))n.put(c);}setCompanyArray("clients",n);}
        JSONObject findClient(String id){JSONArray a=clients();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c!=null&&id.equals(c.optString("ID Cliente")))return c;}return null;}
        void archiveClient(String id){JSONObject c=findClient(id);if(c==null)return;try{JSONArray ar=archived();ar.put(new JSONObject(c.toString()));setCompanyArray("archived",ar);deleteClient(id);}catch(Exception ignored){}}
        void restoreArchived(int idx){JSONArray a=archived();JSONObject c=a.optJSONObject(idx);if(c==null)return;try{JSONArray cl=clients();cl.put(new JSONObject(c.toString()));setCompanyArray("clients",cl);JSONArray n=new JSONArray();for(int i=0;i<a.length();i++)if(i!=idx)n.put(a.opt(i));setCompanyArray("archived",n);}catch(Exception ignored){}}
        void deleteArchived(int idx){JSONArray a=archived(),n=new JSONArray();for(int i=0;i<a.length();i++)if(i!=idx)n.put(a.opt(i));setCompanyArray("archived",n);}
        void record(String type,String action,String details){try{JSONArray a=activity();a.put(new JSONObject().put("type",type).put("action",action).put("details",details).put("date",new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date())));if(a.length()>500){JSONArray n=new JSONArray();for(int i=Math.max(0,a.length()-500);i<a.length();i++)n.put(a.opt(i));a=n;}setCompanyArray("activity",a);}catch(Exception ignored){}}
        void saveSubscription(int idx,JSONObject s){try{JSONArray a=subscriptions();if(idx>=0&&idx<a.length())a.put(idx,s);else a.put(s);setCompanyArray("subscriptions",a);}catch(Exception ignored){}}
        void deleteSubscription(int idx){JSONArray a=subscriptions(),n=new JSONArray();for(int i=0;i<a.length();i++)if(i!=idx)n.put(a.opt(i));setCompanyArray("subscriptions",n);}
        void deleteMovement(int si,int mi){try{JSONArray a=subscriptions();JSONObject s=a.optJSONObject(si);JSONArray m=s.optJSONArray("movements"),n=new JSONArray();if(m!=null)for(int i=0;i<m.length();i++)if(i!=mi)n.put(m.opt(i));s.put("movements",n);a.put(si,s);setCompanyArray("subscriptions",a);}catch(Exception ignored){}}
        void saveShortcut(int idx,JSONObject o){try{JSONArray a=state.optJSONArray("shortcuts");if(a==null)a=new JSONArray();if(idx>=0&&idx<a.length())a.put(idx,o);else a.put(o);state.put("shortcuts",a);save();}catch(Exception ignored){}}
        void addCompany(String name){try{JSONObject c=companyTemplate(uuid("company"),name.isEmpty()?"Empresa":name);companies.put(c);activeCompany=c.optString("id");save();}catch(Exception ignored){}}
        void updateActiveCompanyData(JSONObject data){try{JSONObject c=activeCompany();c.put("data",data);save();}catch(Exception ignored){}}
        JSONObject companyTemplate(String id,String name){try{return new JSONObject().put("id",id).put("name",name).put("data",new JSONObject()).put("clients",new JSONArray()).put("archived",new JSONArray()).put("activity",new JSONArray()).put("subscriptions",new JSONArray()).put("services",new JSONArray()).put("lists",new JSONObject()).put("catalog_equipamentos",new JSONArray()).put("catalog_produtos",new JSONArray()).put("catalog_servicos",new JSONArray()).put("catalog_marcas",new JSONArray());}catch(Exception e){return new JSONObject();}}
        void clearDatabase(){try{JSONObject c=activeCompany();c.put("clients",new JSONArray());c.put("archived",new JSONArray());c.put("activity",new JSONArray());c.put("subscriptions",new JSONArray());c.put("services",new JSONArray());c.put("lists",emptyLists());for(String t:new String[]{"equipamentos","produtos","servicos","marcas"})c.put("catalog_"+t,new JSONArray());state.put("shortcuts",new JSONArray());save();}catch(Exception ignored){}}
        JSONObject exportBackup(){try{JSONObject b=new JSONObject();b.put("clientes",clients());b.put("arquivados",archived());b.put("atividade",activity());b.put("subscricoes",subscriptions());b.put("listas",activeCompany().optJSONObject("lists"));b.put("mensagens",state.optJSONObject("messages"));b.put("appSettings",state);JSONObject cats=new JSONObject();for(String t:new String[]{"equipamentos","produtos","servicos","marcas"})cats.put(t,catalog(t));b.put("catalogos",cats);return b;}catch(Exception e){return new JSONObject();}}
        void importBackup(JSONObject b){try{JSONArray cl=b.optJSONArray("clientes");JSONArray ar=b.optJSONArray("arquivados");JSONArray ac=b.optJSONArray("atividade");JSONArray su=b.optJSONArray("subscricoes");if(cl!=null)setCompanyArray("clients",new JSONArray(cl.toString()));if(ar!=null)setCompanyArray("archived",new JSONArray(ar.toString()));if(ac!=null)setCompanyArray("activity",new JSONArray(ac.toString()));if(su!=null)setCompanyArray("subscriptions",new JSONArray(su.toString()));JSONObject li=b.optJSONObject("listas");if(li!=null){activeCompany().put("lists",new JSONObject(li.toString()));}JSONObject msg=b.optJSONObject("mensagens");if(msg!=null)state.put("messages",new JSONObject(msg.toString()));JSONObject cats=b.optJSONObject("catalogos");if(cats!=null)for(String t:new String[]{"equipamentos","produtos","servicos","marcas"}){JSONArray x=cats.optJSONArray(t);if(x!=null)setCompanyArray("catalog_"+t,new JSONArray(x.toString()));}save();}catch(Exception ignored){}}
        String nextClientId(){int max=0;JSONArray a=clients();for(int i=0;i<a.length();i++){String id=a.optJSONObject(i).optString("ID Cliente","");if(id.startsWith("CLI")){try{max=Math.max(max,Integer.parseInt(id.substring(3)));}catch(Exception ignored){}}}return String.format(Locale.US,"CLI%03d",max+1);}
        int findIndex(JSONArray a,String id){for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c!=null&&id.equals(c.optString("ID Cliente")))return i;}return -1;}
        JSONObject emptyLists(){try{return new JSONObject().put("empresas",new JSONArray()).put("servicos",new JSONArray()).put("pagamentos",new JSONArray()).put("vpns",new JSONArray()).put("nome_equipamentos",new JSONArray()).put("equipamentos",new JSONArray()).put("periodicidades",new JSONArray()).put("metodos_contacto",new JSONArray()).put("valores",new JSONArray()).put("pacotes",new JSONArray());}catch(Exception e){return new JSONObject();}}
    }

    // =========================== ACCOUNTING =============================

    private static final class SubSummary { int purchased, consumed, available; }
    private SubSummary subSummary(JSONObject s){SubSummary out=new SubSummary();JSONArray m=s.optJSONArray("movements");if(m==null||m.length()==0){out.purchased=Math.max(0,s.optInt("limit",0));}else{for(int i=0;i<m.length();i++){JSONObject x=m.optJSONObject(i);if(x==null)continue;if("purchase".equals(x.optString("type")))out.purchased+=Math.max(0,x.optInt("quantity",0));else out.consumed+=Math.max(0,x.optInt("quantity",0));}}int linked=subscriptionLinkedUsage(s);out.consumed=Math.max(out.consumed,linked);out.consumed=Math.max(out.consumed,s.optInt("licenseUsed",0));out.available=Math.max(0,out.purchased-out.consumed);return out;}
    private int subscriptionLinkedUsage(JSONObject target){String targetName=target.optString("name",target.optString("type",""));if(targetName.isEmpty())return 0;if(isPack(target))return 0;int total=0;JSONArray clients=store.clients();for(int i=0;i<clients.length();i++){JSONObject c=clients.optJSONObject(i);if(c==null)continue;JSONArray eqs=c.optJSONArray("equipamentos");if(eqs==null)continue;for(int j=0;j<eqs.length();j++){JSONObject e=eqs.optJSONObject(j);if(e==null)continue;for(JSONObject assignment:assignments(e)){String n=assignment.optString("name","");if(targetName.equals(n))total+=promoUnits(monthsFor(e),purchaseRule(target));else{JSONObject pack=findSubscription(n);if(pack!=null&&isPack(pack)){JSONArray comps=pack.optJSONArray("components");if(comps!=null)for(int k=0;k<comps.length();k++){JSONObject comp=comps.optJSONObject(k);String cn=comp==null?String.valueOf(comps.opt(k)):comp.optString("name",comp.optString("subscriptionName",""));if(targetName.equals(cn))total+=promoUnits(monthsFor(e),purchaseRule(comp));}}}}}}JSONArray d=target.optJSONArray("devices");if(d!=null)total+=d.length();return total;}
    private List<JSONObject> assignments(JSONObject e){List<JSONObject> out=new ArrayList<>();JSONArray a=e.optJSONArray("subscricoes");if(a!=null&&a.length()>0){for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&!x.optString("name",x.optString("subscricao","")).isEmpty())out.add(x);}}else{String s=e.optString("subscricao","");if(!s.isEmpty()){JSONObject y=new JSONObject();try{y.put("name",s);}catch(Exception ignored){}out.add(y);}JSONArray v=e.optJSONArray("vpns");if(v!=null)for(int i=0;i<v.length();i++){JSONObject x=v.optJSONObject(i);if(x!=null){String n=x.optString("subscricao","");if(!n.isEmpty()){JSONObject y=new JSONObject();try{y.put("name",n);}catch(Exception ignored){}out.add(y);}}}}return out;}
    private int monthsFor(JSONObject e){String t=(e.optString("validade","")+" "+e.optString("periodicidade","")).toLowerCase(Locale.ROOT);String[] keys={"mensal","bimestral","bimensal","trimestral","quadrimestral","semestral","anual","bienal","trienal"};int[] vals={1,2,2,3,4,6,12,24,36};for(int i=0;i<keys.length;i++)if(t.contains(keys[i]))return vals[i];for(String n:t.split(" ")){try{return Math.max(1,Integer.parseInt(n.replaceAll("[^0-9]", "")));}catch(Exception ignored){}}return 1;}
    private int promoUnits(int months,String rule){if("6for5".equals(rule))return (months/6)*5 + (months%6);return Math.max(1,months);}
    private String purchaseRule(JSONObject s){
        if(s==null)return "normal";
        String rule=s.optString("purchaseRule", "");
        if(rule.isEmpty())rule=s.optString("purchaseRuleSnapshot", "normal");
        return "6for5".equals(rule)?"6for5":"normal";
    }
    private JSONObject findSubscription(String name){JSONArray a=store.subscriptions();for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s!=null&&name.equals(s.optString("name",s.optString("type",""))))return s;}return null;}
    private boolean isPack(JSONObject s){return s!=null&&("pack".equals(s.optString("kind","") ) || s.optJSONArray("components")!=null&&s.optJSONArray("components").length()>0);}

    // ========================== HELPERS / VISUAL =========================

    private static class Card extends LinearLayout { Card(Context c){super(c);setOrientation(VERTICAL);} }
    private Card card(){Card c=new Card(this);c.setPadding(dp(16),dp(14),dp(16),dp(14));setRoundedBackground(c,PANEL,CARD_OUTLINE,17);return c;}
    // Contornos azuis mais visíveis, usados apenas no módulo Serviços e subscrições.
    private void styleSubscriptionsMenuCard(Card c) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(PANEL);
        d.setCornerRadius(dp(17));
        d.setStroke(dp(1), CARD_OUTLINE);
        c.setBackground(d);
    }
    private TextView tv(String text,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(text);t.setTextColor(color);t.setTextSize(size);t.setGravity(Gravity.CENTER_VERTICAL);t.setTypeface(null,bold?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL);return t;}
    private TextView muted(String text){return tv(text==null?"":text,13,MUTED,false);}
    private Button button(String text,boolean icon){Button b=new Button(this);b.setText(text);b.setTextColor(TEXT);b.setTextSize(icon?18:14);b.setAllCaps(false);b.setPadding(dp(8),0,dp(8),0);setRoundedBackground(b,Color.rgb(10,27,55),LINE,11);return b;}
    private Button primary(String text){Button b=button(text,false);setRoundedBackground(b,BLUE,BLUE,11);b.setTextColor(Color.rgb(3,17,39));b.setTypeface(null,android.graphics.Typeface.BOLD);return b;}
    private Button menuItem(String text){return menuItem("",text,false);}
    private Button menuItem(String text, boolean selected){return menuItem("",text,selected);}
    private Button menuItem(String icon, String label, boolean selected){
        Button b=button(label,false);
        b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        b.setTextSize(16);
        b.setPadding(dp(14),0,dp(14),0);
        b.setCompoundDrawablePadding(dp(20));
        if(icon!=null && !icon.isEmpty()){
            b.setCompoundDrawablesWithIntrinsicBounds(new EmojiDrawable(icon, dp(18)), null, null, null);
        }
        if(selected){
            setRoundedBackground(b,BLUE,BLUE,12);
            b.setTextColor(Color.rgb(3,17,39));
            b.setTypeface(null,Typeface.BOLD);
        }else{
            setRoundedBackground(b,Color.rgb(7,29,62),LINE,12);
            b.setTextColor(TEXT);
            b.setTypeface(null,Typeface.NORMAL);
        }
        return b;
    }


    private class EmojiDrawable extends Drawable {
        private final String value;
        private final int size;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        EmojiDrawable(String value,int size){this.value=value;this.size=size;paint.setTypeface(Typeface.DEFAULT);paint.setTextSize(size);}
        @Override public void draw(Canvas canvas){
            android.graphics.Rect bounds=getBounds();
            paint.setTextSize(size);
            float w=paint.measureText(value);
            Paint.FontMetrics fm=paint.getFontMetrics();
            float x=bounds.left+(bounds.width()-w)/2f;
            float y=bounds.top+(bounds.height()-fm.bottom-fm.top)/2f;
            canvas.drawText(value,x,y,paint);
        }
        @Override public void setAlpha(int alpha){paint.setAlpha(alpha);}
        @Override public void setColorFilter(android.graphics.ColorFilter filter){paint.setColorFilter(filter);}
        @Override public int getOpacity(){return android.graphics.PixelFormat.TRANSLUCENT;}
        @Override public int getIntrinsicWidth(){
            paint.setTextSize(size);
            return Math.max(size, (int)Math.ceil(paint.measureText(value)));
        }
        @Override public int getIntrinsicHeight(){return size;}
    }
    private EditText editorEdit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(145,153,166));e.setTextColor(Color.rgb(22,25,30));e.setTextSize(14);e.setSingleLine(true);e.setMinHeight(dp(28));e.setMinimumHeight(dp(28));e.setPadding(dp(12),0,dp(12),0);setRoundedBackground(e,Color.WHITE,Color.rgb(125,133,145),10);return e;}
    private EditText editorFormEdit(String hint){EditText e=editorEdit(hint);e.setMinHeight(dp(28));e.setMinimumHeight(dp(28));e.setPadding(dp(12),0,dp(12),0);return e;}
    private Spinner editorSpinner(List<String> values,String selected){StyledSpinner s=new StyledSpinner(this);ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values){@Override public View getView(int position,View convertView,android.view.ViewGroup parent){TextView t=(TextView)super.getView(position,convertView,parent);t.setTextColor(Color.rgb(28,31,36));t.setTextSize(14);t.setPadding(dp(10),0,dp(8),0);t.setCompoundDrawablePadding(dp(6));t.setCompoundDrawablesRelative(null,null,new DownChevronDrawable(),null);return t;}@Override public View getDropDownView(int p,View c,android.view.ViewGroup parent){TextView t=(TextView)super.getDropDownView(p,c,parent);styleSelectionRow(t,p,s.getSelectedItemPosition());return t;}};ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(ad);int idx=findSpinner(values,selected);if(idx>=0)s.setSelection(idx);s.setCustomPopupOptions(values, true);s.setMinimumHeight(dp(28));s.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(28)));setRoundedBackground(s,Color.WHITE,Color.rgb(125,133,145),10);return s;}
    private final class DownChevronDrawable extends Drawable {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        DownChevronDrawable(){paint.setColor(Color.rgb(115,123,135));paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);}
        @Override public void draw(Canvas canvas){
            android.graphics.Rect b=getBounds();
            float cx=b.centerX(),cy=b.centerY();
            android.graphics.Path path=new android.graphics.Path();
            path.moveTo(cx-dp(4),cy-dp(1));path.lineTo(cx,cy+dp(3));path.lineTo(cx+dp(4),cy-dp(1));
            canvas.drawPath(path,paint);
        }
        @Override public int getIntrinsicWidth(){return dp(14);}
        @Override public int getIntrinsicHeight(){return dp(14);}
        @Override public void setAlpha(int alpha){paint.setAlpha(alpha);}
        @Override public void setColorFilter(android.graphics.ColorFilter colorFilter){paint.setColorFilter(colorFilter);}
        @Override public int getOpacity(){return android.graphics.PixelFormat.TRANSLUCENT;}
    }

    private Spinner editorFormSpinner(List<String> values,String selected,String hint){
        List<String> options=new ArrayList<>();options.add(hint);
        for(String item:values)if(item!=null&&!item.trim().isEmpty()&&!options.contains(item))options.add(item);
        if(selected!=null&&!selected.trim().isEmpty()&&!options.contains(selected))options.add(selected);
        StyledSpinner s=new StyledSpinner(this);
        final boolean hasValue=selected!=null&&!selected.trim().isEmpty()&&options.contains(selected);
        ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,options){
            @Override public View getView(int position,View convertView,android.view.ViewGroup parent){
                TextView t=(TextView)super.getView(position,convertView,parent);
                t.setTextColor(position==0?Color.rgb(145,153,166):Color.rgb(28,31,36));
                t.setTextSize(14);t.setPadding(dp(10),0,dp(8),0);t.setCompoundDrawablePadding(dp(6));
                t.setCompoundDrawablesRelative(null,null,new DownChevronDrawable(),null);return t;
            }
            @Override public View getDropDownView(int p,View c,android.view.ViewGroup parent){TextView t=(TextView)super.getDropDownView(p,c,parent);styleSelectionRow(t,p,hasValue?s.getSelectedItemPosition():-1);return t;}
        };
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(ad);
        int idx=hasValue?options.indexOf(selected):0;s.setSelection(Math.max(0,idx));
        // O destaque tem de acompanhar a seleção atual, e não o valor que
        // existia quando o formulário foi criado. Ao acrescentar uma nova
        // subscrição, a periodicidade começa vazia; depois de escolher Mensal,
        // a abertura seguinte do menu deve mostrar o visto azul nessa opção.
        s.setCustomPopupOptions(options, true, true);
        s.setMinimumHeight(dp(28));s.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(28)));
        setRoundedBackground(s,Color.WHITE,Color.rgb(125,133,145),10);return s;
    }

    private void updatePackComponentsField(TextView field, LinkedHashSet<String> selectedNames) {
        if (selectedNames == null || selectedNames.isEmpty()) {
            field.setText("Selecionar subscrição");
            field.setTextColor(Color.rgb(145, 153, 166));
        } else {
            field.setText(android.text.TextUtils.join(", ", selectedNames));
            field.setTextColor(Color.rgb(28, 31, 36));
        }
        field.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, new DownChevronDrawable(), null);
    }

    /**
     * Seletor múltiplo personalizado dos componentes de um pack.
     * Mostra subscrições simples já registadas; um pack nunca pode ser
     * componente de outro pack, evitando associações recursivas acidentais.
     */
    private void showPackComponentsPopup(TextView anchor, LinkedHashSet<String> selectedNames, int editingIndex) {
        List<String> options = new ArrayList<>();
        JSONArray all = store.subscriptions();
        for (int i = 0; i < all.length(); i++) {
            if (i == editingIndex) continue;
            JSONObject item = all.optJSONObject(i);
            if (item == null || isPack(item)) continue;
            String name = item.optString("name", item.optString("type", "")).trim();
            if (!name.isEmpty() && !options.contains(name)) options.add(name);
        }
        if (options.isEmpty()) {
            alert("Sem subscrições disponíveis", "Cria primeiro uma subscrição simples para a poderes incluir neste pack.");
            return;
        }

        LinearLayout popupShell = new LinearLayout(this);
        popupShell.setOrientation(LinearLayout.VERTICAL);
        popupShell.setPadding(dp(6), dp(6), dp(6), dp(4));
        android.graphics.drawable.GradientDrawable popupBg = new android.graphics.drawable.GradientDrawable();
        popupBg.setColor(Color.WHITE);
        popupBg.setCornerRadius(dp(16));
        popupBg.setStroke(dp(1), Color.rgb(225, 232, 242));
        popupShell.setBackground(popupBg);

        TextView heading = tv("Selecionar subscrições", 14, Color.rgb(32, 41, 56), true);
        heading.setPadding(dp(14), dp(8), dp(14), dp(6));
        popupShell.addView(heading, new LinearLayout.LayoutParams(-1, dp(38)));

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setCacheColorHint(Color.TRANSPARENT);
        list.setBackgroundColor(Color.TRANSPARENT);
        list.setSelector(new ColorDrawable(Color.TRANSPARENT));
        list.setPadding(0, dp(2), 0, dp(2));
        list.setClipToPadding(false);
        BaseAdapter adapter = new BaseAdapter() {
            @Override public int getCount() { return options.size(); }
            @Override public Object getItem(int position) { return options.get(position); }
            @Override public long getItemId(int position) { return position; }
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                String itemName = options.get(position);
                boolean selected = selectedNames.contains(itemName);
                LinearLayout line = new LinearLayout(MainActivity.this);
                line.setOrientation(LinearLayout.HORIZONTAL);
                line.setGravity(Gravity.CENTER_VERTICAL);
                line.setPadding(dp(14), dp(8), dp(14), dp(8));
                line.setMinimumHeight(dp(46));
                android.graphics.drawable.GradientDrawable lineBg = new android.graphics.drawable.GradientDrawable();
                lineBg.setColor(selected ? Color.rgb(220, 235, 255) : Color.WHITE);
                lineBg.setCornerRadius(dp(10));
                line.setBackground(lineBg);
                TextView label = tv(itemName, 14, selected ? Color.rgb(20, 89, 184) : Color.rgb(32, 41, 56), selected);
                label.setSingleLine(true);
                label.setEllipsize(android.text.TextUtils.TruncateAt.END);
                line.addView(label, new LinearLayout.LayoutParams(0, -2, 1f));
                TextView check = tv(selected ? "✓" : "", 18, Color.rgb(20, 89, 184), true);
                check.setGravity(Gravity.CENTER);
                line.addView(check, new LinearLayout.LayoutParams(dp(26), -2));
                return line;
            }
        };
        list.setAdapter(adapter);
        int rowsHeight = Math.min(dp(options.size() * 50 + 6), dp(260));
        popupShell.addView(list, new LinearLayout.LayoutParams(-1, rowsHeight));

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        TextView done = tv("CONCLUÍDO", 13, Color.rgb(20, 89, 184), true);
        done.setGravity(Gravity.CENTER);
        done.setPadding(dp(18), dp(6), dp(18), dp(6));
        done.setClickable(true);
        footer.addView(done, new LinearLayout.LayoutParams(-2, dp(40)));
        popupShell.addView(footer);

        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int popupWidth = Math.min(Math.max(anchor.getWidth(), dp(230)), screenWidth - dp(24));
        int popupHeight = rowsHeight + dp(90);
        PopupWindow popup = new PopupWindow(popupShell, popupWidth, popupHeight, true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(true);
        popup.setTouchable(true);
        popup.setElevation(dp(12));
        popup.setClippingEnabled(true);
        list.setOnItemClickListener((parent, view, position, id) -> {
            String chosen = options.get(position);
            if (!selectedNames.remove(chosen)) selectedNames.add(chosen);
            updatePackComponentsField(anchor, selectedNames);
            adapter.notifyDataSetChanged();
        });
        done.setOnClickListener(v -> popup.dismiss());
        popup.showAsDropDown(anchor, 0, dp(4));
    }

    /** Spinner Android com lista própria, para garantir o destaque visual em todos os temas Android. */
    private final class StyledSpinner extends Spinner {
        private List<String> customOptions = new ArrayList<>();
        private boolean highlightCurrent = true;
        private boolean firstOptionIsPlaceholder = false;
        StyledSpinner(Context context) { super(context, Spinner.MODE_DROPDOWN); }
        void setCustomPopupOptions(List<String> options, boolean highlight) {
            setCustomPopupOptions(options, highlight, false);
        }
        void setCustomPopupOptions(List<String> options, boolean highlight, boolean firstIsPlaceholder) {
            customOptions = new ArrayList<>(options);
            highlightCurrent = highlight;
            firstOptionIsPlaceholder = firstIsPlaceholder;
        }
        @Override public boolean performClick() {
            if (customOptions == null || customOptions.isEmpty()) return super.performClick();
            int selected = highlightCurrent ? getSelectedItemPosition() : -1;
            if (firstOptionIsPlaceholder && selected == 0) selected = -1;
            showStyledSelectionPopup(this, customOptions, selected);
            return true;
        }
    }

    private void showStyledSelectionPopup(StyledSpinner anchor, List<String> options, int selectedPosition) {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(6), dp(6), dp(6), dp(6));
        android.graphics.drawable.GradientDrawable shellBg = new android.graphics.drawable.GradientDrawable();
        shellBg.setColor(Color.WHITE); shellBg.setCornerRadius(dp(16));
        shellBg.setStroke(dp(1), Color.rgb(225, 232, 242));
        shell.setBackground(shellBg);

        ListView list = new ListView(this);
        list.setDivider(null); list.setDividerHeight(0); list.setCacheColorHint(Color.TRANSPARENT);
        list.setBackgroundColor(Color.TRANSPARENT); list.setSelector(new ColorDrawable(Color.TRANSPARENT));
        list.setPadding(0, dp(2), 0, dp(2)); list.setClipToPadding(false);
        BaseAdapter rows = new BaseAdapter() {
            @Override public int getCount() { return options.size(); }
            @Override public Object getItem(int position) { return options.get(position); }
            @Override public long getItemId(int position) { return position; }
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                boolean selected = position == selectedPosition;
                LinearLayout row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(14), dp(10), dp(14), dp(10));
                row.setMinimumHeight(dp(46));
                android.graphics.drawable.GradientDrawable rowBg = new android.graphics.drawable.GradientDrawable();
                rowBg.setColor(selected ? Color.rgb(220, 235, 255) : Color.WHITE);
                rowBg.setCornerRadius(dp(10)); row.setBackground(rowBg);
                TextView label = new TextView(MainActivity.this);
                label.setText(options.get(position)); label.setTextSize(14);
                label.setTextColor(selected ? Color.rgb(20, 89, 184) : Color.rgb(32, 41, 56));
                label.setTypeface(android.graphics.Typeface.DEFAULT, selected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
                label.setGravity(Gravity.CENTER_VERTICAL); label.setSingleLine(true);
                row.addView(label, new LinearLayout.LayoutParams(0, -2, 1f));
                if (selected) {
                    TextView check = new TextView(MainActivity.this);
                    check.setText("✓"); check.setTextSize(17); check.setTextColor(Color.rgb(20, 89, 184));
                    check.setGravity(Gravity.CENTER); row.addView(check, new LinearLayout.LayoutParams(dp(24), -2));
                }
                return row;
            }
        };
        list.setAdapter(rows);
        final int popupHeight = Math.min(dp(options.size() * 50 + 16), dp(320));
        shell.addView(list, new LinearLayout.LayoutParams(-1, popupHeight - dp(12)));
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int popupWidth = Math.min(Math.max(anchor.getWidth(), dp(210)), screenWidth - dp(24));
        PopupWindow popup = new PopupWindow(shell, popupWidth, popupHeight, true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(true); popup.setTouchable(true); popup.setElevation(dp(12));
        popup.setClippingEnabled(true);
        list.setOnItemClickListener((parent, view, position, id) -> {
            anchor.setSelection(position);
            popup.dismiss();
        });
        popup.showAsDropDown(anchor, 0, dp(4));
    }

    private void styleSelectionRow(TextView row, int position, int selectedPosition) {
        boolean selected = position == selectedPosition;
        row.setTextColor(selected ? Color.rgb(20, 89, 184) : Color.rgb(32, 41, 56));
        row.setTextSize(14); row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(12), dp(16), dp(12));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(selected ? Color.rgb(220, 235, 255) : Color.WHITE); bg.setCornerRadius(dp(10)); row.setBackground(bg);
    }

    private String selectedEditorSpinnerValue(Spinner s){if(s==null||s.getSelectedItem()==null||s.getSelectedItemPosition()<=0)return "";return String.valueOf(s.getSelectedItem());}
    private EditText edit(String hint,float size){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(MUTED);e.setTextColor(TEXT);e.setTextSize(size);e.setSingleLine(false);e.setPadding(dp(12),dp(8),dp(12),dp(8));setRoundedBackground(e,Color.rgb(4,12,29),VALUE_LINE,10);return e;}
    private Spinner spinner(List<String> values,String selected){StyledSpinner s=new StyledSpinner(this);ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values){@Override public View getView(int position,View convertView,android.view.ViewGroup parent){TextView t=(TextView)super.getView(position,convertView,parent);t.setTextColor(TEXT);t.setTextSize(14);t.setPadding(dp(10),dp(8),dp(8),dp(8));t.setCompoundDrawablePadding(dp(6));t.setCompoundDrawablesRelative(null,null,new DownChevronDrawable(),null);return t;}@Override public View getDropDownView(int p,View c,android.view.ViewGroup parent){TextView t=(TextView)super.getDropDownView(p,c,parent);styleSelectionRow(t,p,s.getSelectedItemPosition());return t;}};ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(ad);int idx=findSpinner(values,selected);if(idx>=0)s.setSelection(idx);s.setCustomPopupOptions(values, true);setRoundedBackground(s,Color.rgb(4,12,29),LINE,9);return s;}
    private Spinner spinner(List<String> values,String selectedOrKey,boolean ignored){return spinner(values,selectedOrKey);}
    private ArrayList<String> asList(String... v){ArrayList<String> r=new ArrayList<>();Collections.addAll(r,v);return r;}
    private List<String> optionsToList(JSONArray a){List<String> r=new ArrayList<>();for(int i=0;i<a.length();i++)r.add(a.optString(i,""));return r;}
    private List<String> subscriptionNamesWithPacks(){List<String> r=new ArrayList<>();JSONArray a=store.subscriptions();for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s!=null)r.add(s.optString("name",s.optString("type","")));}return r;}
    private int findSpinner(List<String> a,String value){for(int i=0;i<a.size();i++)if(a.get(i).equals(value)||a.get(i).startsWith(value+":"))return i;return a.isEmpty()?-1:0;}
    private int findSpinner(List<String> a,Object v){return findSpinner(a,String.valueOf(v));}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout lp(int w,int h){return new LinearLayout(this);}
    private LinearLayout.LayoutParams lp0(){return new LinearLayout.LayoutParams(-1,-2);}
    private LinearLayout.LayoutParams homeStatParams(float weight, boolean leftGap, boolean rightGap){
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, weight);
        if (leftGap) p.leftMargin = dp(6);
        if (rightGap) p.rightMargin = dp(6);
        return p;
    }

    private LinearLayout.LayoutParams weightParams(float w){return new LinearLayout.LayoutParams(0,-2,w);}

    private void addSpacer(ViewGroup p,int h){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));p.addView(v);}
    private void addSubscriptionsDivider(ViewGroup parent) {
        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(65, 105, 160));
        parent.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
    }

    private void addDivider(ViewGroup p){View v=new View(this);v.setBackgroundColor(LINE);p.addView(v,new LinearLayout.LayoutParams(-1,1));}
    private LinearLayout wrapDialog(View v){LinearLayout l=new LinearLayout(this);l.setPadding(dp(8),dp(8),dp(8),dp(8));l.addView(v,new LinearLayout.LayoutParams(-1,-2));return l;}

    private void setRoundedBackground(View v,int bg,int stroke,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(bg);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(1,stroke);v.setBackground(d);}
    private static int dp(int value){return (int)(value*ResourcesHolder.density);}private static class ResourcesHolder{static float density=1f;}

    private String value(EditText e){return e==null?"":e.getText().toString();}
    private String value(Spinner s){return s==null?"":String.valueOf(s.getSelectedItem());}
    private void applySettingsVisuals(){appTitleView.setText(store.title());String b64=store.logo();if(!b64.isEmpty()){try{byte[] bytes=android.util.Base64.decode(b64,android.util.Base64.DEFAULT);Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);logoTextView.setVisibility(View.GONE);logoImageView.setVisibility(View.VISIBLE);logoImageView.setImageBitmap(bmp);}catch(Exception ignored){logoTextView.setVisibility(View.GONE);logoImageView.setVisibility(View.VISIBLE);logoImageView.setImageResource(com.aminovacao.amclientes231.R.drawable.ic_launcher);}}else{logoTextView.setVisibility(View.GONE);logoImageView.setVisibility(View.VISIBLE);logoImageView.setImageResource(com.aminovacao.amclientes231.R.drawable.ic_launcher);}}
    private String clientName(JSONObject c){String n=c.optString("Nome","");return n.isEmpty()?orDash(c.optString("Nome Empresa","")):n;}
    private String orDash(String s){return s==null||s.trim().isEmpty()?"—":s;}
    private boolean clientContains(JSONObject c,String q){if(q.isEmpty())return true;Iterator<String> it=c.keys();while(it.hasNext()){String k=it.next();String v=c.optString(k,"");if(v.toLowerCase(Locale.ROOT).contains(q))return true;}return false;}
    private JSONArray filteredClients(String q){JSONArray out=new JSONArray();JSONArray a=store.clients();for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c!=null&&clientContains(c,q))out.put(c);}return out;}
    private String status(JSONObject c){String raw=c.optString("Validade","");if(raw.isEmpty())return "active";Date d=parseDate(raw);if(d==null)return "active";long days=(d.getTime()-startOfDay(new Date()).getTime())/86400000L;return days<0?"expired":days<=30?"warning":"active";}
    private long daysUntilValidity(JSONObject c){Date d=parseDate(c.optString("Validade",""));return d==null?Long.MAX_VALUE:(d.getTime()-startOfDay(new Date()).getTime())/86400000L;}
    private String statusLabel(JSONObject c){String s=status(c);if("expired".equals(s))return "EXPIRADO";long d=daysUntilValidity(c);return d==Long.MAX_VALUE?"—":d+" dias";}
    private Date startOfDay(Date d){Calendar c=Calendar.getInstance();c.setTime(d);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTime();}
    private Date parseDate(String s){try{if(s==null||s.length()<8)return null;return new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(s.substring(0,10));}catch(Exception e){return null;}}
    private String formatDate(String s){Date d=parseDate(s);return d==null?s:new SimpleDateFormat("dd/MM/yyyy",new Locale("pt","PT")).format(d);}
    private String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    private String plusMonths(String s,int m){Date d=parseDate(s);if(d==null)return s;Calendar c=Calendar.getInstance();c.setTime(d);c.add(Calendar.MONTH,m);return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
    private double money(String s){
        try{
            String normalized=String.valueOf(s).replace("€","").replace("\u00a0","").replace("\u202f","").replaceAll("\\s","");
            int comma=normalized.lastIndexOf(',');int dot=normalized.lastIndexOf('.');
            if(comma>=0&&dot>=0){if(comma>dot)normalized=normalized.replace(".","").replace(",",".");else normalized=normalized.replace(",","");}
            else if(comma>=0)normalized=normalized.replace(",",".");
            return Double.parseDouble(normalized);
        }catch(Exception e){try{return Double.parseDouble(s);}catch(Exception ignored){return 0;}}
    }
    private String formatEuro(double v){return NumberFormat.getCurrencyInstance(new Locale("pt","PT")).format(v);}
    private String splitBeforeColon(String s){int i=s.indexOf(':');return i>=0?s.substring(0,i):s;}
    private String splitBeforeColonLabel(String s){return "purchase".equals(s)?"Compra":"activation".equals(s)?"Ativação":"renewal".equals(s)?"Renovação":s;}
    private String titleForCatalog(String t){return "equipamentos".equals(t)?"Equipamentos":"produtos".equals(t)?"Produtos / Consumíveis":"servicos".equals(t)?"Serviços":"Marcas";}
    private String iconForCatalog(String t){return "equipamentos".equals(t)?"📹":"produtos".equals(t)?"📦":"servicos".equals(t)?"🛠️":"🏷️";}
    private String summaryCatalogItem(String type,JSONObject o){if("equipamentos".equals(type))return orDash(o.optString("marca",""))+" · "+orDash(o.optString("modelo",""))+" · PVP "+formatEuro(o.optDouble("pvp",0));if("produtos".equals(type))return orDash(o.optString("marca",""))+" · stock "+stock(o).stock;return orDash(o.optString("tipo",""))+" · "+orDash(o.optString("unidade",""))+" · "+formatEuro(o.optDouble("venda",0));}
    private String pretty(String key){String s=key.replace('_',' ');return s.substring(0,1).toUpperCase()+s.substring(1);}
    private String uuid(String p){return p+"-"+UUID.randomUUID().toString().substring(0,8);}
    private double subscriptionSaleValue(String name){JSONObject s=findSubscription(name);return s==null?0:s.optDouble("revenue",s.optDouble("cost",0));}
    private void pickDate(EditText e) {
        Calendar initial = Calendar.getInstance();
        Date cur = parseDate(value(e));
        if (cur != null) initial.setTime(cur);
        showSequentialDateDialog(e, initial);
    }

    /**
     * Calendário branco com destaque azul. Ao tocar num dia do calendário,
     * abre diretamente a seleção do mês e, depois, do ano, como solicitado.
     */
    private void showSequentialDateDialog(EditText target, Calendar initial) {
        final Calendar selected = (Calendar) initial.clone();
        final Calendar displayed = (Calendar) initial.clone();
        final AlertDialog[] mainDialog = new AlertDialog[1];
        final LinearLayout daysHost = new LinearLayout(this);
        daysHost.setOrientation(LinearLayout.VERTICAL);
        final TextView yearHeader = new TextView(this);
        final TextView dateHeader = new TextView(this);
        final TextView monthLabel = new TextView(this);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(0, 0, 0, dp(4));
        panel.setBackground(roundedDateBackground(Color.WHITE, dp(24)));
        panel.setClipToOutline(true);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(24), dp(18), dp(20), dp(18));
        header.setBackground(roundedDateTopBackground(Color.rgb(97, 165, 255), dp(24)));
        yearHeader.setTextColor(Color.rgb(225, 239, 255));
        yearHeader.setTextSize(17);
        dateHeader.setTextColor(Color.WHITE);
        dateHeader.setTextSize(30);
        dateHeader.setSingleLine(true);
        yearHeader.setOnClickListener(v -> showDateYearPicker(displayed.get(Calendar.YEAR), year -> {
            displayed.set(Calendar.YEAR, year);
            selected.set(Calendar.YEAR, year);
            selected.set(Calendar.DAY_OF_MONTH, Math.min(selected.get(Calendar.DAY_OF_MONTH), selected.getActualMaximum(Calendar.DAY_OF_MONTH)));
            refreshSequentialCalendar(displayed, selected, yearHeader, dateHeader, monthLabel, daysHost,
                    () -> showDateMonthPicker(displayed, selected, yearHeader, dateHeader, monthLabel, daysHost, target, mainDialog[0]));
        }));
        dateHeader.setOnClickListener(v -> showDateMonthPicker(displayed, selected, yearHeader, dateHeader, monthLabel, daysHost, target, mainDialog[0]));
        header.addView(yearHeader);
        addSpacer(header, 2);
        header.addView(dateHeader);
        panel.addView(header, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout monthRow = new LinearLayout(this);
        monthRow.setGravity(Gravity.CENTER_VERTICAL);
        monthRow.setPadding(dp(14), dp(12), dp(14), dp(6));
        TextView prev = new TextView(this); prev.setText("‹"); prev.setTextSize(30); prev.setTextColor(Color.rgb(35,35,35)); prev.setGravity(Gravity.CENTER); prev.setContentDescription("Mês anterior");
        TextView next = new TextView(this); next.setText("›"); next.setTextSize(30); next.setTextColor(Color.rgb(35,35,35)); next.setGravity(Gravity.CENTER); next.setContentDescription("Mês seguinte");
        monthLabel.setTextColor(Color.rgb(30,30,30)); monthLabel.setTextSize(16); monthLabel.setGravity(Gravity.CENTER); monthLabel.setTypeface(null, Typeface.BOLD);
        monthRow.addView(prev, new LinearLayout.LayoutParams(dp(44), dp(42)));
        monthRow.addView(monthLabel, new LinearLayout.LayoutParams(0, dp(42), 1f));
        monthRow.addView(next, new LinearLayout.LayoutParams(dp(44), dp(42)));
        panel.addView(monthRow);

        LinearLayout weekdays = new LinearLayout(this);
        weekdays.setPadding(dp(12), dp(2), dp(12), dp(2));
        String[] weekdayNames = {"D", "S", "T", "Q", "Q", "S", "S"};
        for (String dayName : weekdayNames) {
            TextView w = new TextView(this); w.setText(dayName); w.setTextColor(Color.GRAY); w.setTextSize(13); w.setGravity(Gravity.CENTER);
            weekdays.addView(w, new LinearLayout.LayoutParams(0, dp(32), 1f));
        }
        panel.addView(weekdays);
        daysHost.setPadding(dp(12), 0, dp(12), dp(8));
        panel.addView(daysHost);

        // Footer personalizado dentro do próprio cartão branco. Evita que os botões
        // nativos do AlertDialog apareçam fora do cartão ou duplicados por baixo.
        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setPadding(dp(12), dp(2), dp(12), dp(2));
        TextView defineButton = dateFooterButton("DEFINIR");
        TextView cancelButton = dateFooterButton("CANCELAR");
        TextView okButton = dateFooterButton("OK");
        footer.addView(defineButton, new LinearLayout.LayoutParams(0, dp(48), 1.0f));
        footer.addView(cancelButton, new LinearLayout.LayoutParams(0, dp(48), 1.25f));
        footer.addView(okButton, new LinearLayout.LayoutParams(0, dp(48), 0.55f));
        panel.addView(footer, new LinearLayout.LayoutParams(-1, dp(52)));

        Runnable[] refresh = new Runnable[1];
        refresh[0] = () -> refreshSequentialCalendar(displayed, selected, yearHeader, dateHeader, monthLabel, daysHost,
                () -> showDateMonthPicker(displayed, selected, yearHeader, dateHeader, monthLabel, daysHost, target, mainDialog[0]));
        prev.setOnClickListener(v -> { displayed.add(Calendar.MONTH, -1); refresh[0].run(); });
        next.setOnClickListener(v -> { displayed.add(Calendar.MONTH, 1); refresh[0].run(); });
        monthLabel.setOnClickListener(v -> showDateMonthPicker(displayed, selected, yearHeader, dateHeader, monthLabel, daysHost, target, mainDialog[0]));
        refresh[0].run();

        mainDialog[0] = new AlertDialog.Builder(this, R.style.LightDialogTheme)
                .setView(panel)
                .create();
        yearHeader.setTag(new DatePickerFlowContext(target, mainDialog[0]));
        defineButton.setOnClickListener(v -> {
            Calendar today = Calendar.getInstance();
            target.setText(String.format(Locale.US, "%04d-%02d-%02d", today.get(Calendar.YEAR), today.get(Calendar.MONTH) + 1, today.get(Calendar.DAY_OF_MONTH)));
            mainDialog[0].dismiss();
        });
        cancelButton.setOnClickListener(v -> mainDialog[0].dismiss());
        okButton.setOnClickListener(v -> {
            target.setText(String.format(Locale.US, "%04d-%02d-%02d", selected.get(Calendar.YEAR), selected.get(Calendar.MONTH) + 1, selected.get(Calendar.DAY_OF_MONTH)));
            mainDialog[0].dismiss();
        });
        mainDialog[0].setOnShowListener(d -> {
            if (mainDialog[0].getWindow() != null) {
                mainDialog[0].getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                mainDialog[0].getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.92), -2);
            }
        });
        mainDialog[0].show();
        if (mainDialog[0].getWindow() != null) {
            mainDialog[0].getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            mainDialog[0].getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.92), -2);
        }
    }

    private TextView dateFooterButton(String text) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setTextColor(Color.rgb(97, 165, 255));
        button.setTextSize(14);
        button.setGravity(Gravity.CENTER);
        button.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    private Drawable roundedDateBackground(int color, int radius) {
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(radius);
        return bg;
    }

    private Drawable roundedDateTopBackground(int color, int radius) {
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(color);
        float r = radius;
        bg.setCornerRadii(new float[]{r, r, r, r, 0f, 0f, 0f, 0f});
        return bg;
    }

    private void refreshSequentialCalendar(Calendar displayed, Calendar selected, TextView yearHeader,
            TextView dateHeader, TextView monthLabel, LinearLayout daysHost, Runnable onDayPicked) {
        int year = displayed.get(Calendar.YEAR);
        int month = displayed.get(Calendar.MONTH);
        yearHeader.setText(String.valueOf(year));
        Calendar headerDate = (Calendar) displayed.clone();
        headerDate.set(Calendar.DAY_OF_MONTH, Math.min(selected.get(Calendar.DAY_OF_MONTH), displayed.getActualMaximum(Calendar.DAY_OF_MONTH)));
        String[] weekdays = {"Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"};
        dateHeader.setText(weekdays[headerDate.get(Calendar.DAY_OF_WEEK) - 1] + ", " + String.format(Locale.US, "%02d/%02d", headerDate.get(Calendar.DAY_OF_MONTH), month + 1));
        String[] months = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
        monthLabel.setText(months[month] + " de " + year);
        daysHost.removeAllViews();
        Calendar first = (Calendar) displayed.clone();
        first.set(Calendar.DAY_OF_MONTH, 1);
        int offset = first.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY;
        int count = displayed.getActualMaximum(Calendar.DAY_OF_MONTH);
        int rows = (offset + count + 6) / 7;
        int day = 1;
        for (int r = 0; r < rows; r++) {
            LinearLayout row = new LinearLayout(this);
            for (int c = 0; c < 7; c++) {
                int cell = r * 7 + c;
                TextView cellView = new TextView(this);
                cellView.setGravity(Gravity.CENTER);
                cellView.setTextSize(15);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
                if (cell >= offset && day <= count) {
                    final int chosenDay = day++;
                    cellView.setText(String.valueOf(chosenDay));
                    boolean isSelected = displayed.get(Calendar.YEAR) == selected.get(Calendar.YEAR)
                            && displayed.get(Calendar.MONTH) == selected.get(Calendar.MONTH)
                            && chosenDay == selected.get(Calendar.DAY_OF_MONTH);
                    if (isSelected) {
                        cellView.setTextColor(Color.WHITE);
                        cellView.setBackground(roundedDateBackground(Color.rgb(97, 165, 255), dp(24)));
                    } else {
                        cellView.setTextColor(Color.rgb(35, 35, 35));
                    }
                    cellView.setOnClickListener(v -> {
                        selected.set(Calendar.DAY_OF_MONTH, Math.min(chosenDay, selected.getActualMaximum(Calendar.DAY_OF_MONTH)));
                        Object ctx = yearHeader.getTag();
                        if (ctx instanceof DatePickerFlowContext) {
                            DatePickerFlowContext flow = (DatePickerFlowContext) ctx;
                            showDateMonthPicker(displayed, selected, yearHeader, dateHeader, monthLabel, daysHost, flow.target, flow.dialog, onDayPicked);
                        }
                    });
                }
                row.addView(cellView, lp);
            }
            daysHost.addView(row);
        }
    }

    private static final class DatePickerFlowContext {
        final EditText target;
        final AlertDialog dialog;
        DatePickerFlowContext(EditText target, AlertDialog dialog) { this.target = target; this.dialog = dialog; }
    }

    private interface DateYearChoice { void onChosen(int year); }

    private void showDateMonthPicker(Calendar displayed, Calendar selected, TextView yearHeader, TextView dateHeader,
            TextView monthLabel, LinearLayout daysHost, EditText target, AlertDialog mainDialog) {
        showDateMonthPicker(displayed, selected, yearHeader, dateHeader, monthLabel, daysHost, target, mainDialog, null);
    }

    private void showDateMonthPicker(Calendar displayed, Calendar selected, TextView yearHeader, TextView dateHeader,
            TextView monthLabel, LinearLayout daysHost, EditText target, AlertDialog mainDialog, Runnable onDayPicked) {
        String[] months = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
        final int[] chosenMonth = {displayed.get(Calendar.MONTH)};
        AlertDialog monthDialog = new AlertDialog.Builder(this, R.style.LightDialogTheme)
                .setTitle("Escolher mês")
                .setSingleChoiceItems(months, chosenMonth[0], (d, which) -> {
                    chosenMonth[0] = which;
                    d.dismiss();
                    // Só alterar a data depois de confirmar também o ano.
                    showDateYearPicker(displayed.get(Calendar.YEAR), year -> {
                        displayed.set(Calendar.MONTH, chosenMonth[0]);
                        displayed.set(Calendar.YEAR, year);
                        selected.set(Calendar.YEAR, year);
                        selected.set(Calendar.MONTH, chosenMonth[0]);
                        selected.set(Calendar.DAY_OF_MONTH, Math.min(selected.get(Calendar.DAY_OF_MONTH), selected.getActualMaximum(Calendar.DAY_OF_MONTH)));
                        refreshSequentialCalendar(displayed, selected, yearHeader, dateHeader, monthLabel, daysHost,
                                () -> showDateMonthPicker(displayed, selected, yearHeader, dateHeader, monthLabel, daysHost, target, mainDialog, onDayPicked));
                        if (target != null) {
                            target.setText(String.format(Locale.US, "%04d-%02d-%02d", year, chosenMonth[0] + 1, selected.get(Calendar.DAY_OF_MONTH)));
                            if (mainDialog != null) mainDialog.dismiss();
                        } else if (onDayPicked != null) {
                            onDayPicked.run();
                        }
                    });
                })
                .setNegativeButton("Cancelar", (d, w) -> {})
                .create();
        monthDialog.show();
        if (monthDialog.getWindow() != null) {
            monthDialog.getWindow().setBackgroundDrawableResource(R.drawable.date_dialog_background);
        }
    }

    private void showDateYearPicker(int initialYear, DateYearChoice onChosen) {
        final int[] decadeStart = {Math.max(1900, Math.min(2100, (initialYear / 10) * 10))};
        final int[] chosenYear = {Math.max(1900, Math.min(2100, initialYear))};

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(4), dp(16), dp(12));

        LinearLayout decadeHeader = new LinearLayout(this);
        decadeHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView previous = new TextView(this);
        previous.setText("‹");
        previous.setTextSize(30);
        previous.setTextColor(Color.rgb(97, 165, 255));
        previous.setGravity(Gravity.CENTER);
        TextView range = new TextView(this);
        range.setTextColor(Color.rgb(35, 45, 60));
        range.setTextSize(16);
        range.setTypeface(null, Typeface.BOLD);
        range.setGravity(Gravity.CENTER);
        TextView next = new TextView(this);
        next.setText("›");
        next.setTextSize(30);
        next.setTextColor(Color.rgb(97, 165, 255));
        next.setGravity(Gravity.CENTER);
        decadeHeader.addView(previous, new LinearLayout.LayoutParams(dp(44), dp(46)));
        decadeHeader.addView(range, new LinearLayout.LayoutParams(0, dp(46), 1f));
        decadeHeader.addView(next, new LinearLayout.LayoutParams(dp(44), dp(46)));
        box.addView(decadeHeader);

        LinearLayout yearsGrid = new LinearLayout(this);
        yearsGrid.setOrientation(LinearLayout.VERTICAL);
        box.addView(yearsGrid, new LinearLayout.LayoutParams(-1, -2));

        Runnable[] renderYears = new Runnable[1];
        renderYears[0] = () -> {
            range.setText(decadeStart[0] + "–" + Math.min(decadeStart[0] + 9, 2100));
            yearsGrid.removeAllViews();
            for (int rowIndex = 0; rowIndex < 2; rowIndex++) {
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER);
                for (int col = 0; col < 5; col++) {
                    int year = decadeStart[0] + rowIndex * 5 + col;
                    if (year <= 2100) {
                        TextView yearCell = new TextView(this);
                        yearCell.setText(String.valueOf(year));
                        yearCell.setGravity(Gravity.CENTER);
                        yearCell.setTextSize(15);
                        boolean isChosen = chosenYear[0] == year;
                        yearCell.setTextColor(isChosen ? Color.WHITE : Color.rgb(34, 48, 67));
                        yearCell.setTypeface(null, isChosen ? Typeface.BOLD : Typeface.NORMAL);
                        yearCell.setBackground(roundedDateBackground(isChosen ? Color.rgb(97, 165, 255) : Color.rgb(239, 245, 253), dp(12)));
                        yearCell.setOnClickListener(v -> {
                            chosenYear[0] = year;
                            renderYears[0].run();
                        });
                        LinearLayout.LayoutParams cellParams = new LinearLayout.LayoutParams(0, dp(44), 1f);
                        cellParams.setMargins(dp(3), dp(4), dp(3), dp(4));
                        row.addView(yearCell, cellParams);
                    } else {
                        View empty = new View(this);
                        LinearLayout.LayoutParams emptyParams = new LinearLayout.LayoutParams(0, dp(44), 1f);
                        emptyParams.setMargins(dp(3), dp(4), dp(3), dp(4));
                        row.addView(empty, emptyParams);
                    }
                }
                yearsGrid.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
            previous.setAlpha(decadeStart[0] <= 1900 ? 0.35f : 1f);
            next.setAlpha(decadeStart[0] >= 2100 ? 0.35f : 1f);
        };
        previous.setOnClickListener(v -> {
            if (decadeStart[0] > 1900) {
                decadeStart[0] = Math.max(1900, decadeStart[0] - 10);
                chosenYear[0] = Math.max(decadeStart[0], Math.min(decadeStart[0] + 9, chosenYear[0]));
                renderYears[0].run();
            }
        });
        next.setOnClickListener(v -> {
            if (decadeStart[0] < 2100) {
                decadeStart[0] = Math.min(2100, decadeStart[0] + 10);
                chosenYear[0] = Math.max(decadeStart[0], Math.min(Math.min(decadeStart[0] + 9, 2100), chosenYear[0]));
                renderYears[0].run();
            }
        });
        renderYears[0].run();

        AlertDialog yearDialog = new AlertDialog.Builder(this, R.style.LightDialogTheme)
                .setTitle("Escolher ano")
                .setView(box)
                .setNegativeButton("CANCELAR", (d, w) -> {})
                .setPositiveButton("OK", (d, w) -> onChosen.onChosen(chosenYear[0]))
                .create();
        yearDialog.show();
        if (yearDialog.getWindow() != null) {
            yearDialog.getWindow().setBackgroundDrawableResource(R.drawable.date_dialog_background);
            yearDialog.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.84), -2);
        }
    }

    private void openExternal(String url){if(url==null||url.isEmpty())return;try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}}
    private interface FormDialogSaveAction {
        void save(AlertDialog dialog);
    }

    private static final class FormDialogParts {
        final AlertDialog dialog;
        final Button save;
        final Button cancel;
        FormDialogParts(AlertDialog dialog, Button save, Button cancel) {
            this.dialog = dialog;
            this.save = save;
            this.cancel = cancel;
        }
    }

    /** Formulários pop-up com o mesmo tema azul-escuro do resto da aplicação. */
    private FormDialogParts showDarkFormDialog(String title, LinearLayout fields, String saveLabel,
                                                FormDialogSaveAction saveAction) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(18), dp(18), dp(16));
        setRoundedBackground(panel, PANEL, LINE, 22);

        TextView heading = tv(title, 21, TEXT, true);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        panel.addView(heading, new LinearLayout.LayoutParams(-1, -2));
        addSpacer(panel, 10);

        ScrollView formScroll = new ScrollView(this) {
            @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int maxHeight = (int) (MainActivity.this.getResources().getDisplayMetrics().heightPixels * 0.54f);
                super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(maxHeight, MeasureSpec.AT_MOST));
            }
        };
        formScroll.setFillViewport(false);
        formScroll.setVerticalScrollBarEnabled(false);
        formScroll.setClipToPadding(false);
        formScroll.addView(fields, new ScrollView.LayoutParams(-1, -2));
        panel.addView(formScroll, new LinearLayout.LayoutParams(-1, -2));
        addSpacer(panel, 12);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        Button cancel = button("Cancelar", false);
        cancel.setTextSize(14);
        cancel.setPadding(dp(12), 0, dp(12), 0);
        actions.addView(cancel, new LinearLayout.LayoutParams(-2, dp(42)));
        Button save = primary(saveLabel);
        save.setTextSize(14);
        save.setPadding(dp(14), 0, dp(14), 0);
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(-2, dp(42));
        saveLp.leftMargin = dp(8);
        actions.addView(save, saveLp);
        panel.addView(actions, new LinearLayout.LayoutParams(-1, dp(42)));

        AlertDialog dialog = new AlertDialog.Builder(this, R.style.AppTheme).setView(panel).create();
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            dialog.getWindow().setLayout(Math.min((int) (screenWidth * 0.94f), dp(540)),
                    WindowManager.LayoutParams.WRAP_CONTENT);
        }
        cancel.setOnClickListener(v -> dialog.dismiss());
        save.setOnClickListener(v -> saveAction.save(dialog));
        return new FormDialogParts(dialog, save, cancel);
    }

    private android.graphics.drawable.GradientDrawable dialogPill(int color, int radiusDp) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    /** Mensagens de confirmação com botões equilibrados, afastados das margens. */
    private void confirm(String title, String message, Runnable yes) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(24), dp(22), dp(24), dp(22));
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setBackground(dialogPill(Color.WHITE, 26));

        TextView heading = tv(title, 22, Color.rgb(45, 48, 56), true);
        heading.setGravity(Gravity.CENTER);
        panel.addView(heading, new LinearLayout.LayoutParams(-1, -2));
        addSpacer(panel, 12);
        TextView body = tv(message, 17, Color.rgb(83, 85, 93), false);
        body.setGravity(Gravity.CENTER);
        body.setLineSpacing(dp(2), 1f);
        panel.addView(body, new LinearLayout.LayoutParams(-1, -2));
        addSpacer(panel, 20);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        Button cancel = new Button(this);
        cancel.setText("Cancelar");
        cancel.setAllCaps(false);
        cancel.setTextSize(16);
        cancel.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        cancel.setTextColor(Color.rgb(55, 57, 63));
        cancel.setBackground(dialogPill(Color.rgb(231, 232, 236), 18));
        cancel.setMinHeight(dp(48));
        cancel.setPadding(dp(6), 0, dp(6), 0);
        Button confirm = new Button(this);
        confirm.setText("Confirmar");
        confirm.setAllCaps(false);
        confirm.setTextSize(16);
        confirm.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        confirm.setTextColor(Color.WHITE);
        confirm.setBackground(dialogPill(Color.rgb(91, 151, 222), 18));
        confirm.setMinHeight(dp(48));
        confirm.setPadding(dp(6), 0, dp(6), 0);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        bp.rightMargin = dp(8);
        actions.addView(cancel, bp);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        cp.leftMargin = dp(4);
        actions.addView(confirm, cp);
        panel.addView(actions, new LinearLayout.LayoutParams(-1, dp(48)));

        AlertDialog dialog = new AlertDialog.Builder(this, R.style.LightDialogTheme)
                .setView(panel).create();
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int width = Math.min((int)(getResources().getDisplayMetrics().widthPixels * 0.92f), dp(560));
            dialog.getWindow().setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
        }
        cancel.setOnClickListener(v -> dialog.dismiss());
        confirm.setOnClickListener(v -> {
            dialog.dismiss();
            if (yes != null) yes.run();
        });
    }

    /** Avisos simples seguem o mesmo cartão arredondado e usam um botão azul legível. */
    private void alert(String title, String msg) {
        showAlert(title, msg, false);
    }

    /** Aviso curto para confirmações de sucesso, com largura reduzida e texto em linhas controladas. */
    private void alertCompact(String title, String msg) {
        // O aviso de sucesso mantém a tipografia original e o botão OK largo.
        showAlert(title, msg, false, true);
    }

    private void showAlert(String title, String msg, boolean compact) {
        showAlert(title, msg, compact, false);
    }

    private void showAlert(String title, String msg, boolean compact, boolean fullWidthButton) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int horizontalPadding = fullWidthButton ? 16 : (compact ? 12 : 24);
        panel.setPadding(dp(horizontalPadding), dp(compact ? 14 : 22),
                dp(horizontalPadding), dp(compact ? 12 : 18));
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setBackground(dialogPill(Color.WHITE, 24));
        TextView heading = tv(title, compact ? 18 : 22, Color.rgb(45, 48, 56), true);
        heading.setGravity(Gravity.CENTER);
        panel.addView(heading, new LinearLayout.LayoutParams(-1, -2));
        addSpacer(panel, compact ? 9 : 12);
        TextView body = tv(msg, compact ? 15 : 17, Color.rgb(83, 85, 93), false);
        body.setGravity(Gravity.CENTER);
        body.setLineSpacing(dp(2), 1f);
        panel.addView(body, new LinearLayout.LayoutParams(-1, -2));
        addSpacer(panel, compact ? 10 : 18);
        Button ok = new Button(this);
        ok.setText("OK");
        ok.setAllCaps(false);
        ok.setTextSize(16);
        ok.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        ok.setTextColor(Color.WHITE);
        ok.setBackground(dialogPill(Color.rgb(91, 151, 222), 18));
        LinearLayout.LayoutParams op = fullWidthButton
                ? new LinearLayout.LayoutParams(-1, dp(48))
                : new LinearLayout.LayoutParams(dp(compact ? 100 : 112), dp(compact ? 42 : 46));
        op.gravity = Gravity.CENTER_HORIZONTAL;
        panel.addView(ok, op);
        AlertDialog dialog = new AlertDialog.Builder(this, R.style.LightDialogTheme).setView(panel).create();
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int width = compact
                    ? Math.min((int) (getResources().getDisplayMetrics().widthPixels * 0.70f), dp(300))
                    : fullWidthButton
                        ? Math.min((int) (getResources().getDisplayMetrics().widthPixels * 0.82f), dp(380))
                        : Math.min((int) (getResources().getDisplayMetrics().widthPixels * 0.92f), dp(560));
            dialog.getWindow().setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
        }
        ok.setOnClickListener(v -> dialog.dismiss());
    }
    private TextWatcher simpleWatcher(Runnable r){return new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){r.run();}public void afterTextChanged(Editable e){}};}
    private String readText(Uri u)throws Exception{try(InputStream in=getContentResolver().openInputStream(u)){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);return out.toString(StandardCharsets.UTF_8.name());}}
    private void startActivityForResultSafe(Intent i,int req){try{startActivityForResult(i,req);}catch(Exception e){alert("Erro",e.getMessage());}}

    // ========================== XLS SpreadsheetML ========================
    private String toSpreadsheetXml(JSONObject backup)throws Exception{
        StringBuilder b=new StringBuilder();b.append("<?xml version=\"1.0\"?><?mso-application progid=\"Excel.Sheet\"?>");b.append("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\"><Worksheet ss:Name=\"Clientes\"><Table>");writeSheetRows(b,backup.optJSONArray("clientes"));b.append("</Table></Worksheet><Worksheet ss:Name=\"Arquivados\"><Table>");writeSheetRows(b,backup.optJSONArray("arquivados"));b.append("</Table></Worksheet><Worksheet ss:Name=\"Subscricoes\"><Table>");writeSheetRows(b,backup.optJSONArray("subscricoes"));b.append("</Table></Worksheet></Workbook>");return b.toString();}
    private void writeSheetRows(StringBuilder b,JSONArray a){if(a==null||a.length()==0)return;LinkedHashSet<String> keys=new LinkedHashSet<>();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null){Iterator<String> it=o.keys();while(it.hasNext())keys.add(it.next());}}b.append("<Row>");for(String k:keys)b.append("<Cell><Data ss:Type=\"String\">").append(xml(k)).append("</Data></Cell>");b.append("</Row>");for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;b.append("<Row>");for(String k:keys)b.append("<Cell><Data ss:Type=\"String\">").append(xml(o.optString(k,"")).replace("<", "&lt;").replace(">","&gt;")).append("</Data></Cell>");b.append("</Row>");}}
    private String xml(String s){return s==null?"":s.replace("&","&amp;").replace("\"","&quot;").replace("'","&apos;");}
    private JSONObject parseSpreadsheetXml(String text)throws Exception{Document d=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new java.io.ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)));JSONObject out=new JSONObject();parseWorksheet(d,"Clientes","clientes",out);parseWorksheet(d,"Arquivados","arquivados",out);parseWorksheet(d,"Subscricoes","subscricoes",out);return out;}
    private void parseWorksheet(Document d,String sheetName,String outKey,JSONObject out)throws Exception{NodeList sheets=d.getElementsByTagName("Worksheet");for(int i=0;i<sheets.getLength();i++){Element e=(Element)sheets.item(i);if(!sheetName.equals(e.getAttributeNS("urn:schemas-microsoft-com:office:spreadsheet","Name"))&&!sheetName.equals(e.getAttribute("ss:Name")))continue;NodeList rows=e.getElementsByTagName("Row");if(rows.getLength()==0)continue;List<String> headers=new ArrayList<>();JSONArray arr=new JSONArray();for(int r=0;r<rows.getLength();r++){Element row=(Element)rows.item(r);NodeList cells=row.getElementsByTagName("Cell");List<String> vals=new ArrayList<>();for(int c=0;c<cells.getLength();c++){NodeList data=((Element)cells.item(c)).getElementsByTagName("Data");vals.add(data.getLength()>0?data.item(0).getTextContent():"");}if(r==0)headers.addAll(vals);else{JSONObject o=new JSONObject();for(int c=0;c<Math.min(headers.size(),vals.size());c++)o.put(headers.get(c),vals.get(c));arr.put(o);}}out.put(outKey,arr);return;}}

    private int stockAlerts(){int n=0;for(String t:new String[]{"equipamentos","produtos"}){JSONArray a=store.catalog(t);for(int i=0;i<a.length();i++){StockResult r=stock(a.optJSONObject(i));if(r.low||r.stock==0)n++;}}return n;}
    private static class StockResult{int stock;boolean low;}
    private StockResult stock(JSONObject o){StockResult r=new StockResult();if(o==null)return r;r.stock=Math.max(0,(int)o.optDouble("quantidade_comprada",o.optDouble("quantidade",0))- (int)o.optDouble("quantidade_utilizada",0));double min=o.optDouble("stock_minimo",0);r.low=r.stock>0&&min>0&&r.stock<=min;return r;}


    @Override public void onBackPressed(){if(drawerOverlay!=null&&drawerOverlay.getVisibility()==View.VISIBLE){closeDrawer();return;}if(!"inicio".equals(currentScreen)){showScreen("inicio");return;}super.onBackPressed();}

    static { ResourcesHolder.density=android.content.res.Resources.getSystem().getDisplayMetrics().density; }

}
