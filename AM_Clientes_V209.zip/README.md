AM Clientes V209 — regra de compra das subscrições.

A validade continua a determinar o que é cobrado ao cliente. A subscrição pode agora usar a regra de compra Normal (1 por 1) ou Promoção 6 por 5. Na promoção, 6 meses consumem 5 licenças de stock e 12 meses consomem 10, repetindo a regra por blocos de 6 meses. O cliente continua a ter e a pagar as 6/12 licenças; apenas o consumo do stock e o custo efetivo unitário refletem a promoção.
