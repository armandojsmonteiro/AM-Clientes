# AM Clientes V295

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 295
- `versionName`: `1.0.295`

## Alteração desta versão

Correção localizada no menu **Serviços e subscrições**: os formulários de serviços e subscrições passaram a estar integrados na página com campos brancos, seletores com seta e botões azuis; os registos existentes permitem edição no formulário inline e eliminação com confirmação; as ações dos cartões de subscrição foram reorganizadas em duas linhas para evitar sobreposição; movimentos e equipamentos associados são apresentados de forma legível; as janelas de aviso/confirmação e os diálogos de operações deste menu usam estilo claro. Os outros ecrãs não foram alvo de alterações visuais intencionais.
