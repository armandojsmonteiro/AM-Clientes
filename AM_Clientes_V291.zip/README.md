# AM Clientes V291

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 291
- `versionName`: `1.0.291`

Alteração limitada ao regresso do editor de cliente: guarda a posição de scroll do ecrã anterior ao abrir a edição e, ao cancelar, reconstrói a pré-visualização/lista preservando a posição anterior e anima até ela a partir da posição atual, em qualquer direção. Evita reiniciar sempre no topo e mantém Início e Clientes separados.
