AM Clientes V268 — projeto Android nativo.

Estado consolidado da nova aplicação independente.
- Package / Application ID: com.aminovacao.amclientes231
- Aplicação 100% Android nativa; sem HTML/WebView como solução de interface.
- V230 é apenas a referência funcional da aplicação original; esta aplicação é independente.
- Arranque em estado vazio, sem dados de demonstração.
- O backup JSON externo continua a ser a fonte de dados para testes/importação.
- Interface trabalhada progressivamente, menu a menu, sem patches ou implementações concorrentes para o mesmo elemento.

Alterações V268:
- Botão Fechar Cliente fica rigidamente em 72 x 40 dp, impedindo expansão automática causada pelo texto.
- O texto Fechar Cliente continua em duas linhas dentro do mesmo botão standard.
- Nome do cliente reduzido ligeiramente para 18sp, mantendo negrito e quebra natural conforme o espaço disponível.
- Separação antes de Equipamento aumentada ligeiramente, sem alterar a estrutura das restantes secções.
