# AM Clientes V294

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 294
- `versionName`: `1.0.294`

Alteração localizada no fluxo de edição do cliente: a abertura do editor começa no topo do formulário e anima o scroll para baixo até ao campo Tipo de Equipamento do primeiro equipamento, colocando os campos de equipamento e serviços/subscrições na zona visível conforme a referência enviada. Se o cliente ainda não tiver equipamentos, a animação termina na secção `Novo equipamento`. O objetivo é manter o comportamento de cancelamento da V293 e mudar apenas o ponto final da animação de abertura do editor.
