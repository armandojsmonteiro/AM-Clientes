# AM Clientes V340

## Alterações da V340

- O painel principal de Estatísticas passa a englobar os quatro cartões de resumo e todas as secções/submenus, com os mesmos contornos azul médio aprovados.
- O título Estatísticas passa a usar o tamanho padrão dos títulos dos menus. O botão Fechar fecha o módulo completo e regressa ao Início; deixa de recolher apenas os cartões de resumo.
- Ao entrar em Estatísticas, os quatro cartões de resumo ficam visíveis e os submenus começam fechados. As secções continuam reordenáveis e a ordem guardada mantém-se.
- Gestão da base de dados: o ícone fica alinhado ao centro do título em duas linhas e com maior afastamento do texto.
- Os cinco comandos da Gestão da base de dados passam a ter puxador, ícone e legenda em colunas alinhadas pela esquerda, com o contorno azul médio aplicado de forma uniforme.

## Versão

- `versionCode`: 340
- `versionName`: `1.0.340`
- Aplicação Android nativa.
