AM Clientes V227 — correção definitiva do consumo de Packs e do scroll por toque na lista de clientes/equipamentos.

VersionCode: 227
VersionName: 1.0.227
