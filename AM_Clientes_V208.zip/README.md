AM Clientes V208 — consumo de subscrições por meses de validade: cada atribuição a um equipamento consome o número de meses definido em Validade; múltiplas subscrições no mesmo equipamento são contabilizadas separadamente e o detalhe mostra o total utilizado por cliente/equipamento.

AM Clientes V200 — correção do suporte a valores monetários com cêntimos e criação de snapshots dos preços atribuídos aos clientes. Os preços existentes deixam de ser alterados automaticamente quando o catálogo muda; só mudam quando o utilizador volta a selecionar o serviço ou subscrição no cliente.
