package com.aminovacao.amclientes.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aminovacao.amclientes.data.Database

private val Bg = Color(0xFF030B20)
private val Panel = Color(0xCC071127)
private val Panel2 = Color(0xCC071630)
private val Line = Color(0xFF29405F)
private val Blue = Color(0xFF61A5FF)
private val TextMain = Color(0xFFF5F7FB)
private val Muted = Color(0xFF9AA0AA)
private val Green = Color(0xFF35D07F)
private val Orange = Color(0xFFFFAD45)
private val Red = Color(0xFFFF5C68)

private data class NavItem(val title: String, val emoji: String)
private val navItems = listOf(
    NavItem("Início", "🏠"), NavItem("Clientes", "📋"),
    NavItem("Subscrições", "🔐"), NavItem("Catálogos", "📦"),
    NavItem("Arquivado", "📁"), NavItem("Histórico", "🕘"),
    NavItem("Estatísticas", "📊"), NavItem("Configurações", "⚙️"),
    NavItem("Gestão", "🔧")
)

@Composable
fun AMClientesApp(context: Context) {
    val db = remember { Database(context) }
    var selected by remember { mutableStateOf("Início") }
    var companyId by remember { mutableStateOf("") }
    var companyName by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var homeClientsOpen by remember { mutableStateOf(true) }
    var clientRefreshKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        val company = db.ensureDefaultCompany()
        companyId = company.first
        companyName = company.second
    }

    Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF12376F), Color(0xFF071630), Bg), radius = 1100f))) {
        Column(Modifier.fillMaxSize().padding(start = 16.dp, end = 16.dp, top = 50.dp, bottom = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Surface(
                    modifier = Modifier.size(44.dp).clickable { menuOpen = !menuOpen },
                    shape = RoundedCornerShape(16.dp), color = Color(0xFF071630),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Line)
                ) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Menu, "Menu", tint = TextMain, modifier = Modifier.size(25.dp)) } }
                Spacer(Modifier.width(12.dp))
                Surface(modifier = Modifier.size(44.dp), shape = RoundedCornerShape(11.dp), color = Color(0xFF0A1C3C), border = androidx.compose.foundation.BorderStroke(1.dp, Line)) {
                    Box(contentAlignment = Alignment.Center) { Text("AM", color = Blue, fontWeight = FontWeight.Black, fontSize = 20.sp) }
                }
                Spacer(Modifier.width(14.dp))
                Text("AM Clientes", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            }

            Spacer(Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .border(1.dp, Line, RoundedCornerShape(13.dp))
                    .background(Color(0xFF020817), RoundedCornerShape(13.dp))
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                BasicTextField(
                    value = search,
                    onValueChange = { search = it },
                    singleLine = true,
                    textStyle = LocalTextStyle.current.copy(color = TextMain, fontSize = 15.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(Blue),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { innerTextField ->
                        if (search.isBlank()) {
                            Text(
                                "Pesquisar nome, contacto, empresa, equipamento, MAC, nº série...",
                                color = Muted,
                                fontSize = 15.sp,
                                maxLines = 1
                            )
                        }
                        innerTextField()
                    }
                )
            }

            if (selected == "Início" || selected == "Clientes") {
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("0", "Ativos", Green, Modifier.weight(1f))
                    StatCard("0", "A expirar", Orange, Modifier.weight(1f))
                    StatCard("0", "Expirados", Red, Modifier.weight(1f))
                }
            }

            Spacer(Modifier.height(18.dp))
            Surface(
                Modifier.fillMaxSize(),
                shape = RoundedCornerShape(24.dp),
                color = Color.Transparent,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.Transparent)
            ) {
                Box(Modifier.fillMaxSize()) {
                    when (selected) {
                        "Início" -> Home(
                            company = companyName,
                            clientsOpen = homeClientsOpen,
                            onToggleClients = { homeClientsOpen = !homeClientsOpen },
                            onOpenClients = { selected = "Clientes" }
                        )
                        else -> Section(
                            title = selected,
                            company = companyName,
                            companyId = companyId,
                            db = db,
                            refreshKey = clientRefreshKey,
                            onChanged = { clientRefreshKey++ },
                            onGoHome = { selected = "Início" }
                        )
                    }
                }
            }
        }

        if (menuOpen) {
            MenuOverlay(onClose = { menuOpen = false })
            SideMenu(
                company = companyName,
                selected = selected,
                onSelect = { selected = it; menuOpen = false },
                onClose = { menuOpen = false }
            )
        }
    }
}

@Composable private fun StatCard(value: String, label: String, valueColor: Color, modifier: Modifier) {
    Surface(modifier, shape = RoundedCornerShape(20.dp), color = Color(0x66071127), border = androidx.compose.foundation.BorderStroke(1.dp, Line)) {
        Column(Modifier.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = valueColor, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(label, color = TextMain, fontSize = 15.sp)
        }
    }
}

@Composable
private fun Home(
    company: String,
    clientsOpen: Boolean,
    onToggleClients: () -> Unit,
    onOpenClients: () -> Unit
) {
    LazyColumn(Modifier.fillMaxSize().padding(top = 0.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item {
            CardPanel {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("📋  Clientes", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    // Reservar exatamente o mesmo espaço do grupo de botões do ecrã Clientes.
                    // Assim, o botão Fechar não muda de posição entre Início e Clientes.
                    Box(
                        modifier = Modifier.width(136.dp).height(40.dp),
                        contentAlignment = Alignment.CenterEnd
                    ) {
                        Button(
                            onClick = onToggleClients,
                            modifier = Modifier.width(64.dp).height(40.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                            shape = RoundedCornerShape(13.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Bg)
                        ) {
                            Text(if (clientsOpen) "Fechar" else "Abrir", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (clientsOpen) {
                    Spacer(Modifier.height(12.dp))
                    Surface(
                        Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onOpenClients),
                        shape = RoundedCornerShape(18.dp),
                        color = Color(0x22071127),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Line)
                    ) {
                        Text("Nenhum cliente.", color = Muted, fontSize = 15.sp, modifier = Modifier.padding(16.dp))
                    }
                }
            }
        }
        item {
            CardPanel {
                Text("🔗  Atalhos", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Text("Ainda não existem atalhos. Pode adicioná-los em Configurações.", color = Muted, fontSize = 13.sp)
            }
        }
    }
}

@Composable private fun CardPanel(content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Panel)
            .border(1.dp, Line, shape)
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
private fun MenuOverlay(onClose: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .clickable(onClick = onClose)
    )
}

@Composable
private fun SideMenu(
    company: String,
    selected: String,
    onSelect: (String) -> Unit,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxHeight()
            .width(205.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF071A36),
            tonalElevation = 12.dp,
            shadowElevation = 18.dp,
            shape = RoundedCornerShape(topEnd = 22.dp, bottomEnd = 22.dp)
        ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(start = 16.dp, end = 16.dp, top = 28.dp, bottom = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().height(42.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "AM Clientes",
                    color = TextMain,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0x120B1935), RoundedCornerShape(14.dp))
                        .border(1.dp, Line, RoundedCornerShape(14.dp))
                        .clickable(onClick = onClose),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Close,
                        "Fechar",
                        tint = TextMain,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            HorizontalDivider(color = Line, modifier = Modifier.padding(vertical = 9.dp))

            OutlinedButton(
                onClick = {},
                modifier = Modifier.fillMaxWidth().height(44.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Blue),
                border = androidx.compose.foundation.BorderStroke(1.dp, Line),
                contentPadding = PaddingValues(horizontal = 10.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    company.ifBlank { "Empresa" },
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
            }

            Spacer(Modifier.height(8.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 4.dp)
            ) {
                items(navItems.size) { i ->
                    val item = navItems[i]
                    val isSelected = selected == item.title
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clickable { onSelect(item.title) },
                        shape = RoundedCornerShape(14.dp),
                        color = if (isSelected) Blue else Color(0x120B1935),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) Blue else Line)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                item.emoji,
                                fontSize = 20.sp,
                                maxLines = 1,
                                modifier = Modifier.width(31.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                item.title,
                                color = if (isSelected) Bg else TextMain,
                                fontSize = 15.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
        }

        // Limite vertical da barra lateral, conforme a referência visual.
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .width(1.dp)
                .background(Line)
        )
    }
}

@Composable
private fun Section(
    title: String,
    company: String,
    companyId: String,
    db: Database,
    refreshKey: Int,
    onChanged: () -> Unit,
    onGoHome: () -> Unit
) {
    when (title) {
        "Clientes" -> ClientesScreen(company = company, companyId = companyId, db = db, refreshKey = refreshKey, onChanged = onChanged)
        "Subscrições" -> SubscriptionsScreen(onGoHome = onGoHome)
        "Catálogos" -> CatalogsScreen(onGoHome = onGoHome)
        "Arquivado" -> ArchivedScreen(company, onGoHome)
        "Histórico", "Estatísticas", "Configurações", "Gestão" ->
            SectionPlaceholder(title = title, company = company, onGoHome = onGoHome)
        else -> onGoHome()
    }
}

@Composable
private fun SectionPlaceholder(title: String, company: String, onGoHome: () -> Unit) {
    val icon = when (title) {
        "Histórico" -> "🕘"
        "Estatísticas" -> "📊"
        "Configurações" -> "⚙️"
        else -> "🔧"
    }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Panel,
        border = androidx.compose.foundation.BorderStroke(1.dp, Line)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 22.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(icon, fontSize = 23.sp, modifier = Modifier.padding(end = 8.dp))
                Text(
                    title,
                    color = TextMain,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = onGoHome,
                    modifier = Modifier.width(64.dp).height(40.dp),
                    contentPadding = PaddingValues(0.dp),
                    shape = RoundedCornerShape(13.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Bg)
                ) {
                    Text("Fechar", fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Empresa ativa: $company", color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
private fun ArchivedScreen(company: String, onGoHome: () -> Unit) {
    var archivedOpen by remember { mutableStateOf(true) }
    var archivedSearch by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 0.dp, vertical = 0.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = Panel,
            border = androidx.compose.foundation.BorderStroke(1.dp, Line)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 22.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("📁", fontSize = 23.sp, modifier = Modifier.padding(end = 8.dp))
                    Text(
                        "Arquivados",
                        color = TextMain,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { if (archivedOpen) archivedOpen = false else onGoHome() },
                        modifier = Modifier.width(64.dp).height(40.dp),
                        contentPadding = PaddingValues(0.dp),
                        shape = RoundedCornerShape(13.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Bg)
                    ) {
                        Text(
                            if (archivedOpen) "Fechar" else "Abrir",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }

                if (archivedOpen) {
                    Spacer(Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp)
                            .border(1.dp, Line, RoundedCornerShape(15.dp))
                            .background(Color(0xFF020817), RoundedCornerShape(15.dp))
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        BasicTextField(
                            value = archivedSearch,
                            onValueChange = { archivedSearch = it },
                            singleLine = true,
                            textStyle = LocalTextStyle.current.copy(color = TextMain, fontSize = 15.sp),
                            cursorBrush = androidx.compose.ui.graphics.SolidColor(Blue),
                            modifier = Modifier.fillMaxWidth(),
                            decorationBox = { innerTextField ->
                                if (archivedSearch.isBlank()) {
                                    Text(
                                        "Pesquisar nome, contacto, empresa, equipamento...",
                                        color = Muted,
                                        fontSize = 15.sp,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                                innerTextField()
                            }
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(
                        if (archivedSearch.isBlank()) "Ainda não existem clientes arquivados." else "Nenhum resultado para a pesquisa.",
                        color = Muted,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun CatalogsScreen(onGoHome: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Panel,
        border = androidx.compose.foundation.BorderStroke(1.dp, Line)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 22.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("📦", fontSize = 23.sp, modifier = Modifier.padding(end = 8.dp))
                Text(
                    "Catálogos",
                    color = TextMain,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = onGoHome,
                    modifier = Modifier.width(64.dp).height(40.dp),
                    contentPadding = PaddingValues(0.dp),
                    shape = RoundedCornerShape(13.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Bg)
                ) {
                    Text(
                        "Fechar",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                color = Color(0x22071127),
                border = androidx.compose.foundation.BorderStroke(1.dp, Line)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CatalogItem(
                        icon = "📺",
                        title = "Equipamentos",
                        description = "Para instalação em clientes"
                    )
                    CatalogItem(
                        icon = "📦",
                        title = "Produtos / Consumíveis",
                        description = "Material e consumíveis com stock"
                    )
                    CatalogItem(
                        icon = "🛠️",
                        title = "Serviços",
                        description = "Mão de obra e outros serviços"
                    )
                    CatalogItem(
                        icon = "🏷️",
                        title = "Marcas",
                        description = "De equipamentos e produtos"
                    )
                }
            }
        }
    }
}

@Composable
private fun CatalogItem(icon: String, title: String, description: String) {
    var open by remember { mutableStateOf(false) }
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .clickable { open = true },
        shape = RoundedCornerShape(20.dp),
        color = Color(0x22071127),
        border = androidx.compose.foundation.BorderStroke(1.dp, Line)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(icon, fontSize = 18.sp, modifier = Modifier.padding(end = 6.dp))
                Text(
                    title,
                    color = TextMain,
                    fontSize = 14.sp,
                    lineHeight = 18.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    softWrap = false
                )
            }
            Spacer(Modifier.height(0.dp))
            Text(
                description,
                color = Muted,
                fontSize = 13.sp,
                lineHeight = 16.sp,
                maxLines = 1,
                softWrap = false
            )
        }
    }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text(title, fontWeight = FontWeight.Bold) },
            text = { Text(description) },
            confirmButton = { Button(onClick = { open = false }) { Text("OK") } }
        )
    }
}

@Composable
private fun SubscriptionsScreen(onGoHome: () -> Unit) {
    var open by remember { mutableStateOf(true) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 0.dp, vertical = 0.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = Panel,
            border = androidx.compose.foundation.BorderStroke(1.dp, Line)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 22.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🔐", fontSize = 23.sp, modifier = Modifier.padding(end = 8.dp))
                    Text(
                        "Subscrições",
                        color = TextMain,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { if (open) open = false else onGoHome() },
                        modifier = Modifier.width(64.dp).height(40.dp),
                        contentPadding = PaddingValues(0.dp),
                        shape = RoundedCornerShape(13.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Bg)
                    ) {
                        Text(
                            if (open) "Fechar" else "Abrir",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }

                if (open) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Ainda não existem subscrições.",
                        color = Muted,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun ClientesScreen(
    company: String,
    companyId: String,
    db: Database,
    refreshKey: Int,
    onChanged: () -> Unit
) {
    var clientsOpen by remember { mutableStateOf(true) }
    var clientSearch by remember { mutableStateOf("") }
    var clients by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var showAdd by remember { mutableStateOf(false) }
    var newClientName by remember { mutableStateOf("") }

    LaunchedEffect(companyId, refreshKey) {
        clients = db.getClients(companyId)
    }

    val filtered = clients.filter { it.second.contains(clientSearch, ignoreCase = true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 0.dp, vertical = 0.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = Panel,
            border = androidx.compose.foundation.BorderStroke(1.dp, Line)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 22.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("📋", fontSize = 23.sp, modifier = Modifier.padding(end = 8.dp))
                    Text(
                        "Clientes",
                        color = TextMain,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { clientsOpen = !clientsOpen },
                        modifier = Modifier.width(64.dp).height(40.dp),
                        contentPadding = PaddingValues(0.dp),
                        shape = RoundedCornerShape(13.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Bg)
                    ) {
                        Text(
                            if (clientsOpen) "Fechar" else "Abrir",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = { showAdd = true },
                        modifier = Modifier.width(64.dp).height(40.dp),
                        contentPadding = PaddingValues(0.dp),
                        shape = RoundedCornerShape(13.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Bg)
                    ) {
                        Text("Adicionar", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }

                if (clientsOpen) {
                    Spacer(Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp)
                            .border(1.dp, Line, RoundedCornerShape(15.dp))
                            .background(Color(0xFF020817), RoundedCornerShape(15.dp))
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        BasicTextField(
                            value = clientSearch,
                            onValueChange = { clientSearch = it },
                            singleLine = true,
                            textStyle = LocalTextStyle.current.copy(color = TextMain, fontSize = 15.sp),
                            cursorBrush = androidx.compose.ui.graphics.SolidColor(Blue),
                            modifier = Modifier.fillMaxWidth(),
                            decorationBox = { innerTextField ->
                                if (clientSearch.isBlank()) {
                                    Text(
                                        "Pesquisar nome, contacto, empresa, equipamento...",
                                        color = Muted,
                                        fontSize = 15.sp,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                                innerTextField()
                            }
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    if (filtered.isEmpty()) {
                        Text(
                            if (clientSearch.isBlank()) "Ainda não existem clientes." else "Nenhum resultado para a pesquisa.",
                            color = Muted,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(filtered.size) { index ->
                                val client = filtered[index]
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color(0x22071127),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Line)
                                ) {
                                    Row(
                                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("👤", fontSize = 18.sp)
                                        Spacer(Modifier.width(8.dp))
                                        Text(client.second, color = TextMain, fontSize = 14.sp, modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Adicionar cliente", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newClientName,
                    onValueChange = { newClientName = it },
                    singleLine = true,
                    label = { Text("Nome") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (db.addClient(companyId, newClientName)) {
                            newClientName = ""
                            showAdd = false
                            onChanged()
                        }
                    },
                    enabled = newClientName.isNotBlank()
                ) { Text("Guardar") }
            },
            dismissButton = {
                TextButton(onClick = { showAdd = false }) { Text("Cancelar") }
            }
        )
    }
}
