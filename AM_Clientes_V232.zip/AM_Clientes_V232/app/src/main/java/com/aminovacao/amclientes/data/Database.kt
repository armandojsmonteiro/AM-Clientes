package com.aminovacao.amclientes.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.UUID

class Database(context: Context) : SQLiteOpenHelper(context, "am_clientes.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE companies (id TEXT PRIMARY KEY, name TEXT NOT NULL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE clients (id TEXT PRIMARY KEY, company_id TEXT NOT NULL, name TEXT NOT NULL, data_json TEXT NOT NULL, FOREIGN KEY(company_id) REFERENCES companies(id))")
        db.execSQL("CREATE TABLE products (id TEXT PRIMARY KEY, company_id TEXT NOT NULL, name TEXT NOT NULL, data_json TEXT NOT NULL, FOREIGN KEY(company_id) REFERENCES companies(id))")
        db.execSQL("CREATE TABLE subscriptions (id TEXT PRIMARY KEY, company_id TEXT NOT NULL, client_id TEXT, data_json TEXT NOT NULL, FOREIGN KEY(company_id) REFERENCES companies(id))")
        db.execSQL("CREATE TABLE quotes (id TEXT PRIMARY KEY, company_id TEXT NOT NULL, data_json TEXT NOT NULL, FOREIGN KEY(company_id) REFERENCES companies(id))")
        db.execSQL("CREATE TABLE settings (id TEXT PRIMARY KEY, company_id TEXT NOT NULL, data_json TEXT NOT NULL, FOREIGN KEY(company_id) REFERENCES companies(id))")
        db.execSQL("CREATE TABLE activity (id TEXT PRIMARY KEY, company_id TEXT NOT NULL, data_json TEXT NOT NULL, created_at INTEGER NOT NULL, FOREIGN KEY(company_id) REFERENCES companies(id))")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { }

    fun ensureDefaultCompany(): Pair<String, String> {
        val db = writableDatabase
        db.rawQuery("SELECT id,name FROM companies ORDER BY created_at LIMIT 1", null).use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0) to cursor.getString(1)
        }
        val id = UUID.randomUUID().toString()
        db.execSQL(
            "INSERT INTO companies(id,name,created_at) VALUES(?,?,?)",
            arrayOf(id, "Empresa 1", System.currentTimeMillis())
        )
        return id to "Empresa 1"
    }

    fun getClients(companyId: String): List<Pair<String, String>> {
        if (companyId.isBlank()) return emptyList()
        val result = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery(
            "SELECT id,name FROM clients WHERE company_id=? ORDER BY name COLLATE NOCASE",
            arrayOf(companyId)
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result += cursor.getString(0) to cursor.getString(1)
            }
        }
        return result
    }

    fun addClient(companyId: String, name: String): Boolean {
        if (companyId.isBlank() || name.isBlank()) return false
        val values = ContentValues().apply {
            put("id", UUID.randomUUID().toString())
            put("company_id", companyId)
            put("name", name.trim())
            put("data_json", "{\"name\":${org.json.JSONObject.quote(name.trim())}}")
        }
        return writableDatabase.insert("clients", null, values) != -1L
    }
}
