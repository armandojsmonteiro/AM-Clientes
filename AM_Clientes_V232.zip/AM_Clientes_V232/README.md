# AM Clientes — V232

## Objetivo

V232 é a primeira reconstrução visual da base Android limpa, usando a V59 como referência de interface e mantendo a aplicação 100% Android nativo.

## Base

- Base visual: AM Clientes V59.
- Sem HTML, JavaScript ou WebView.
- Jetpack Compose + Material 3.
- Versionamento oficial: V232.

## Alterações desta versão

- Recuperada a estrutura visual da V59 para o menu lateral e ecrã inicial.
- Mantidos os 9 itens do menu: Início, Clientes, Subscrições, Catálogos, Arquivado, Histórico, Estatísticas, Configurações e Gestão.
- Recuperados tamanhos, espaçamentos, caixas arredondadas, cores e disposição dos principais elementos da V59.
- Mantida a pesquisa superior e os indicadores Ativos / A expirar / Expirados no contexto Início/Clientes.
- Navegação do menu lateral funcional.
- Botões Fechar/Abrir dos módulos principais passam a responder.
- Ecrã Clientes: pesquisa funcional e Adicionar cliente funcional, com gravação local SQLite.
- Ecrã Catálogos: os quatro cartões respondem com uma confirmação simples, mantendo o desenho visual.

## Limites desta versão

A V59 foi usada como referência visual. As funcionalidades completas dos módulos que ainda não estavam implementadas na V59 não foram inventadas nesta versão. O objetivo desta V232 é validar primeiro a recuperação visual e a navegação da aplicação dentro da nova base Android nativa.

## Build

O projeto inclui um workflow GitHub Actions para gerar o APK de teste.

Comando local:

`gradle :app:assembleDebug --no-daemon`

APK produzido:

`app/build/outputs/apk/debug/app-debug.apk`

Nome oficial de distribuição desta versão:

`AM_Clientes_V232.apk`
