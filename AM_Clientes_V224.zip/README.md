AM Clientes V224

Version sequencial 224. Mantém o applicationId original e a assinatura estável para permitir atualização da instalação existente.
