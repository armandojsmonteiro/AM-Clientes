AM Clientes V231 — RECONSTRUÇÃO

Base de referência: AM Clientes V230.
Esta versão é uma reconstrução independente para comparação lado a lado.

Package/Application ID:
com.aminovacao.amclientes231

Version:
versionCode 231
versionName 1.0.231

Regras:
- Android-only (WebView local empacotado no APK; não é uma aplicação web externa).
- Não lê nem migra dados da V230.
- Não contém o código legado da V230.
- Uma única fonte de verdade para associações: clients[].equipamentos[].subscricoes[].
- Packs guardam components[] diretamente.
- A utilização é sempre calculada das associações atuais.
- Não existe licenseUsed histórico a contaminar a contagem.
- Scroll da página é único; não existe scroll interno na lista de equipamentos.
- Apenas o ☷ inicia reordenação dos cartões.

Cenário de validação:
WireGuard 6 + OpenVPN 6 + Pack Segurança 6 (Pack = WireGuard + OpenVPN)
Resultado esperado: WireGuard 12 / OpenVPN 12 / Pack Segurança 6.
