plugins { id("com.android.application") }

android {
    namespace = "com.aminovacao.amclientes231"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aminovacao.amclientes231"
        minSdk = 26
        targetSdk = 35
        versionCode = 231
        versionName = "1.0.231"
    }
    buildTypes {
        getByName("debug") { isMinifyEnabled = false }
        getByName("release") { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
