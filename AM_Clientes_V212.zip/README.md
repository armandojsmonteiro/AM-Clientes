# AM Clientes V212

V212: Packs com seleção dinâmica de subscrições/packs existentes.
- Tipo de subscrição imediatamente após a regra de compra.
- Ao escolher Pack, surge um seletor de subscrições/packs existentes.
- Cada seleção fica registada num cartão removível e surge novamente um seletor para adicionar outra.
- Permite vários componentes e vários packs dentro de um pack, evitando auto-inclusão do próprio pack.
- Mantém compatibilidade com a estrutura de componentes das versões anteriores.
