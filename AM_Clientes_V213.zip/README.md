AM Clientes V213

Correções: seleção de componentes de Pack pelo catálogo real de subscrições; interface sem texto explicativo; consumo de stock das subscrições recalculado a partir das associações reais dos clientes/equipamentos e respeitando validade/promoção.
