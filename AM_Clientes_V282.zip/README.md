# AM Clientes V282

Aplicação Android nativa.
- Package / Application ID: `com.aminovacao.amclientes231`
- Versão: V282

Correções do editor de clientes:
- Campos vazios mostram exemplos úteis em vez de traços.
- Cabeçalho de criação não mostra o nome da empresa nem um botão Cancelar.
- Formulário de cliente novo termina com Guardar e Cancelar; Arquivar/Apagar só aparecem ao editar clientes existentes.
- A empresa fica por selecionar até o utilizador escolher uma.
- Tipo/nome do equipamento, serviço, subscrição e método de pagamento apresentam opções de seleção com texto orientador, sem pré-seleção automática.
- Campos e separações têm mais altura/espaço para evitar elementos amontoados.
- Os preços de serviço/subscrição são calculados a partir da opção escolhida e ficam ocultos, conforme o desenho de referência.
- Cada equipamento apresenta o seu total e a secção apresenta também o total acumulado de todos os equipamentos.
- A numeração dos equipamentos e das linhas Serviço/Subscrição é atualizada quando são adicionados/removidos elementos.

Identificador Android mantido: `com.aminovacao.amclientes231`.


V282: compact white editor fields and consistent button heights; service/subscription price fields become visible and update totals when a selection is made.
