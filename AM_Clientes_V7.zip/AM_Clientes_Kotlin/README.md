# AM Clientes — V7

Base de referência: V6, a primeira versão funcional do projeto Kotlin/Android.

## V7
- Ícone oficial AM Clientes incorporado ao APK.
- Nome da aplicação: AM Clientes.
- VersionCode: 7.
- VersionName: 1.0.7.
- Mesma applicationId e mesma assinatura debug estável da V6, permitindo atualização sem desinstalar a versão anterior.
- Java e Kotlin alinhados em JVM 17, incluindo toolchain Gradle, para evitar o erro de incompatibilidade JVM 1.8/17.
- Ajustes visuais de espaçamento e dimensões do menu lateral com base nos ecrãs de referência.

## Regra de versões
O projeto deve avançar sequencialmente. V1 e V2 não foram funcionais; V3 é a primeira versão funcional. V6 é a base desta alteração e a próxima versão é obrigatoriamente V7. Nunca repetir ou reutilizar um número de versão.
