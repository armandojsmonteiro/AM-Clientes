# AM Clientes V284

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 284
- `versionName`: `1.0.284`

Correções desta versão:
- Cancelar a edição regressa ao ecrã de origem e reconstrói o conteúdo, sem duplicar menus.
- Tocar novamente no cliente selecionado fecha a pré-visualização/edição desse cliente.
- Tocar no título Clientes alterna a lista entre aberta e fechada, tal como o botão lateral.
- Mantidas as dimensões de campos e botões da versão anterior.
