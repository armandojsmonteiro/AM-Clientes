# AM Clientes V287

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 287
- `versionName`: `1.0.287`

Correções desta versão, limitadas ao menu Clientes:
- Repostos os indicadores Ativos, A expirar e Expirados antes do painel Clientes.
- Separados os botões Fechar e Adicionar, mantendo dimensões compactas e um intervalo consistente.
- Reposto o espaçamento vertical entre cabeçalho, pesquisa e lista de clientes.
- O menu Iniciar e os restantes ecrãs mantêm o código anterior.
