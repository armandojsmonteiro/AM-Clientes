AM Clientes V226 — correção definitiva do consumo de Packs e do scroll por toque na lista de clientes/equipamentos.

VersionCode: 226
VersionName: 1.0.226
