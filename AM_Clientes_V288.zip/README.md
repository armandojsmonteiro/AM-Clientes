# AM Clientes V288

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 288
- `versionName`: `1.0.288`

Correções desta versão, limitadas ao menu Clientes:
- Botões Fechar e Adicionar mantêm dimensão compacta e o texto numa única linha.
- Barra de pesquisa passa a uma única linha, com altura fixa de 48 dp e truncagem do texto excedente.
- Não foram alterados o menu Iniciar, os dados, nem o formulário de edição.
