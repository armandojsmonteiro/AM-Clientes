# AM Clientes V306

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 306
- `versionName`: `1.0.306`

## Alterações desta versão

- Mantidos os menus de seleção personalizados da V303: fundo branco, cantos arredondados, opção atual destacada a azul-claro e visto, com as opções próprias de cada campo.
- Reforçada a captura do toque no cabeçalho do calendário após o layout do Android, para iniciar a sequência de escolha de dia, mês e ano. Mantidos os botões Definir (data de hoje), Cancelar e OK.
- O aviso Serviço guardado volta à tipografia original e usa um botão OK largo, sem reduzir o tamanho do texto ou do aviso.

## Validação

A compilação Android/Gradle deve ser confirmada no workflow do GitHub Actions.
