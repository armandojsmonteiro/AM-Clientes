AM Clientes V233

Base funcional reconstruída diretamente a partir da V230.

Objetivo: converter a aplicação de WebView/HTML para Android nativo, preservando a navegação, organização e comportamento funcional da V230. A V59 é apenas referência visual para a organização do menu; não é base funcional.

Application ID da nova aplicação de teste: com.aminovacao.amclientes231

A aplicação antiga com applicationId com.aminovacao.amclientes não é atualizada por este projeto e pode permanecer instalada ao lado desta.

Principais módulos nativos: Início, Clientes, Serviços e subscrições, Catálogos, Arquivado, Histórico, Estatísticas, Configurações e Gestão.

A contabilização de subscrições considera atribuições diretas, VPNs, packs e a regra 6 por 5. Os dados são persistidos localmente por empresa.

Build: Gradle 8.9 / Java 17 / Android SDK 35.
