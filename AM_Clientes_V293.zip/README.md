# AM Clientes V293

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 293
- `versionName`: `1.0.293`

Correção localizada no cancelamento do editor: ao cancelar a edição de um cliente existente, a animação regressa até ao topo da pré-visualização do cliente, usando o mesmo alvo e a mesma lógica de scroll usados ao abrir a pré-visualização. Não restaura a posição antiga da lista, que podia deixar a pré-visualização a meio ou junto ao fundo. Ao cancelar a criação de um cliente novo, conserva-se o retorno à posição anterior. O restante comportamento foi mantido.
