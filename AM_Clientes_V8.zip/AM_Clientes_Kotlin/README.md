# AM Clientes — V8

Base de referência: V7.

## V8
- Ecrã principal compactado para aproximar a escala das imagens de referência.
- Barra de pesquisa com altura reduzida.
- Cartões de estado mais compactos.
- Blocos Clientes e Atalhos redimensionados.
- Títulos, textos e espaçamentos reduzidos para evitar elementos gigantes e quebras de linha desnecessárias.
- Botão Fechar redimensionado.
- Mantida a identidade visual AM Clientes e o ícone já incorporado.
- Mantida a mesma applicationId e a mesma assinatura debug estável, com VersionCode 8 e VersionName 1.0.8, para permitir atualização sobre a versão anterior sem desinstalar.

## Regra de versões
A numeração é sempre sequencial e nunca é repetida ou recuada. V1 e V2 não foram funcionais; V3 foi a primeira versão funcional. A evolução atual segue V6 → V7 → V8.
