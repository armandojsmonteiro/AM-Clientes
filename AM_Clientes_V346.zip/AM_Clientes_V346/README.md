AM Clientes V346 — Android nativo

V346 recupera a estrutura do menu Configurações com secções recolhíveis e reorganizáveis, contornos azulados, campos de 50 dp, logótipo e ações separadas, gestão da empresa ativa, opções editáveis, mensagens e atalhos.

Projeto exclusivamente Android nativo. O workflow GitHub Actions compila o APK e publica o artefacto AM_Clientes_V346.apk.

A compilação final deve ser validada no GitHub Actions antes de instalar o APK no dispositivo.
