AM Clientes V197 — correção do editor de clientes: restaurada a renderização dos equipamentos e mantida a seleção direta de subscrições com custo automático.
