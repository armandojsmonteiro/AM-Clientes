# AM Clientes V308

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 308
- `versionName`: `1.0.308`

## Alterações desta versão

- Periodicidade: o menu personalizado acompanha a opção atualmente selecionada e mostra o realce azul-claro e o visto azul, incluindo após escolher a periodicidade pela primeira vez. O campo vazio não apresenta uma seleção falsa no placeholder.
- Cabeçalho Serviços e subscrições: ícone e texto separados visualmente; quando o título ocupa duas linhas, ambas ficam alinhadas na coluna do texto, sem a segunda linha começar por baixo do cadeado.
- Mantidas as correções da V307 para o calendário e as restantes funcionalidades.

## Validação

A compilação Android/Gradle deve ser confirmada no workflow do GitHub Actions.
