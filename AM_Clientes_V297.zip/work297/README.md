# AM Clientes V296

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 296
- `versionName`: `1.0.296`

## Alteração desta versão

Correção localizada no menu **Serviços e subscrições**: os campos brancos regressam à altura compacta de 28 dp, os seletores abrem sobre fundo branco, o formulário de serviço usa apenas os placeholders originais e os botões dos cartões têm larguras proporcionais. Os cartões de subscrição usam o indicador de ordenação `☷` em vez de cadeados; tocar no nome abre/fecha a lista de equipamentos associados sem sair do menu, e os movimentos podem ser expandidos separadamente. As ações Editar regressam suavemente ao formulário embutido no ecrã, sem janelas de edição escuras. Os restantes menus não foram alvo de alterações visuais intencionais.
