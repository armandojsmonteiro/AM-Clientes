# AM Clientes V303

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 303
- `versionName`: `1.0.303`

## Alterações desta versão

- Menus de seleção implementados com uma lista própria: fundo branco, cantos arredondados e destaque azul-claro com visto na opção selecionada. Cada campo mantém a sua lista de opções original.
- O cabeçalho da data responde ao toque e inicia a sequência de escolha de dia, mês e ano. Inclui uma procura alternativa do cabeçalho para diferentes versões Android.
- Mantidos o calendário branco, o destaque azul, os cantos arredondados e os botões Definir, Cancelar e OK. Definir aplica a data de hoje.
- Diálogo de confirmação de serviço guardado mais estreito e com menos espaço branco lateral, mantendo a mensagem em duas linhas.

## Validação

O arquivo ZIP foi verificado. A compilação Android/Gradle ainda precisa de validação no workflow do GitHub Actions.
