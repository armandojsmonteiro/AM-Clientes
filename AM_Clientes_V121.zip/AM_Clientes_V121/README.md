# AM Clientes V121

Base: V112.

Correções desta versão:
- Mantém exatamente as dimensões dos campos e botões da V112.
- Os textos dos campos especiais passam a usar a mesma fonte/tamanho herdado dos restantes campos, sem valores de tamanho inventados.
- Selecionar data e Selecionar validade ficam verticalmente alinhados pelo mesmo padrão dos restantes campos.
- Os placeholders dos selects do equipamento deixam de usar os tracinhos decorativos.
- Mantém a opção Selecionar validade para permitir voltar ao estado vazio.
- Mantém a lógica existente de periodicidade/validade e o campo de data apenas quando aplicável.
- Não altera a altura dos campos.


V121: única alteração visual no campo Validade: Selecionar validade passa para 18px e alinhado à esquerda. Sem outras alterações.
