AM Clientes V247 — projeto Android nativo.
Base: V246. Alterações exclusivamente visuais no menu lateral e submenu de empresas.
