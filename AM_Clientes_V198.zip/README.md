AM Clientes V198 — correção do valor automático das subscrições, eliminação da periodicidade duplicada e melhoria da coerência visual das subscrições no cliente.
