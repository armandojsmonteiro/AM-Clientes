# AM Clientes V75

Base: V73 funcional.

V75 acrescenta Configurações → Serviços com criação de serviços, campos personalizados e associação a subscrições. Os campos definidos para cada serviço são apresentados no formulário do cliente quando o serviço é selecionado.

Android version: 1.0.75 / versionCode 75
