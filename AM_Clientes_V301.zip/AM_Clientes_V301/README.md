# AM Clientes V301

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 301
- `versionName`: `1.0.301`

## Alterações desta versão

- Diálogos de Adicionar movimento e Associar equipamento com painel azul-escuro arredondado, campos brancos e botões Cancelar/Guardar alinhados com o estilo da aplicação.
- Aviso Serviço guardado mais compacto, com o texto dividido em duas linhas e botão OK centrado.
- O formulário inline de edição de serviços inclui agora Cancelar ao lado de Guardar; cancelar descarta as alterações e recolhe o editor.
- Mantidos o sistema de reordenação e o tratamento anterior dos formulários.

## Validação

O ZIP contém o código-fonte Android atualizado. A compilação APK ainda não foi executada neste ambiente.
