plugins { id("com.android.application") }

android {
    namespace = "com.aminovacao.amclientes"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aminovacao.amclientes"
        minSdk = 26
        targetSdk = 35
        versionCode = 61
        versionName = "1.0.61"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildTypes {
        getByName("debug") { isMinifyEnabled = false }
    }
}
