V341 — AM Clientes (Android nativo)

- Gestão da base de dados: o botão Fechar recolhe apenas os cinco comandos e mantém o utilizador no mesmo menu; Abrir volta a apresentar os comandos. Os puxadores, ícones e textos foram reduzidos para se aproximarem da referência visual enviada.
- Estatísticas: o botão Fechar recolhe os cartões e as secções, sem regressar ao Início; Abrir repõe o conteúdo. O título usa o tamanho padrão e os puxadores das secções são mais discretos.
- Mantidos os contornos azuis e as ações existentes dos cinco comandos de gestão.

Projeto exclusivamente Android. Nome do pacote de entrega: AM_Clientes_V341.zip.
