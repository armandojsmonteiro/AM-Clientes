# AM Clientes V316

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 314
- `versionName`: `1.0.315`

## Alterações desta versão

- Contornos dos cartões unificados com o azul médio aprovado no menu Serviços e subscrições, incluindo o cabeçalho de navegação e as barras de pesquisa.
- Removido o ícone repetido dos cartões individuais de serviço; o ícone permanece no cabeçalho da secção.
- Tipo de subscrição corrigido para duas opções de lógica: `Subscrição simples` ou `Pack`. O nome do pack continua a ser definido no campo Nome.
- Ao escolher `Pack`, aparece o seletor múltiplo `Subscrições incluídas no pack`, com as subscrições simples já registadas, realce azul-claro e visto por cada opção selecionada.
- As subscrições incluídas são guardadas como componentes estruturados, preservando o custo e a regra de compra da subscrição associada, incluindo o campo usado pelo cálculo de licenças consumidas.
- O cartão exterior de Subscrições passa a conter o formulário e todos os cartões individuais, à semelhança da secção Serviços.
- Contornos da barra lateral ajustados para a mesma cor e espessura visual dos cartões principais.
- Texto dos botões Fechar/Abrir no ecrã Início ajustado ao tamanho padrão dos menus Clientes e Serviços e subscrições.
- Contornos azuis mais visíveis no módulo Serviços e subscrições, sem alterar o tema global da aplicação.
- Preservadas as correções anteriores do calendário, menus, aviso e edição de serviços.

## Validação

A compilação Android/Gradle deve ser confirmada no workflow do GitHub Actions.
