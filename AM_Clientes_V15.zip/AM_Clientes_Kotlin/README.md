# AM Clientes — V15

V15 é a continuação direta da V14 e mantém a base funcional existente.

## Alteração desta versão
- Menu lateral com tipografia mais compacta.
- Título AM Clientes numa única linha.
- Ícones coloridos para recuperar a variedade visual da referência.
- Estado Início selecionado em azul principal da aplicação.
- Botão X compacto.
- Mantido o alinhamento e espaçamento geral do menu.

Não foram alteradas as funcionalidades das restantes áreas da aplicação.
