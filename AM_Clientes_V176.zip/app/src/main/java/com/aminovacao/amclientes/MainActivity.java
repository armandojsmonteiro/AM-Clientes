package com.aminovacao.amclientes;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Base64;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 1001;
    private static final int FILE_SAVER = 1002;
    private String pendingSaveFilename;
    private String pendingSaveMimeType;
    private byte[] pendingSaveBytes;


    private class DownloadBridge {
        @JavascriptInterface
        public void saveFile(String filename, String mimeType, String base64) {
            try {
                pendingSaveFilename = (filename == null || filename.trim().isEmpty()) ? "AM_Clientes_backup" : filename;
                pendingSaveMimeType = (mimeType == null || mimeType.trim().isEmpty()) ? "application/octet-stream" : mimeType;
                pendingSaveBytes = Base64.decode(base64 == null ? "" : base64, Base64.DEFAULT);
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(pendingSaveMimeType);
                i.putExtra(Intent.EXTRA_TITLE, pendingSaveFilename);
                runOnUiThread(() -> {
                    try { startActivityForResult(i, FILE_SAVER); }
                    catch (Exception e) {
                        pendingSaveFilename = null;
                        pendingSaveMimeType = null;
                        pendingSaveBytes = null;
                    }
                });
            } catch (Exception ignored) {
                pendingSaveFilename = null;
                pendingSaveMimeType = null;
                pendingSaveBytes = null;
            }
        }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // A janela continua a ocupar todo o ecrã. O fundo fica por trás
        // das barras do Android, mas o WebView é colocado apenas dentro
        // da área segura entre a barra de estado e a barra de navegação.
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        window.getDecorView().setSystemUiVisibility(0);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(4, 17, 38));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.TRANSPARENT);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top;
            int bottom;
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }

            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) webView.getLayoutParams();
            lp.topMargin = top;
            lp.bottomMargin = bottom;
            lp.leftMargin = 0;
            lp.rightMargin = 0;
            webView.setLayoutParams(lp);
            return insets;
        });

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        webView.addJavascriptInterface(new DownloadBridge(), "AndroidDownloader");

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true; } catch (Exception ignored) {}
                }
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                try { startActivityForResult(i, FILE_CHOOSER); return true; }
                catch (Exception e) { fileCallback = null; return false; }
            }
        });

        setContentView(root);
        root.requestApplyInsets();
        webView.loadUrl("file:///android_asset/am_clientes.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_SAVER) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSaveBytes != null) {
                try {
                    Uri uri = data.getData();
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out != null) out.write(pendingSaveBytes);
                    }
                    if (webView != null) webView.evaluateJavascript("window.__amSaveCompleted && window.__amSaveCompleted(true);", null);
                } catch (Exception e) {
                    if (webView != null) webView.evaluateJavascript("window.__amSaveCompleted && window.__amSaveCompleted(false);", null);
                }
            } else if (webView != null) {
                webView.evaluateJavascript("window.__amSaveCompleted && window.__amSaveCompleted(false);", null);
            }
            pendingSaveFilename = null;
            pendingSaveMimeType = null;
            pendingSaveBytes = null;
        }
        if (requestCode == FILE_CHOOSER) {
            if (fileCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
                fileCallback.onReceiveValue(result);
                fileCallback = null;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
