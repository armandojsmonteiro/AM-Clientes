AM Clientes V176

V176:
- Serviços adicionais do cliente passam a aparecer imediatamente abaixo do serviço principal, na mesma sequência.
- Quando existe pelo menos um serviço adicional, o serviço principal passa a chamar-se Serviço 1 e os seguintes Serviço 2, Serviço 3, etc.
- Ao selecionar um serviço adicional, o nome fica imediatamente com a cor normal e o valor é carregado do catálogo.
- No catálogo de Serviços, nomes longos podem ocupar duas linhas sem deslocar os botões Editar/Apagar.
- Os cartões Serviços e Subscrições ficam com a mesma altura quando fechados.

AM Clientes V167

Correção: os botões passam a apresentar Adicionar serviço e Adicionar subscrição, nesta ordem, sem o símbolo +. A tipografia dos dois botões fica com 13px, igual à do botão Guardar, mantendo a dimensão/altura dos botões.


Alteração: no editor de equipamento foram removidas as secções VPN deste equipamento e Serviços extra, ficando apenas os botões Adicionar serviço e Adicionar subscrição lado a lado.

# AM Clientes V136

Base: V112.

Correções desta versão:
- Mantém exatamente as dimensões dos campos e botões da V112.
- Os textos dos campos especiais passam a usar a mesma fonte/tamanho herdado dos restantes campos, sem valores de tamanho inventados.
- Selecionar data e Selecionar validade ficam verticalmente alinhados pelo mesmo padrão dos restantes campos.
- Os placeholders dos selects do equipamento deixam de usar os tracinhos decorativos.
- Mantém a opção Selecionar validade para permitir voltar ao estado vazio.
- Mantém a lógica existente de periodicidade/validade e o campo de data apenas quando aplicável.
- Não altera a altura dos campos.


V126: única alteração visual no campo Validade: Selecionar validade passa para 16px, peso 400, line-height 1.2 e alinhamento à esquerda. Sem outras alterações.

V136: ajuste apenas do texto Selecionar data no campo Data de criação do cliente.

V142: ajuste exclusivamente visual/tipográfico dos placeholders Selecionar data de Data de compra e Data de início; 14px, peso 400, com text-size-adjust 100% para impedir ampliação automática no WebView.
V143: deslocamento dos dois placeholders de data para a direita.
V144: pequeno recuo para a esquerda dos dois placeholders de data, mantendo o tamanho e peso definidos na V142.


V146: o botão/título Serviços e subscrições passa a abrir e fechar simultaneamente os blocos Serviços e Subscrições.

V152: a lista de subscrições foi colocada dentro do balão interno Subscrições, para abrir/fechar em conjunto com o respetivo formulário.

V153: ao clicar em Subscrições, recolhe apenas o formulário de nova subscrição; as subscrições existentes permanecem visíveis.

V154: ao abrir o módulo principal Serviços e subscrições, os blocos Serviços e Subscrições iniciam fechados. A lista de subscrições existentes permanece imediatamente visível; para adicionar uma nova subscrição, o utilizador abre o cabeçalho Subscrições.
