# AM Clientes — migração Kotlin/Android

Base de referência: `AM_Clientes_744.html`.

## Objetivo desta versão

Esta é a V4 e parte exclusivamente da V3, definida como a primeira versão funcional.
- Estrutura Android/Kotlin nativa.
- Navegação dos módulos principais.
- Contexto de empresa ativo.
- Base SQLite local preparada para isolamento por `company_id`.
- Cada empresa possui o seu universo de Clientes, Produtos, Subscrições, Orçamentos, Configurações e Histórico.

## Próxima fase
Reproduzir integralmente o visual e depois migrar a lógica funcional do HTML 744 módulo a módulo, sem misturar dados entre empresas.

## Regra de versões
O projeto deve avançar sequencialmente. Cada ZIP/commit é uma versão única; versões descartadas não voltam a ser base.
