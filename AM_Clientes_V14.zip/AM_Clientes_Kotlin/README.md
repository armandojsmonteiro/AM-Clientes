# AM Clientes — V10

Base de referência: V9.

## V10
- Ajuste do botão Fechar no ecrã principal para uma dimensão compacta e consistente com os restantes menus.
- Mantido o alinhamento geral e a escala visual da V9.
- Cabeçalho reposicionado para não ficar colado à zona superior/status bar.
- Barra de pesquisa reduzida para a escala visual pretendida e sem corte vertical do texto.
- Espaçamento entre cabeçalho, pesquisa e cartões de estado recalibrado.
- Mantidos o ícone AM, o nome AM Clientes e os restantes elementos da V8.
- Mantida a mesma applicationId e a mesma assinatura debug estável, com VersionCode 10 e VersionName 1.0.10, para permitir atualização sobre a versão anterior sem desinstalar.

## Regra de versões
A numeração é sempre sequencial e nunca é repetida ou recuada. V1 e V2 não foram funcionais; V3 foi a primeira versão funcional. A evolução atual segue V6 → V7 → V8 → V9 → V10.


## V13
- Correção de alinhamento horizontal dos balões Clientes e Atalhos.
- Os balões passam a usar toda a largura disponível do painel, alinhando as margens esquerda e direita com a grelha superior.
- Sem alterações ao menu lateral ou às restantes funcionalidades.
