AM Clientes V214

Correções: consumo de subscrições sem duplicar a mesma associação guardada em campos legado/lista; preserva consumo por packs, validade e regra 6 por 5; corrige o seletor de componentes de Pack para deixar de ser reescrito em ciclo e elimina a atualização periódica responsável pelo efeito de aparecer/desaparecer.
