# AM Clientes V78

Base: V77.

V78 corrige a apresentação e persistência dos campos personalizados dos Serviços. Os campos ficam compactos, brancos e uniformes; podem ser adicionados em quantidade livre e são preservados no catálogo oficial, incluindo a associação a subscrições.

Android version: 1.0.78 / versionCode 78
