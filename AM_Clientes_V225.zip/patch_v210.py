from pathlib import Path
p=Path('/mnt/data/v209work/app/src/main/assets/am_clientes.html')
s=p.read_text(encoding='utf-8')
# Add pack stats section
needle='''  <div class="card stats-section-card stats-section-collapsed" style="margin-top:12px">\n    <h3 onclick="toggleStatsSection(\'revenue\')" style="cursor:pointer" title="Abrir/fechar">💶 Faturação mensal</h3>'''
repl='''  <div class="card stats-section-card stats-section-collapsed" style="margin-top:12px">\n    <h3 onclick="toggleStatsSection(\'packs\')" style="cursor:pointer" title="Abrir/fechar">📦 Packs</h3>\n    <div id="statsSection_packs" class="hidden"><div id="statsPacks"></div></div>\n  </div>\n  <div class="card stats-section-card stats-section-collapsed" style="margin-top:12px">\n    <h3 onclick="toggleStatsSection(\'revenue\')" style="cursor:pointer" title="Abrir/fechar">💶 Faturação mensal</h3>'''
if needle not in s: raise SystemExit('stats needle not found')
s=s.replace(needle,repl,1)
# Extend openEstatisticas list
s=s.replace("['status','services','subscriptions','vpns','stock','revenue']", "['status','services','subscriptions','vpns','stock','packs','revenue']", 1)
# Replace subOptions label to mark packs
old='''      arr.map(s=>`<option value="${esc(String(s.name||''))}" ${String(s.name||'')===cur?'selected':''}>${esc(String(s.name||''))}</option>`).join('')+'''
new='''      arr.map(s=>{const isPack=String(s.kind||'')==='pack'||Array.isArray(s.components)&&s.components.length;const label=(isPack?'📦 ':'')+String(s.name||'');return `<option value="${esc(String(s.name||''))}" ${String(s.name||'')===cur?'selected':''}>${esc(label)}</option>`}).join('')+'''
if old not in s: raise SystemExit('subOptions not found')
s=s.replace(old,new,1)
# Change the direct inline subscription value calculation to sale value helper
s=s.replace("const cost=v183Money(sub?.cost||0);", "const cost=v210SubscriptionSaleValue(sub);", 1)
s=s.replace("if(s)e.subscricaoValor=money(s.cost);", "if(s)e.subscricaoValor=money(v210SubscriptionSaleValue(s));", 1)
s=s.replace("if(s)item.value=money(s.cost);", "if(s)item.value=money(v210SubscriptionSaleValue(s));", 1)
s=s.replace("const s=catalogSub(el.value);e.subscricao=el.value||'';e.subscricaoValor=s?money(s.cost):0;", "const s=catalogSub(el.value);e.subscricao=el.value||'';e.subscricaoValor=s?money(v210SubscriptionSaleValue(s)):0;", 1)
# Change v117SubscriptionCost function to use helper if present
s=s.replace("return v183Money(sub?.cost||0);", "return typeof window.v210SubscriptionSaleValue==='function' ? v210SubscriptionSaleValue(sub) : v183Money(sub?.cost||0);", 1)
# Insert pack UI before closing subscription create panel actions
needle='''<div class="actions" style="margin-top:10px">\n<button class="primary" onclick="addSubscription()">+ Adicionar</button>'''
repl='''<div id="v210PackConfig" class="card" style="display:none;margin-top:10px;padding:12px;background:rgba(2,9,23,.55)">\n<div class="row">\n<div class="field"><label>Tipo de subscrição</label><select id="subKind"><option value="subscription">Subscrição normal</option><option value="pack">Pack</option></select></div>\n<div class="field"><label>Subscrições incluídas no pack</label><select id="subPackComponents" multiple size="4"></select><small class="muted">Seleciona as subscrições que este pack vai consumir.</small></div>\n</div>\n</div>\n<div class="actions" style="margin-top:10px">\n<button class="primary" onclick="addSubscription()">+ Adicionar</button>'''
if needle not in s: raise SystemExit('form action needle not found')
s=s.replace(needle,repl,1)
# Append V210 implementation before final closing body/html
marker='</body>'
if marker not in s: marker='</html>'
code=r'''<script id="v210-packs-and-pack-statistics">
(function(){
  if(window.__v210PacksAndStats)return;
  window.__v210PacksAndStats=true;
  const clean=v=>String(v??'').trim();
  const money=v=>{
    if(v==null||v==='')return 0;
    let x=String(v).trim().replace(/\s/g,'').replace(/€/g,'');
    if(x.includes(','))x=x.replace(/\./g,'').replace(',','.');
    const n=Number(x);return Number.isFinite(n)?n:0;
  };
  const isPack=s=>!!s&&(String(s.kind||'')==='pack'||(Array.isArray(s.components)&&s.components.length>0));
  const subs=()=>Array.isArray(window.SUBSCRIPTIONS)?window.SUBSCRIPTIONS:[];
  const findSub=name=>subs().find(s=>clean(s?.name||s?.type)===clean(name))||null;
  const saleValue=s=>isPack(s)?money(s.revenue):money(s?.cost);
  window.v210SubscriptionSaleValue=saleValue;
  const ruleOf=s=>String(s?.purchaseRule||'normal')==='6for5'?'6for5':'normal';
  const promoUnits=(months,rule)=>{
    const m=Math.max(1,Number(months)||1);
    if(rule==='6for5') return Math.max(1,Math.ceil(m*5/6));
    return m;
  };
  window.v210PromoUnits=promoUnits;
  function componentsOf(pack){
    if(!isPack(pack))return [];
    return (Array.isArray(pack.components)?pack.components:[]).map(c=>{
      const name=clean(c?.name||c?.subscriptionName||c);
      const live=findSub(name);
      return {id:clean(c?.id||live?.id),name,cost:money(c?.costSnapshot??c?.cost??live?.cost),purchaseRule:String(c?.purchaseRuleSnapshot||c?.purchaseRule||live?.purchaseRule||'normal')};
    }).filter(c=>c.name);
  }
  function fillPackComponentSelect(selected){
    const el=document.getElementById('subPackComponents'); if(!el)return;
    const chosen=new Set((Array.isArray(selected)?selected:[]).map(c=>clean(c?.name||c)));
    el.innerHTML=subs().filter(s=>!isPack(s)).map(s=>{
      const n=clean(s?.name||s?.type);return `<option value="${esc(n)}" ${chosen.has(n)?'selected':''}>${esc(n)}</option>`;
    }).join('');
  }
  function selectedComponents(){
    const el=document.getElementById('subPackComponents');
    return [...(el?.selectedOptions||[])].map(o=>{const s=findSub(o.value);return s?{id:s.id,name:clean(s.name||s.type),costSnapshot:money(s.cost),purchaseRuleSnapshot:ruleOf(s)}:null}).filter(Boolean);
  }
  function syncPackFields(){
    const kind=document.getElementById('subKind'), box=document.getElementById('v210PackConfig');
    if(!kind||!box)return;
    const pack=kind.value==='pack';box.style.display=pack?'block':'none';
    if(pack)fillPackComponentSelect(window.__v210EditingComponents||[]);
  }
  function installPackUI(){
    const kind=document.getElementById('subKind');
    if(!kind)return;
    kind.onchange=syncPackFields;
    fillPackComponentSelect([]);syncPackFields();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',installPackUI,{once:true});else installPackUI();

  // Normaliza os dados existentes sem alterar subscrições antigas.
  subs().forEach(s=>{if(!s.kind)s.kind='subscription';if(isPack(s)&&!Array.isArray(s.components))s.components=[];});

  const oldAdd=window.addSubscription;
  if(typeof oldAdd==='function'&&!oldAdd.__v210Wrapped){
    window.addSubscription=function(){
      const kind=document.getElementById('subKind')?.value||'subscription';
      const comps=kind==='pack'?selectedComponents():[];
      if(kind==='pack'&&comps.length<2){showAppAlert('Pack','Seleciona pelo menos duas subscrições para criar um pack.');return;}
      const before=subs().length;
      oldAdd.apply(this,arguments);
      const s=subs()[before];
      if(!s)return;
      s.kind=kind;s.components=comps;
      if(kind==='pack'){
        s.purchaseRule='normal';
        s.movements=[];s.initialPurchaseRecorded=false;
        s.limit=0;s.licenseUsed=0;
        s.packVersion=1;
      }
      saveSubscriptions();renderSubscriptions();
      if(kind==='pack'){
        const kindEl=document.getElementById('subKind');if(kindEl)kindEl.value='subscription';
        window.__v210EditingComponents=[];syncPackFields();
      }
    };
    window.addSubscription.__v210Wrapped=true;
  }

  const oldEdit=window.editSubscription;
  if(typeof oldEdit==='function'&&!oldEdit.__v210Wrapped){
    window.editSubscription=function(i){
      const s=subs()[i];
      window.__v210EditingComponents=isPack(s)?componentsOf(s):[];
      const r=oldEdit.apply(this,arguments);
      const kind=document.getElementById('subKind');if(kind)kind.value=isPack(s)?'pack':'subscription';
      fillPackComponentSelect(window.__v210EditingComponents);syncPackFields();
      return r;
    };
    window.editSubscription.__v210Wrapped=true;
  }
  const oldSave=window.saveEditedSubscription;
  if(typeof oldSave==='function'&&!oldSave.__v210Wrapped){
    window.saveEditedSubscription=function(){
      const i=window.editingSubscriptionIndex;
      const kind=document.getElementById('subKind')?.value||'subscription';
      const comps=kind==='pack'?selectedComponents():[];
      if(kind==='pack'&&comps.length<2){showAppAlert('Pack','Seleciona pelo menos duas subscrições para guardar o pack.');return;}
      oldSave.apply(this,arguments);
      if(i!==null&&i!==undefined&&subs()[i]){
        const s=subs()[i];s.kind=kind;s.components=comps;
        if(kind==='pack'){s.purchaseRule='normal';s.movements=[];s.limit=0;s.licenseUsed=0;s.initialPurchaseRecorded=false;s.packVersion=(Number(s.packVersion)||0)+1;}
        saveSubscriptions();renderSubscriptions();
      }
    };
    window.saveEditedSubscription.__v210Wrapped=true;
  }

  // Novo comportamento: adicionar um serviço/subscrição ao cliente é uma associação, não cria um catálogo novo.
  window.v156AddSubscription=function(i){
    const e=window.v117EditorEquipments?.[i];if(!e)return;
    const arr=subs();if(!arr.length){showAppAlert('Aviso','Ainda não existem subscrições configuradas.');return;}
    const options=arr.map((s,n)=>`${n+1} — ${isPack(s)?'📦 ':''}${s.name||s.type||'Subscrição'}`).join('\n');
    const choice=prompt('Escolhe a subscrição ou pack pelo número:\n\n'+options);
    if(choice===null)return;
    const n=parseInt(choice,10);if(!(n>=1&&n<=arr.length))return;
    const sub=arr[n-1],name=clean(sub.name||sub.type||'Subscrição');
    e.subscricoes=Array.isArray(e.subscricoes)?e.subscricoes:[];
    const entry={id:sub.id||('sub_'+Date.now()),name,value:saleValue(sub)};
    if(isPack(sub)){
      entry.pack=true;entry.revenueSnapshot=money(sub.revenue);entry.components=componentsOf(sub);entry.assignedAt=new Date().toISOString().slice(0,10);
    }
    e.subscricoes.push(entry);
    if(!clean(e.subscricao)){
      e.subscricao=name;e.subscricaoValor=saleValue(sub);
      if(isPack(sub))e.subscricaoPackSnapshot={name,id:sub.id,revenueSnapshot:money(sub.revenue),components:componentsOf(sub),assignedAt:new Date().toISOString().slice(0,10)};
    }
    v117RenderEquipments();v117UpdatePaymentBalance();
  };

  // Snapshot do pack quando é escolhido no campo principal do equipamento.
  document.addEventListener('change',function(ev){
    const el=ev.target;if(!(el instanceof HTMLSelectElement))return;
    const field=el.closest('#v117EquipmentBox .field');if(!field)return;
    const label=clean(field.querySelector('label')?.textContent);
    if(label!=='Subscrição'&&label!=='Subscrição 1')return;
    const e=window.v117EditorEquipments?.[[...document.querySelectorAll('#v117EquipmentBox .v118-eq-card')].indexOf(el.closest('.v118-eq-card'))];
    const s=findSub(el.value);if(!e||!s)return;
    e.subscricaoValor=saleValue(s);
    if(isPack(s))e.subscricaoPackSnapshot={name:s.name,id:s.id,revenueSnapshot:money(s.revenue),components:componentsOf(s),assignedAt:new Date().toISOString().slice(0,10)};
    else delete e.subscricaoPackSnapshot;
  },true);

  // Consumo: packs descontam diretamente das subscrições originais que os compõem.
  window.subscriptionLinkedCount=function(s){
    const target=clean(s?.name||s?.type);if(!target)return 0;
    let total=0;
    (Array.isArray(window.DATA)?window.DATA:[]).forEach(c=>{
      (Array.isArray(c?.equipamentos)?c.equipamentos:[]).forEach(e=>{
        const months=Math.max(1,Number(window.v210ValidityMonthsForEquipment?.(e)||0)||1);
        const assignments=[];
        if(clean(e?.subscricao))assignments.push({name:clean(e.subscricao),snapshot:e.subscricaoPackSnapshot});
        (Array.isArray(e?.subscricoes)?e.subscricoes:[]).forEach(x=>assignments.push({name:clean(x?.name),snapshot:x?.pack?x:null}));
        assignments.forEach(a=>{
          if(a.name===target){
            if(isPack(s)) total+=promoUnits(months,ruleOf(s));
          }
          const pack=findSub(a.name);
          if(isPack(pack)){
            const comps=Array.isArray(a.snapshot?.components)&&a.snapshot.components.length?a.snapshot.components:componentsOf(pack);
            if(comps.some(x=>clean(x.name)===target)) total+=promoUnits(months, String(comps.find(x=>clean(x.name)===target)?.purchaseRuleSnapshot||findSub(target)?.purchaseRule||'normal')==='6for5'?'6for5':'normal');
          }
        });
      });
    });
    const manual=!isPack(s)&&Array.isArray(s?.devices)?s.devices.filter(d=>clean(d?.name)).length:0;
    return total+manual;
  };
  window.v210ValidityMonthsForEquipment=function(e){
    const raw=clean(e?.periodicidade||e?.validade);const t=raw.toLowerCase();
    const m={mensal:1,bimestral:2,trimestral:3,quadrimestral:4,semestral:6,anual:12,bienal:24,trienal:36};
    for(const k in m)if(t.includes(k))return m[k];
    const n=t.match(/\d+/);return n?Math.max(1,Number(n[0])):1;
  };

  // Renderização dos cartões: packs aparecem como agrupadores e não como stock de licenças.
  const oldRender=window.renderSubscriptions;
  if(typeof oldRender==='function'&&!oldRender.__v210Wrapped){
    window.renderSubscriptions=function(){
      oldRender.apply(this,arguments);
      document.querySelectorAll('#subscricoes .v194-sub-card').forEach((card,i)=>{
        const s=subs()[i];if(!isPack(s))return;
        const counter=card.querySelector('.sub-counter');if(counter)counter.textContent='PACK';
        counter?.classList.remove('sub-ok','sub-warning','sub-full');
        const info=card.querySelector('.muted');
        const lines=card.querySelectorAll('.muted');
        if(lines.length){const last=lines[lines.length-1];last.textContent='Inclui: '+componentsOf(s).map(c=>c.name).join(' · ');}
        card.querySelector('.sub-actions')?.querySelectorAll('button')[0]?.remove();
        const movements=card.querySelector('.sub-movements');if(movements)movements.remove();
      });
    };
    window.renderSubscriptions.__v210Wrapped=true;
  }

  // Estatísticas de packs: receita e custo são calculados por atribuição, usando snapshots.
  function packStats(){
    const out={};
    (Array.isArray(window.DATA)?window.DATA:[]).forEach(c=>{
      const client=clean(c?.['Nome'])||'Cliente';
      (Array.isArray(c?.equipamentos)?c.equipamentos:[]).forEach(e=>{
        const months=Math.max(1,Number(window.v210ValidityMonthsForEquipment(e))||1);
        const assignments=[];
        if(clean(e?.subscricao))assignments.push({name:clean(e.subscricao),snapshot:e.subscricaoPackSnapshot});
        (Array.isArray(e?.subscricoes)?e.subscricoes:[]).forEach(x=>assignments.push({name:clean(x?.name),snapshot:x?.pack?x:null}));
        assignments.forEach(a=>{
          const p=findSub(a.name);if(!isPack(p))return;
          const snap=a.snapshot;
          const comps=Array.isArray(snap?.components)&&snap.components.length?snap.components:componentsOf(p);
          const revenue=money(snap?.revenueSnapshot??p.revenue)*months;
          const cost=comps.reduce((sum,c)=>sum+money(c.costSnapshot)*promoUnits(months,c.purchaseRuleSnapshot),0);
          const key=clean(p.name);if(!out[key])out[key]={name:key,clients:new Set(),count:0,revenue:0,cost:0};
          out[key].clients.add(client);out[key].count++;out[key].revenue+=revenue;out[key].cost+=cost;
        });
      });
    });
    return Object.values(out).map(x=>({...x,clientCount:x.clients.size,margin:x.revenue-x.cost}));
  }
  function renderPackStats(){
    const box=document.getElementById('statsPacks');if(!box)return;
    const rows=packStats();
    if(!rows.length){box.innerHTML='<div class="muted" style="padding:12px 0">Ainda não existem packs atribuídos a clientes.</div>';return;}
    const totalR=rows.reduce((a,x)=>a+x.revenue,0),totalC=rows.reduce((a,x)=>a+x.cost,0);
    box.innerHTML=`<div class="stats-row"><span>Packs utilizados</span><strong>${rows.length}</strong></div><div class="stats-row"><span>Receita dos packs</span><strong>${euroAfter(totalR)}</strong></div><div class="stats-row"><span>Custo das subscrições</span><strong>${euroAfter(totalC)}</strong></div><div class="stats-row"><span>Margem dos packs</span><strong>${euroAfter(totalR-totalC)}</strong></div>`+
      rows.sort((a,b)=>b.margin-a.margin).map(x=>`<div class="stats-row"><span>📦 ${esc(x.name)} · ${x.clientCount} cliente(s)</span><strong>${euroAfter(x.revenue)} · custo ${euroAfter(x.cost)} · margem ${euroAfter(x.margin)}</strong></div>`).join('');
  }
  const oldStats=window.renderEstatisticas;
  if(typeof oldStats==='function'&&!oldStats.__v210Wrapped){
    window.renderEstatisticas=function(){oldStats.apply(this,arguments);renderPackStats();};
    window.renderEstatisticas.__v210Wrapped=true;
  }
  // Recalcular valores de venda dos packs nos campos do cliente sem tocar em snapshots já guardados.
  const oldRefresh=window.v183RefreshEquipmentTotals;
  if(typeof oldRefresh==='function'&&!oldRefresh.__v210Wrapped){
    window.v183RefreshEquipmentTotals=function(i){
      const e=window.v117EditorEquipments?.[i];const s=findSub(e?.subscricao);if(e&&s)e.subscricaoValor=saleValue(s);
      return oldRefresh.apply(this,arguments);
    };window.v183RefreshEquipmentTotals.__v210Wrapped=true;
  }
})();
</script>
'''
s=s.replace(marker,code+marker,1)
# version comments and files
s=s.replace('<!-- V198 — Subscrições:', '<!-- V210 — Packs de subscrições: agrupamento, consumo nas subscrições originais e estatísticas de receita/custo/margem. -->\n<!-- V198 — Subscrições:',1)
p.write_text(s,encoding='utf-8')
for f in ['version.yaml','app/version.yaml','app/src/version.yaml']:
    q=Path('/mnt/data/v209work')/f
    if q.exists():
        q.write_text('210\nversionCode: 210\nversionName: 1.0.210\n',encoding='utf-8')
