# V214 final patch: deduplicate subscription associations and stop pack picker refresh loop.
