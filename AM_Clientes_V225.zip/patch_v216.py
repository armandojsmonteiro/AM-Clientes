# V216: sincroniza a seleção visual de Packs com o seletor legado usado pelo
# guardado da aplicação e evita dupla contabilização de utilizações legadas.

from pathlib import Path

ROOT = Path(__file__).resolve().parent
html = ROOT / 'app' / 'src' / 'main' / 'assets' / 'am_clientes.html'
text = html.read_text(encoding='utf-8')

script = r'''
<script id="v216-pack-selection-and-stock-final">
(function(){
  if(window.__v216PackSelectionAndStockFinal)return;
  window.__v216PackSelectionAndStockFinal=true;
  const clean=v=>String(v??'').trim();
  const getSubs=()=>((typeof SUBSCRIPTIONS!=='undefined'&&Array.isArray(SUBSCRIPTIONS))?SUBSCRIPTIONS:[]);
  const isPack=s=>!!s&&(String(s.kind||'')==='pack'||(Array.isArray(s.components)&&s.components.length>0));
  const findSub=name=>getSubs().find(s=>clean(s?.name||s?.type)===clean(name))||null;
  const currentIndex=()=>window.editingSubscriptionIndex===null||window.editingSubscriptionIndex===undefined?-1:Number(window.editingSubscriptionIndex);

  function selectedNamesFromDom(){
    const names=[...document.querySelectorAll('#v212PackSelected .v212-pack-selected-card')]
      .map(el=>clean(el.dataset.name)).filter(Boolean);
    if(names.length) window.__v216PackSelectedNames=[...new Set(names)];
    return [...new Set(names)];
  }

  function getSelectedNames(){
    const dom=selectedNamesFromDom();
    if(dom.length)return dom;
    return Array.isArray(window.__v216PackSelectedNames)
      ? [...new Set(window.__v216PackSelectedNames.map(clean).filter(Boolean))]
      : [];
  }

  function ensureLegacySelect(names){
    let hidden=document.getElementById('subPackComponents');
    if(!hidden){
      hidden=document.createElement('select');
      hidden.id='subPackComponents';
      hidden.multiple=true;
      hidden.size=1;
      hidden.style.display='none';
      const host=document.getElementById('v212PackComponentsArea') ||
        document.getElementById('v210PackConfig') ||
        document.getElementById('subscriptionCreatePanel') || document.body;
      host.appendChild(hidden);
    }
    const current=currentIndex();
    const wanted=new Set(names);
    hidden.innerHTML=getSubs().map((s,i)=>{
      if(i===current)return '';
      const n=clean(s?.name||s?.type); if(!n)return '';
      return '<option value="'+escHtml216(n)+'"'+(wanted.has(n)?' selected':'')+'>'+escHtml216(n)+'</option>';
    }).join('');
    return hidden;
  }

  function escHtml216(v){
    return String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

  function syncPackSelectionForSave(){
    const kind=document.getElementById('subKind');
    if(!kind || kind.value!=='pack')return [];
    const names=getSelectedNames();
    window.__v216PackSelectedNames=names;
    ensureLegacySelect(names);
    return names;
  }

  // A camada V210 valida através de #subPackComponents, enquanto a V212 mostra
  // os cartões selecionados. Mantemos ambas sincronizadas antes de qualquer
  // criação/edição, para que os mesmos 2+ elementos sejam reconhecidos pelo
  // ciclo completo de wrappers.
  const oldAdd=window.addSubscription;
  if(typeof oldAdd==='function'&&!oldAdd.__v216Wrapped){
    window.addSubscription=function(){
      const kind=document.getElementById('subKind');
      if(kind?.value==='pack'){
        const names=syncPackSelectionForSave();
        if(names.length<2){
          if(typeof showAppAlert==='function')showAppAlert('Pack','Seleciona pelo menos duas subscrições ou packs para criar este pack.');
          return;
        }
      }
      return oldAdd.apply(this,arguments);
    };
    window.addSubscription.__v216Wrapped=true;
  }

  const oldSave=window.saveEditedSubscription;
  if(typeof oldSave==='function'&&!oldSave.__v216Wrapped){
    window.saveEditedSubscription=function(){
      const kind=document.getElementById('subKind');
      if(kind?.value==='pack'){
        const names=syncPackSelectionForSave();
        if(names.length<2){
          if(typeof showAppAlert==='function')showAppAlert('Pack','Seleciona pelo menos duas subscrições ou packs para guardar este pack.');
          return;
        }
      }
      return oldSave.apply(this,arguments);
    };
    window.saveEditedSubscription.__v216Wrapped=true;
  }

  function observePicker(){
    const box=document.getElementById('v212PackSelected');
    if(!box || box.__v216Observed)return;
    box.__v216Observed=true;
    const observer=new MutationObserver(()=>{
      const names=selectedNamesFromDom();
      if(names.length)ensureLegacySelect(names);
      else window.__v216PackSelectedNames=[];
    });
    observer.observe(box,{childList:true,subtree:true});
  }

  document.addEventListener('change',ev=>{
    const el=ev.target;
    if(!(el instanceof HTMLSelectElement))return;
    if(el.id==='v212PackAddSelect' || el.id==='subKind'){
      setTimeout(()=>{
        observePicker();
        const names=selectedNamesFromDom();
        if(el.id==='v212PackAddSelect' && names.length)ensureLegacySelect(names);
      },0);
    }
  },true);

  document.addEventListener('click',()=>{setTimeout(observePicker,0);},true);
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',observePicker,{once:true});
  else observePicker();
  setTimeout(observePicker,50);
  setTimeout(observePicker,200);

  // ---------------- Stock: uma utilização por subscrição e equipamento ----------------
  const ruleOf=s=>String(s?.purchaseRule||'normal')==='6for5'?'6for5':'normal';
  const promoUnits=(months,rule)=>{
    const m=Math.max(1,Number(months)||1);
    return rule==='6for5'?Math.max(1,Math.ceil(m*5/6)):m;
  };
  const monthsFor=e=>{
    if(typeof window.v210ValidityMonthsForEquipment==='function'){
      const n=Number(window.v210ValidityMonthsForEquipment(e));
      if(n>0)return n;
    }
    const t=clean(e?.periodicidade||e?.validade).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    const map={mensal:1,bimestral:2,bimensal:2,trimestral:3,quadrimestral:4,semestral:6,anual:12,bienal:24,trienal:36};
    for(const k in map)if(t.includes(k))return map[k];
    const n=t.match(/\d+/);return n?Math.max(1,Number(n[0])):1;
  };
  const componentList=pack=>{
    if(!isPack(pack))return [];
    return (Array.isArray(pack.components)?pack.components:[]).map(c=>{
      const name=clean(c?.name||c?.subscriptionName||c);
      const live=findSub(name);
      return {
        name,
        purchaseRuleSnapshot:String(c?.purchaseRuleSnapshot||c?.purchaseRule||live?.purchaseRule||'normal')==='6for5'?'6for5':'normal'
      };
    }).filter(c=>c.name);
  };

  // As três estruturas e.subscricao/e.subscricoes/e.vpns são versões do mesmo
  // vínculo em diferentes versões da aplicação. Dentro de cada equipamento,
  // uma mesma subscrição só pode consumir uma vez.
  const canonicalAssignments=e=>{
    const map=new Map();
    const add=(name,snapshot)=>{
      const n=clean(name); if(!n || map.has(n))return;
      map.set(n,{name:n,snapshot:snapshot||null});
    };
    add(e?.subscricao,e?.subscricaoPackSnapshot);
    (Array.isArray(e?.subscricoes)?e.subscricoes:[]).forEach(x=>add(x?.name,x?.pack?x:null));
    (Array.isArray(e?.vpns)?e.vpns:[]).forEach(v=>add(v?.subscricao,v?.subscricaoPackSnapshot||null));
    return [...map.values()];
  };

  function countLinked(s){
    const target=clean(s?.name||s?.type);
    if(!target || isPack(s))return 0;
    const data=(Array.isArray(window.DATA)?window.DATA:[]);
    let total=0;
    let hasClientLink=false;
    data.forEach(c=>{
      (Array.isArray(c?.equipamentos)?c.equipamentos:[]).forEach(e=>{
        const months=monthsFor(e);
        canonicalAssignments(e).forEach(a=>{
          if(a.name===target){
            hasClientLink=true;
            total+=promoUnits(months,ruleOf(s));
            return;
          }
          const pack=findSub(a.name);
          if(!isPack(pack))return;
          const snap=Array.isArray(a.snapshot?.components)&&a.snapshot.components.length?a.snapshot:pack;
          const comp=componentList(snap).find(x=>x.name===target);
          if(comp){
            hasClientLink=true;
            total+=promoUnits(months,comp.purchaseRuleSnapshot);
          }
        });
      });
    });

    // O array devices é legado e, quando já existem vínculos através de clientes,
    // não deve voltar a contabilizar a mesma utilização pela segunda vez.
    if(!hasClientLink && Array.isArray(s?.devices)){
      total+=s.devices.filter(d=>clean(d?.name)).length;
    }
    return total;
  }

  function linkedEntries(s){
    const target=clean(s?.name||s?.type);
    if(!target || isPack(s))return [];
    const rows=[];
    const data=(Array.isArray(window.DATA)?window.DATA:[]);
    data.forEach(c=>{
      const clientId=clean(c?.['ID Cliente']);
      const clientName=clean(c?.['Nome']||c?.['Nome Empresa'])||'Cliente';
      (Array.isArray(c?.equipamentos)?c.equipamentos:[]).forEach((e,idx)=>{
        const months=monthsFor(e);
        let used=0;
        canonicalAssignments(e).forEach(a=>{
          if(a.name===target){used+=promoUnits(months,ruleOf(s));return;}
          const pack=findSub(a.name); if(!isPack(pack))return;
          const snap=Array.isArray(a.snapshot?.components)&&a.snapshot.components.length?a.snapshot:pack;
          const comp=componentList(snap).find(x=>x.name===target);
          if(comp)used+=promoUnits(months,comp.purchaseRuleSnapshot);
        });
        if(used>0)rows.push({
          key:clientId+'\u0000'+String(e?.id||idx),
          clientId,clientName,
          equipment:clean(e?.nome||c?.['Equipamento']||'Equipamento')||'Equipamento',
          used
        });
      });
    });
    return rows;
  }

  window.subscriptionLinkedCount=countLinked;
  window.subscriptionLinkedEntries=linkedEntries;
  window.v216SubscriptionLinkedCount=countLinked;
})();
</script>
'''

if 'id="v216-pack-selection-and-stock-final"' in text:
    raise SystemExit('V216 já existe no HTML')

text = text.rstrip() + '\n' + script + '\n'
html.write_text(text, encoding='utf-8')

for rel in ['version.yaml','app/version.yaml','app/src/version.yaml']:
    p=ROOT/rel
    p.write_text('version: 216\nname: AM Clientes\n', encoding='utf-8')

(ROOT/'README.md').write_text(
    'AM Clientes V216\n\n'
    'Correções: sincroniza a seleção visual dos componentes de Packs com o seletor legado usado no guardado; '
    'evita o falso erro de menos de duas subscrições; evita dupla contabilização do mesmo vínculo em estruturas legadas '
    'e não soma dispositivos legados quando já existem vínculos por cliente/equipamento.\n',
    encoding='utf-8'
)
