# V215: deduplica associações espelhadas de subscrições e remove o refresh periódico do seletor de Packs.
