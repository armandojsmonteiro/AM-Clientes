from pathlib import Path
p=Path('/mnt/data/v210work/app/src/main/assets/am_clientes.html')
s=p.read_text(encoding='utf-8')
marker='</body>'
script=r'''<script id="v211-pack-ui-and-subscription-stock-fix">
(function(){
  if(window.__v211Fix)return;
  window.__v211Fix=true;
  const clean=v=>String(v??'').trim();
  const subs=()=>Array.isArray(window.SUBSCRIPTIONS)?window.SUBSCRIPTIONS:[];
  const isPack=s=>!!s&&(String(s.kind||'')==='pack'||(Array.isArray(s.components)&&s.components.length>0));
  const findSub=name=>subs().find(s=>clean(s?.name||s?.type)===clean(name))||null;
  const ruleOf=s=>String(s?.purchaseRule||'normal')==='6for5'?'6for5':'normal';
  const promoUnits=(months,rule)=>{
    const m=Math.max(1,Number(months)||1);
    return rule==='6for5'?Math.max(1,Math.ceil(m*5/6)):m;
  };
  function monthsFor(e){
    if(typeof window.v210ValidityMonthsForEquipment==='function') return Math.max(1,Number(window.v210ValidityMonthsForEquipment(e))||1);
    const t=clean(e?.periodicidade||e?.validade).toLowerCase();
    const map={mensal:1,bimestral:2,trimestral:3,quadrimestral:4,semestral:6,anual:12,bienal:24,trienal:36};
    for(const k in map) if(t.includes(k)) return map[k];
    const n=t.match(/\d+/); return n?Math.max(1,Number(n[0])):1;
  }
  function assignments(e){
    const out=[];
    if(clean(e?.subscricao)) out.push({name:clean(e.subscricao),snapshot:e.subscricaoPackSnapshot});
    (Array.isArray(e?.subscricoes)?e.subscricoes:[]).forEach(x=>{
      const n=clean(x?.name); if(n) out.push({name:n,snapshot:x?.pack?x:null});
    });
    (Array.isArray(e?.vpns)?e.vpns:[]).forEach(v=>{
      const n=clean(v?.subscricao); if(n) out.push({name:n,snapshot:v?.subscricaoPackSnapshot||null});
    });
    return out;
  }
  function componentsOf(pack){
    if(!isPack(pack)) return [];
    return (Array.isArray(pack.components)?pack.components:[]).map(c=>{
      const name=clean(c?.name||c?.subscriptionName||c);
      const live=findSub(name);
      return {id:clean(c?.id||live?.id),name,
        cost:Math.max(0,Number(c?.costSnapshot??c?.cost??live?.cost)||0),
        purchaseRule:String(c?.purchaseRuleSnapshot||c?.purchaseRule||live?.purchaseRule||'normal')==='6for5'?'6for5':'normal'};
    }).filter(c=>c.name);
  }

  // Corrige o contador de stock: uma subscrição simples consome stock diretamente;
  // um Pack consome stock nas subscrições originais que o compõem. Inclui também
  // subscrições colocadas dentro das VPNs do equipamento.
  window.subscriptionLinkedCount=function(s){
    const target=clean(s?.name||s?.type); if(!target) return 0;
    if(isPack(s)) return 0; // packs não têm stock próprio
    let total=0;
    (Array.isArray(window.DATA)?window.DATA:[]).forEach(c=>{
      (Array.isArray(c?.equipamentos)?c.equipamentos:[]).forEach(e=>{
        const months=monthsFor(e);
        assignments(e).forEach(a=>{
          if(a.name===target){
            total += promoUnits(months,ruleOf(s));
            return;
          }
          const pack=findSub(a.name);
          if(isPack(pack)){
            const comps=Array.isArray(a.snapshot?.components)&&a.snapshot.components.length?a.snapshot.components:componentsOf(pack);
            const comp=comps.find(x=>clean(x.name)===target);
            if(comp) total += promoUnits(months,comp.purchaseRule);
          }
        });
      });
    });
    return total + (Array.isArray(s?.devices)?s.devices.filter(d=>clean(d?.name)).length:0);
  };

  // Mantém também a lista de clientes/equipamentos coerente com o contador.
  window.subscriptionLinkedEntries=function(s){
    const target=clean(s?.name||s?.type); if(!target||isPack(s)) return [];
    const rows=[];
    (Array.isArray(window.DATA)?window.DATA:[]).forEach(c=>{
      const clientId=clean(c?.['ID Cliente']);
      const clientName=clean(c?.['Nome']||c?.['Nome Empresa'])||'Cliente';
      (Array.isArray(c?.equipamentos)?c.equipamentos:[]).forEach((e,idx)=>{
        const months=monthsFor(e); let used=0;
        assignments(e).forEach(a=>{
          if(a.name===target) used+=promoUnits(months,ruleOf(s));
          else {
            const pack=findSub(a.name);
            if(isPack(pack)){
              const comps=Array.isArray(a.snapshot?.components)&&a.snapshot.components.length?a.snapshot.components:componentsOf(pack);
              const comp=comps.find(x=>clean(x.name)===target);
              if(comp) used+=promoUnits(months,comp.purchaseRule);
            }
          }
        });
        if(used>0) rows.push({key:clientId+'\u0000'+String(e?.id||idx),clientId,clientName,equipment:clean(e?.nome||c?.['Equipamento']||'Equipamento')||'Equipamento',used});
      });
    });
    return rows;
  };

  // O tipo fica junto da Regra de compra, como os outros campos do formulário.
  // O bloco inferior aparece apenas quando o utilizador escolhe Pack.
  function installPackTypeUI(){
    const kind=document.getElementById('subKind');
    const packBox=document.getElementById('v210PackConfig');
    if(!kind||!packBox)return;
    kind.options[0].textContent='Subscrição simples';
    const oldField=kind.closest('.field');
    const rule=document.getElementById('subPurchaseRule');
    const ruleField=rule?.closest('.field');
    if(oldField && ruleField && oldField.parentElement!==ruleField.parentElement){
      ruleField.parentElement.appendChild(oldField);
    }
    // Retira o título/caixa duplicada e deixa apenas a seleção das componentes.
    packBox.style.background='transparent';
    packBox.style.padding='0';
    packBox.style.border='0';
    const compField=document.getElementById('subPackComponents')?.closest('.field');
    if(compField){
      compField.style.width='100%';
      compField.querySelector('small')?.replaceChildren(document.createTextNode('Escolhe as subscrições que este pack vai consumir.'));
    }
    const sync=()=>{
      const pack=kind.value==='pack';
      packBox.style.display=pack?'block':'none';
      if(pack && typeof window.v210FillPackComponentSelect==='function') window.v210FillPackComponentSelect(window.__v211EditingComponents||[]);
    };
    kind.onchange=sync;
    sync();
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',installPackTypeUI,{once:true});
  else installPackTypeUI();
  const oldOpen=window.openSubscriptions;
  if(typeof oldOpen==='function'&&!oldOpen.__v211Wrapped){
    const f=function(){const r=oldOpen.apply(this,arguments);setTimeout(installPackTypeUI,0);return r;};f.__v211Wrapped=true;window.openSubscriptions=f;
  }

  // Força a atualização do resumo assim que os dados dos clientes mudam.
  const oldSaveDB=window.saveDB;
  if(typeof oldSaveDB==='function'&&!oldSaveDB.__v211Wrapped){
    const f=function(){const r=oldSaveDB.apply(this,arguments);try{if(typeof window.renderSubscriptions==='function')window.renderSubscriptions();}catch(_){}return r;};
    f.__v211Wrapped=true;window.saveDB=f;
  }
})();
</script>
'''
s=s.replace(marker,script+marker,1)
p.write_text(s,encoding='utf-8')

# Version files
for fn in ['version.yaml','app/version.yaml','app/src/version.yaml']:
    q=Path('/mnt/data/v210work')/fn
    if q.exists():
        q.write_text('211\nversionCode: 211\nversionName: 1.0.211\n',encoding='utf-8')
readme=Path('/mnt/data/v210work/README.md')
readme.write_text('''AM Clientes V211 — Packs e correção do consumo de subscrições.\n\nO tipo de subscrição passa a poder ser Subscrição simples ou Pack no próprio formulário de subscrições. Ao escolher Pack, aparecem apenas as subscrições que o compõem. Os Packs não têm stock próprio: o consumo é descontado diretamente nas subscrições originais. Corrigido também o contador de Utilizadas/Disponíveis para voltar a considerar as subscrições simples e as subscrições associadas às VPNs, respeitando a periodicidade e a regra 6 por 5.\n''',encoding='utf-8')
