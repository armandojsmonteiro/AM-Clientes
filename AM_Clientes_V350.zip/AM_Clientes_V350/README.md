AM Clientes V350 — Android nativo

V350 corrige apenas as dimensões dos botões dos submenus indicados: Adicionar empresa fica estreito e com a mesma altura do botão Guardar dados da empresa; o botão do lápis mantém dimensões compactas; os botões Adicionar em Botões do menu Início e Empresas dos clientes deixam de herdar a altura mínima predefinida do Android.

Projeto exclusivamente Android nativo. O workflow GitHub Actions compila o APK e publica o artefacto AM_Clientes_V350.apk.
