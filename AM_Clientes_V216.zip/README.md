AM Clientes V216

Correções: sincroniza a seleção visual dos componentes de Packs com o seletor legado usado no guardado; evita o falso erro de menos de duas subscrições; evita dupla contabilização do mesmo vínculo em estruturas legadas e não soma dispositivos legados quando já existem vínculos por cliente/equipamento.
