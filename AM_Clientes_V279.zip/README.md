# AM Clientes V279

Projeto Android nativo independente.
- Package / Application ID: `com.aminovacao.amclientes231`
- Base: V279 (V279 não utilizada)
- V279 é apenas referência funcional.

Alterações V279: edição visual branca e linhas de Serviço/Subscrição selecionáveis diretamente no cartão, sem pop-ups. A primeira linha chama-se `Serviço`/`Subscrição`; só ao adicionar a segunda passam a existir `Serviço 1`, `Serviço 2` e `Subscrição 1`, `Subscrição 2`. Apenas linhas adicionais podem ser apagadas.
