plugins { id("com.android.application") }
android { namespace = "com.aminovacao.amclientes231"; compileSdk = 35
 defaultConfig { applicationId = "com.aminovacao.amclientes231"; minSdk = 23; targetSdk = 35; versionCode = 273; versionName = "273" }
}
