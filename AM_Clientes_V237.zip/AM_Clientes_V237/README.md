# AM Clientes V237

Reconstrução Android nativa da aplicação AM Clientes, baseada na V230 funcional.

- Application ID: `com.aminovacao.amclientes231`
- Version Code: `234`
- Version Name: `1.0.237`
- 100% Android nativo; sem HTML/WebView.
- A V230 original permanece separada e não é atualizada por esta aplicação.
- A V59 é usada apenas como referência visual quando necessário.
