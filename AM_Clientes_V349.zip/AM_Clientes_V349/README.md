AM Clientes V349 — Android nativo

V349 corrige exclusivamente os submenus de Configurações indicados: iguala a largura de Adicionar empresa à de Guardar dados da empresa, usa o ícone de lápis em emoji, reduz a altura do campo e do botão em Empresas dos clientes e ajusta a altura do botão Adicionar em Botões do menu Início. O botão Remover logótipo limpa agora a pré-visualização e remove o ícone da barra superior.

Projeto exclusivamente Android nativo. O workflow GitHub Actions compila o APK e publica o artefacto AM_Clientes_V349.apk.
