# AM Clientes V290

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 290
- `versionName`: `1.0.290`

Alterações limitadas ao botão de pré-visualização e à animação de deslocamento: a letra de Fechar Cliente corresponde à do botão Fechar padrão e mantém a mesma dimensão de 64 × 40 dp; o scroll usa uma animação gradual de 900 ms com desaceleração, para a pré-visualização subir suavemente. Uma nova navegação cancela qualquer animação anterior.
