AM Clientes V244

Base: V244. Ajuste visual do menu lateral: largura, proporções, cores dos itens e alinhamento superior da aplicação. Sem alteração das funcionalidades.
