package com.aminovacao.amclientes.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aminovacao.amclientes.data.Database
import java.util.UUID

private val Bg = Color(0xFF030B20)
private val Panel = Color(0xCC071127)
private val Panel2 = Color(0xCC071630)
private val Line = Color(0xFF29405F)
private val Blue = Color(0xFF61A5FF)
private val TextMain = Color(0xFFF5F7FB)
private val Muted = Color(0xFF9AAAC2)
private val Green = Color(0xFF35D07F)
private val Orange = Color(0xFFFFAD45)
private val Red = Color(0xFFFF5C68)

private data class NavItem(val title: String, val icon: ImageVector)
private val navItems = listOf(
    NavItem("Início", Icons.Default.Home), NavItem("Clientes", Icons.Default.People),
    NavItem("Subscrições", Icons.Default.CreditCard), NavItem("Catálogos", Icons.Default.Inventory2),
    NavItem("Arquivado", Icons.Default.Folder), NavItem("Histórico", Icons.Default.History),
    NavItem("Estatísticas", Icons.Default.BarChart), NavItem("Configurações", Icons.Default.Settings),
    NavItem("Gestão", Icons.Default.Build)
)

@Composable
fun AMClientesApp(context: Context) {
    val db = remember { Database(context) }
    var selected by remember { mutableStateOf("Início") }
    var companyId by remember { mutableStateOf("") }
    var companyName by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        if (companyId.isBlank()) {
            val existing = db.writableDatabase.rawQuery("SELECT id,name FROM companies ORDER BY created_at LIMIT 1", null)
            if (existing.moveToFirst()) {
                companyId = existing.getString(0)
                companyName = existing.getString(1)
            } else {
                val id = UUID.randomUUID().toString()
                db.writableDatabase.execSQL("INSERT INTO companies(id,name,created_at) VALUES(?,?,?)", arrayOf(id, "Empresa 1", System.currentTimeMillis()))
                companyId = id
                companyName = "Empresa 1"
            }
            existing.close()
        }
    }

    Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF12376F), Color(0xFF071630), Bg), radius = 1100f))) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Surface(
                    modifier = Modifier.size(54.dp).clickable { menuOpen = !menuOpen },
                    shape = RoundedCornerShape(16.dp), color = Color(0xFF071630),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Line)
                ) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Menu, "Menu", tint = TextMain, modifier = Modifier.size(30.dp)) } }
                Spacer(Modifier.width(12.dp))
                Surface(modifier = Modifier.size(54.dp), shape = RoundedCornerShape(16.dp), color = Color(0xFF0A1C3C), border = androidx.compose.foundation.BorderStroke(1.dp, Line)) {
                    Box(contentAlignment = Alignment.Center) { Text("AM", color = Blue, fontWeight = FontWeight.Black, fontSize = 22.sp) }
                }
                Spacer(Modifier.width(14.dp))
                Text("AM Clientes", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            }

            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = search, onValueChange = { search = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), placeholder = { Text("Pesquisar nome, contacto, empresa, equipamento, MAC, nº série...", color = Muted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Blue, unfocusedBorderColor = Line,
                    focusedContainerColor = Color(0xB8030B20), unfocusedContainerColor = Color(0xB8030B20),
                    focusedTextColor = TextMain, unfocusedTextColor = TextMain, cursorColor = Blue
                ), shape = RoundedCornerShape(22.dp)
            )

            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("0", "Ativos", Green, Modifier.weight(1f))
                StatCard("0", "A expirar", Orange, Modifier.weight(1f))
                StatCard("0", "Expirados", Red, Modifier.weight(1f))
            }

            Spacer(Modifier.height(14.dp))
            Surface(Modifier.fillMaxSize(), shape = RoundedCornerShape(28.dp), color = Panel, border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x1429405F))) {
                Box(Modifier.fillMaxSize()) {
                    when (selected) {
                        "Início" -> Home(companyName)
                        else -> Section(selected, companyName)
                    }
                    if (menuOpen) SideMenu(companyName, selected, { selected = it; menuOpen = false }, { menuOpen = false })
                }
            }
        }
    }
}

@Composable private fun StatCard(value: String, label: String, valueColor: Color, modifier: Modifier) {
    Surface(modifier, shape = RoundedCornerShape(22.dp), color = Color(0x66071127), border = androidx.compose.foundation.BorderStroke(1.dp, Line)) {
        Column(Modifier.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = valueColor, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text(label, color = TextMain, fontSize = 16.sp)
        }
    }
}

@Composable private fun Home(company: String) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Clientes", color = TextMain, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
        item {
            CardPanel {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("📋  Clientes", color = TextMain, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Button(onClick = {}, shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Bg)) { Text("Fechar", fontWeight = FontWeight.Bold) }
                }
                Spacer(Modifier.height(12.dp))
                Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), color = Color(0x22071127), border = androidx.compose.foundation.BorderStroke(1.dp, Line)) {
                    Text("Nenhum cliente.", color = Muted, fontSize = 17.sp, modifier = Modifier.padding(22.dp))
                }
            }
        }
        item {
            CardPanel {
                Text("🔗  Atalhos", color = TextMain, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Text("Ainda não existem atalhos. Pode adicioná-los em Configurações.", color = Muted, fontSize = 17.sp)
            }
        }
    }
}

@Composable private fun CardPanel(content: @Composable ColumnScope.() -> Unit) {
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), color = Color(0x66030B20), border = androidx.compose.foundation.BorderStroke(1.dp, Line)) { Column(Modifier.padding(20.dp), content = content) }
}

@Composable private fun SideMenu(company: String, selected: String, onSelect: (String) -> Unit, onClose: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = Color(0xF5081328)) {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("AM Clientes", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Fechar", tint = TextMain) }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = {}, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = Blue), border = androidx.compose.foundation.BorderStroke(1.dp, Line), shape = RoundedCornerShape(15.dp)) { Text(company.ifBlank { "Empresa" }) }
            Spacer(Modifier.height(10.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(navItems.size) { i ->
                    val item = navItems[i]
                    NavigationDrawerItem(label = { Text(item.title) }, selected = selected == item.title, onClick = { onSelect(item.title) }, icon = { Icon(item.icon, null) }, colors = NavigationDrawerItemDefaults.colors(selectedContainerColor = Color(0xFFE9E0F5), selectedTextColor = Bg, selectedIconColor = Bg, unselectedTextColor = TextMain, unselectedIconColor = Muted))
                }
            }
        }
    }
}

@Composable private fun Section(title: String, company: String) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(title, color = TextMain, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Empresa ativa: $company", color = Muted, fontSize = 17.sp)
    }
}
