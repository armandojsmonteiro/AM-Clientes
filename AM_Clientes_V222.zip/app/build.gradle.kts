plugins { id("com.android.application") }

android {
    namespace = "com.aminovacao.amclientes"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aminovacao.amclientes.test222"
        minSdk = 26
        targetSdk = 35
        versionCode = 222
        versionName = "1.0.222"
    }

    buildTypes {
        getByName("debug") {
            isMinifyEnabled = false
        }
        getByName("release") {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
