# AM Clientes V95

Base: V94.

V95 uniformiza os campos de toda a aplicação: exemplos com Ex.: em cinzento, texto introduzido a preto, seleções com — Selecionar — e indicação uniforme nos campos de data. A lógica existente é preservada.

Android version: 1.0.82 / versionCode 82
