# AM Clientes V76

Base: V75.

V76 corrige a limpeza total da base para que uma base limpa não volte a criar automaticamente as cinco subscrições/serviços de demonstração. O catálogo de serviços passa a respeitar a empresa ativa. Corrige também a criação de campos personalizados vazios e uniformiza visualmente esses campos com caixas brancas arredondadas de tamanho intermédio.

Android version: 1.0.76 / versionCode 76
