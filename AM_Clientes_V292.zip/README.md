# AM Clientes V292

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 292
- `versionName`: `1.0.292`

Correção localizada da navegação do editor de cliente: ao abrir a edição, mantém temporariamente a altura e posição do conteúdo anterior e anima o scroll até ao título do editor. Ao cancelar, restaura o ecrã e o cliente anteriormente selecionado e anima de volta até à posição onde a pré-visualização estava, mesmo quando a ação é feita no fim do formulário. A altura temporária é removida após a animação, evitando saltos ou espaço extra permanente. Mantém Início e Clientes separados.
