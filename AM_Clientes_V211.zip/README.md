AM Clientes V211 — Packs e correção do consumo de subscrições.

O tipo de subscrição passa a poder ser Subscrição simples ou Pack no próprio formulário de subscrições. Ao escolher Pack, aparecem apenas as subscrições que o compõem. Os Packs não têm stock próprio: o consumo é descontado diretamente nas subscrições originais. Corrigido também o contador de Utilizadas/Disponíveis para voltar a considerar as subscrições simples e as subscrições associadas às VPNs, respeitando a periodicidade e a regra 6 por 5.
