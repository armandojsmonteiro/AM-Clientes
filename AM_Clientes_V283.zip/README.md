# AM Clientes V283

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 283
- `versionName`: `1.0.283`

Alterações nesta versão:
- Botões de remover serviço/subscrição alinhados horizontalmente com o respetivo campo de valor.
- Setas indicadoras em todos os seletores do formulário; as listas continuam a abrir pelo próprio seletor.
- Após adicionar equipamento, serviço ou subscrição, o ecrã desloca-se automaticamente para a nova secção/linha.
- Dimensões dos campos e botões mantidas; não foram intencionalmente alteradas nesta versão.
