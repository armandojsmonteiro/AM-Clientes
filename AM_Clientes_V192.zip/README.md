AM Clientes V192 — baseada na V190; correções de validação de subscrições, diálogos próprios para movimentos e recolha dos cartões de subscrição.
