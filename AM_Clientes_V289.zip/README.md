# AM Clientes V289

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 289
- `versionName`: `1.0.289`

Alterações desta versão, focadas no menu Clientes e na pré-visualização do cliente:
- Indicadores coloridos do menu Clientes ligeiramente maiores, mantendo as dimensões dos cartões.
- Texto dos botões Fechar e Adicionar ajustado para caber numa linha.
- Fechar recolhe/reabre a lista dentro do menu Clientes, sem saltar para Início.
- Barra superior, pesquisa global e conteúdo passam a fazer scroll em conjunto, permitindo que o cabeçalho saia do ecrã ao percorrer a pré-visualização.
- Ao abrir a pré-visualização, o ecrã desliza suavemente até ao detalhe do cliente.
- Conteúdo de Atalhos continua apenas no ecrã Início.
