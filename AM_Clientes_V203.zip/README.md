AM Clientes V200 — correção do suporte a valores monetários com cêntimos e criação de snapshots dos preços atribuídos aos clientes. Os preços existentes deixam de ser alterados automaticamente quando o catálogo muda; só mudam quando o utilizador volta a selecionar o serviço ou subscrição no cliente.

V203 — cálculo do total do equipamento por validade: todos os valores recorrentes (serviços e subscrições) são multiplicados pelo número de meses da validade. Ex.: (2,00 € + 0,83 €) × 6 = 16,98 €.
