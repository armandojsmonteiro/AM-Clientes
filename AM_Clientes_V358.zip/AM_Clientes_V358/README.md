# AM Clientes V354

V354 recupera os cinco modelos originais de mensagem (Renovação, Expirado, Pagamento, Manutenção e Personalizada) no submenu nativo Android Configurações > Mensagens. Os modelos são semeados apenas quando ainda não existe uma lista configurada; os textos editados ficam guardados e são usados no ecrã de contacto com o cliente.

Mantém “Atalhos do menu Início” como o único submenu de configuração para os atalhos e não adiciona um submenu autónomo “Atalhos”. Uniformiza os ícones de edição com o emoji de lápis colorido, compacta o botão de editar empresa para um quadrado e mantém os cartões de mensagens com o mesmo fundo azul-marinho dos restantes itens.

Projeto exclusivamente Android nativo (Java), sem WebView ou componentes HTML.
