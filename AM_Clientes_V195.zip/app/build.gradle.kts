plugins { id("com.android.application") }

android {
    namespace = "com.aminovacao.amclientes"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aminovacao.amclientes"
        minSdk = 26
        targetSdk = 35
        versionCode = 195
        versionName = "1.0.195"
    }
    signingConfigs {
        create("stableDebug") {
            storeFile = file("../keystore/am_clientes_test.jks")
            storePassword = "AMClientesTest2026"
            keyAlias = "amclientes"
            keyPassword = "AMClientesTest2026"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("stableDebug")
            isMinifyEnabled = false
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("stableDebug")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildTypes {
        getByName("debug") { isMinifyEnabled = false }
    }
}
