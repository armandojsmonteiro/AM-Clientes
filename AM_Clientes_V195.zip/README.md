AM Clientes V193 — seleção direta de subscrições no cliente, múltiplas subscrições e valor automático pelo custo da subscrição.
