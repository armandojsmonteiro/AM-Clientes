# AM Clientes V286

Aplicação Android nativa.

- Package / Application ID: `com.aminovacao.amclientes231`
- `versionCode`: 286
- `versionName`: `1.0.286`

Correções desta versão, limitadas ao formulário de edição do cliente:
- Cancelar regressa ao ecrã de origem e preserva a pré-visualização do cliente quando a edição foi aberta a partir dela, tanto no menu Iniciar como no menu Clientes.
- O formulário de edição de um cliente existente apresenta apenas Guardar, Cancelar e Apagar, na mesma linha.
- Removido o botão Arquivar do rodapé do formulário de edição; o arquivamento disponível na pré-visualização não foi alterado.
