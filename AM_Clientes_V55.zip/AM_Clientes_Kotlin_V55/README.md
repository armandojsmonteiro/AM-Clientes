# AM Clientes — V34

V16 é a continuação direta da V15.

## Alteração desta versão
- Menu lateral alinhado com a referência visual enviada.
- Todos os itens do menu passam a ter caixas individuais arredondadas com contorno.
- Início selecionado em azul principal.
- Ícones coloridos preservados.
- Tipografia compacta preservada para manter todos os itens visíveis.
- Seletor de empresa mantido em caixa própria.

## Estado funcional
A navegação inicial e o menu lateral estão implementados. As páginas Clientes, Subscrições, Catálogos, Arquivado, Histórico, Estatísticas, Configurações e Gestão ainda apresentam o ecrã-base da secção; a área completa de Configurações ainda não foi construída.


### V17
Primeiro ecrã do menu Clientes ajustado à referência. A navegação inicial e o menu lateral da V16 permanecem preservados.


### V24
V24 parte da V23 e altera exclusivamente o menu Clientes, reduzindo os botões Fechar/Abrir e Adicionar para 62dp de largura. O Início/Home permanece intocado.


### V30
Correção visual do menu Subscrições a partir da V29: os indicadores do contexto Clientes deixam de aparecer neste menu e o balão de Subscrições é ligeiramente ampliado verticalmente.


### V34
Correção exclusiva do espaçamento vertical entre os botões do menu lateral, retomando o pequeno intervalo visual da referência. Nenhum outro elemento do menu foi alterado.


### V35
Correção exclusivamente visual do menu lateral a partir da V34:
- adicionada a linha vertical de limite no lado direito da barra lateral;
- adicionado o contorno/caixa arredondada no botão X;
- aumentada ligeiramente a altura dos botões dos itens do menu, mantendo o espaçamento entre eles;
- mantidos os ícones, tipografia e restante estrutura sem alterações funcionais.


### V37
Correção da compilação da V35. Foi reposto o fecho correto da estrutura Compose do menu lateral, sem alterar o desenho pretendido. A V37 mantém a linha vertical, o botão X com caixa e as dimensões dos itens introduzidas na V35.


### V44
Base: V39. As versões V40–V43 foram descartadas e não são utilizadas como base.

Alteração exclusiva no menu Catálogos:
- aproximação ligeira entre cada título e a respetiva descrição;
- redução controlada da altura de linha dos dois textos para compactar o conjunto sem sobreposição;
- mantidos os tamanhos e posições dos balões, os quatro itens, os ícones, o botão Fechar e os restantes menus.


### V47
Base: V46.

Correção exclusivamente visual no menu Início/Home:
- o botão Fechar do cartão Clientes passa a ocupar a mesma posição horizontal que ocupa no ecrã Clientes;
- é reservado o espaço correspondente ao botão Adicionar, sem o mostrar no Home;
- reforçado o arredondamento dos cantos do cartão Clientes;
- nenhuma outra área foi alterada.


### V51
Base: V48.

Alteração exclusivamente no menu Início/Home: o botão Fechar do cartão Clientes foi alinhado à direita dentro do espaço já reservado. Nenhum outro elemento foi alterado.
