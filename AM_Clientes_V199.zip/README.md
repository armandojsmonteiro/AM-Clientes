AM Clientes V199 — correção da persistência dos Valores de pagamento, separação dos valores de serviços e remoção dos caracteres literais \n\n que apareciam no ecrã.
