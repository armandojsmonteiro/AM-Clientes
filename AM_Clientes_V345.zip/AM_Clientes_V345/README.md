AM Clientes V345 — Android nativo

Versão baseada na V344, com recuperação do desenho do menu Configurações: cartões arredondados com contorno azul, campos claros, pré-visualização e gestão do logótipo, campos da empresa ativa e linhas de opções alinhadas.

Projeto exclusivamente Android. Nome do pacote de entrega: AM_Clientes_V345.zip.

A compilação deve ser validada através do workflow GitHub Actions do projeto.
