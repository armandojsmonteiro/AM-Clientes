AM Clientes V246

Base: V246. Ajuste visual do menu lateral: largura, proporções, cores dos itens e alinhamento superior da aplicação. Sem alteração das funcionalidades.
