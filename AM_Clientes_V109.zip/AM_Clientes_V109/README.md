# AM Clientes V109

Base: V86.

V87 reorganiza a gestão de Serviços e Subscrições: Serviços passam para o módulo Serviços e subscrições, acima das Subscrições, e deixam de aparecer em Configurações e Catálogos. Mantém-se a persistência dos campos personalizados e a associação entre serviços e subscrições.

Android version: 1.0.80 / versionCode 80
