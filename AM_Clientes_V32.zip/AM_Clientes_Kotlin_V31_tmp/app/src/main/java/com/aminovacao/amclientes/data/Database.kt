package com.aminovacao.amclientes.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Database(context: Context) : SQLiteOpenHelper(context, "am_clientes.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE companies (id TEXT PRIMARY KEY, name TEXT NOT NULL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE clients (id TEXT PRIMARY KEY, company_id TEXT NOT NULL, name TEXT NOT NULL, data_json TEXT NOT NULL, FOREIGN KEY(company_id) REFERENCES companies(id))")
        db.execSQL("CREATE TABLE products (id TEXT PRIMARY KEY, company_id TEXT NOT NULL, name TEXT NOT NULL, data_json TEXT NOT NULL, FOREIGN KEY(company_id) REFERENCES companies(id))")
        db.execSQL("CREATE TABLE subscriptions (id TEXT PRIMARY KEY, company_id TEXT NOT NULL, client_id TEXT, data_json TEXT NOT NULL, FOREIGN KEY(company_id) REFERENCES companies(id))")
        db.execSQL("CREATE TABLE quotes (id TEXT PRIMARY KEY, company_id TEXT NOT NULL, data_json TEXT NOT NULL, FOREIGN KEY(company_id) REFERENCES companies(id))")
        db.execSQL("CREATE TABLE settings (id TEXT PRIMARY KEY, company_id TEXT NOT NULL, data_json TEXT NOT NULL, FOREIGN KEY(company_id) REFERENCES companies(id))")
        db.execSQL("CREATE TABLE activity (id TEXT PRIMARY KEY, company_id TEXT NOT NULL, data_json TEXT NOT NULL, created_at INTEGER NOT NULL, FOREIGN KEY(company_id) REFERENCES companies(id))")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { }
}
