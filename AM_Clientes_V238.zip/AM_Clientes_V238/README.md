# AM Clientes V238

Reconstrução Android nativa da aplicação AM Clientes, baseada na V230 funcional.

- Application ID: `com.aminovacao.amclientes231`
- Version Code: `238`
- Version Name: `1.0.238`
- 100% Android nativo; sem HTML/WebView.
- A V230 original permanece separada e não é atualizada por esta aplicação.
- A V59 é usada apenas como referência visual quando necessário.
