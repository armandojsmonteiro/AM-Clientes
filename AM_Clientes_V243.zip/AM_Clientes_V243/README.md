AM Clientes V243

Base: V242. Ajuste visual do menu lateral: largura, proporções, cores dos itens e alinhamento superior da aplicação. Sem alteração das funcionalidades.
