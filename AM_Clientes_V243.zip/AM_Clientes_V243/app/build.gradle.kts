plugins { id("com.android.application") }

android {
    namespace = "com.aminovacao.amclientes231"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aminovacao.amclientes231"
        minSdk = 26
        targetSdk = 34
        versionCode = 242
        versionName = "1.0.242"
    }

    signingConfigs {
        create("stableDebug") {
            storeFile = file("../keystore/am_clientes_test.jks")
            storePassword = "AMClientesTest2026"
            keyAlias = "amclientes"
            keyPassword = "AMClientesTest2026"
        }
    }

    buildTypes {
        getByName("debug") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("stableDebug")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("stableDebug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
