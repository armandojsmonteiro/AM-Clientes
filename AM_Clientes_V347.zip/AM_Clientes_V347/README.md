AM Clientes V347 — Android nativo

V347 corrige o estado fechado do menu Configurações para corresponder à referência: cabeçalhos compactos com 50 dp de conteúdo, cantos arredondados e contorno azul coerente. As secções iniciam recolhidas por defeito; tocar no cabeçalho abre/fecha a secção. Remove os botões + das linhas fechadas, mantendo a adição, edição, eliminação e reordenação dentro das secções.

Projeto exclusivamente Android nativo. O workflow GitHub Actions compila o APK e publica o artefacto AM_Clientes_V347.apk.

A compilação final deve ser validada no GitHub Actions antes de instalar o APK no dispositivo.
